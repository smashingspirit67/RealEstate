({
    doInit: function(component, event, helper) {
        var action = component.get('c.canCreateAccount');
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess){
                var result = response.getReturnValue();
                if(result){
                    var createRecordEvent = $A.get("e.force:createRecord");
                    createRecordEvent.setParams({
                        "entityApiName": "Account"
                    });
                    createRecordEvent.fire();
                }else{
                    component.set('v.showError',true);
                }
            }
        });
        $A.enqueueAction(action);
    }
})