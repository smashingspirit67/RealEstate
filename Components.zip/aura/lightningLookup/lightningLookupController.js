({
    
    keyPressController: function(component, event, helper) {
        
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord");
        // check if getInputKeyWord size id more then 0 then open the lookup result List and 
        // call the helper 
        // else close the lookup result List part.   
        if (getInputkeyWord.length > 0) {
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component, event, helper, getInputkeyWord);
        } else {
            component.set("v.listOfSearchRecords", null);
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        } 
        
    },
    
    // function for clear the Record Selaction 
    clear: function(component, event, heplper) {
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField");
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        
        /*clear fields for collapsible panel*/
        component.set('v.SearchKeyWord','');
        
        /*clear fields for collapsible panel*/
        component.set('v.LegalEntityType', null);		
        component.set('v.StateOfIncorporation', null);
        component.set('v.cep', false);
        if(component.get('v.fieldValue') === 'DBACustomer'){
            component.set('v.averageSalesForDBA', 0.0);
        }
        
        //Do not delete. It's been added for a reason!
        var myEvent = $A.get("e.c:AddressChange");
        var emptyAddress = {};
        if(!$A.util.isUndefinedOrNull(myEvent)){
            myEvent.setParams({
                "billingAddress": emptyAddress,
                "noticeAddress": emptyAddress,
                "fieldValue": component.get('v.fieldValue')
            });
            myEvent.fire();
        }
        
        component.set('v.selectedRecordId',null);
        component.set('v.contactRec', {});
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent: function(component, event, helper) {
        // get the selected Account record from the COMPONETN event 	 
        var selectedAccountGetFromEvent = event.getParam("accountByEvent");
        if (selectedAccountGetFromEvent.Name != 'New Account' && selectedAccountGetFromEvent.Name != 'New Opportunity') {
            component.set("v.selectedRecord", selectedAccountGetFromEvent);
            component.set("v.selectedRecordId", selectedAccountGetFromEvent.Id);
            if (component.get('v.objectName') == 'User' && component.get('v.fieldValue') == 'dealMaker') {
                var act = component.get("c.getDealMakerFields");
                act.setParams({
                    'idDealMaker': String(component.get('v.selectedRecord').Id)
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    //component.set('v.strLeasingDivision', result == null ? '' : result);
                    component.set("v.selectedRecord", result.dealMaker);
                    component.set("v.strLeasingDivision", result.dealMaker.Division);
                });
                $A.enqueueAction(act);
            }
            if (component.get('v.objectName') == 'Opportunity' && component.get('v.fieldValue') == 'ParentOpportunity') {
                var act = component.get("c.getOppDetails");
                act.setParams({
                    'idOpportunity': String(component.get('v.selectedRecord').Id)
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set("v.selectedRecord", result);
                    component.set("v.cep", result.CEPDeal_WF__c);
                });
                $A.enqueueAction(act);
            }
            if (component.get('v.fieldValue') == 'B2BCustomer') {
                var act = component.get("c.getRelatedAccountDetails");
                act.setParams({
                    'strAccountId': component.get('v.selectedRecord').Id
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set('v.B2BCustomerParent', result.accountParent);
                    component.set('v.B2BCustomerSuperParent', result.accountSuperParent);
                    component.set('v.legalEntity', result.legalEntity);
                    component.set('v.dealMaker', result.dealMaker);
                    component.set('v.strLeasingDivision', result.strLeasingDivision);
                });
                $A.enqueueAction(act);
            }
            if (component.get('v.fieldValue') == 'LegalEntity') {
                var act = component.get("c.getRelatedLegalEntityDetails");
                act.setParams({
                    'strlegalEntityId': component.get('v.selectedRecord').Id
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set("v.selectedRecord", result.legalEntity);
                    component.set('v.LegalEntityType', result.legalEntity.CompanyLegalType_WF__c);
                    component.set('v.StateOfIncorporation', result.legalEntity.StateOfIncorporation_WF__c);
                    var myEvent = $A.get("e.c:AddressChange");
                    if(!$A.util.isUndefinedOrNull(myEvent)){
                        console.log('a',myEvent);
                        myEvent.setParams({
                            "billingAddress": result.BillingAddress,
                            "noticeAddress": result.NoticeAddress,
                            "fieldValue": component.get('v.fieldValue')
                        });
                        myEvent.fire();
                    }
                });
                $A.enqueueAction(act);
            }
            if (component.get('v.displayValue') === 'Guarantor') {
                var act = component.get("c.getGurantorDetails");
                act.setParams({
                    'strGuarantorId': component.get('v.selectedRecord').Id,
                    'dbaId': component.get('v.dbaRec').Id
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set('v.StateOfIncorporation', result.stateOfFormation);
                    component.set('v.contactRec', result.guarantorContact);
                    component.set('v.LegalEntityType', result.guarantorRel.TypeofGuarantee_WF__c);
                    //component.set('v.guarantorId', result.guarantorRel.Id);
                });
                $A.enqueueAction(act);
            }
            if(component.get('v.fieldValue') === 'DBACustomer'){
                var act = component.get("c.getUseClause");
                act.setParams({
                    'accId': component.get('v.selectedRecord').Id
                });
                act.setCallback(this, function(a){
                    var result = a.getReturnValue();
                    component.set('v.useClause', result.useClause);
                    component.set('v.averageSalesForDBA', result.AvergageSalesForDBA);
                });
                $A.enqueueAction(act);
            }
            if(component.get('v.fieldValue') === 'SuperParent' || component.get('v.fieldValue') === 'Parent'){
                var act = component.get("c.getNonDBA");
                act.setParams({
                    'accId': component.get('v.selectedRecord').Id
                });
                act.setStorable();
                act.setCallback(this, function(a){
                    var result = a.getReturnValue();
                    component.set('v.isNonDBA', result);
                });
                $A.enqueueAction(act);
            }
            var forclose = component.find("lookup-pill");
            $A.util.addClass(forclose, 'slds-show');
            $A.util.removeClass(forclose, 'slds-hide');
            
            var forcloseRes = component.find("searchRes");
            $A.util.addClass(forcloseRes, 'slds-is-close');
            $A.util.removeClass(forcloseRes, 'slds-is-open');
            
            var lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');
        } 
        else if(selectedAccountGetFromEvent.Name == 'New Opportunity'){
            component.set("v.SearchKeyWord", null);
            component.set("v.showPopupOpp", true);
            component.set("v.SearchKeyWord", null);
            component.set("v.listOfSearchRecords", null);
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
            console.log(component.get('v.centerName'));
        }
        else {
            component.set("v.SearchKeyWord", null);
            component.set("v.showPopup", true);
            console.log('popup',component.get("v.showPopup"));
            component.set("v.SearchKeyWord", null);
            component.set("v.listOfSearchRecords", null);
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    }, 
    recordChange: function(component, event, helper){
        if(!$A.util.isEmpty(component.get('v.selectedRecord'))&&!$A.util.isEmpty(component.get('v.selectedRecord').Name)){
            var forclose = component.find("lookup-pill");
            $A.util.addClass(forclose, 'slds-show');
            $A.util.removeClass(forclose, 'slds-hide');
            
            var forcloseRes = component.find("searchRes");
            $A.util.addClass(forcloseRes, 'slds-is-close');
            $A.util.removeClass(forcloseRes, 'slds-is-open');
            
            var lookUpTarget = component.find("lookupField");
            $A.util.removeClass(lookUpTarget, 'slds-show');
            $A.util.addClass(lookUpTarget, 'slds-hide');
        }
    }
})