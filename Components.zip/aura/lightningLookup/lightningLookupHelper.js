({
	searchHelper : function(component, event, helper, getInputkeyWord) {
	  // call the apex class method 
     var action = component.get("c.fetchAccount");
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'objectName' : component.get("v.objectName"),
            'createNew' : component.get("v.createNew"),
            'fieldValue' : component.get("v.fieldValue")
        });
      // set a callBack    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
              // if storeResponse size is equal 0 ,display No Result Found... message on screen.
                if (storeResponse.length == 1
                   && storeResponse[0].Name=="New Account"
                   && component.get('v.showNewOption')==true) {
                    component.set("v.Message", 'No Result Found...');
                    console.log('case 1');
                } else if(storeResponse.length == 1 
                          && storeResponse[0].Name=="New Account" 
                          && component.get('v.showNewOption')==false){
                    /*if we weren't meant to show the options, then do nothing and display nothing*/
                    component.set("v.Message", '');
                    component.set("v.listOfSearchRecords", null);
            		var forclose = component.find("searchRes");
            		$A.util.addClass(forclose, 'slds-is-close');
            		$A.util.removeClass(forclose, 'slds-is-open');
                    helper.hideSpinner(component, event, helper);
                    return; 
                }else if(storeResponse.length >= 1 
                         && storeResponse[0].Name!="New Account"){
                    component.set("v.Message", 'Search Result...');
                }else if(storeResponse.length === 0){
                    component.set("v.listOfSearchRecords", null);
                    component.set("v.Message", 'No Result Found...');
                } else {
                    /*error has occurred, or the return value has been modified in the apex controller*/
                    helper.hideSpinner(component, event, helper);
                    return; 
                }
                helper.hideSpinner(component, event, helper);
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
        });
      // enqueue the Action 
        helper.showSpinner(component, event, helper); 
        $A.enqueueAction(action);
	},
    hideSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({
        	isVisible: false
        });
        evt.fire();
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
		var evt = spinner.get("e.toggle");
		evt.setParams({
			isVisible: true
		});
		evt.fire();
    }, 
})