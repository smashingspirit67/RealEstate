({
    setPicklistValues : function(component){
        var result = component.get('v.result');
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    },
    changeBuildOut : function(component,event,helper){
        component.set('v.Construction.BuildOut_WF__c','');
        component.set('v.TTPriorWorkCommentsError',false);
        component.set('v.TTWorkCommentsError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cBuildOut_WF__c'))){            
            component.find('Construction_WF__cBuildOut_WF__c').reInit();
        }       
        component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
            component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
        }  
        component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
            component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
        }  
        component.set('v.Construction.MinimumSpendRequired_WF__c',false);
        helper.helperChangeMinimumSpendReq(component,event);
        helper.helperChangeWorkRequiredRCD(component,event);
        helper.helperChangeWorkRequiredMidTerm(component,event);
        var constructionEvent = $A.get("e.c:changeConstructionEvent");
        if(!$A.util.isUndefinedOrNull(constructionEvent)){            
            constructionEvent.fire();
        } 
    },
    changeBuildOutPick : function(component,event,helper){
        if(component.get('v.Construction.BuildOut_WF__c')=='No Work Required' || component.get('v.Construction.BuildOut_WF__c')==''){
            component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
            
            component.set('v.TTPriorWorkCommentsError',false);
        	component.set('v.TTWorkCommentsError',false);
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
            }  
            component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
            }  
            component.set('v.Construction.MinimumSpendRequired_WF__c',false);
            helper.helperChangeMinimumSpendReq(component,event);
            helper.helperChangeWorkRequiredRCD(component,event);
            helper.helperChangeWorkRequiredMidTerm(component,event);
        }
        if(component.get('v.Construction.BuildOut_WF__c')=='Prior To RCD'){
            
			component.set('v.TTWorkCommentsError',false);
            component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
            }  
            helper.helperChangeWorkRequiredMidTerm(component,event);
        }
		if(component.get('v.Construction.BuildOut_WF__c')=='Mid-Term Remodel'){
            component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
            component.set('v.TTPriorWorkCommentsError',false);
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
            }  
            helper.helperChangeWorkRequiredRCD(component,event);
        }
    },
    changeWorkRequiredRCD : function(component,event,helper){
        helper.helperChangeWorkRequiredRCD(component,event);
    },
    changeWorkRequiredMidTerm : function(component,event,helper){
        helper.helperChangeWorkRequiredMidTerm(component,event);
    },
    changeMinimumSpendReq : function(component,event,helper){
        helper.helperChangeMinimumSpendReq(component,event);
    },
    changeIndemnityNeeded : function(component,event,helper){
        helper.helperChangeIndemnityNeeded(component,event);
    }
})