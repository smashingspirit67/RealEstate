({
	helperChangeWorkRequiredRCD : function(component,event) {
		if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')=='Full'){
            component.set('v.Construction.StoreFront_WF__c','New');
            component.set('v.Construction.Signage_WF__c','New Sign');
            component.set('v.Construction.Floors_WF__c','New');
            component.set('v.Construction.Fixtures_WF__c','New');
            component.set('v.Construction.Ceiling_WF__c','New');
            component.set('v.Construction.Lighting_WF__c','New');
            component.set('v.Construction.HVAC_WF__c','New');
            component.find("Construction_WF__cStoreFront_WF__c").reInit();
            component.find("Construction_WF__cSignage_WF__c").reInit();
            component.find("Construction_WF__cFloors_WF__c").reInit();
            component.find("Construction_WF__cFixtures_WF__c").reInit();
            component.find("Construction_WF__cCeiling_WF__c").reInit();
            component.find("Construction_WF__cLighting_WF__c").reInit();
            component.find("Construction_WF__cHVAC_WF__c").reInit();
        }
        console.log('b');
        if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')=='Partial'|| component.get('v.Construction.PriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.StoreFront_WF__c','');
            component.set('v.Construction.Signage_WF__c','');
            component.set('v.Construction.Floors_WF__c','');
            component.set('v.Construction.Fixtures_WF__c','');
            component.set('v.Construction.Ceiling_WF__c','');
            component.set('v.Construction.Lighting_WF__c','');
            component.set('v.Construction.HVAC_WF__c','');
            component.find("Construction_WF__cStoreFront_WF__c").reInit();
            component.find("Construction_WF__cSignage_WF__c").reInit();
            component.find("Construction_WF__cFloors_WF__c").reInit();
            component.find("Construction_WF__cFixtures_WF__c").reInit();
            component.find("Construction_WF__cCeiling_WF__c").reInit();
            component.find("Construction_WF__cLighting_WF__c").reInit();
            component.find("Construction_WF__cHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.TTWorkComments_WF__c','');
            component.set('v.Construction.IndemnityRequired_WF__c',false);
            //component.set('v.Construction.IndemnityAmt_WF__c',0);
        }
	},
    helperChangeWorkRequiredMidTerm : function(component,event) {
		if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='Full'){
            component.set('v.Construction.MidTermStoreFront_WF__c','New');
            component.set('v.Construction.MidTermSignage_WF__c','New Sign');
            component.set('v.Construction.MidTermFloors_WF__c','New');
            component.set('v.Construction.MidTermFixtures_WF__c','New');
            component.set('v.Construction.MidTermCeiling_WF__c','New');
            component.set('v.Construction.MidTermLighting_WF__c','New');
            component.set('v.Construction.MidTermHVAC_WF__c','New');
            component.set('v.TTWorkCommentsError',false);
            component.find("Construction_WF__cMidTermStoreFront_WF__c").reInit();
            component.find("Construction_WF__cMidTermSignage_WF__c").reInit();
            component.find("Construction_WF__cMidTermFloors_WF__c").reInit();
            component.find("Construction_WF__cMidTermFixtures_WF__c").reInit();
            component.find("Construction_WF__cMidTermCeiling_WF__c").reInit();
            component.find("Construction_WF__cMidTermLighting_WF__c").reInit();
            component.find("Construction_WF__cMidTermHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='Partial' || component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.MidTermStoreFront_WF__c','');
            component.set('v.Construction.MidTermSignage_WF__c','');
            component.set('v.Construction.MidTermFloors_WF__c','');
            component.set('v.Construction.MidTermFixtures_WF__c','');
            component.set('v.Construction.MidTermCeiling_WF__c','');
            component.set('v.Construction.MidTermLighting_WF__c','');
            component.set('v.Construction.MidTermHVAC_WF__c','');
            component.set('v.TTWorkCommentsError',false);
            component.find("Construction_WF__cMidTermStoreFront_WF__c").reInit();
            component.find("Construction_WF__cMidTermSignage_WF__c").reInit();
            component.find("Construction_WF__cMidTermFloors_WF__c").reInit();
            component.find("Construction_WF__cMidTermFixtures_WF__c").reInit();
            component.find("Construction_WF__cMidTermCeiling_WF__c").reInit();
            component.find("Construction_WF__cMidTermLighting_WF__c").reInit();
            component.find("Construction_WF__cMidTermHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.MidTermTTWorkComments_WF__c','');
            component.set('v.Construction.RemodelDueDate_WF__c',null);
        }
	},
    helperChangeMinimumSpendReq : function(component,event){
        component.set('v.Construction.MinimumSpendAmount_WF__c',0);
    },
    helperChangeIndemnityNeeded : function(component,event){
        component.set('v.Construction.IndemnityAmt_WF__c',0);
    }
})