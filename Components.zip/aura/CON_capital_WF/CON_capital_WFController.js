({
    init : function(component,event,helper){
        helper.helperChangeTenantAllowance(component,event);
        var otherLandlordCost = isNaN(parseFloat(component.find('otherLandlordCost').get('v.value'))) ? 0 : parseFloat(component.find('otherLandlordCost').get('v.value'));
        if(otherLandlordCost==0){
            component.set('v.Other',false);
        }else{
            component.set('v.Other',true);
        }
        helper.setPicklistValues(component,component.get('v.result'));       
    },
    changeUnit : function(component,event,helper){
        var psf = component.get('v.Construction.TARate_WF__c');
        console.log('sssCapital',component.get('v.GLA'));
        var GLA = isNaN(parseFloat(component.get('v.GLA'))) ? 1 : parseFloat(component.get('v.GLA'));
        if(GLA==0){
            GLA = 1;
        }
        var total = psf * GLA;
        component.set('v.Construction.TenantAllowance_WF__c',total);
        var totalTA = component.get('v.Construction.TenantAllowance_WF__c');
        console.log(total);
        if(!$A.util.isUndefinedOrNull(component.find('brokerCom'))){
            var brokerCom = isNaN(parseFloat(component.find('brokerCom').get('v.value'))) ? 0 : parseFloat(component.find('brokerCom').get('v.value'));
        }else{
            var brokerCom = 0;
        }
        console.log(brokerCom);
        var landlordWorkEst = isNaN(parseFloat(component.find('landlordWorkEst').get('v.value'))) ? 0 : parseFloat(component.find('landlordWorkEst').get('v.value'));
        console.log(landlordWorkEst,component.find('landlordWorkEst').get('v.value'));
        var TenantBuyout = isNaN(parseFloat(component.find('TenantBuyout').get('v.value'))) ? 0 : parseFloat(component.find('TenantBuyout').get('v.value'));
        console.log(TenantBuyout);
        var otherLandlordCost = isNaN(parseFloat(component.find('otherLandlordCost').get('v.value'))) ? 0 : parseFloat(component.find('otherLandlordCost').get('v.value'));
        console.log(otherLandlordCost,component.find('otherLandlordCost').get('v.value'));
        var total = totalTA + brokerCom + landlordWorkEst + TenantBuyout + otherLandlordCost;
        var totalPSF = total/GLA;
        
        
        component.find('CapitalTotal').set('v.value',total.toFixed(2));
        
        component.find('CapitalPSF').set('v.value',totalPSF.toFixed(2));
        //helper.helperUpdateTenantAllowance(component,event);
    },
    updateTenantAllowance : function(component,event,helper){
        helper.helperUpdateTenantAllowance(component,event);
    },
    changeCapital : function(component,event,helper){
        var TARateTotal;
        var TARatePSF;
        var GLA = isNaN(parseFloat(component.get('v.GLA'))) ? 1 : parseFloat(component.get('v.GLA'));
        if(event.getSource().get('v.name')=='TARateTotal'){
            TARateTotal = isNaN(parseFloat(component.find('TARateTotal').get('v.value'))) ? 0 : parseFloat(component.find('TARateTotal').get('v.value'));
            component.find('TARatePSF').set('v.value',(TARateTotal/GLA).toFixed(2));
        }else if(event.getSource().get('v.name')=='TARatePSF'){
            TARatePSF = isNaN(parseFloat(component.find('TARatePSF').get('v.value'))) ? 0 : parseFloat(component.find('TARatePSF').get('v.value'));
            component.find('TARateTotal').set('v.value',(TARatePSF*GLA).toFixed(2));
            TARateTotal = TARatePSF*GLA;
        }else{
            TARateTotal = isNaN(parseFloat(component.find('TARateTotal').get('v.value'))) ? 0 : parseFloat(component.find('TARateTotal').get('v.value'));
        }
       // console.log('TARateTotal',TARateTotal);
        if(!$A.util.isUndefinedOrNull(component.find('brokerCom'))){
        	var brokerCom = isNaN(parseFloat(component.find('brokerCom').get('v.value'))) ? 0 : parseFloat(component.find('brokerCom').get('v.value'));
        }else{
            var brokerCom =0;
        }
       // console.log(brokerCom);
        var landlordWorkEst = isNaN(parseFloat(component.find('landlordWorkEst').get('v.value'))) ? 0 : parseFloat(component.find('landlordWorkEst').get('v.value'));
       // console.log(landlordWorkEst);
        var TenantBuyout = isNaN(parseFloat(component.find('TenantBuyout').get('v.value'))) ? 0 : parseFloat(component.find('TenantBuyout').get('v.value'));
      //  console.log(TenantBuyout);
        var otherLandlordCost = isNaN(parseFloat(component.find('otherLandlordCost').get('v.value'))) ? 0 : parseFloat(component.find('otherLandlordCost').get('v.value'));
        if(otherLandlordCost==0){
            component.set('v.Other',false);
        }else{
            component.set('v.Other',true);
        }
        var total = TARateTotal + brokerCom + landlordWorkEst + TenantBuyout + otherLandlordCost;
        var totalPSF = total/GLA;
        //console.log(total);
        component.find('CapitalTotal').set('v.value',total.toFixed(2));
        
        component.find('CapitalPSF').set('v.value',totalPSF.toFixed(2));

   		helper.helperChangeTenantAllowance(component,event);
        
        var constructionEvent = $A.get("e.c:changeScopeOfWork");
        if(!$A.util.isUndefinedOrNull(constructionEvent)){
            constructionEvent.fire();
        }
    },
    percentStabilize : function(component,event,helper){
    	var value = event.getSource().get('v.value');
        console.log('value',value);
        event.getSource().set('v.value',value/100);
    },
    validateForNegativeValues : function(component,event,helper){
        
        var type = component.get('v.Construction.TAPaymentSchedule_WF__c');
        
        var taPayPer1 = component.get('v.Construction.TAPaymentPercent1_WF__c');
        var taPayPer2 = component.get('v.Construction.TAPaymentPercent2_WF__c');
        var taPayPer3 = component.get('v.Construction.TAPaymentPercent3_WF__c');
        var taPayPer4 = component.get('v.Construction.TAPaymentPercent4_WF__c');
        var taPayPer5 = component.get('v.Construction.TAPaymentPercent5_WF__c');
        
        var taPayAmt1 = component.get('v.Construction.TAPaymentAmount1_WF__c');
        var taPayAmt2 = component.get('v.Construction.TAPaymentAmount2_WF__c');
        var taPayAmt3 = component.get('v.Construction.TAPaymentAmount3_WF__c');
        var taPayAmt4 = component.get('v.Construction.TAPaymentAmount4_WF__c');
        var taPayAmt5 = component.get('v.Construction.TAPaymentAmount5_WF__c');
        
        var taPayOpt1Percent = component.get('v.Construction.TAPaymentOpions1PerofCons_WF__c');
        var taPayOpt2Percent = component.get('v.Construction.TAPaymentOpions2PerofCons_WF__c');
        var taPayOpt3Percent = component.get('v.Construction.TAPaymentOpions3PerofCons_WF__c');
        var taPayOpt4Percent = component.get('v.Construction.TAPaymentOpions4PerofCons_WF__c');
        var taPayOpt5Percent = component.get('v.Construction.TAPaymentOpions5PerofCons_WF__c');
        
        if(type=='90/10'){
            if(taPayOpt1Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther901Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther901Err"), 'slds-hide');
            
            if(taPayOpt2Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther902Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther902Err"), 'slds-hide');
        }
        else if(type=='50/50'){
            if(taPayOpt1Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther501Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther501Err"), 'slds-hide');
            
            if(taPayOpt2Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther502Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther502Err"), 'slds-hide');           
        }
        else if(type=='Thirds'){
            if(taPayOpt1Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther331Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther331Err"), 'slds-hide');
            
            if(taPayOpt2Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther332Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther332Err"), 'slds-hide');
            
            if(taPayOpt3Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther333Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther333Err"), 'slds-hide');
        }
        else if(type=='Other'){
            //Payment amount Errors
            if(taPayAmt1<0)
                $A.util.removeClass(component.find("TAPaymentAmt1Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentAmt1Err"), 'slds-hide');
            
            if(taPayAmt2<0)
                $A.util.removeClass(component.find("TAPaymentAmt2Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentAmt2Err"), 'slds-hide');
            
            if(taPayAmt3<0)
                $A.util.removeClass(component.find("TAPaymentAmt3Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentAmt3Err"), 'slds-hide');
            
            if(taPayAmt4<0 )
                $A.util.removeClass(component.find("TAPaymentAmt4Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentAmt4Err"), 'slds-hide');
            
            if(taPayAmt5<0 )
                $A.util.removeClass(component.find("TAPaymentAmt5Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentAmt5Err"), 'slds-hide');
            
            //Payment Percentage Errors
            if(taPayPer1<0)
                $A.util.removeClass(component.find("TAPaymentPer1Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPer1Err"), 'slds-hide');
            
            if(taPayPer1!= '' && taPayAmt2 != null && taPayPer2<0 )
                $A.util.removeClass(component.find("TAPaymentPer2Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPer2Err"), 'slds-hide');
            
            if(taPayAmt3!= '' && taPayAmt3 != null && taPayPer3<0 )
                $A.util.removeClass(component.find("TAPaymentPer3Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPer3Err"), 'slds-hide');
            
            if(taPayAmt4!= '' && taPayAmt4 != null && taPayPer4<0 )
                $A.util.removeClass(component.find("TAPaymentPer4Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPer4Err"), 'slds-hide');
            
            if(taPayAmt5!= '' && taPayAmt5 != null && taPayPer5<0 )
                $A.util.removeClass(component.find("TAPaymentPer5Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPer5Err"), 'slds-hide');
            
            
            //Payment amount Percent Errors
            if(taPayOpt1Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther1Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther1Err"), 'slds-hide');
            
            if(taPayOpt2Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther2Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther2Err"), 'slds-hide');
            
            if(taPayOpt3Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther3Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther3Err"), 'slds-hide');
            
            if(taPayOpt4Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther4Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther4Err"), 'slds-hide');
            
            if(taPayOpt5Percent<0 )
                $A.util.removeClass(component.find("TAPaymentPerOther5Err"), 'slds-hide');
            else
                $A.util.addClass(component.find("TAPaymentPerOther5Err"), 'slds-hide');
        }
    },
    changeTAPaymentSchdule : function(component,event,helper){
        component.set('v.Construction.TAPaymentPercent1_WF__c',0);
        component.set('v.Construction.TAPaymentPercent2_WF__c',0);
        component.set('v.Construction.TAPaymentPercent3_WF__c',0);
        component.set('v.Construction.TAPaymentPercent4_WF__c',0);
        component.set('v.Construction.TAPaymentPercent5_WF__c',0);
        component.set('v.Construction.TAPaymentAmount1_WF__c',0);
        component.set('v.Construction.TAPaymentAmount2_WF__c',0);
        component.set('v.Construction.TAPaymentAmount3_WF__c',0);
        component.set('v.Construction.TAPaymentAmount4_WF__c',0);
        component.set('v.Construction.TAPaymentAmount5_WF__c',0);
        component.set('v.Construction.TAPaymentOpions1PerofCons_WF__c',0);
        component.set('v.Construction.TAPaymentOpions2PerofCons_WF__c',0);
        component.set('v.Construction.TAPaymentOpions3PerofCons_WF__c',0);
        component.set('v.Construction.TAPaymentOpions4PerofCons_WF__c',0);
        component.set('v.Construction.TAPaymentOpions5PerofCons_WF__c',0);
        component.set('v.Construction.TAPaymentOptions1Other_WF__c','');
        component.set('v.Construction.TAPaymentOptions2Other_WF__c','');
        component.set('v.Construction.TAPaymentOptions3Other_WF__c','');
        component.set('v.Construction.TAPaymentOptions4Other_WF__c','');
        component.set('v.Construction.TAPaymentOptions5Other_WF__c','');
        component.set('v.Construction.TAPaymentOptions1_WF__c','');
        component.set('v.Construction.TAPaymentOptions2_WF__c','');
        component.set('v.Construction.TAPaymentOptions3_WF__c','');
        component.set('v.Construction.TAPaymentOptions4_WF__c','');
        component.set('v.Construction.TAPaymentOptions5_WF__c','');
        component.set('v.Construction.TAProgressPaymentOtherType_WF__c','$');
        helper.helperChangeTenantAllowance(component,event);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cTAProgressPaymentOtherType_WF__c'))){            
            component.find('Construction_WF__cTAProgressPaymentOtherType_WF__c').reInit();
        }
    },
    changePaymentOtherType : function(component,event,helper){
        component.set('v.Construction.TAPaymentPercent1_WF__c',0);
        component.set('v.Construction.TAPaymentPercent2_WF__c',0);
        component.set('v.Construction.TAPaymentPercent3_WF__c',0);
        component.set('v.Construction.TAPaymentPercent4_WF__c',0);
        component.set('v.Construction.TAPaymentPercent5_WF__c',0);
        component.set('v.Construction.TAPaymentAmount1_WF__c',0);
        component.set('v.Construction.TAPaymentAmount2_WF__c',0);
        component.set('v.Construction.TAPaymentAmount3_WF__c',0);
        component.set('v.Construction.TAPaymentAmount4_WF__c',0);
        component.set('v.Construction.TAPaymentAmount5_WF__c',0);
    }
})