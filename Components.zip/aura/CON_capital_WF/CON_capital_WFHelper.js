({
	helperChangeTenantAllowance : function(component,event) {
		var value = component.get('v.Construction.TenantAllowance_WF__c');
        component.find('nintyPercent').set('v.value',(value*0.90).toFixed(2));
        component.find('tenPercent').set('v.value',(value*0.10).toFixed(2));
        component.find('fiftyPercent1').set('v.value',(value*0.50).toFixed(2));
        component.find('fiftyPercent').set('v.value',(value*0.50).toFixed(2));
        component.find('tirtyPercent').set('v.value',(value/3).toFixed(2));
        component.find('tirtyPercent1').set('v.value',(value/3).toFixed(2));
        component.find('tirtyPercent2').set('v.value',(value/3).toFixed(2));
        if(component.get('v.Construction.TAPaymentSchedule_WF__c')=='90/10'){
            component.set('v.Construction.TAPaymentAmount1_WF__c',(value*0.90).toFixed(2));
            component.set('v.Construction.TAPaymentAmount2_WF__c',(value*0.10).toFixed(2));
            component.set('v.Construction.TAPaymentAmount3_WF__c',0);
        }
        if(component.get('v.Construction.TAPaymentSchedule_WF__c')=='50/50'){
            component.set('v.Construction.TAPaymentAmount1_WF__c',(value*0.50).toFixed(2));
            component.set('v.Construction.TAPaymentAmount2_WF__c',(value*0.50).toFixed(2));
            component.set('v.Construction.TAPaymentAmount3_WF__c',0);
        }
        if(component.get('v.Construction.TAPaymentSchedule_WF__c')=='Thirds'){
            component.set('v.Construction.TAPaymentAmount1_WF__c',(value/3).toFixed(2));
            component.set('v.Construction.TAPaymentAmount2_WF__c',(value/3).toFixed(2));
            component.set('v.Construction.TAPaymentAmount3_WF__c',(value/3).toFixed(2));
        }     
	},
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
        //Joshna - 3rd oct 2017 - added below line to fix a training issue
        var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
        if(fetchPickListTable !== undefined){
            fetchPickListTable.fire();
        }
    },
    helperUpdateTenantAllowance : function(component,event) {
        var GLA = isNaN(parseFloat(component.get('v.GLA'))) ? 1 : parseFloat(component.get('v.GLA'));
        if(GLA==0){
            GLA = 1;
        }
        var totalTA = component.get('v.Construction.TAPaymentAmount1_WF__c')+
            		component.get('v.Construction.TAPaymentAmount2_WF__c')+
                    component.get('v.Construction.TAPaymentAmount3_WF__c')+
                    component.get('v.Construction.TAPaymentAmount4_WF__c')+
                    component.get('v.Construction.TAPaymentAmount5_WF__c');
        component.find('TARateTotal').set('v.value',totalTA);
        component.find('TARatePSF').set('v.value',(totalTA/GLA).toFixed(2));
        
        var brokerCom = isNaN(parseFloat(component.find('brokerCom').get('v.value'))) ? 0 : parseFloat(component.find('brokerCom').get('v.value'));
        //console.log(brokerCom);
        var landlordWorkEst = isNaN(parseFloat(component.find('landlordWorkEst').get('v.value'))) ? 0 : parseFloat(component.find('landlordWorkEst').get('v.value'));
        //console.log(landlordWorkEst,component.find('landlordWorkEst').get('v.value'));
        var TenantBuyout = isNaN(parseFloat(component.find('TenantBuyout').get('v.value'))) ? 0 : parseFloat(component.find('TenantBuyout').get('v.value'));
        //console.log(TenantBuyout);
        var otherLandlordCost = isNaN(parseFloat(component.find('otherLandlordCost').get('v.value'))) ? 0 : parseFloat(component.find('otherLandlordCost').get('v.value'));
        console.log(otherLandlordCost,component.find('otherLandlordCost').get('v.value'));
        var total = totalTA + brokerCom + landlordWorkEst + TenantBuyout + otherLandlordCost;
        var totalPSF = total/GLA;
        
        component.find('CapitalTotal').set('v.value','$'+total.toFixed(2));
        
        component.find('CapitalPSF').set('v.value','$'+totalPSF.toFixed(2));
    }
})