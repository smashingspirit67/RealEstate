({
    //function to initiaise the opportunity field values
	doInit : function(component, event, helper) {
        var action = component.get('c.getRelatedOpportunityDetails');
        var idOpportunity = component.get('v.idOpportunity');
        action.setParams({"strOpportunityId" : idOpportunity});
        action.setCallback(this, function(response){
        	var isSuccess = response.getState();
            if(isSuccess){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.opportunity',result);
                    console.log('result',result);
                    if(!$A.util.isUndefinedOrNull(component.find('coDetails'))){ 
                    	component.find('coDetails').reInit(); 
                    }
                    var fetchPickList = $A.get("e.c:fetchPicklist");
                    if(!$A.util.isUndefinedOrNull(fetchPickList)){ 
                    	fetchPickList.fire(); 
                    }
                    helper.getIsRecApprover(component);
                }
            }
        });
       $A.enqueueAction(action);
	},
    //Function to perform opportunity save
    handleSave : function(component, event,helper){
        //set boolean value to true to disable save button
        component.set('v.BoolSaveDisable',true);
        var opportunity = component.get('v.opportunity'); 
        var action = component.get('c.saveOpportunity');
        var onHoldCheck = helper.validateOnHoldReason(component);
        console.log('+++onHoldCheck++'+onHoldCheck,' +++check++',(onHoldCheck == false));
        
        if(onHoldCheck == false){
        action.setParams({
            strOpportunity : JSON.stringify(opportunity)
        }); 
        action.setCallback(this, function(response){
			var isSuccess = response.getState();            
            if(isSuccess){
                if( (typeof sforce != 'undefined') && (sforce != null) ) {                    		
                    sforce.one.navigateToSObject(opportunity.Id); 
                }
                /* back up if - sforce.one.navigateToSObject(recordId) code fails */
                else{                    		
                    var urlOpptyDetailPage = "/one/one.app#/sObject/"+opportunity.Id+"/view";
                    window.open(urlOpptyDetailPage,"_self");
                }
            }
        });
        $A.enqueueAction(action);
        } else {
            component.set('v.oppOnHoldValidation',true);
            component.set('v.error',true);
        }   
    },
    //function to redirect to opportunity page on cancel
    handleCancel : function(cmp,eve){
        if( (typeof sforce != 'undefined') && (sforce != null) ) {                    		                        
            sforce.one.navigateToSObject(cmp.get('v.idOpportunity')); 
        }
        /*back up if - sforce.one.navigateToSObject(recordId) code fails */
        else{                    		
            var urlOpptyDetailPage = "/one/one.app#/sObject/"+cmp.get('v.idOpportunity')+"/view";
            window.open(urlOpptyDetailPage,"_self");
        }
    }
})