({
	helperMethod : function() {
		
	},
    validateOnHoldReason : function(component){
        var holdChk = false;
        var onHoldCheck = component.get('v.opportunity.On_Hold_WF__c');
        var onHoldReason = component.get('v.opportunity.HoldReason_WF__c');
        console.log('++onHoldCheck++',onHoldCheck,'++onHoldReason+++',onHoldReason);
        if( onHoldCheck && (onHoldReason == '' || onHoldReason == 'undefined')){
            holdChk = true;
        }else{
            holdChk = false;
	}
        return holdChk;
	},
	
	getIsRecApprover : function(component) {
		var action = component.get('c.checkIsRecApprover');
        var opportunity = component.get('v.opportunity');
        action.setParams({
            strOpportunity : JSON.stringify(opportunity)
        });
        action.setCallback(this, function(response){
        	var isSuccess = response.getState();
            if(isSuccess){
                component.set('v.isRecApprover',response.getReturnValue());
            }
        });
       $A.enqueueAction(action);
	}
})