({
	doInit : function(component, event, helper) {
        helper.setPicklistValues(component,component.get('v.result'));
        var num = component.get('v.opportunity.Leasing_Revenue_Var_to_Prior__c');
        num = Math.round(num * 100)/100; 
        var leasingRevVar = num + '%';
        component.set('v.leasingRevVar', leasingRevVar);
        
        //GDM-8388 - START
        var arrLease = [];
        arrLease = component.get('v.lease');
        
        if(arrLease.length){
            for(var i=0; i<arrLease.length; i++){
                var minRentPSF = 0;
                if(!$A.util.isUndefinedOrNull(arrLease[i].MRAmount_WF__c))
                	minRentPSF = arrLease[i].GLAUsed_WF__c != 0 ? (arrLease[i].MRAmount_WF__c/arrLease[i].GLAUsed_WF__c) : 0;
                
                var occupancyCost = 0;
                if(!$A.util.isUndefinedOrNull(arrLease[i].MRAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].MRAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].Percentage_Rent_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].Percentage_Rent_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].In_Lieu_of_Rent_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].In_Lieu_of_Rent_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].CAMAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].CAMAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].FoodCourtCAMAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].FoodCourtCAMAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].IndexRentAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].IndexRentAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].PromoAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].PromoAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].EnclosedMallHVACAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].EnclosedMallHVACAmount_WF__c;
                if(!$A.util.isUndefinedOrNull(arrLease[i].TaxesAmount_WF__c))
                    occupancyCost = occupancyCost + arrLease[i].TaxesAmount_WF__c;
                
                arrLease[i].Minimum_Rent_PSF_WF__c = minRentPSF;
                arrLease[i].Occupancy_Cost_RO_WF__c = occupancyCost;
            }    
        }
        
        if(!$A.util.isUndefinedOrNull(arrLease)){
            if(arrLease.length > 0){
                component.set('v.lease', arrLease);         
            }
        }        
        //GDM-8388 - END
	},
     validateRestrictionTimePeriod : function(component)
    {
         var result =component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.RestrictionTimePeriod_WF__c')) && component.get('v.opportunity.RestrictionTimePeriod_WF__c')!='' && component.get('v.opportunity.RestrictionTimePeriod_WF__c')!=null
          && component.get('v.opportunity.RestrictionTimePeriod_WF__c').length > covenantTextFieldMap['RestrictionTimePeriod_WF__c'])
        {
            component.set('v.error',true);
            component.set('v.restrictionTimePeriodError',true);
            
        }else
        {
            component.set('v.error',false);
            component.set('v.restrictionTimePeriodError',false);
        }
    }
})