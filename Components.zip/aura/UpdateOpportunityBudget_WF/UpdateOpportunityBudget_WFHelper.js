({
	doInit : function(component, event, helper) {
		helper.loadOpportunityBudget(component);
	},
	
	refreshBudgetData : function(component, event, helper) {
		var action = component.get("c.refreshOpportunityBudgetFromProducts");
		action.setParams({
			"strOppBudget" : JSON.stringify(component.get("v.opportunityBudget"))
		});
		action.setCallback(this, function(response){
			var result = response.getReturnValue();  
			
			setTimeout(function(){ 
				if(result && response.getState() == "SUCCESS" && component.isValid()){
					if (result == $A.get("$Label.c.Opp_Budget_Refresh_Success")) {
						//success scenario
						component.set("v.themeClass", "slds-theme_success");
						$A.get("e.force:refreshView").fire();
					} 
				}
				
				component.set("v.message", result);
				component.set("v.display", 0);
				
				var yesButton = component.find("yes");
				var noButton = component.find("no");
				$A.util.toggleClass(yesButton, "slds-hidden");	
				noButton.set("v.label", "Ok");
			}
			, 4000);
		});
		$A.enqueueAction(action);
		component.set("v.display", 1);
	},
	
	loadOpportunityBudget : function(component) {
		var action = component.get("c.loadOpportunityBudget");
		action.setParams({
			"id" : component.get("v.recordId")
		});
		action.setCallback(this, function(response){
			var result = response.getReturnValue();  
			if(result && response.getState() == "SUCCESS" && component.isValid()){
				component.set("v.opportunityBudget",result);
				component.find("yes").set("v.disabled", false);
			}
		});
		$A.enqueueAction(action);
	}
})