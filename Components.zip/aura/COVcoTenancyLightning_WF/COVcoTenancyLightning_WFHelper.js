({
    clearOperatingCoTenancy : function(component,event){
        var operatingCoTenancy = {};
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Operating'){
                operatingCoTenancy = lstCoTenants[item];
            }
        }
        operatingCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        operatingCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        operatingCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        operatingCoTenancy.SalesTest_WF__c=0;
        operatingCoTenancy.DefinitionofDeptStoresf_WF__c = '';
        operatingCoTenancy.DepartmentStores_WF__c = false;  
        operatingCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        operatingCoTenancy.NoofDeptStoresRequired_WF__c=0;
        operatingCoTenancy.SizeofDepartmentStore_WF__c=0;
        operatingCoTenancy.Remedy_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionRemedy_WF__c='';
        operatingCoTenancy.Concurrence_WF__c='Or';
        operatingCoTenancy.NamedStoreCoTenancy_WF__c='';
        operatingCoTenancy.GLARequired_WF__c=false;
        operatingCoTenancy.GLAPercent_WF__c=0;
        operatingCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionGLARequired_WF__c='';
        operatingCoTenancy.NamedStoreCT_WF__c='';
        operatingCoTenancy.NoofNamedStoresRequired_WF__c=0;
        operatingCoTenancy.NamedStoreRequirement_WF__c=false;
        operatingCoTenancy.OtherRequirement_WF__c=false;
        operatingCoTenancy.Explanation_WF__c='';
        operatingCoTenancy.ReplacementTenantDescription_WF__c='';
        operatingCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionOtherRequirement_WF__c='';
        operatingCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        operatingCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
    },
    clearOpeningCoTenancy : function(component,event){
        var openingCoTenancy = {};
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Opening'){
                openingCoTenancy = lstCoTenants[item];
            }
        }
        openingCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        openingCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        openingCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        openingCoTenancy.SalesTest_WF__c=0;
        openingCoTenancy.DefinitionofDeptStoresf_WF__c=''
        openingCoTenancy.DepartmentStores_WF__c = false;
        openingCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        openingCoTenancy.NoofDeptStoresRequired_WF__c=0;
        openingCoTenancy.SizeofDepartmentStore_WF__c=0;
        openingCoTenancy.Remedy_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionRemedy_WF__c='';
        openingCoTenancy.Concurrence_WF__c='Or';
        openingCoTenancy.NamedStoreCoTenancy_WF__c='';
        openingCoTenancy.GLARequired_WF__c=false;
        openingCoTenancy.GLAPercent_WF__c=0;
        openingCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionGLARequired_WF__c='';
        openingCoTenancy.NamedStoreCT_WF__c='';
        openingCoTenancy.NoofNamedStoresRequired_WF__c=0;
        openingCoTenancy.NamedStoreRequirement_WF__c=false;
        openingCoTenancy.OtherRequirement_WF__c=false;
        openingCoTenancy.Explanation_WF__c='';
        openingCoTenancy.ReplacementTenantDescription_WF__c='';
        openingCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionOtherRequirement_WF__c='';
        openingCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        openingCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        openingCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        openingCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        openingCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        openingCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
    },
    clearConstructionCoTenancy : function(component,event){
        var constructionCoTenancy = {};
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Construction'){
                constructionCoTenancy = lstCoTenants[item];
            }
        }
        constructionCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        constructionCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        constructionCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        constructionCoTenancy.SalesTest_WF__c=0;
        constructionCoTenancy.DefinitionofDeptStoresf_WF__c=''
        constructionCoTenancy.DepartmentStores_WF__c = false;
        constructionCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        constructionCoTenancy.NoofDeptStoresRequired_WF__c=0;
        constructionCoTenancy.SizeofDepartmentStore_WF__c=0;
        constructionCoTenancy.Remedy_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionRemedy_WF__c='';
        constructionCoTenancy.Concurrence_WF__c='Or';
        constructionCoTenancy.NamedStoreCoTenancy_WF__c='';
        constructionCoTenancy.GLARequired_WF__c=false;
        constructionCoTenancy.GLAPercent_WF__c=0;
        constructionCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionGLARequired_WF__c='';
        constructionCoTenancy.NamedStoreCT_WF__c='';
        constructionCoTenancy.NoofNamedStoresRequired_WF__c=0;
        constructionCoTenancy.NamedStoreRequirement_WF__c=false;
        constructionCoTenancy.OtherRequirement_WF__c=false;
        constructionCoTenancy.Explanation_WF__c='';
        constructionCoTenancy.ReplacementTenantDescription_WF__c='';
        constructionCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionOtherRequirement_WF__c='';
        constructionCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        constructionCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        constructionCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        constructionCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        constructionCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        constructionCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
        constructionCoTenancy.IsTenantRequiredToStartConstruction_WF__c=false;        
    },
    clearPosessionCoTenancy : function(component,event){
        var posessionCoTenancy = {};
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Posession'){
                posessionCoTenancy = lstCoTenants[item];
            }
        }
        posessionCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        posessionCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        posessionCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        posessionCoTenancy.SalesTest_WF__c=0;
        posessionCoTenancy.DefinitionofDeptStoresf_WF__c=''
        posessionCoTenancy.DepartmentStores_WF__c = false;
        posessionCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        posessionCoTenancy.NoofDeptStoresRequired_WF__c=0;
        posessionCoTenancy.SizeofDepartmentStore_WF__c=0;
        posessionCoTenancy.Remedy_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionRemedy_WF__c='';
        posessionCoTenancy.Concurrence_WF__c='Or';
        posessionCoTenancy.NamedStoreCoTenancy_WF__c='';
        posessionCoTenancy.GLARequired_WF__c=false;
        posessionCoTenancy.GLAPercent_WF__c=0;
        posessionCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionGLARequired_WF__c='';
        posessionCoTenancy.NamedStoreCT_WF__c='';
        posessionCoTenancy.NoofNamedStoresRequired_WF__c=0;
        posessionCoTenancy.NamedStoreRequirement_WF__c=false;
        posessionCoTenancy.OtherRequirement_WF__c=false;
        posessionCoTenancy.Explanation_WF__c='';
        posessionCoTenancy.ReplacementTenantDescription_WF__c='';
        posessionCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionOtherRequirement_WF__c='';
        posessionCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        posessionCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        posessionCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        posessionCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        posessionCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        posessionCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
        posessionCoTenancy.IsTenantRequiredToStartConstruction_WF__c=false;
        posessionCoTenancy.IsTntReqdtoAcceptPosession_WF__c=false;
    },
    validateCovenantTextField:function(component,result)
    {
        
        console.log("COTENCNCY VALIDATION METHOD");
         var coTenancyError = false;
         var COV_exclusiveRightError= false;
    	 var coTenants = component.get('v.lstCoTenants');
         var covenantTextFieldMap =result.covenantTextFieldMap;
        component.set("v.coTenancyTempError",false);
        console.log('result',result);
		console.log('covenantTextFieldMap..,.,.,.,.',covenantTextFieldMap);
         for(var i=0; i<coTenants.length; i++){
if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true)){
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DefinitionofDeptStoresf_WF__c'])&& !$A.util.isUndefinedOrNull(coTenants[i].DefinitionofDeptStoresf_WF__c)&&
                coTenants[i].DefinitionofDeptStoresf_WF__c.length > covenantTextFieldMap['DefinitionofDeptStoresf_WF__c'])
             {
                 $A.util.removeClass(document.getElementById('defDeptStoreLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('defDeptStoreLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionRemedy_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionRemedy_WF__c) && coTenants[i].DescriptionRemedy_WF__c.length > covenantTextFieldMap['DescriptionRemedy_WF__c'])
             {
                 $A.util.removeClass(document.getElementById('noDeptRemDescReqdLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
                 
             }
             else{
                 $A.util.addClass(document.getElementById('noDeptRemDescReqdLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionGLARequired_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionGLARequired_WF__c)&&coTenants[i].DescriptionGLARequired_WF__c.length > covenantTextFieldMap['DescriptionGLARequired_WF__c'])
             {
                 $A.util.removeClass(document.getElementById('descGLAReqdLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
                 
             }
             else{
                 $A.util.addClass(document.getElementById('descGLAReqdLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['NamedStoreCoTenancy_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].NamedStoreCoTenancy_WF__c)&&coTenants[i].NamedStoreCoTenancy_WF__c.length > covenantTextFieldMap['NamedStoreCoTenancy_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('namedStoreCotenancyLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('namedStoreCotenancyLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionNamedStoreRequirement_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionNamedStoreRequirement_WF__c)&&coTenants[i].DescriptionNamedStoreRequirement_WF__c.length > covenantTextFieldMap['DescriptionNamedStoreRequirement_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('descNamedStoreReqLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('descNamedStoreReqLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['NamedStoreCT_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].NamedStoreCT_WF__c)&&coTenants[i].NamedStoreCT_WF__c.length > covenantTextFieldMap['NamedStoreCT_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('namedStoreCTLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('namedStoreCTLengthErrorId'+i),'slds-hide');
             }

             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ReplacementTenantDescription_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].ReplacementTenantDescription_WF__c)&&coTenants[i].ReplacementTenantDescription_WF__c.length > covenantTextFieldMap['ReplacementTenantDescription_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('RepDescReqLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('RepDescReqLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Explanation_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].Explanation_WF__c)&&coTenants[i].Explanation_WF__c.length > covenantTextFieldMap['Explanation_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('explanationLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('explanationLengthErrorId'+i),'slds-hide');
             }
             
             if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionOtherRequirement_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionOtherRequirement_WF__c)&&coTenants[i].DescriptionOtherRequirement_WF__c.length > covenantTextFieldMap['DescriptionOtherRequirement_WF__c']) 
             {
                 $A.util.removeClass(document.getElementById('descOtherReqLengthErrorId'+i),'slds-hide');
                 coTenancyError=true;
             }
             else{
                 $A.util.addClass(document.getElementById('descOtherReqLengthErrorId'+i),'slds-hide');
             }
             
           }  
             if(coTenancyError)
             {
                 component.set("v.coTenancyTempError",true);
             }else
             {
                component.set("v.coTenancyTempError",false);
             }
           }
     }
})