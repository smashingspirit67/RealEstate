({
    doInit : function(component, event, helper) {
        var inputsel = component.find("incorporationId");
        var action = component.get('c.getState');                 
         var opts=[];
        
        action.setCallback(this, function(a) {
            var state = a.getState();
            if(state == 'SUCCESS'){
                opts.push({"class": "optionClass", label: '--None--', value: '--None--'});
                for(var i=0;i< a.getReturnValue().length;i++){
                    
                    opts.push({"class": "optionClass", label: a.getReturnValue()[i], value: a.getReturnValue()[i]});
                }
                inputsel.set("v.options", opts);
            }
        });
        $A.enqueueAction(action); 
    },
    closeNewAccountPopup : function(component, event, helper) {
          component.set('v.showPopup', 'false');
        component.set('v.idLegalEntity',null);
        $("input[id|='65:0_typeahead']").val('');
        
    },
    createAccount : function(component, event, helper){              
        var action = component.get('c.createNewAccount');        
        action.setParams({
            "strAccountName": component.get('v.accountName'),
            "strLegalType" : component.get('v.legalEntityType'),
            "strState" : component.get('v.stateOfIncorporation'),            
        });
        
        action.setCallback(this,function(a){
            var state = a.getState();
            if(state === 'SUCCESS'){
            	var response = a.getReturnValue();     
                if(response != 'Failed'){
        			component.set('v.legalEntity', response);            
                    component.set('v.showPopup', 'false');
                }
            }                        
        });
        $A.enqueueAction(action);
    }
})