({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Exclusive Right']){
                component.set('v.exclusiveRights',covenant[item]);
                var isPresent = true;
            }
        }
        if(!isPresent){
            var exclusiveRights = {};
            exclusiveRights.RecordTypeId =component.get('v.CovenantRecordType')['Exclusive Right'];
            component.set('v.exclusiveRights',exclusiveRights);
            covenant.push(component.get('v.exclusiveRights'));
            component.set('v.Covenant',covenant);
        }
	},
	validateExclDuration : function(component, event, helper){
			var exclDuration = component.get('v.exclusiveRights.ExclDuration_WF__c');
			
			if(exclDuration != null && exclDuration.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]"))
			{
				$A.util.removeClass(component.find("exclDurationSpecCharErrorId"), 'slds-hide');
				//boolIsreqFiledEmpty = true;
			}
			else
			{
				$A.util.addClass(component.find("exclDurationSpecCharErrorId"), 'slds-hide');
			}
		},
    changeExclusiveRights : function(component, event, helper) {
        component.set('v.exclusiveRights.ExclRightDescription_WF__c','');
        component.set('v.exclusiveRights.ExclDuration_WF__c','');
        component.set('v.exclusiveRights.ExclRemedyDescription_WF__c','');
    }
})