({
	doInit : function(component, event, helper) {
		var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Other Charges']){
                component.set('v.other',charges[item]);
            }
        }
        helper.setPicklistValues(component,component.get('v.result'));       
	},
})