({
    doInit : function(component, event, helper) {
        var idCenter = component.get('v.center');
        if(idCenter != null){
            helper.getRelatedUnits(component, event);
        }
    },

    previousPage : function(component, event, helper) {
        helper.previousPageHelper(component);
	},
	nextPage : function(component, event, helper) {
        helper.nextPageHelper(component);
	},
    
    getUnits : function(component, event, helper){
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        helper.getRelatedUnits(component, event,'getUnits');
    },
    closeProductsPopup : function(component, event, helper) {        
        component.set('v.showProductsPopup', 'false');          
    },
    onChangeChildCheckbox: function(component, event,helper) {
        var unitToAdd=component.get('v.addProduct');        
        var productId = event.getSource().get('v.text');                                                                        
        component.set('v.addProduct',productId);        
    },
    selectProductsAndSaveTask : function(component, eve, helper){
        var commentsError = component.find("commentsErrorId");
        console.log(component.get('v.strComments'));
        console.log(component.get('v.strComments')!='');
        console.log(component.get('v.strComments')!=null);
        var strErrors =[];
        if(helper.validateExpirationDate(component, eve)){
            component.set('v.strErrors',[]);
        if(component.get('v.strComments')!='' && component.get('v.strComments')!=null){
            console.log('in if');
            component.set('v.strCreateTasks','true');
            if(component.get('v.unitType') == $A.get("$Label.c.StorageLeasing_WF"))
            {
            	component.set('v.strCreateTaskA3','true');
            }
            helper.selectProducts(component);  
            console.log('commentsError',commentsError);
            $A.util.addClass(commentsError, 'slds-hide');
        }else{
            console.log('in else');
            console.log('commentsError',commentsError);
            $A.util.removeClass(commentsError, 'slds-hide');
        }           
        }else{
            strErrors.push('Please select a unit with expiration date');
            component.set('v.strErrors', strErrors);
        }
    },
    selectProducts : function(component, eve, helper){
        var strErrors = [];
        if(helper.validateExpirationDate(component, eve)){
            helper.selectProducts(component); 
        if(component.get('v.unitType') != null && component.get('v.unitType') != ''){
                component.set('v.strErrors',[]);
            var compEvent = component.getEvent("UnitProdLinkCompEvent");
            compEvent.fire();    
        }
        }else{
            strErrors.push('Please select a unit with expiration date');
            component.set('v.strErrors', strErrors);                       
        }
        
    },
    showFilters : function(cmp, eve, helper){
        var showFilters = cmp.get('v.strShowFilter');
        console.log(showFilters);
        if(showFilters == 'Yes'){
            cmp.set('v.boolFilterUnits', true);
            if(!$A.util.isUndefinedOrNull(cmp.find('vvpickval'))){                           
                cmp.find('vvpickval').reInit();
            }
        }else{
            var spinner = cmp.find("spinner");
			$A.util.removeClass(spinner, "slds-hide");
            cmp.set('v.boolFilterUnits', false);
            cmp.set('v.intFloor', '');
            cmp.set('v.intUnitArea', '');
            cmp.set('v.intUnitAreaTo', '');
            cmp.set('v.selVirVacancy', '');
            cmp.set('v.strUnitNumberFrom', '');
            cmp.set('v.datStartDate', '');
            cmp.set('v.datExpiryDate', '');
            cmp.set('v.strCurrTenant', '');
            helper.getRelatedUnits(cmp, eve);
        }
    },
    
    validateAreaFromTo : function(component, event, helper){console.log('In Valid');
        var areaFrom = component.get('v.intUnitArea');
        var areaTo = component.get('v.intUnitAreaTo');
        var regErrorFrom = false;
        var regErrorTo = false;
        
        if(!$A.util.isUndefinedOrNull(areaFrom) && areaFrom.match(/^[0-9]*$/))
        {
            $A.util.addClass(component.find("areaFromErrorId"), 'slds-hide');
            regErrorFrom = false;
        }
        else
        {
        	if(!$A.util.isUndefinedOrNull(areaFrom))
            {
        		$A.util.removeClass(component.find("areaFromErrorId"), 'slds-hide');
        		regErrorFrom = true;
        	}
        }
        
        if(!$A.util.isUndefinedOrNull(areaTo) && areaTo.match(/^[0-9]*$/))
        {
            $A.util.addClass(component.find("areaToErrorId"), 'slds-hide');
            regErrorTo = false;
        }
        else
        {
        	if(!$A.util.isUndefinedOrNull(areaTo))
            {
        		$A.util.removeClass(component.find("areaToErrorId"), 'slds-hide');
        		regErrorTo = true;
        	}
        }
        
        if(regErrorFrom == true || regErrorTo == true)
        {
        	component.set('v.regErrorUnits', true);
        }
        else
        {
        	component.set('v.regErrorUnits', false);
        }
    },
    
    getFilteredUnits : function(cmp, event){
        cmp.set('v.GLAZero',false);
        var spinner = cmp.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
        if(cmp.get('v.idCenterName') != null || cmp.get('v.intUnitArea') != null || cmp.get('v.intUnitAreaTo') != null || cmp.get('v.intFloor') != null || cmp.get('v.strCurrTenant') != null || 
        		cmp.get('v.strUnitNumberFrom') != null || cmp.get('v.selVirVacancy') != null){
            var action = cmp.get('c.getFilteredUnitsBasedOnCenter');
            var products = JSON.parse(JSON.stringify(cmp.get('v.products')));        
            var filterUnits = {};        
            var centerOnOfferScreen = cmp.get('v.center');
            var filterCenter = cmp.get('v.idCenterName');
            var isSameCenter;
            var arrExistingProductIds = JSON.parse(JSON.stringify(cmp.get('v.arrProductIds')));
            var productDetailsToShow = [];
            var productDetails = [];
            
            filterUnits.intFloor = cmp.get('v.intFloor') == '' ? null : cmp.get('v.intFloor');
            filterUnits.intArea = cmp.get('v.intUnitArea') == '' ? null : cmp.get('v.intUnitArea');
            filterUnits.intAreaTo = cmp.get('v.intUnitAreaTo') == '' ? null : cmp.get('v.intUnitAreaTo');
            filterUnits.strCurrTenantName = cmp.get('v.strCurrTenant');
            filterUnits.strUnitNumberFrom = cmp.get('v.strUnitNumberFrom') == '' ? null : cmp.get('v.strUnitNumberFrom');
            filterUnits.virVacancy = cmp.get('v.selVirVacancy') == '' ? null : cmp.get('v.selVirVacancy');
            filterUnits.unitType = cmp.get('v.unitType') == '' ? null : cmp.get('v.unitType');
            filterUnits.InvType = cmp.get('v.strInvType') == ''? 'GLA' : cmp.get('v.strInvType');
            filterUnits.buildingNumber = cmp.get('v.strBuildingNumber') == ''? null : cmp.get('v.strBuildingNumber');
            
            if(filterCenter != null && filterCenter != centerOnOfferScreen){
                filterUnits.idCenterName = filterCenter;
            }else if((filterCenter != null && filterCenter == centerOnOfferScreen) || filterCenter ==  null){ 
                filterUnits.idCenterName = centerOnOfferScreen; 
                isSameCenter = true;
            }else{
                filterUnits.idCenterName = null;
            }                    
            
            action.setParams({"strFilterUnits": JSON.stringify(filterUnits)});
            action.setCallback(this, function(response){
                var isSuccess = response.getState();
                console.log('Response ---> ', response);
                if(isSuccess){
                    var result = response.getReturnValue();   
                    console.log('result',result);
                    if(result.length != 0){                  
                        if(isSameCenter){
                        	for(var i=0; i< result.length; i++){
                				productDetails.push(result[i]);
            				}
                            cmp.set('v.products', productDetails);
                        }else{                            
                            for(var i = 0; i< result.length; i++){                                
                                var index = arrExistingProductIds.indexOf(result[i].idProduct);
                                if( index == -1){                                    
                                    productDetails.push(result[i]);             
                                    arrExistingProductIds.push(result[i].idProduct);
                                }                                
                            }                                
                            cmp.set('v.products', productDetails);    
                            cmp.set('v.arrProductIds', arrExistingProductIds);
                        }
                        
                        cmp.set('v.intPage', 1);
                		cmp.set('v.intPages', (Math.ceil(productDetails.length/10)));
                		cmp.set('v.intTotal', productDetails.length);
                        var pageSize = 0;
                        var j=0;
                        if(Number(cmp.get('v.intPage'))<Number(cmp.get('v.intPages'))){
                            pageSize = Number(cmp.get('v.intPage'))*10;
                        }
                        else{
                            pageSize = productDetails.length-(Number(cmp.get('v.intPage'))-1)*10;
                        }
                        
                        for(var i=(Number(cmp.get('v.intPage'))-1)*10; i < pageSize; i++){
                            productDetailsToShow.push(productDetails[i]);
                        }
                        cmp.set('v.productsToShow', productDetailsToShow);
                    }
                    else
                    {
                    	cmp.set('v.productsToShow', []);
                    	cmp.set('v.intPage', 1);
                		cmp.set('v.intTotal', 1);
                		cmp.set('v.intPages', 1);
                    }
                }
                var spinner = cmp.find("spinner");
                $A.util.addClass(spinner, "slds-hide");
            });
            $A.enqueueAction(action);            
        }
    }
})