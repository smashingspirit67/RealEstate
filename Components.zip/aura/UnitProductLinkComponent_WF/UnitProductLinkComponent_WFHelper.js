({
	getRelatedUnits : function(component, event, invokedFrom) {
		var page = component.get("v.page") || 1;
        if(invokedFrom == 'getUnits'){
            var direction = event.getParam("direction");
            page = direction === "previous" ? (page - 1) : (page + 1);
        }
        var idCenter = component.get('v.center');
        var action = component.get('c.getProductDetails');
        var selectedUnit = component.get('v.addProduct');
        var idOpportunity = component.get('v.idOpportunity');
        var arrExistingProductIds = JSON.parse(JSON.stringify(component.get('v.arrProductIds')));
        var unitTypeVal=  component.get('v.unitType');  
        var strInvType = component.get('v.strInvType');  
        var bReconfigChan = component.get('v.bolReconfigChange');
        action.setParams({
            "strCenter":idCenter,
            "pageNumber": page,
            "idOpportunity":idOpportunity,
            "unitType":unitTypeVal,
            "strInvType":strInvType,
            "bReconfigChan":bReconfigChan
        });
        action.setCallback(this, function(response){
        	var productDetailsToShow = [];
            var state = response.getState();
            if( state == 'SUCCESS'){
                var result = response.getReturnValue();                
                if(result != null){console.log(result.lstProduct.length);
                    component.set('v.intPage', 1); console.log(result.lstProduct.length, Math.ceil(result.lstProduct.length/10));
                    component.set('v.intPages', (Math.ceil(result.lstProduct.length/10)));
                    component.set('v.intTotal', result.lstProduct.length);           
                    component.set('v.products', result.lstProduct);
                 
                    var pageSize = 0;
                    var j=0;
                    if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
                    	pageSize = Number(component.get('v.intPage'))*10;
                    }
                    else{
                    	pageSize = result.lstProduct.length-(Number(component.get('v.intPage'))-1)*10;
                    }
                
                    for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
                    	productDetailsToShow[j] = result.lstProduct[i];
                    	j++;
                    }
                    
                    component.set('v.productsToShow', productDetailsToShow);  
                 
                    if(result.lstProduct != undefined){
                        if(result.lstProduct.length > 0){console.log('1log');
                            for(var i = 0; i <  result.lstProduct.length; i++){console.log(result.lstProduct[i].cntrCountry);
                            	console.log('Inside the getRelated', arrExistingProductIds.indexOf( result.lstProduct[i].idProduct));
                                if(!arrExistingProductIds.indexOf( result.lstProduct[i].idProduct) > -1){
                                    arrExistingProductIds.push( result.lstProduct[i].idProduct);                                  
                                }                
                            }                            
                        }
                    }
                    
                    if(arrExistingProductIds.length > 0)
                     component.set('v.arrProductIds', arrExistingProductIds);
                }
            }
            var spinner = component.find("spinner");
			$A.util.addClass(spinner, "slds-hide");
        });
        $A.enqueueAction(action);
	},
	
	previousPageHelper : function(component){
        if(Number(component.get('v.intPage')) > 1){	
    		component.set('v.intPage', Number(component.get('v.intPage'))-1);
        }
        var productDetails = [];
        productDetails = JSON.parse(JSON.stringify(component.get('v.products')));
        //console.log(productDetails);
        var productDetailsToShow = [];
        productDetailsToShow = JSON.parse(JSON.stringify(component.get('v.productsToShow')));
        //console.log(productDetailsToShow);
        for(var i=0;i<productDetailsToShow.length;i++){
            for(j=0;j<productDetails.length;j++){
                if(productDetailsToShow[i].unitNo == productDetails[j].unitNo){
                    productDetails[j] = productDetailsToShow[i];
                    break;
                }
            }
        }
        component.set('v.products',productDetails);
        var j=0;
        var productDetailsToShow = [];
        var pageSize = 0;
        if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
        	pageSize = Number(component.get('v.intPage'))*10;
        }
        else{
        	//@Joshna - replaced result.length with v.intTotal
        	pageSize = component.get('v.intTotal')-(Number(component.get('v.intPage'))-1)*10;
        }
        for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
        	productDetailsToShow[j] = productDetails[i];
            j++;
        }
        component.set('v.productsToShow', productDetailsToShow);
    },
    nextPageHelper : function(component){
        if(Number(component.get('v.intPage')) < Number(component.get('v.intPages'))){	
    		component.set('v.intPage', Number(component.get('v.intPage'))+1);
        }
        var productDetails = JSON.parse(JSON.stringify(component.get('v.products')));
        var productDetailsToShow = JSON.parse(JSON.stringify(component.get('v.productsToShow')));
        
        for(var i=0;i<productDetailsToShow.length;i++){
            for(j=0;j<productDetails.length;j++){
                if(productDetailsToShow[i].unitNo == productDetails[j].unitNo){
                    productDetails[j] = productDetailsToShow[i];
                    break;
                }
            }
        }
        //console.log(productDetails.length);
        component.set('v.products',productDetails);
        var j=0;
        var productDetailsToShow = [];
        var pageSize = 0;
        if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
        	pageSize = Number(component.get('v.intPage'))*10;
        }
        else{
        	//@Joshna - replaced result.length with v.intTotal
        	pageSize = component.get('v.intTotal');//-(Number(component.get('v.intPage'))-1)*10;
        }
        for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
        	productDetailsToShow[j] = productDetails[i];
            j++;
        }
        component.set('v.productsToShow', productDetailsToShow);
    },
       
    selectProducts : function(component, event){
	    var products = component.get('v.products');
        var unitToAdd = component.get('v.addProduct');
        var selectedProducts = [];
        var strReservations = {};
        var tempGLA = 0;
         var glaZero = 0;
        
        if(products.length > 0){
            for(var i = 0; i < products.length; i++){ 
                if( products[i].idProduct == unitToAdd ){
                    if(products[i].includepopout == true){
                        glaZero = products[i].GLA != null ? products[i].GLA + products[i].popoutGLA : products[i].popoutGLA;
                    }else{
						glaZero = products[i].GLA != null ? products[i].GLA : 0;
                    }
                }
            }
        }
        if(glaZero<=0){
            component.set('v.GLAZero', true);
            return;
        }else{
            /* Commenting as this breaking the Budget Data updation logic on change of unit selection */
          //  component.set('v.showProductsPopup', 'false'); 
        }
        if(products.length > 0){
            for(var i = 0; i < products.length; i++){ 
                if( products[i].idProduct == unitToAdd ){
                	component.set('v.productSelected', products[i].prodRecord);
                    component.set('v.storageTermVal',products[i].StorageTerm);
                    component.set('v.currTenant', products[i].tenantName!=null ?  products[i].tenantName:'');
                    component.set('v.tenantLeaseExpDate',products[i].expirationDate!=null ? products[i].expirationDate : '');   
                    //GDM-8345 Rounding off change
                    console.log('++products[i].GLA++',products[i].GLA,'+++Rounded Off++',Math.round(products[i].GLA),'++popoutGLA++',Math.round(products[i].popoutGLA));
                    products[i].GLA = Math.round(products[i].GLA);
                    products[i].popoutGLA = Math.round(products[i].popoutGLA);
                    if(products[i].includepopout == true)
                    {
                        component.set('v.GLAUsed',products[i].GLA != null ? products[i].GLA + products[i].popoutGLA : products[i].popoutGLA);
                        component.set('v.storageGLA',products[i].GLA != null ? products[i].GLA + products[i].popoutGLA : products[i].popoutGLA);
                    }
                    else
                    {                 
                    	component.set('v.GLAUsed',products[i].GLA != null ? products[i].GLA : 0);
                        component.set('v.storageGLA',products[i].GLA != null ? products[i].GLA : 0);
                    }   
                    component.set('v.strProducts',products[i].unitNo);   
                    component.set('v.storageAnnualIncr',products[i].StorageAnnIncr != null ? products[i].StorageAnnIncr : 0.05);   
                    component.set('v.storageTerm',products[i].StorageTerm != null ? products[i].StorageTerm : '');
                    component.set('v.storageElecCharge',products[i].StorageElecChr != null ? products[i].StorageElecChr : 0);
                    component.set('v.storageType',products[i].StorageType != null ? products[i].StorageType : '');
                   	/* Commenting the below line as it is breaking the Budget data updation logic */
                    //component.set('v.showProductsPopup', 'false'); 
                    console.log('Storage--', component.get('v.storageType'), component.get('v.storageTerm'))
                    component.set('v.unitConfig', []);
                    if(component.get('v.datStartDate') != null && component.get('v.datStartDate') != '')
                    {
                        component.set('v.datUCStart', component.get('v.datStartDate'));                                                
                    }
                    if(component.get('v.datExpiryDate') != null && component.get('v.datExpiryDate') != ''){
                    	component.set('v.datUCEnd', component.get('v.datExpiryDate'));
                    } 
                    if(component.get('v.idCenterName') != null && component.get('v.center') != component.get('v.idCenterName')){                                                
                        component.set('v.center', products[i].idCenter);
                        component.set('v.centerName', products[i].strCenter);
                    }
                    console.log('unitype', component.get('v.unitType'));
                    if(component.get('v.unitType') != null && component.get('v.unitType') != '')
                    {
                    	strReservations.unitType = component.get('v.unitType'); 
                        console.log('unitTypeStr', component.get('v.unitType'));
                    }
                    
                    strReservations.popoutGLA = products[i].popoutGLA;
                    strReservations.includepopout =  products[i].includepopout;
                    strReservations.idProduct = products[i].idProduct;                                        
                    strReservations.unitNo = products[i].unitNo;
                    strReservations.activationEndDate = products[i].activationEndDate;
                    strReservations.unitStatus = products[i].unitStatus;
                    strReservations.activationStartDate = products[i].activationStartDate;
                    console.log('strReser', strReservations);
                }
            }                                   
            var unitNumberToShow = component.get('v.strProducts');
            
            
            var centerOnOffer = component.get('v.centerOnOffer');
            var centerRec = component.get('v.centerRec');
            console.log('centerOnOffercenterOnOffercenterOnOffercenterOnOffer',centerOnOffer);
            if(centerOnOffer!=null && centerOnOffer.Name != undefined && centerOnOffer != centerRec){
                component.set('v.centerOnOffer', centerRec);
            }                    
            component.set('v.strProducts', unitNumberToShow);
            component.set('v.selectedProducts', strReservations);
            if(component.get('v.unitType') != null && component.get('v.unitType') != '')  
            {
            	component.set('v.isStorageInvoked', true);
            }
            else
            {
            	component.set('v.isUnitInvoked', true);
            }                 
            /* Verify if the user changed the selection of the product. 
               If yes, then call the prepareBudgetData method to get the budget information for 
               the newly selected product. */
            var opportunity = component.get('v.opportunity');
            var sObjOppBU;
            var sObjOppRefBU;            
            if(!$A.util.isUndefinedOrNull(opportunity)){
                if($A.util.isUndefinedOrNull(opportunity.StageName) || opportunity.StageName !='Offer'){
		/* Author - Sachin. Added the below logic as part of defect GDM-7729. When we are trying to create a new Renewal Amendment 
		            from a lease which has an opportunity linked via Opportunity__c variable it was failing whilie deserializing the opportunity in PrepareBudgetData method 
			    in the offer details controller */
                    if(!$A.util.isUndefinedOrNull(opportunity.Opportunity__c)){
                    	opportunity = component.get('v.opportunity');
                    	sObjOppBU = opportunity.Opportunity__c;
                        sObjOppRefBU = opportunity.Opportunity__r;
                        opportunity.Opportunity__c = '';
                        opportunity.Opportunity__r = null;
                    }
                    var action = component.get("c.prepareBudgetData");
                    action.setParams({
                        "opty" : JSON.stringify(opportunity),
                        "productId" : strReservations.idProduct,
                        "unitNumber" : unitNumberToShow,
                        "strOpportunityBudgets" : JSON.stringify(component.get('v.budget')),
                        "objName": component.get('v.objName')
                    });   
                    action.setCallback(this, function(resp){
                        var res = resp.getReturnValue();
                        if(res !== null){
                            component.set('v.budget', res);
                        } 
                        component.set('v.showProductsPopup', 'false');        
                    });
                    $A.enqueueAction(action);
                    opportunity.Opportunity__c = sObjOppBU;
                    opportunity.Opportunity__r = sObjOppRefBU;
                } else
                    component.set('v.showProductsPopup', 'false');        
            }else{
                component.set('v.showProductsPopup', 'false');    
            }
        }
    },
    /*GDM-8413 (Author - Sachin) : Below method is used to validate and display error messages when user tries to select an active product 
    			 with the lease term on the deal is not in between the Activation Start Date and Activation End Date of the product.*/ 
    
    validateExpirationDate: function(cmp, eve){
        var productDetails = cmp.get('v.products');
        var opportunityExpirationDate = cmp.get('v.datUCEnd');
        var unitToAdd = cmp.get('v.addProduct');
        var opportunityRCDDate = cmp.get('v.datUCStart');
        var strErrors = [];
        var NoExpError = true;
        var NoRCDError = true;
        if(productDetails.length > 0){
            for(var i = 0; i < productDetails.length; i++){ 
                if( productDetails[i].idProduct == unitToAdd ){
                     // Validating the lease term on the deal with the product start and end date only if the unit status is active
                    if(productDetails[i].unitStatus == 'Active'){
                        if(!$A.util.isUndefinedOrNull(opportunityExpirationDate) && !$A.util.isUndefinedOrNull(productDetails[i].activationEndDate)){
                            if(opportunityExpirationDate > productDetails[i].activationEndDate){
                                strErrors.push('Expiration date on the deal cannot be after the End Date '+ productDetails[i].activationEndDate +' of the unit '+ productDetails[i].unitNo +'. Please change the Expiration Date or select a different unit.'); 
                                NoExpError = false;
                            }
                        }
                        if(!$A.util.isUndefinedOrNull(opportunityRCDDate) && !$A.util.isUndefinedOrNull(productDetails[i].activationStartDate)){
                            if(opportunityRCDDate < productDetails[i].activationStartDate){
                                strErrors.push('RCD date on the deal cannot be before the Start Date '+ productDetails[i].activationStartDate +' of the unit '+ productDetails[i].unitNo +'. Please change the RCD Date or select a different unit.');     
                            	NoRCDError = false;
                            }
                        }
                    }
                }
            }
            if(NoExpError && NoRCDError){
                strErrors =[];
                cmp.set('v.strErrors', strErrors);
            }
            if(strErrors.length > 0){
                cmp.set('v.strErrors', strErrors);                          
                return false;
            }else return true;
        }
    }
})