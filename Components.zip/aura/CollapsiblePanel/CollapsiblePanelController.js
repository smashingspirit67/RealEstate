({
    /*** Start Clearing logic for Data ***/
    changeACDBE : function(component, event, helper) {
        if(component.get('v.opportunity.ACDBEParticipation_WF__c'))
            component.set('v.opportunity.ACDBEParticipationPercentage_WF__c', '0');
        else
            component.set('v.opportunity.ACDBEParticipationPercentage_WF__c', null);        
        component.set('v.opportunity.ACDBEDescription_WF__c', '');
    },	
    changeLeaseDeposit : function(component,event){
			if(!component.get('v.opportunity.LeaseDeposit_WF__c')){
				component.set('v.opportunity.LeaseDepositAmount_WF__c',0);
			}
		},
		changeSecurityDepositRequired : function(component,event,helper){
			component.set('v.opportunity.SecurityType_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('OpportunitySecurityType_WF__c'))){
				component.find('OpportunitySecurityType_WF__c').reInit();
			}
			helper.setSecurityTypeHelper(component, event,"change",null);
			//complex logic will do it at last
		},
		changeStorageRequired : function(component,event,helper){
			component.set('v.opportunity.StorageRentAmount_WF__c',0);
			component.set('v.opportunity.StorageTerm_WF__c','');
			component.set('v.opportunity.StorageElectricityCharge_WF__c',0);
			component.set('v.opportunity.StorageType_WF__c','');
			component.set('v.opportunity.StorageGLA_WF__c',0);
			component.set('v.strStorageProducts','');
			component.set('v.opportunity.StorageAnnualIncrease_WF__c',0);
			component.set('v.opportunity.StorageReconfiguration_WF__c',false);
			if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageTerm_WF__c'))){
				component.find('OpportunityStorageTerm_WF__c').reInit();
			}
			if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageType_WF__c'))){
				component.find('OpportunityStorageType_WF__c').reInit();
			}        
		},
		changePatioRequired : function(component,event){
			if(!component.get('v.opportunity.Patio_WF__c')){
				component.set('v.opportunity.PatioComments_WF__c','');
				component.set('v.opportunity.PatioMR_WF__c',false);
				component.set('v.opportunity.MRAmount_WF__c',0);
				component.set('v.opportunity.PatioCAM_WF__c',false);
				component.set('v.opportunity.CAMAmount_WF__c',0);
				component.set('v.opportunity.PatioPromo_WF__c',false);
				component.set('v.opportunity.PromoAmount_WF__c',0);
				component.set('v.opportunity.PatioTaxes_WF__c',false);
				component.set('v.opportunity.TaxesAmount_WF__c',0);            
			}
		},
		changePatioMRRequired : function(component,event){
			if(!component.get('v.opportunity.PatioMR_WF__c')){
				component.set('v.opportunity.MRAmount_WF__c',0);
			}
		},
		changePatioCAMRequired : function(component,event){
			if(!component.get('v.opportunity.PatioCAM_WF__c')){
				component.set('v.opportunity.CAMAmount_WF__c',0);
			}
		},
		changePatioPromoRequired : function(component,event){
			if(!component.get('v.opportunity.PatioPromo_WF__c')){
				component.set('v.opportunity.PromoAmount_WF__c',0);
			}
		},
		changePatioTaxRequired : function(component,event){
			if(!component.get('v.opportunity.PatioTaxes_WF__c')){
				component.set('v.opportunity.TaxesAmount_WF__c',0);            
			}
		},
		//Kickout
		changeKickouts : function(component,event){
			console.log('skdkhjdhj');
			var noOfkickouts = component.get('v.noOfKickouts');
			var lstKickout = component.get('v.lstKickouts');
			var lstToDelete = []
			for(var i=0 ;i<noOfkickouts; i++){
				lstKickout.pop();                      
			}   
			var action = component.get('c.deleteKickoutAll');
			action.setParams({
				"OppId" : component.get('v.idOpportunity')
			});
			console.log(action.getParams());
			action.setCallback(this, function(response){
				var result = response.getReturnValue();  
				console.log('*************',result);
				if(result && response.getState() == 'SUCCESS' && component.isValid()){
					component.set('v.lstKickouts',lstKickout);
					component.set('v.noOfKickouts',0);
				}
			});
			$A.enqueueAction(action);
		},
		changeLeaseholdImprovement : function(component, event, helper){   
			var kickouts = component.get('v.lstKickouts');
			for(var i=0; i<kickouts.length; i++){
				if(kickouts[i].Paybackunamoritzedleaseholdimprovemen_WF__c==false){
					kickouts[i].Unamoritzedleaseholdimprovementamount_WF__c = 0;
					kickouts[i].Unamoritzedleaseholdimprovementper_WF__c = 0;
				}
			}
			component.set('v.lstKickouts',kickouts);
		},
		changePaybackCommiss : function(component, event, helper){
			console.log('in pay commision');
			var kickouts = component.get('v.lstKickouts');
			for(var i=0; i<kickouts.length; i++){
				console.log('in pay loop');
				if(kickouts[i].IfTenantkickspaybackTACommiss_WF__c==false){
					kickouts[i].Unamortizedpaybackamount_WF__c = 0;
					kickouts[i].Unamortizedpaybackpercent_WF__c = 0;
				}
			}
			component.set('v.lstKickouts',kickouts);
		},
		changeLeaseholdImprovementPicklist : function(component, eve, helper){  
			var kickouts = component.get('v.lstKickouts');
			for(var i=0; i<kickouts.length; i++){
				if(kickouts[i].Unamoritzedleaseholdimprovementtype_WF__c == '%'){
					kickouts[i].Unamoritzedleaseholdimprovementamount_WF__c = 0;                
				}
				else if(kickouts[i].Unamoritzedleaseholdimprovementtype_WF__c == '$'){
					kickouts[i].Unamoritzedleaseholdimprovementper_WF__c = 0;
				}
				else{
					kickouts[i].Unamoritzedleaseholdimprovementamount_WF__c = 0;   
					kickouts[i].Unamoritzedleaseholdimprovementper_WF__c = 0;              
				}
			}
			component.set('v.lstKickouts',kickouts);
		},
		changePaybackCommissPicklist : function(component, eve, helper){
			var kickouts = component.get('v.lstKickouts');
			for(var i=0; i<kickouts.length; i++){
				if(kickouts[i].Unamortizedpaybacktype_WF__c == '%'){
					kickouts[i].Unamortizedpaybackamount_WF__c = 0;                
				}
				else if(kickouts[i].Unamortizedpaybacktype_WF__c == '$'){
					kickouts[i].Unamortizedpaybackpercent_WF__c = 0;
				}
				else{
					kickouts[i].Unamortizedpaybackamount_WF__c = 0;   
					kickouts[i].Unamortizedpaybackpercent_WF__c = 0;              
				}
			}
			component.set('v.lstKickouts',kickouts);
		},
		//Radius Restriction
		changeRadiusRestriction : function(component, event, helper) {
			component.set('v.radiusRestriction.of_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cof_WF__c'))){
				component.find('Covenant_WF__cof_WF__c').reInit();
			}
			component.set('v.radiusRestriction.RR_Other_WF__c','');
			component.set('v.radiusRestriction.RadiusDistance_WF__c',0);
			component.set('v.radiusRestriction.Duration_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cDuration_WF__c'))){
				component.find('Covenant_WF__cDuration_WF__c').reInit();
			}
			component.set('v.radiusRestriction.DurationYears_WF__c',0);
			component.set('v.radiusRestriction.Duration_Months__c',0);
			component.set('v.radiusRestriction.RadiusPenalty_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cRadiusPenalty_WF__c'))){
				component.find('Covenant_WF__cRadiusPenalty_WF__c').reInit();
			}
			component.set('v.radiusRestriction.RadiusAppliesTo_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cRadiusAppliesTo_WF__c'))){
				component.find('Covenant_WF__cRadiusAppliesTo_WF__c').reInit();
			}
		},
		changeNoOf : function(component, event, helper) {
			component.set('v.radiusRestriction.RR_Other_WF__c','');
		},
		changeDuration : function(component, event, helper) {
			component.set('v.radiusRestriction.DurationYears_WF__c',0);
			component.set('v.radiusRestriction.Duration_Months__c',0);
		},
		//CoTenancy
		changeCoTenancy : function(component,event,helper){
			var lstCoTenants = component.get('v.lstCoTenants');
			for(var item in lstCoTenants){
				lstCoTenants[item].ConstructionCoTenancy_WF__c=false;
				lstCoTenants[item].OpeningCoTenancy_WF__c=false;
				lstCoTenants[item].OperatingCoTenancy_WF__c=false;
				lstCoTenants[item].PosessionCoTenancy_WF__c=false;
			}
			helper.clearOperatingCoTenancy(component,event);
			helper.clearOpeningCoTenancy(component,event);
			helper.clearConstructionCoTenancy(component,event);
			helper.clearPosessionCoTenancy(component,event);
		},
		changeOperatingCoTenancy : function(component,event,helper){
			helper.clearOperatingCoTenancy(component,event);        
		},
		changeOpeningCoTenancy : function(component,event,helper){
			helper.clearOpeningCoTenancy(component,event);        
		},
		changeConstructionCoTenancy : function(component,event,helper){
			helper.clearConstructionCoTenancy(component,event);        
		},
		changePossessionCoTenancy : function(component,event,helper){
			helper.clearPosessionCoTenancy(component,event);        
		},
		//Common Area Restriction
		changeCommonAreaRestriction: function(component, event, helper){
			component.set('v.commonArRestriction.LandlordPenalty_WF__c',0);
			component.set('v.commonArRestriction.IfCompetingUseNoofFt_WF__c',0);
			component.set('v.commonArRestriction.IfCompetingUseDescription_WF__c','');
			component.set('v.commonArRestriction.Competing_Use_WF__c',false);
			component.set('v.commonArRestriction.RestrictionType_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cRestrictionType_WF__c'))){
				component.find('Covenant_WF__cRestrictionType_WF__c').reInit();
			}
			component.set('v.commonArRestriction.Description_Restriction_Type_WF__c','');
			component.set('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c','');
			if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cAreaRestrictionUnitofMeasure_WF__c'))){
				component.find('Covenant_WF__cAreaRestrictionUnitofMeasure_WF__c').reInit();
			}
			component.set('v.commonArRestriction.LLrighttorenewexisting_WF__c',false);
			component.set('v.commonArRestriction.DistancefromStorefront_WF__c',0);
			component.set('v.commonArRestriction.LLrighttoreplaceexisting_WF__c',false);
			component.set('v.commonArRestriction.Duration_of_Restriction_WF__c',0);
		},
		changeCompetingUse : function(component, event, helper){
			component.set('v.commonArRestriction.IfCompetingUseNoofFt_WF__c',0);
			component.set('v.commonArRestriction.IfCompetingUseDescription_WF__c','');
		 component.set('v.commonArRestrictionError',false);
		},
		//ll relocation 
		changeLLRelocation : function(component, event, helper){
			component.set('v.llRelocationRight.Zone_WF__c',false);
			component.set('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c','');
		},
		changeLLZone : function(component, event, helper){
			component.set('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c','');
		},
		//ll Termination
		changeLLTermination : function(component, event, helper){
			component.set('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c','');
		},
		//No Build Zone
		changeBuildZone : function(component, event, helper) {
			component.set('v.SLR.Zone_WF__c',false);
			component.set('v.SLR.ZoneDetails_WF__c','');
			component.set('v.SLR.DescriptionZone_WF__c','');
		},
		changeZone : function(component, event, helper) {
			component.set('v.SLR.ZoneDetails_WF__c','');
			component.set('v.SLR.DescriptionZone_WF__c','');
		},
		//Exclusive Rights
		changeExclusiveRights : function(component, event, helper) {
			component.set('v.exclusiveRights.ExclRightDescription_WF__c','');
			component.set('v.exclusiveRights.ExclDuration_WF__c','');
			component.set('v.exclusiveRights.ExclRemedyDescription_WF__c','');
		},
		/*** End Clearing logic for Data ***/
		initStoragePicklist : function(component,event){
			component.find('OpportunityStorageTerm_WF__c').reInit();
			component.find('OpportunityStorageType_WF__c').reInit();
		},
		updateStorageDetails : function(component, event, helper){
			component.set('v.opportunity.StorageRentAmount_WF__c',0);
			component.set('v.opportunity.StorageTerm_WF__c','');
			component.set('v.opportunity.StorageElectricityCharge_WF__c',0);
			component.set('v.opportunity.StorageType_WF__c','');
			component.set('v.opportunity.StorageGLA_WF__c',0);
			component.set('v.strStorageProducts','');
			component.set('v.opportunity.StorageAnnualIncrease_WF__c',0);
            component.set('v.strStorageProductIds', []);
		
if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageTerm_WF__c'))){
				component.find('OpportunityStorageTerm_WF__c').reInit();
			}
			if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageType_WF__c'))){
				component.find('OpportunityStorageType_WF__c').reInit();
			}       

			if(!component.get('v.opportunity.StorageReconfiguration_WF__c'))
			{
				component.set('v.bolReconfigStrChange', 'true');
			}

		},
		updateUnitDetails : function(component, event, helper){
			component.set('v.strProducts', '');
			component.set('v.opportunity.GLAUsed_WF__c', 0);
            component.set('v.strProductIds', []);
			if(component.get('v.reconfigBool') == 'N')
			{
				component.set('v.bolReconfigChange', 'true');
			}
		},
		changeOpportunityDeadOtherReason : function(component,event, helper){
			component.set('v.opportunity.OtherReasonOpportunityDead_WF__c','');            
		},
		changeLeaseTerm : function(component, event, helper){
			console.log('update ex date');
			var rcdDate = component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c');
			if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate!=''){
				var drcdDare = new Date(rcdDate + ' 00:00:00');
				var noofDaysinRCDDate = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
				var years = parseInt(component.get('v.opportunity.TermYears_WF__c'));
				var zeroTerm = false;
				if(years<0 || isNaN(years)){
					years =0;
				}
				var months = parseInt(component.get('v.opportunity.TermMonths_WF__c'));
				if(months<0 || isNaN(months)){
					months=0;
				}
				if(years ==0 && months ==0){
					zeroTerm = true;
				}
				var monthsToAdd = years*12+months-1;
				if(monthsToAdd<0)
					monthsToAdd=0;
				if(zeroTerm){
					var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
					var dexpDateZero = new Date(drcdDare-tzoffset);
					component.set('v.opportunity.ExpirationDate_WF__c',dexpDateZero.toISOString().slice(0,10));
				}
				else{
					if(noofDaysinRCDDate == drcdDare.getDate()){
						monthsToAdd = monthsToAdd +1;   
						console.log('monthsToAdd',monthsToAdd);
						if(monthsToAdd%2==1){
							console.log('in if');
							var dexpDate = new Date();
							dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
							//dexpDate.setMonth(drcdDare.getMonth()+monthsToAdd);
							//console.log('ddd',dexpDate);
						}else{
							console.log('in else');
							var dexpDate = new Date();
							dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
							//dexpDate.setMonth(drcdDare.getMonth()+monthsToAdd);
							//dexpDate.setDate(dexpDate.getDate()-1);
						}
					}
					else{
						console.log('in out most else');
						var dexpDate = new Date();
						console.log('curr',dexpDate);
						dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
						console.log('afterMonth',dexpDate);
					}
					var noofDaysinExpDate = new Date(dexpDate.getFullYear(), dexpDate.getMonth()+1, 0).getDate();
					console.log('noofDaysinExpDate',noofDaysinExpDate);
					dexpDate.setDate(noofDaysinExpDate);
					console.log('date after Day',dexpDate);             
					var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
					dexpDate = new Date(dexpDate-tzoffset);
					component.set('v.opportunity.ExpirationDate_WF__c',dexpDate.toISOString().slice(0,10));
				}
                
                if(!$A.util.isUndefinedOrNull(dexpDate)){
					//component.get('v.optionsComponent')[0].updateRenewalStartDate();
                    if(!$A.util.isUndefinedOrNull(component.get('v.optionsComponent'))){
                        var optionComponent = component.get('v.optionsComponent');
                        if(optionComponent.length > 0 && optionComponent[0]){
                            component.get('v.optionsComponent')[0].updateRenewalStartDate();     
                        }
                    }   
                    //component.find('idOptions').updateRenewalStartDate();
                }
			}
		},
		updateLeaseTerm : function(component, event, helper){
			helper.helperUpdateLeaseTerm(component, event);
		},
		passSection : function(component,event){
			var sectionName = event.getParam("section");
			if(component.get('v.'+sectionName)){
				component.set('v.'+sectionName,false); 
				$A.util.addClass(component.find(sectionName), 'slds-hide'); 
			}else{
				component.set('v.'+sectionName,true);   
				$A.util.removeClass(component.find(sectionName), 'slds-hide'); 
			}
		},
		updateConstruction : function(component,event,helper){
			//component.find('CON_landlordConstructionReqComp').updateStartDate();
			component.get('v.llConsComponent')[0].updateStartDate();
			var vOptylease = component.get('v.lease');
			if(vOptylease[0].id == null || vOptylease == null || vOptylease == '' || vOptylease == '{}' )
			{console.log('cont Lease');
				helper.setVacateDate(component, event);
			} 
		},
		holdReasonChange : function(component,event){
		var strDesc = '';
		var strReason = component.get('v.opportunity.HoldReason_WF__c');
			switch(strReason){
			case 'H1':
				strDesc = "Deal not approved by Tenant's REC.";
				break;
			case 'H2':
				strDesc = "Leasing/Development Hold.";
				break;
			 case 'H3':
				strDesc = "Tenant Unresponsive.";
				break;
			 case 'H4':
				strDesc = "Tenant's atty/rep not authorized to work on deal or will not work on deal due to prioritizing other deals first.";
				break;
			 case 'H5':
				strDesc = "Tenant states deal is dead.";
				break;
			 case 'H6':
				strDesc = "Tenant executed deal stalled due to issue with Tenant Entity.";
				break;
			 case 'H7':
				strDesc = "Tenant executed deal stalled out due to Tenant's failure to provide Security Deposit, LOC, other money due, etc.";
				break;
			 case 'H8':
				strDesc = "Other.";
				break;
			 case 'H9':
				strDesc = "JV/Lender approval pending.";
				break;
			 case 'H10':
				strDesc =  	 "Waiting more than 5 business days for a Deal Modification on a Tenant executed document.";
                break;
            case 'H11':
                strDesc = "Client Approval Delayed.";
			}
			component.set('v.HoldDescription', strDesc);
			component.set('v.opportunity.HoldOtherReasonComment_WF__c', '');
		}, 
		passAccount : function(component,event){
			var record = event.getParam("record");
			var fieldValue = event.getParam("fieldValue");
			if(!fieldValue.includes('Guarantor')){
			component.set('v.'+ fieldValue , record);
			}
		},
		clearAccount : function(component,event){
			var fieldValue = event.getParam("fieldValue");
			if(!fieldValue.includes('Guarantor')){
				component.set('v.'+ fieldValue , null);
			}
		},
		changeSecurityType : function(component,event,helper){
			helper.changeSecurityTypeHelper(component,event,helper);
		},
		calculateYear : function(component,event){
			var years = parseInt(component.find('cashHoldYears').get("v.value"));
			var months = parseInt(component.find('cashHoldMonths').get("v.value"));
			var totaltime= years*12+months;
			console.log('totaltime',totaltime);
			component.set('v.totalTime',totaltime);
		},
		calculateWhenTimePeriod : function(component,event){
			var years = parseInt(component.find('whenYears').get("v.value"));
			var months = parseInt(component.find('whenMonths').get("v.value"));
			var totaltime= years*12+months;
			component.set('v.totalTime',totaltime);
		},
		onSelectLeaseTermFields : function(component, event, helper){
			var dtRcd = Number(component.find('rcdEarlier').get('v.value'));
			var dtExp = Number(component.find('expDate').get('v.value'));
			var dtDiff = Math.floor((dtExp - dtRcd)/30); 
			//console.log('In Method Hema');
			if(dtDiff != null){
				//console.log('Check Hema If');
				component.set("v.strLeaseYears",String(Math.floor(dtDiff/12)));
				component.set("v.strLeaseMonths",String(dtDiff%12));
				component.set("v.totalTime",dtDiff);
			}
			else{
				//console.log('Check Hema else');
				component.set("v.strLeaseYears","0");
				component.set("v.strLeaseMonths","0");
			}
			//console.log('Out Method Hema');
		},
		doInit: function(component,event,helper) {
			var opportunity = {};               
            component.set('v.opportunity', opportunity);
            
            if(component.get('v.disabled') !== true){
                component.set('v.BoolSaveDisable', true);    
                component.set('v.BoolValidateDisable', true);
            }
            
			var account ={};
			component.set('v.account', account);
			
			var lease = [];               
			component.set('v.lease', lease);
			
			var arrBudget =[];
			component.set('v.budgets', arrBudget);
			
			component.set('v.lstKickouts', []);
			
			console.log(JSON.stringify(component.get('v.DBACustomer')));
			
			var arrLeaseTermYearsOptions = [];
			var arrLeaseTermMonthsOptions = [];
			var action;
			for(var i=0;i<=25;i++){
				arrLeaseTermYearsOptions.push({ value: String(i), label: String(i) });
                console.log("arrLeaseTermYearsOptions",arrLeaseTermYearsOptions);
			}
			for(var i=0;i<12;i++){
				arrLeaseTermMonthsOptions.push({ value: String(i), label: String(i) });
                console.log("arrLeaseTermMonthsOptions",arrLeaseTermMonthsOptions);
			}
			component.set('v.arrLeaseTermYearsOptions',arrLeaseTermYearsOptions);
			component.set('v.arrLeaseTermMonthsOptions',arrLeaseTermMonthsOptions);
			
			//var action = component.get('c.getRelatedOpportunityDetails');
			var action = component.get('c.getOpportunityDetail');
			
			var idOpportunity = component.get('v.idOpportunity');
			action.setParams({"strOpportunityId" : idOpportunity});
			action.setCallback(this, function(response){
				var isSuccess = response.getState();
				if(isSuccess){
					var result = response.getReturnValue();
					if(result != null){
                        component.set('v.relatedRecord',result);
                        component.set('v.isRecApprover', result.isRecApprover);
						var opportunity = result.opportunity; 
						if($A.util.isUndefinedOrNull(opportunity.Comments_WF__c)){
							opportunity.Comments_WF__c='';
						}
						
						var account = opportunity.B2BCustomer_WF__r;                     
						var legalEntity = opportunity.LegalEntity_WF__r;                     
						if(opportunity.UseClause_WF__c=='' || $A.util.isUndefinedOrNull(opportunity.UseClause_WF__c)){
							if(!$A.util.isUndefinedOrNull(account)){
								opportunity.UseClause_WF__c = account.UseClause_WF__c;   
							}
						}
						console.log('Product details ====> ', result.product); 
						/*if(result)                    
							if(result.product !== undefined){
								component.set('v.product', result.product);
							}
						if(result.storageProduct !== undefined){
							component.set('v.product', result.storageProduct);
						}*/
						if(opportunity.LeaseTerm_WF__c != null){
							if(component.find("whenYears") !== undefined){
								component.find("whenYears").set("v.value", String(Math.floor(opportunity.LeaseTerm_WF__c/12)));
								component.find("whenMonths").set("v.value", String(opportunity.LeaseTerm_WF__c%12));
							}
						}
						else{
							if(component.find("whenYears") !== undefined){
								component.find("whenYears").set("v.value", "0");
								component.find("whenMonths").set("v.value", "0");
							}
						}
												
						//console.log('**',account);
						if(opportunity != null){
							if(opportunity.IsMinimumRent_WF__c){
								component.set('v.IsMinimumRent', true);
                                var unitOfMeasure = opportunity.AnnualGrowthSteptype_WF__c.includes("$") ? "$" : "%"
                                component.set('v.unitOfMeasure',unitOfMeasure );
							}else{
								component.set('v.IsMinimumRent', false);
							}
							if(opportunity.IsOptionsMinimumRent_WF__c){
								component.set('v.IsOptionsMinimumRent', true);
                                var optionsUnitOfMeasure = opportunity.OptionsAnnualGrowthSteptype_WF__c.includes("$") ? "$" : "%"
                                component.set('v.optionsUnitOfMeasure',optionsUnitOfMeasure );
							}else{
								component.set('v.IsOptionsMinimumRent', false);
							}
							
						/*	if(result.lstRentTableWrapper != undefined ){                            
								component.set('v.lstGrowthRateTable', result.lstRentTableWrapper);
								console.log(JSON.stringify(result.lstRentTableWrapper));
								component.set('v.showTable', true);
							}
							
							if(result.lstOptionsRentTableWrapper != undefined ){                            
								component.set('v.lstOptionsTable', result.lstOptionsRentTableWrapper); 
								component.set('v.showOptionsTable', true);
							}
							if(result.lstLeaseRenewalOptionsWrapper != undefined){
								component.set('v.renewalOptions', result.lstLeaseRenewalOptionsWrapper)
							}
						*/	
							component.set('v.parentAccountPrepopulated', opportunity.ParentAccount_WF__c != null ? true : false);
							component.set('v.superParentPrepopulated', opportunity.SuperParent_WF__c != null ? true : false);
							
							component.set('v.Center', opportunity.CenterName_WF__c != null ? opportunity.CenterName_WF__r : null);
							component.set('v.centerForPopup', opportunity.CenterName_WF__c != null ? opportunity.CenterName_WF__r : null);
							
							component.set('v.strProducts', opportunity.ProposedUnitNumber_WF__c);
							component.set('v.strStorageProducts', opportunity.ProposedStorageUnitNumber_WF__c != undefined ? opportunity.ProposedStorageUnitNumber_WF__c : '' );
							
							//component.set('v.defaultDate', result.defaultDate);
							
							if(opportunity.Reconfiguration_WF__c == 'Y'){
								component.set('v.boolReconfiguration' ,true);
							}else{
								component.set('v.boolReconfiguration' ,false);
							}
							if(!$A.util.isUndefinedOrNull(opportunity) &&  !$A.util.isUndefinedOrNull(opportunity.LegalEntity_WF__r)){
								if(opportunity.LegalEntity_WF__r.StateOfIncorporation_WF__c==null || opportunity.LegalEntity_WF__r.StateOfIncorporation_WF__c	==''){
									opportunity.LegalEntity_WF__r.StateOfIncorporation_WF__c = 'None';
								}
								if(opportunity.LegalEntity_WF__r.CompanyLegalType_WF__c ==null || opportunity.LegalEntity_WF__r.CompanyLegalType_WF__c ==''){
									opportunity.LegalEntity_WF__r.CompanyLegalType_WF__c = 'None';
								}
							}
							component.set('v.opportunity',opportunity);
							if(opportunity.Reconfiguration_WF__c=='Y'){
								component.set('v.reconfigBool',true);
							}else{
								component.set('v.reconfigBool',false);
							}                                                
							
							//Charges
							/*if(result.charges !== undefined && result.charges.length!=0){
								component.set('v.Charges',result.charges);
							}
							if(result.chargesRecordTypeMap !== undefined && result.chargesRecordTypeMap.length!=0){
								component.set('v.ChargesRecordType',result.chargesRecordTypeMap);
							}
							if(result.standardCharges !== undefined && result.standardCharges.length!=0){
								component.set('v.StandardCharges',result.standardCharges);
							}
							
							
							component.set('v.budgets', result.budgets != null ? result.budgets : []);
							
							if(result.construction !== undefined ){
								component.set('v.Construction',result.construction);
							}                 
											   
							component.set('v.account',account);
							
							
							if(component.find('CON_capitalComp') !== undefined){
								component.find('CON_capitalComp').init();
							}
							if(component.find('CON_tenantConstructionReqComp') !== undefined){
								component.find('CON_tenantConstructionReqComp').init();
							}
							if(component.find('CON_landlordConstructionReqComp') !== undefined){
								component.find('CON_landlordConstructionReqComp').updateStartDate();
							}
							if(component.find('CH_operatingExpenseComp') !== undefined){
								component.find('CH_operatingExpenseComp').reInit();
							}
							if(component.find('CH_insuranceComp') !== undefined){
								component.find('CH_insuranceComp').reInit();
							}
							if(component.find('CH_foodCourtExpenseComp') !== undefined){
								component.find('CH_foodCourtExpenseComp').reInit();
							}
							if(component.find('CH_promotionalChargesComp') !== undefined){
								component.find('CH_promotionalChargesComp').reInit();
							}
							if(component.find('CH_realEstateTaxComp') !== undefined){
								component.find('CH_realEstateTaxComp').reInit();
							}
							if(component.find('CH_mallChargesComp') !== undefined){
								component.find('CH_mallChargesComp').reInit();
							}
							if(component.find('CH_otherComp') !== undefined){
								component.find('CH_otherComp').reInit();  
							}
                            if(component.find('GI_CurrentTenant_WF') !== undefined){
								component.find('GI_CurrentTenant_WF').reInit();  
							}							
							
							var radiusRestriction = {};
							radiusRestriction.of_WF__c = 'Miles';
							radiusRestriction.RR_Other_WF__c = '';
							radiusRestriction.RadiusDistance_WF__c = 10;
							radiusRestriction.Duration_WF__c = 'Entire Term incl. any Option(s)';
							radiusRestriction.DurationYears_WF__c = '0';
							radiusRestriction.Duration_Months__c = '0';
							radiusRestriction.RadiusPenalty_WF__c = 'Incl. GS From Competing Location (standard);Any Kickout(s) Removed';
							radiusRestriction.RadiusAppliesTo_WF__c = '';
							radiusRestriction.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Radius_Restriction");
							radiusRestriction.RadiusRestriction_WF__c = true;
							
							var ct = {};
							ct.Remedy_WF__c = 'Reduction in Rent';
							ct.RemedyGLARequired_WF__c = 'Reduction in Rent';
							ct.RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
							ct.RemedyotherRequirement_WF__c = 'Reduction in Rent';
							ct.Concurrence_WF__c = 'Or';
							ct.ConcurrenceOpeningGLACTWF__c = 'Or';
							ct.OpeningCoTenancy_WF__c = false;
							ct.OperatingCoTenancy_WF__c = false;
							ct.PosessionCoTenancy_WF__c = false;
							ct.ConstructionCoTenancy_WF__c = false;
							ct.DepartmentStores_WF__c = false;
							ct.NooofDeptStoresatCenter_WF__c = null;
							ct.DefinitionofDeptStoresf_WF__c = '';
							ct.NoofDeptStoresRequired_WF__c = null;
							ct.DescriptionRemedy_WF__c = '';
							ct.IsTenantRequiredtoOpen_WF__c = false;
							ct.NamedStoreCoTenancy_WF__c = '';
							ct.GLARequired_WF__c = false;
							ct.GLAPercent_WF__c = null;
							ct.DescriptionGLARequired_WF__c = '';
							ct.IsTnntreqdtoopenGLAReqd_WF__c = false;
							ct.NamedStoreRequirement_WF__c = false;
							ct.NamedStoreCT_WF__c = '';
							ct.NoofNamedStoresRequired_WF__c = null;
							ct.DescriptionNamedStoreRequirement_WF__c = '';
							ct.IsTntReqdtoOpenNSRqmnt_WF__c = false;
							ct.OtherRequirement_WF__c = false;
							ct.Explanation_WF__c = '';
							ct.DescriptionOtherRequirement_WF__c = '';
							ct.IsTntReqdtoOpenOthrRqmnt_WF__c = false;
							ct.ReplacementTenantDescription_WF__c = '';
							ct.IsTntReqdtoAcceptPosession_WF__c = false;
							ct.IsTenantRequiredToStartConstruction_WF__c = false;
							ct.SalesTest_WF__c = null;
							ct.SalesTestMeasuringPeriod_WF__c = 'Months';
							ct.SalesTestMeasuringPeriodDays_WF__c = null;
							ct.SalesTestMeasuringPeriodMonths_WF__c = null;
							//ct.SizeofDepartmentStore_WF__c = 20000;
							ct.SalesTestMeasuringPeriod_WF__c = 'Months';
							ct.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Co_Tenancy");
							var arrCovenants = [];
							
							var coTenantOperating = JSON.parse(JSON.stringify(ct));
							coTenantOperating.CoTenancyType_WF__c = 'Operating';
							arrCovenants.push(coTenantOperating);
							var coTenantOpening = JSON.parse(JSON.stringify(ct));
							coTenantOpening.CoTenancyType_WF__c = 'Opening';
							arrCovenants.push(coTenantOpening);
							var coTenantConstruction = JSON.parse(JSON.stringify(ct));
							coTenantConstruction.CoTenancyType_WF__c = 'Construction';
							arrCovenants.push(coTenantConstruction);
							var coTenantPosession = JSON.parse(JSON.stringify(ct));
							coTenantPosession.CoTenancyType_WF__c = 'Posession';
							arrCovenants.push(coTenantPosession);
							
							if(result.coTenants !== undefined && result.coTenants != null){
								var opening = false;
								var posession = false;
								
								for(var i=0;i<result.coTenants.length;i++){
									if(result.coTenants[i].CoTenancyType_WF__c == 'Operating'){                                    
										arrCovenants[0] = result.coTenants[i];
									}
									if(result.coTenants[i].CoTenancyType_WF__c == 'Opening'){
										arrCovenants[1] = result.coTenants[i];
										opening = true;
									}
									if(result.coTenants[i].CoTenancyType_WF__c == 'Construction'){
										arrCovenants[2] = result.coTenants[i];
									}
									if(result.coTenants[i].CoTenancyType_WF__c == 'Posession'){
										arrCovenants[3] = result.coTenants[i];
										posession = true;
									}
								}
								
								if(posession == false){
									var coTenant = JSON.parse(JSON.stringify(arrCovenants[1]));
									coTenant.OpeningCoTenancy_WF__c = false;
									coTenant.CoTenancyType_WF__c = 'Posession';
									arrCovenants[3] = coTenant;
								}
							}
							var commonAreaRestriction = {};
							commonAreaRestriction.RestrictionType_WF__c = '--None--';
							commonAreaRestriction.Description_Restriction_Type_WF__c = '';
							commonAreaRestriction.IfCompetingUseNoofFt_WF__c = 0;
							commonAreaRestriction.IfCompetingUseDescription_WF__c = '';
							commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c = '--None--';
							commonAreaRestriction.DistancefromStorefront_WF__c = 0;
							commonAreaRestriction.Duration_of_Restriction_WF__c = 0;
							commonAreaRestriction.LandlordPenalty_WF__c = 0;
							commonAreaRestriction.CommonAreaRestrictions_WF__c = false;
							commonAreaRestriction.Competing_Use_WF__c = false;
							commonAreaRestriction.LLrighttorenewexisting_WF__c = false;
							commonAreaRestriction.LLrighttoreplaceexisting_WF__c = false;
							commonAreaRestriction.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Common_Area_Restrictions_WF");
							
							var llRelocationRight = {};
							llRelocationRight.StandardRelocationRights_WF__c = true;
							llRelocationRight.Zone_WF__c = false;
							llRelocationRight.IfNoRelocationRightsDescription_WF__c = '';
							llRelocationRight.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Landlord_Relocation_Rights_WF");
							component.set('v.lstCoTenants',arrCovenants);
							component.set('v.lease', (result.lease != null && result.lease != 'undefined') ? result.lease  : '{}');
							if($A.util.isUndefinedOrNull(result.lease))
							{console.log('vd0.1');
								helper.setVacateDate(component);
							}
			
							component.set('v.noOfKickouts', result.covenants != null ? result.covenants.length : 0);
							//component.set('v.boolRadiusRestriction', true);
							component.set('v.lstKickouts', result.covenants != null ? result.covenants : []);
							component.set('v.otherCovenant', result.other != null ? result.other:{"CovenantComments_WF__c":"","RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Other")});
							component.set('v.exclusiveRights', result.exclusiveRight != null ? result.exclusiveRight:{"DoesTnthaveanExclusiveRight_WF__c":false,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Exclusive_Right"),ExclDuration_WF__c:null,ExclRightDescription_WF__c:"",ExclRemedyDescription_WF__c:""});
							component.set('v.SLR', result.SLR != null ? result.SLR:{"NoBdZneSiteLnRestrnLsngRestrn_WF__c":false,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_SLR"),Zone_WF__c:false,ZoneDetails_WF__c:"",DescriptionZone_WF__c:""});
							component.set('v.landlordTerminationtionRight', result.landlordTerminationRights != null ? result.landlordTerminationRights:{"StandardTerminationRights_WF__c":true,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Landlord_Termination_Rights"),TerminationRightsDescription_WF__c:""});
							component.set('v.radiusRestriction', result.radiusRestrictions != null ? result.radiusRestrictions : radiusRestriction);
							component.set('v.commonArRestriction',result.commonAreaRestrictions != null ? result.commonAreaRestrictions : commonAreaRestriction);
							component.set('v.llRelocationRight', result.llRelocationRights != null ? result.llRelocationRights : llRelocationRight);
						*/   
							var securityType = result.opportunity.SecurityType_WF__c;
							securityType = String(securityType);
							
							if(securityType == '--None--' || securityType == ''){
								component.set('v.IsCashDeposit', false);
								component.set('v.IsGuarantor', false);
								component.set('v.IsLetterOfCredit', false);
							}
							else {
								
								if(securityType.includes("Cash Deposit")){
                                   
                                    component.set('v.IsCashDeposit', true); 
                                    if(!$A.util.isUndefinedOrNull(result.opportunity.Hold_Cash_Deposit_For_WF__c)){
                                        var years = String(Math.floor(result.opportunity.Hold_Cash_Deposit_For_WF__c/12));
                                        var months = String(Math.floor(result.opportunity.Hold_Cash_Deposit_For_WF__c%12));
                                        if( opportunity.Hold_Cash_Deposit_For_Amendment_WF__c == 'Other'){
                                            if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears'))){
                                                component.find('cashHoldYears').set('v.value', years);
                                            }
                                            if(!$A.util.isUndefinedOrNull(component.find('cashHoldMonths'))){
                                                component.find('cashHoldMonths').set('v.value', months);     
                                            }   
                                        }                                                                                
                                    }
								}else {
									component.set('v.IsCashDeposit', false);
								}
								if(securityType.includes("Letter of Credit")){            
									
							var lstLOC = component.get('v.lstLOC');
							var count = 1;
							for(var i = 1 ; i <= 5 ; i++){                         
								var objLOC = {};
								var letterCredit = 'LetterofCredit_'+i+'_WF__c';  
								var bankAddress  = 'BankAddress_'+i+'_WF__c';                
								var hoc 		 = 'HoldLOCFor_'+i+'_WF__c';
								var identifyBank = 'IdentifyBank_'+i+'_WF__c';
								var locComments = 'LOCComments_'+ i+'_WF__c';
								var hocAmd		 = 'Hold_LOC_For_'+i+'_Amendment_WF__c';
								if(typeof result.opportunity[hoc] !== "undefined" && typeof result.opportunity[letterCredit] !== "undefined" && 
								   result.opportunity[hoc] !== '' && result.opportunity[letterCredit] !== '' && result.opportunity[letterCredit] > 0){
									objLOC.LetterofCredit = result.opportunity[letterCredit];
									objLOC.BankAddress =  result.opportunity[bankAddress];
									if(typeof result.opportunity[hoc] !== "undefined" && result.opportunity[hoc] !== null && result.opportunity[hoc] !== ''){
										objLOC.years = String(Math.floor(result.opportunity[hoc]/12));
										objLOC.months = String(result.opportunity[hoc]%12);
									}
									objLOC.IdentifyBank = result.opportunity[identifyBank];
									objLOC.LOCComments = result.opportunity[locComments];
                                    objLOC.holdLOCFor = result.opportunity[hocAmd];
									objLOC.count = count;
                                    console.log("LstLOC 1",lstLOC);
									lstLOC.push(objLOC);
                                    console.log("LstLOC",lstLOC);
									count = count + 1;
								}
							}
							component.set('v.lstLOC', lstLOC);
							component.set('v.LetterOfCreditBool', true);
							component.set('v.noOfletterOfCredit' , lstLOC.length);
																			
									component.set('v.IsLetterOfCredit', true);
								}else{
									component.set('v.IsLetterOfCredit', false);
								}
								if(securityType.includes("Guarantor")){            
									if(result.guarantors !== undefined){
										var guarantors = result.guarantors;
										var updatedGuarantors = [];
										for(var each in guarantors){
											var eachG = {};
											eachG = JSON.parse(JSON.stringify(guarantors[each]));
                                            //Joshna, 18/10/2017 - INC0038047
                                            eachG.stateOfIncorp = $A.util.isUndefinedOrNull(guarantors[each].RelatedAccount_WF__r) ? '' : guarantors[each].RelatedAccount_WF__r.StateOfIncorporation_WF__c;
											//Need to convert this string as the "set" for ui:inputseectOption doesn't work if it's not of the same data type
											if(guarantors[each].Years_WF__c !== undefined && guarantors[each].Years_WF__c !== null && guarantors[each].Years_WF__c !== '')
												eachG.Years_WF__c = String(guarantors[each].Years_WF__c);
											if(guarantors[each].Months_WF__c !== undefined && guarantors[each].Months_WF__c !== null && guarantors[each].Months_WF__c !== '')
												eachG.Months_WF__c = String(guarantors[each].Months_WF__c);
											updatedGuarantors.push(eachG);
                                            console.log("updatedGuarantors",updatedGuarantors);
										}
										component.set('v.guarantor', updatedGuarantors);
										component.set('v.GuarantorBool', true);
										component.set('v.noOfGuarantor',guarantors.length);
									}
									component.set('v.IsGuarantor', true);            
									
								}else{
									component.set('v.IsGuarantor', false);            
								}
							} 
							var yearPickValue = [];
							var monthPickValue = [];
							for(var i=0;i<=25;i++){
								yearPickValue.push({ value: String(i), label: String(i) });
                                console.log("yearPickValue",yearPickValue);
							}
							for(var i=0;i<12;i++){
								monthPickValue.push({ value: String(i), label: String(i) });
                                      console.log("monthPickValue",monthPickValue);
							}
							component.set('v.yearPickValue',yearPickValue);
							component.set('v.monthPickValue',monthPickValue);
                            if(!$A.util.isUndefinedOrNull(component.find('coDetailsComp'))){ 
			 					component.find('coDetailsComp').reInit();
						 }
                            helper.lazyLoadComponents(component, helper, result);                            
						}
					}			
				}
			});
			$A.enqueueAction(action);
			
		},
		saveOpportunities  : function(component, event,helper){
            var validationError=false;
            console.log('sjsjhd',JSON.stringify(component.get('v.Charges')));
			component.set('v.BoolSaveDisable',true);
            if(helper.commonValidations(component)){
                validationError=true;
        }
        if(helper.validateComponentTextField(component)){
            validationError=true;
        }
        var recApprovalStatus = component.get("v.opportunity.REC_Approval_Status_WF__c");
        var recApprovalStatusComments = component.get("v.opportunity.REC_Comments_WF__c");
        if((recApprovalStatus == 'Reject'|| recApprovalStatus == 'On Hold') && recApprovalStatusComments == ''){
            component.set('v.CO_detailsError', true);
            component.set('v.recCommentsRejectError', true);
                validationError=true;
            }
        else {
            component.set('v.CO_detailsError', false);
            component.set('v.recCommentsRejectError', false);
        }
            component.set('v.DealValidated', false);
            helper.getSecurityDepositDetails(component, false);
             if(component.get('v.showErrors') ||component.get('v.showGuarantorErrors')||validationError){
            component.set('v.BoolSaveDisable',false);
            if(component.get('v.showErrors') ||component.get('v.showGuarantorErrors'))
            {
                component.set('v.GI_securitySectionError',true);
            }else{
            	component.set('v.GI_securitySectionError',false);
            } 
            return;
        }
        helper.saveOpporHelper(component, event,helper);
    },
    oppoValidate  : function(component, event,helper){
        component.set('v.SaveAndValidateClicked', true);
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var validated=false;
        helper.getSecurityDepositDetails(component, true);
        /*check if all the required fields are filled*/
        console.log('sssCharges',component.get( 	'v.Charges'));
        if(helper.checkRequiredFieldsHelper(component, event)){
            console.log('saveOpportunities - if-->');
            /*if(helper.validateCovenantTextField(component)){
					return;	
                }else{
                    return;
                }*/
            validated=true;
        }
        if(helper.validateComponentTextField(component))
        {
            console.log('saveOpportunities - if-->2');
            validated=true;
        }
        
        if(validated)
        {
            return;   
        }
        else{
            console.log('inside else');
            component.set('v.BoolValidateDisable',true);
            component.set('v.DealValidated', true);
            helper.saveOpporHelper(component, event,helper);
        }
        
    },
		handleCancel : function(cmp,eve){
			console.log(cmp.get('v.Center'));
			if( (typeof sforce != 'undefined') && (sforce != null) ) {                    		                        
				sforce.one.navigateToSObject(cmp.get('v.idOpportunity')); 
			}
			/*back up if - sforce.one.navigateToSObject(recordId) code fails */
			else{                    		
				var urlOpptyDetailPage = "/one/one.app#/sObject/"+cmp.get('v.idOpportunity')+"/view";
				window.open(urlOpptyDetailPage,"_self");
			}
		},
		showGrowthRateTable : function(cmp, eve){        
			var lstGrowthRate = JSON.parse(JSON.stringify(cmp.get('v.lstGrowthRateTable')));
			var objGrowthRateTable = {};
			objGrowthRateTable.startDate = '05/01/2017';
			objGrowthRateTable.endDate = '01/31/2018';
			objGrowthRateTable.step = 1;
			objGrowthRateTable.increasePercent = null;
			objGrowthRateTable.annualizedRent = 100000;
			objGrowthRateTable.selectRent = false;
			lstGrowthRate.push(objGrowthRateTable);
			cmp.set('v.lstGrowthRateTable', lstGrowthRate);        
			cmp.set('v.showGrowthRateTable', 'true');
		}, 
		showBlendedTable : function(cmp, eve){        
			var BlendedTable = JSON.parse(JSON.stringify(cmp.get('v.BlendedTable')));
			var objBlendedTable = {};
			objBlendedTable.startDate = '05/01/2017';
			objBlendedTable.endDate = '01/31/2018';
			objBlendedTable.step = 1;
			objBlendedTable.increasePercent = null;
			objBlendedTable.annualizedRent = 100000;
			objBlendedTable.selectRent = false;
			BlendedTable.push(objBlendedTable);
            console.log("BlendedTable",BlendedTable);
			cmp.set('v.BlendedTable', BlendedTable);        
			cmp.set('v.showBlendedTable', 'true');
		},
		showOverageRentTable : function(cmp, eve){        
			var OverageRentTable = JSON.parse(JSON.stringify(cmp.get('v.OverageRentTable')));
			var objOverageRentTable = {};
			objOverageRentTable.startDate = '05/01/2017';
			objOverageRentTable.endDate = '01/31/2018';
			objOverageRentTable.step = 1;
			objOverageRentTable.increasePercent = null;
			objOverageRentTable.annualizedRent = 100000;
			objOverageRentTable.selectRent = false;
			OverageRentTable.push(objOverageRentTable);
            console.log("OverageRentTable",OverageRentTable);
			cmp.set('v.OverageRentTable', OverageRentTable);        
			cmp.set('v.showOverageRentTable', 'true');
		},
		showProducts : function(cmp, eve, helper){console.log('is popup set?');                    
												  cmp.set('v.showProductsPopup', 'true'); 
												  cmp.set('v.boolUnitConfig', 'true');          
												 },
		showStorageProducts : function (cmp, eve, helper){
			cmp.set('v.showStorageProductsPopup', 'true'); 
			cmp.set('v.boolUnitConfig', 'true');    
		},
		displayGLAFields : function(component, event, helper) {
			var reconfig = component.get('v.opportunity.Reconfiguration_WF__c');
			if(reconfig){
				var unitConfig = [];
				component.set('v.remainingGLAProducts', unitConfig);
				component.set('v.selectedUnits',unitConfig);
				component.set('v.boolMerge',false);
				
			}else if(!reconfig){
				var unitConfig = [];
				component.set('v.unitConfig',unitConfig);
				component.set('v.remainingGLAProducts', unitConfig);
				component.set('v.selectedUnits',unitConfig);
			}
		},
		addKickout : function(component,event){ 
			if(component.get('v.noOfKickouts')<5){
				component.set('v.noOfKickouts',component.get('v.noOfKickouts')+1);
				var objKickout = {};    
				var lstKickouts = component.get('v.lstKickouts');
				objKickout.Id = null;            
				objKickout.TypeofKickout_WF__c = 'Mutual';
				objKickout.MeasuringPeriod_WF__c = '25-36';
				objKickout.OtherDescription_WF__c = '';
				objKickout.LandlordSalesThreshold_WF__c = null;
				objKickout.TenantSalesThreshold_WF__c = null;
				objKickout.NoticePerioddays_WF__c = null;
				objKickout.TerminationEffectivefromNoticeDate_WF__c = null;
				objKickout.IfTenantkickspaybackTACommiss_WF__c = false;
				objKickout.Unamortizedpaybacktype_WF__c = '$';
				objKickout.Unamortizedpaybackamount_WF__c = 0;
				objKickout.Paybackunamoritzedleaseholdimprovemen_WF__c = false;
				objKickout.Unamoritzedleaseholdimprovementtype_WF__c = '$';
				objKickout.Unamoritzedleaseholdimprovementamount_WF__c  = 0;
				objKickout.Unamortizedpaybackpercent_WF__c = 0;
				objKickout.Unamoritzedleaseholdimprovementper_WF__c  = 0;
				objKickout.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Kickout");
				
				component.set('v.lstKickouts', lstKickouts);
				var action = component.get('c.getExpiryDate');
				action.setParams({
					'strRcd' : component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c'),
					'kickouts' : '['+JSON.stringify(objKickout)+']'
				});
				action.setCallback(this, function(response){
					var result = response.getReturnValue();
					objKickout.StartDate_WF__c = result[0].StartDate_WF__c;
					objKickout.EndDate_WF__c = result[0].EndDate_WF__c;
					lstKickouts.push(objKickout);
					component.set('v.lstKickouts',lstKickouts);
                    console.log('I am here in add kickout before fetch picklist is set in variable');
                    
					var fetchPickList = $A.get("e.c:fetchPicklist");
					console.log('I am here in add kickout after fetch picklist is set in variable');
                    fetchPickList.fire();     
                    console.log('I am here in add kickout after fetch picklist is fired');
				});
				console.log('I am here in add kickout before fetch picklist');
                $A.enqueueAction(action);
				console.log('I am here in add kickout after fetch picklist');
			}
		},
		deleteKickout : function(component,event){ 
			if(component.get('v.noOfKickouts')>0){
				var lstKickouts = component.get("v.lstKickouts");
				var deleteKickout = lstKickouts.pop();
				var deleteKickoutList = component.get('v.kickoutToDelete');
				if(!$A.util.isUndefinedOrNull(deleteKickout.Id)){
					deleteKickoutList.push(deleteKickout.Id);
					component.set('v.kickoutToDelete',deleteKickoutList);   
				}
				component.set("v.lstKickouts", lstKickouts);
				component.set('v.noOfKickouts',component.get('v.noOfKickouts')-1);
			}
		},
		enableHelpTextdescriptionRemedy : function(component, event, helper){
			component.set('v.showHelpTextDesRem',true);
		},
		enableHelpTextDesGLA : function(component, event, helper){
			component.set('v.showHelpTextDesGLA',true);
		},
		enableHelpTextdescriptionNSR : function(component, event, helper){
			component.set('v.showHelpTextDesNSR',true);
		},
		enableHelpTextdescriptionOR : function(component, event, helper){
			component.set('v.showHelpTextDesRemOR',true);
		},
		enableHelpTextdesExclRemedy : function(component, event, helper){
			component.set('v.showHelpTextDesExclRemedy',true);
		},
		enableHelpTextdesSLR : function(component, event, helper){
			component.set('v.showHelpTextDesSLR',true);
		},
		enableHelpTextdesSTR : function(component, event, helper){
			component.set('v.showHelpTextDesSTR',true);
		},
		enableHelpTextSRR : function(component, event, helper){
			component.set('v.showHelpTextSRR',true);
		},
		enableHelpTextCAR : function(component, event, helper){
			component.set('v.showHelpTextCAR',true);
		},
		disableHelpText : function(component, event, helper){
			component.set('v.showHelpTextDesRem',false);
			component.set('v.showHelpTextDesGLA',false);
			component.set('v.showHelpTextDesNSR',false);
			component.set('v.showHelpTextDesRemOR',false);
			component.set('v.showHelpTextDesExclRemedy',false);
			component.set('v.showHelpTextDesSLR',false);
			component.set('v.showHelpTextDesSTR',false);
			component.set('v.showHelpTextSRR',false);
			component.set('v.showHelpTextCAR',false);
		},
		calculateStartAndEndDate : function(component, event, helper){
			
            helper.updateStandardChargesHelper(component);
			var action = component.get('c.getExpiryDate');
			action.setParams({
				'strRcd' : component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c'),
				'kickouts' : JSON.stringify(component.get('v.lstKickouts'))
			});
			action.setCallback(this, function(response){
				var result = response.getReturnValue();
				for(var i=0; i<component.get('v.lstKickouts').length;i++){
					component.set('v.lstKickouts['+i+'].StartDate_WF__c',result[i].StartDate_WF__c);
					component.set('v.lstKickouts['+i+'].EndDate_WF__c',result[i].EndDate_WF__c);
				}
			});
			$A.enqueueAction(action);    	
			helper.helperUpdateLeaseTerm(component, event);
        helper.updateBudgetData(component,event);
		},
		validateExclDuration : function(component, event, helper){
			var exclDuration = component.get('v.exclusiveRights.ExclDuration_WF__c');
			
			if(exclDuration != null && exclDuration.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]"))
			{
				$A.util.removeClass(component.find("exclDurationSpecCharErrorId"), 'slds-hide');
				//boolIsreqFiledEmpty = true;
			}
			else
			{
				$A.util.addClass(component.find("exclDurationSpecCharErrorId"), 'slds-hide');
			}
		},
		onRestrictionTypeChange : function(component, event, helper){
			var restrictionTypeStr = '';
			var commonArRestriction=component.get('v.commonArRestriction');
			if(component.get('v.commonArRestriction.RestrictionType_WF__c') !== undefined){
				restrictionTypeStr = component.get('v.commonArRestriction.RestrictionType_WF__c');
			}
			var boolRestrictionTypeOther = false;
			if(restrictionTypeStr.includes("Other")){
				boolRestrictionTypeOther = true;
			}else{
           if(!$A.util.isUndefinedOrNull(commonArRestriction.Description_Restriction_Type_WF__c))
           {
               commonArRestriction.Description_Restriction_Type_WF__c='';
           }
        }
			component.set('v.boolRestrictionTypeOther', boolRestrictionTypeOther);
		},
		
		setSecurityType:function(component, eve, helper) {
			helper.setSecurityTypeHelper(component, event,"change",null);        
				
			
		},
		
		validateForNegativeValues:function(component, eve, helper){
        var ACDBEParticipation = component.get('v.opportunity.ACDBEParticipationPercentage_WF__c');
        if(ACDBEParticipation <0){
            console.log('if');
            $A.util.removeClass(component.find("ACDBEParticipationErr"), 'slds-hide');
        }
        else{
            console.log('else');
            $A.util.addClass(component.find("ACDBEParticipationErr"), 'slds-hide');
        }
			var storagePercent = component.get('v.opportunity.StorageAnnualIncrease_WF__c');
			console.log('STP : ',storagePercent);
			if(storagePercent >= 0 ){
				$A.util.addClass(component.find("StorageAnnualIncreaseErrorId"),'slds-hide');
				console.log('STP pass');
			}
			else{
				$A.util.removeClass(component.find("StorageAnnualIncreaseErrorId"),'slds-hide');
				console.log('STP fail');
			}
			console.log('entered onchange negative values method-->');
			//Co-Tenancy section fields
			var coTenants = component.get('v.lstCoTenants');
			
			if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
				for(var i=0; i<coTenants.length; i++){
					if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true)){
						if(coTenants[i].OperatingCoTenancy_WF__c == true){
							//check for Sales Test (decrease by %) not negative
							if(coTenants[i].SalesTest_WF__c != '' && coTenants[i].SalesTest_WF__c != null && coTenants[i].SalesTest_WF__c <0){
								console.log('salesTestDecrease negative-->',i);
								$A.util.removeClass(document.getElementById('salesTestDecreaseNegativeId' + i), 'slds-hide');
							}else{
								$A.util.addClass(document.getElementById('salesTestDecreaseNegativeId' + i), 'slds-hide');
							}
						}
						
						//check for GLA % not negative
						if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].GLAPercent_WF__c != '' && coTenants[i].GLAPercent_WF__c != null && coTenants[i].GLAPercent_WF__c <0)){
							console.log('gla % negative-->',i);
							$A.util.removeClass(document.getElementById('glaPercentNegativeId' + i), 'slds-hide');
						}else{
							$A.util.addClass(document.getElementById('glaPercentNegativeId' + i), 'slds-hide');
						}
					}
				}
			}
			
			//Charges section fields
			var charges = component.get('v.Charges');
			
			if(charges.length >=1){
				//check for Op. Exp. Fixed Increase not negative
				if(charges[0].Exp_Rate_Adjustment_Type_WF__c == 'Fixed' && charges[0].Exp_Fixed_Increase_WF__c != '' && charges[0].Exp_Fixed_Increase_WF__c != null && charges[0].Exp_Fixed_Increase_WF__c <0){
					console.log('Op. Exp. Fixed Increase negative-->');
					$A.util.removeClass(component.find("opExpFixedIncNegativeId"), 'slds-hide');
				}else{
					$A.util.addClass(component.find("opExpFixedIncNegativeId"), 'slds-hide');
				}
			}
			
			if(charges.length >=3){
				//check for FC Exp. % of Sales not negative
				if(charges[2].Exp_Rate_FCAdjustment_Type_WF__c == '% of Sales' && charges[2].FC_Exp_Per_of_Sales_WF__c != '' && charges[2].FC_Exp_Per_of_Sales_WF__c != null && charges[2].FC_Exp_Per_of_Sales_WF__c <0){
					console.log('FC Exp. % of Sales negative-->');
					$A.util.removeClass(component.find("fcExpPercentSalesNegativeId"), 'slds-hide');
				}else{
					$A.util.addClass(component.find("fcExpPercentSalesNegativeId"), 'slds-hide');
				}
				
				//check for FC Exp. Fixed Increase not negative
				if(charges[2].Exp_Rate_FCAdjustment_Type_WF__c == 'Fixed' && charges[2].Exp_Fixed_Increase_WF__c != '' && charges[2].Exp_Fixed_Increase_WF__c != null && charges[2].Exp_Fixed_Increase_WF__c <0){
					console.log('FC Exp. Fixed Increase negative-->');
					$A.util.removeClass(component.find("fcExpFixedIncNegativeId"), 'slds-hide');
				}else{
					$A.util.addClass(component.find("fcExpFixedIncNegativeId"), 'slds-hide');
				}
			}
			
			if(charges.length >=5){
				//check for Tax Fixed Increase not negative
				if(charges[4].Charge_Type_Oth_WF__c == true && charges[4].Exp_Rate_TaxAdjustment_Type__c == 'Fixed' && charges[4].Tax_Income_Type_WF__c =='%' && charges[4].Exp_Fixed_Increase_WF__c != '' && charges[4].Exp_Fixed_Increase_WF__c != null && charges[4].Exp_Fixed_Increase_WF__c <0){
					console.log('Tax Fixed Increase negative-->');
					$A.util.removeClass(component.find("taxFixedIncNegativeId"), 'slds-hide');
				}else{
					$A.util.addClass(component.find("taxFixedIncNegativeId"), 'slds-hide');
				}
			}
			
			var kickouts = component.get('v.lstKickouts');
			console.log('checking kickouts');
			for(var iter=0; iter<kickouts.length;iter++){
				console.log('checking kickouts for loop' , kickouts[iter].Unamortizedpaybackamount_WF__c);
				if((kickouts[iter].Unamortizedpaybackpercent_WF__c != null && kickouts[iter].Unamortizedpaybackpercent_WF__c != '' && kickouts[iter].Unamortizedpaybackpercent_WF__c < 0 ) ||
						(kickouts[iter].Unamortizedpaybackamount_WF__c != null && kickouts[iter].Unamortizedpaybackamount_WF__c != '' && kickouts[iter].Unamortizedpaybackamount_WF__c < 0 )){
					$A.util.removeClass(document.getElementById('UnamortizedpaybackamountErrorId' + iter), 'slds-hide');
				}
				else{
					$A.util.addClass(document.getElementById('UnamortizedpaybackamountErrorId' + iter), 'slds-hide');
				}
				if((kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c !=null && kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c!= '' && kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c < 0 ) ||
						(kickouts[iter].Unamoritzedleaseholdimprovementamount_WF__c !=null && kickouts[iter].Unamoritzedleaseholdimprovementamount_WF__c!= '' && kickouts[iter].Unamoritzedleaseholdimprovementamount_WF__c < 0 )){
					$A.util.removeClass(document.getElementById('LeaseholdimprovementErrorId'+iter), 'slds-hide');
				}
				else{
					$A.util.addClass(document.getElementById('LeaseholdimprovementErrorId'+iter), 'slds-hide');
				}
			}

		}, 
		
		setVacateDate  : function(component, event, helper){
			var vOptylease = component.get('v.lease');
			if((vOptylease[0] != null && vOptylease[0].Id == null) || vOptylease == null || vOptylease == '' || vOptylease == '{}' )
			{console.log('cont Lease');
				helper.setVacateDate(component, event);
			} 
		}, 
		
		docTypeManualOverride:function(component, eve, helper){
			var boolDocTypeManualOverride = true; 
			component.set('v.opportunity.DocTypeManualOverride_WF__c', boolDocTypeManualOverride);        
            helper.updateStandardChargesHelper(component);
		},
		onUnitChange:function(component, eve, helper){
			console.log('Inside Unit change');
			component.set('v.lease', '{}');
            if(!component.get('v.disabled'))
                helper.updateStandardChargesHelper(component);
		},
		onStorageChange : function(component,event,helper){
			if(component.get('v.opportunity.Storage_WF__c')){
				console.log('storage changed');
				component.set('v.opportunity.StorageAnnualIncrease_WF__c',0.05);
			}
		},
    changeOtherRequirement : function(component,event,helper){        
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                	coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTntReqdtoOpenOthrRqmnt_WF__c = false;
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTenantRequiredToStartConstruction_WF__c = false;
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){                
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTntReqdtoAcceptPosession_WF__c = false;
                }
                
            }
        }
    },
    changeNamedStoreRequirement : function(component,event,helper){
    var coTenants = component.get('v.lstCoTenants');
    if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
    	for(var i=0; i<coTenants.length; i++){
    		if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
            	coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
             if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
    			coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
                coTenants[i].IsTntReqdtoOpenNSRqmnt_WF__c = false;
			}
            if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
                coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
			if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){                
           		coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
 		}
 	}
 	},
    changeMajorTenants : function(component,event,helper){
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].IsTenantRequiredtoOpen_WF__c=false;
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
            }
        }
    },
    
    changeGLARequired : function(component,event,helper){
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].IsTnntreqdtoopenGLAReqd_WF__c=false;
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
            }
        }
    } 
	})