({
   /*
    * Modification Log
    * -------------------------------------------------------------------------------------------------------
    * Name              Date            Comments
    * --------------    ------------    ---------------------------------------------------------------------
    * Arut              08/21/2018      Changes for GDM-8354: Clearing out milestone dates on opportunity
    * 
    * */ 

    updateStandardChargesHelper : function(component){
        var documentType = component.get('v.opportunity.Document_Type_WF__c');
        var rcdDate = component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c');
        var charges = component.get('v.Charges');
        var GLA = component.get('v.opportunity.GLAUsed_WF__c');
        var productId ='';
        console.log('GLAGLAGLAGLAGLA',GLA);
        if(!$A.util.isUndefinedOrNull(component.get('v.product'))){
            productId = component.get('v.product').Id; 
        }
        console.log('productId',productId,rcdDate);
        var action = component.get('c.getStandardChargesFly');
        action.setParams({
            "RCDDate" : rcdDate,
            "UnitId" : productId,
            "GLA" : GLA,
            "charges" : JSON.stringify(charges),
            "DocumentType" : documentType
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            console.log('isSuccess',isSuccess);
            if(isSuccess){
                var result = response.getReturnValue();
                console.log(result);
                if(result != null){
                    component.set('v.Charges',result);
                    $A.createComponent(
                        "c:CHoperatingExpense",
                        {
                            "aura:id": "CH_operatingExpenseComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "error": component.getReference("v.CH_operatingExpenseError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(opChargesCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var opChCmp = [];
                                opChCmp.push(opChargesCmp);
                                component.set('v.opChargeComponent', opChCmp);
                                opChargesCmp.reInit();
                                opChargesCmp.changeUnit();
                                if(!component.get('v.disabled'))
                                    opChargesCmp.calculateVariance();
                            }
                        }
                    );
                    console.log(component.getReference("v.Charges"));
                    $A.createComponent(
                        "c:CHinsurance",
                        {
                            "aura:id": "CH_insuranceComp",
                            "disabled": component.getReference("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "error": component.getReference("v.CH_insuranceError")
                        },
                        function(insuranceCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var insCmp = [];
                                insCmp.push(insuranceCmp);
                                component.set('v.insuranceComponent', insCmp);
                                insuranceCmp.reInit();                                           
                                if(!component.get('v.disabled'))
                                    insuranceCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHfoodCourtExpense",
                        {
                            "aura:id": "CH_foodCourtExpenseComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "error": component.getReference("v.CH_foodCourtExpenseError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(fcCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var fdCrtCmp = [];
                                fdCrtCmp.push(fcCmp);
                                component.set('v.fcComponent', fdCrtCmp);
                                fcCmp.reInit();
                                fcCmp.changeUnit();
                                if(!component.get('v.disabled'))
                                    fcCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHpromotionalCharges",
                        {
                            "aura:id": "CH_promotionalChargesComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "error": component.getReference("v.CH_promotionalChargesError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(pCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var promoCmp = [];
                                promoCmp.push(pCmp);
                                component.set('v.promoComponent', promoCmp);
                                pCmp.reInit();
                                pCmp.changeUnit();
                                if(!component.get('v.disabled'))
                                    pCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHrealEstateTax",
                        {
                            "aura:id": "CH_realEstateTaxComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "taxDescLengthErr":component.getReference("v.taxDescLengthErr"),
                            "error": component.getReference("v.CH_realEstateTaxError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(reCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var rEstateCmp = [];
                                rEstateCmp.push(reCmp);
                                component.set('v.realEstComponent', rEstateCmp);
                                reCmp.reInit();
                                reCmp.changeUnit();
                                if(!component.get('v.disabled'))
                                    reCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHmallCharges",
                        {
                            "aura:id": "CH_mallChargesComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "error": component.getReference("v.CH_mallChargesError"),
                            "result": component.getReference("v.relatedRecord"),
                            "WaterError": component.getReference("v.WaterError"),
                            "FDSError": component.getReference("v.FDSError"),
                            "ElectricityError": component.getReference("v.ElectricityError"),
                            "TrashError": component.getReference("v.TrashError"),
                            "EncldMallError": component.getReference("v.EncldMallError"),
                            "HVACError": component.getReference("v.HVACError"),
                            "ParkingError": component.getReference("v.ParkingError"),
                            "Other1Error": component.getReference("v.Other1Error"),
                            "Other2Error": component.getReference("v.Other2Error"),
                            "OtherDes1Error": component.getReference("v.OtherDes1Error"),
                            "OtherDes2Error": component.getReference("v.OtherDes2Error"),
                            "OtherDes3Error": component.getReference("v.OtherDes3Error"),
                            "Other3Error": component.getReference("v.Other3Error")
                        },
                        function(mallCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var mCmp = [];
                                mCmp.push(mallCmp);
                                component.set('v.mallComponent', mCmp);
                                mallCmp.reInit();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHother",
                        {
                            "aura:id": "CH_otherComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": component.getReference("v.Charges"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "error": component.getReference("v.CH_otherError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(otherCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var oCmp = [];
                                oCmp.push(otherCmp);
                                component.set('v.otherChargeComponent', oCmp);
                                otherCmp.reInit();
                            }
                        }
                    );
                    console.log('tesing charges',component.get('v.Charges'));
                }
            }
        });
        if(!$A.util.isUndefinedOrNull(component.get('v.product')) && !$A.util.isEmpty(charges) ){
            $A.enqueueAction(action);
        }
    },
    changeSecurityTypeHelper : function(component, event, operation) {
        if(component.find("OpportunitySecurityType_WF__c").get("v.value")=="Letter of Credit"){
            component.set("v.LetterOfCreditBool", true);
            component.set("v.CashDepositBool", false);
            component.set("v.GuarantorBool", false);
        }else if(component.find("OpportunitySecurityType_WF__c").get("v.value")=="Cash Deposit"){
            component.set("v.LetterOfCreditBool", false);
            component.set("v.CashDepositBool", true);
            component.set("v.GuarantorBool", false); 
            component.find("cashHoldYears").set("v.value", component.find("whenYears").get("v.value"));
            component.find("cashHoldMonths").set("v.value", component.find("whenMonths").get("v.value"));
        }else if(component.find("OpportunitySecurityType_WF__c").get("v.value")=="Guarantor"){
            component.set("v.LetterOfCreditBool", false);
            component.set("v.CashDepositBool", false);
            component.set("v.GuarantorBool", true);
        }else{
            component.set("v.LetterOfCreditBool", false);
            component.set("v.CashDepositBool", false);
            component.set("v.GuarantorBool", false);
        }
    },
    
    commonValidations : function(component){
        var hasError = false;
        if(component.get('v.IsMinimumRent') && !$A.util.isUndefinedOrNull(component.get('v.lstGrowthRateTable')) && 
           component.get('v.lstGrowthRateTable').length > 30){
            component.set('v.FI_minimumRentError', true);
            hasError = true;
        } else{
            component.set('v.FI_minimumRentError', false);
        }
        return hasError;
    },
    
    checkRequiredFieldsHelper : function(component, event ) {
        /*changes to make fields required : start*/
        
        var docTypeError = component.find("docTypeErrorId");        
        var legalEntityTypeError = component.find("legalEntityTypeErrorId");
        var useClauseError = component.find("useClauseErrorId");
        var securityTypeError = component.find("securityTypeErrorId");
        var spaceDeliveryError = component.find("spaceDeliveryErrorId");
        var rcdEarlierOfError = component.find("rcdEarlierOfErrorId");
        var expirationError = component.find("expirationErrorId");      
        var dbaCustomerError = component.find("dbaCustomerErrorId");
        var legalEntityError = component.find("legalEntityErrorId");
        var brokerError = component.find("brokerErrorId");
        var dealmakerError = component.find("dealmakerErrorId");
        var centerNameError = component.find("centerNameErrorId");
        var useTypeError = component.find("useTypeErrorId");
        var productFamilyError = component.find("productFamilyErrorId");
        var unitError = component.find("unitErrorId");  
        var restrictionTypeError = component.find("restrictionTypeErrorId");
        var areaRestUnitOfMeasureError = component.find("areaRestUnitOfMeasureErrorId");
        var relocRightsDescriptionError = component.find("relocRightsDescriptionErrorId");
        var growthRateTable = component.get("v.lstGrowthRateTable");
        var conCommsErrorId = component.find("conCommsErrorId");
        var boolIsreqFiledEmpty = false;
        var securityTypeErrorMsg = false;
        var strDeadReasonComms = component.get("v.opportunity.OtherReasonOpportunityDead_WF__c");
        var strDeadReason = component.get("v.opportunity.LossReason_WF__c");
        var Operator = component.get('v.opportunity.Operator_WF__c'); //Airports
        var result =component.get('v.relatedRecord');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        var holdReason = component.get("v.opportunity.HoldReason_WF__c");
        var holdCheck = component.get("v.opportunity.On_Hold_WF__c");
        var recApprovalStatus = component.get("v.opportunity.REC_Approval_Status_WF__c");
        var recApprovalStatusComments = component.get("v.opportunity.REC_Comments_WF__c");
        component.set("v.GI_whereSectionTempError",false);
        component.set("v.GI_whenSectionTempError",false);
        component.set("v.FI_minimumRentTempError",false);
        component.set("v.OP_detailsTempError",false);
        component.set("v.CH_mallChargesTempError", false);
        component.set('v.CON_capitalTempError',false);
        component.set('v.CON_tenantConstructionReqTempError',false);
        component.set("v.COV_radiusRestrictionTempError", false);
        component.set("v.commonAreaRestrictionTempError", false);
        component.set('v.CO_detailsTempError',false);
        component.set("v.GI_securitySectionTempError", false);
        component.set('v.FI_overageRentTempError', false);
        component.set("v.COV_kickoutsTempError", false);
        component.set("v.llRelocationRightsTempError",false);
        component.set("v.llTerminationRightsTempError", false);
        component.set("v.noZoneTempError",false);
        component.set("v.exclusiveRightTempError",false);
        component.set("v.coTenancyTempError",false);
        
        boolIsreqFiledEmpty = this.commonValidations(component);
        var dealExpiryDate = component.get('v.opportunity.ExpirationDate_WF__c');
        var dealRCDDate = component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c');
        var isReconfig = component.get('v.reconfigBool');
        var unitConfig = component.get('v.selectedUnits');
        var reservation = component.get('v.selectedProducts');
        var invalidUnitChoosen = false;
        var noRCDError = true;
        var noExpirationError = true;
        
        if(isReconfig == true){
            if(!$A.util.isUndefinedOrNull(unitConfig)){
                for(var i = 0; i < unitConfig.length; i++){
                    if(unitConfig[i].unitStatus == 'Active'){
                        if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(unitConfig[i].activationEndDate)){
                            if(dealExpiryDate > unitConfig[i].activationEndDate){
                                invalidUnitChoosen = true;
                                boolIsreqFiledEmpty = true;
                                noExpirationError = false;                                
                            }                                                        
                        }
                        if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(unitConfig[i].activationStartDate)){
                            if(dealRCDDate < unitConfig[i].activationStartDate){
                                invalidUnitChoosen = true;
                                boolIsreqFiledEmpty = true;
                                noRCDError = false;                              
                            }                                                        
                        }
                    }
                }       
            }
        }else if(!isReconfig){
            var unitToAdd = component.get('v.addProduct');
            if(!$A.util.isUndefinedOrNull(reservation)){
                if(reservation.length > 0){
                    for(var i = 0; i < reservation.length; i++){ 
                        if( reservation[i].idProduct == unitToAdd ){
                            if(reservation[i].unitStatus == 'Active'){
                                if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(reservation[i].activationEndDate)){
                                    if(dealExpiryDate > reservation[i].activationEndDate){
                                        invalidUnitChoosen = true;
                                        boolIsreqFiledEmpty = true;
                                        noExpirationError = false;
                                    }                                      
                                }
                                if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(reservation[i].activationStartDate)){
                                    if(dealRCDDate < reservation[i].activationStartDate){
                                        invalidUnitChoosen = true;
                                        boolIsreqFiledEmpty = true;
                                        noRCDError = false;
                                    }                                        
                                }                                
                            }
                        }
                    }
                }
            }
        }
        
        if(noRCDError){
            $A.util.addClass(component.find("unitRCDErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitRCDErrorId"),'slds-hide');
        }
        if(noExpirationError){
            $A.util.addClass(component.find("unitExpirationErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitExpirationErrorId"),'slds-hide');
        }
        
        //Joshna - 25 Jun '17, Bug 5004       
        if(component.get('v.IsMinimumRent') && (component.get('v.opportunity.FirstyrAnnualizedAmount_WF__c') === undefined || component.get('v.opportunity.FirstyrAnnualizedAmount_WF__c') === null
                                                || component.get('v.opportunity.FirstyrAnnualizedAmount_WF__c') < 0 || component.get('v.opportunity.FirstYrRatePSF_WF__c') === undefined
                                                || component.get('v.opportunity.FirstYrRatePSF_WF__c') === null || component.get('v.opportunity.FirstYrRatePSF_WF__c') < 0 
                                                || component.get('v.opportunity.RentIncreases_WF__c') === 'NA' || component.get('v.opportunity.AnnualGrowthSteptype_WF__c') === 'NA')){
            component.set('v.FI_minimumRentTempError', true);
            boolIsreqFiledEmpty = true;
        } else{
            component.set('v.FI_minimumRentTempError', false);
        }
        if(component.get('v.IsNegativeValue') || component.get('v.FI_minimumRentTempError')){
            component.set('v.FI_minimumRentTempError', true);
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.FI_minimumRentTempError', false);
        }
        /* Required Field Validations Options Section */
        if(component.get('v.opportunity.OptionToExtend_WF__c')){
            var showOptionsError = false;
            if(component.get('v.opportunity.OptionsMeasuringPeriod_WF__c') ==='Other' && ($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsMeasuringPeriodComments_WF__c')) || component.get('v.opportunity.OptionsMeasuringPeriodComments_WF__c') == '' )){
                showOptionsError = true;
            }                        
            var renewalOptions = component.get('v.renewalOptions');
            var showCommentsError = false;
            if(!$A.util.isUndefinedOrNull(renewalOptions)){
                if(renewalOptions.length > 0){
                    for(var i = 0; i < renewalOptions.length; i++){
                        if(renewalOptions[i].strNotifyLLBy == 'Other'){
                            if($A.util.isUndefinedOrNull(renewalOptions[i].strNotifyLLByOtherComments) || renewalOptions[i].strNotifyLLByOtherComments === ''){
                                showCommentsError = true;
                            }
                        }
                    }
                }
            }
            if(showCommentsError || showOptionsError){
              //  component.set('v.OP_detailsError', true);
                if(showCommentsError)
                    component.set('v.optionsCommentsErrors', true);
                if(showOptionsError)
                    component.set('v.optionsErrors', true);
                boolIsreqFiledEmpty = true;
            } else{ 
               // component.set('v.OP_detailsError', false);
                if(!showCommentsError)
                    component.set('v.optionsCommentsErrors', false);
                if(!showOptionsError)
                    component.set('v.optionsErrors', false);
            }
            /* Required Field Validations Options Minimum Rent Section */
            if(component.get('v.IsOptionsMinimumRent') && (component.get('v.opportunity.OptionsFirstyrAnnualizedAmount_WF__c') === undefined || component.get('v.opportunity.OptionsFirstyrAnnualizedAmount_WF__c') === null
                                                    || component.get('v.opportunity.OptionsFirstyrAnnualizedAmount_WF__c') < 0 || component.get('v.opportunity.OptionsFirstYrRatePSF_WF__c') === undefined
                                                    || component.get('v.opportunity.OptionsFirstYrRatePSF_WF__c') === null || component.get('v.opportunity.OptionsFirstYrRatePSF_WF__c') < 0 
                                                    || component.get('v.opportunity.OptionsRentIncreases_WF__c') === 'NA' || component.get('v.opportunity.OptionsAnnualGrowthSteptype_WF__c') === 'NA')){
                //component.set('v.OP_detailsError', true);
                component.set('v.hasMinErrors', true);
                boolIsreqFiledEmpty = true;
            } else{
              //  component.set('v.OP_detailsError', false);
                component.set('v.hasMinErrors', false);
            }
            /* Required Field Validations for Options Percent Rent Section */
            var optionsShowPerError = false; 
            if(component.get('v.opportunity.OptionsToPercentRent_WF__c')  && component.get('v.opportunity.RevenueLine_WF__c') != $A.get("$Label.c.AirportLeasing_WF")){
            if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsBreakpointType_WF__c')) || component.get('v.opportunity.OptionsBreakpointType_WF__c') === '--None--'){
                optionsShowPerError = true;
            }
            if(component.get('v.opportunity.OptionsBreakpointType_WF__c') === 'Unnatural'){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsPercentRentRate_WF__c')) || $A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsBreakpointStepType_WF__c')) || $A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsRentTypeBasis_WF__c')) 
                   || component.get('v.opportunity.OptionsPercentRentRate_WF__c') === '--None--'
                   || component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === '--None--' || component.get('v.opportunity.OptionsRentTypeBasis_WF__c') === '--None--'){
                    optionsShowPerError = true;                   
                }
            }
            if(optionsShowPerError){
               // component.set('v.OP_detailsError', true);
                boolIsreqFiledEmpty = true;
                component.set('v.hasPercentErrors', true);
            } else{
               // component.set('v.OP_detailsError', false);
                component.set('v.hasPercentErrors', false);
            }
            }                        
            if(component.get('v.IsOptionsMiniNegativeValue') || component.get('v.IsOptionsPerNegativeValue') || component.get('v.hasMinErrors')){
                //component.set('v.OP_detailsError', true);
                if(component.get('v.IsOptionsMiniNegativeValue') || component.get('v.hasMinErrors'))
                    component.set('v.hasMinErrors', true);
                boolIsreqFiledEmpty = true;
            }else{
              //  component.set('v.OP_detailsError', false);
                component.set('v.hasMinErrors', false);
            }
            if(component.get('v.hasMinErrors') || component.get('v.hasPercentErrors') ||    component.get('v.optionsCommentsErrors') || component.get('v.optionsErrors') ){
                  component.set('v.OP_detailsTempError', true);                
            }else{
                component.set('v.OP_detailsTempError', false);
                
            }
        }
        /* Required Field Validations for Percent Rent Section */
        if(component.get('v.opportunity.PercentRent_WF__c') && component.get('v.opportunity.RevenueLine_WF__c') != $A.get("$Label.c.AirportLeasing_WF")){
            var showPerError = false;
            var checkCommentError = true;           
            
            if($A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointType_WF__c') )|| component.get('v.opportunity.BreakpointType_WF__c') === '--None--'){
                showPerError = true;
            }
            if(component.get('v.opportunity.BreakpointType_WF__c') === 'Unnatural'){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.PercentRentRate_WF__c')) || $A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointStepType_WF__c')) || $A.util.isUndefinedOrNull(component.get('v.opportunity.RentTypeBasis_WF__c')) 
                   || component.get('v.opportunity.PercentRentRate_WF__c') === '--None--'
                   || component.get('v.opportunity.BreakpointStepType_WF__c') === '--None--' || component.get('v.opportunity.RentTypeBasis_WF__c') === '--None--'){
                    showPerError = true;
                }
            }
        
            if(component.get('v.IsPercentNegativeValue') || showPerError){
            component.set('v.FI_overageRentTempError', true);
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.FI_overageRentTempError', false);
        }
        
            
            } else{
                component.set('v.FI_overageRentTempError', false);
        }
        // check for Contingency Comments is not empty, if Contingency is Other
        var whenContingency = component.get('v.opportunity.ContingenciesIfAny_WF__c');
        if(whenContingency.includes('Other') && (component.get('v.opportunity.ContingencyComments_WF__c')=='' || component.get('v.opportunity.ContingencyComments_WF__c')==null))
        {
            $A.util.removeClass(conCommsErrorId, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }
        else
        {
            $A.util.addClass(conCommsErrorId, 'slds-hide');
        }
        
        // check for Document Type is not empty
        if(component.get('v.opportunity.Document_Type_WF__c')=='' || component.get('v.opportunity.Document_Type_WF__c')==null || component.get('v.opportunity.Document_Type_WF__c')=='--None--'){
            $A.util.removeClass(docTypeError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(docTypeError, 'slds-hide');
        }
        // check for Use Clause is not empty
        if(component.get('v.opportunity.UseClause_WF__c')=='' || component.get('v.opportunity.UseClause_WF__c')==null){
            $A.util.removeClass(useClauseError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(useClauseError, 'slds-hide');
        }
        // check for Security Type is not empty
        if(component.get('v.opportunity.SecurityDepositRequired_WF__c') == true && (component.get('v.opportunity.SecurityType_WF__c')=='' || component.get('v.opportunity.SecurityType_WF__c')==null || component.get('v.opportunity.SecurityType_WF__c')=='--None--')){
            $A.util.removeClass(securityTypeError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(securityTypeError, 'slds-hide');
        }
        if(component.get('v.opportunity.SecurityDepositRequired_WF__c')){
            var securityType = component.get('v.opportunity.SecurityType_WF__c');
            if(securityType !== undefined && securityType !== null && securityType !== ''){
                var errorMsgDiv = component.find("cashDepError");
                //If ‘Cash Deposit’ is selected, user can save the Opportunity without entering in ‘Cash Deposit’ amount
                if(securityType.includes('Cash Deposit') && (component.get('v.opportunity.Cash_Deposit_Amount_WF__c') === undefined || component.get('v.opportunity.Cash_Deposit_Amount_WF__c') === null || 
                                                             component.get('v.opportunity.Cash_Deposit_Amount_WF__c') === '' || component.get('v.opportunity.Cash_Deposit_Amount_WF__c') <= 0)){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    boolIsreqFiledEmpty = true;
                    securityTypeErrorMsg = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                var errorMsgDiv = component.find("holdCashDepError");
                if(securityType.includes('Cash Deposit') && (component.get('v.opportunity.Hold_Cash_Deposit_For_Amendment_WF__c') === undefined || component.get('v.opportunity.Hold_Cash_Deposit_For_Amendment_WF__c') === null || 
                                                             component.get('v.opportunity.Hold_Cash_Deposit_For_Amendment_WF__c') === '')){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    boolIsreqFiledEmpty = true;
                    securityTypeErrorMsg = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                
                errorMsgDiv = component.find("locError");
                //adding at least one LOC should be required IF ‘Letter of Credit’ is selected/included in the ‘Security Type’
                if(securityType.includes('Letter of Credit') && component.get('v.noOfletterOfCredit') === 0){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    boolIsreqFiledEmpty = true;
                    securityTypeErrorMsg = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                
                errorMsgDiv = component.find("guarantorError");
                //adding at least one Guarantor should be required IF ‘Guarantor’ is selected/included in the ‘Security Type’
                if(securityType.includes('Guarantor') && component.get('v.noOfGuarantor') === 0){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    boolIsreqFiledEmpty = true;
                    securityTypeErrorMsg = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
            }
        }
        var dateError=false;
        // check for Space Delivery is not empty
        if(component.get('v.opportunity.SpaceDeliveryDate__c')=='' || component.get('v.opportunity.SpaceDeliveryDate__c')==null){
            $A.util.removeClass(spaceDeliveryError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(spaceDeliveryError, 'slds-hide');
        }
        // check for RCD Earlier Of is not empty
        if(component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c')=='' || component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c')==null){
            $A.util.removeClass(rcdEarlierOfError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(rcdEarlierOfError, 'slds-hide');
        }
        // check for Expiration is not empty
        if(component.get('v.opportunity.ExpirationDate_WF__c')=='' || component.get('v.opportunity.ExpirationDate_WF__c')==null){
            $A.util.removeClass(expirationError, 'slds-hide');
            $A.util.addClass(component.find('expirationPastErrorId'), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            if(new Date(component.get('v.opportunity.ExpirationDate_WF__c')) < new Date(component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c'))){
                $A.util.removeClass(component.find('expirationPastErrorId'), 'slds-hide');
                dateError = true;  
                boolIsreqFiledEmpty = true;
            }else{
                $A.util.addClass(component.find('expirationPastErrorId'), 'slds-hide');
            }
            $A.util.addClass(expirationError, 'slds-hide');
        }
        // check for DBA Customer is not empty
        if(component.get('v.opportunity.B2BCustomer_WF__c')==null){
            $A.util.removeClass(dbaCustomerError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(dbaCustomerError, 'slds-hide');
        }
        // check for Legal Entity is not empty
        if(component.get('v.opportunity.LegalEntity_WF__c')==null){
            $A.util.removeClass(legalEntityError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(legalEntityError, 'slds-hide');
        }
        // check for Broker is not empty
        var BrokerCost = isNaN(parseFloat(component.get('v.Construction.BrokerCommissions_WF__c'))) ? 0 : parseFloat(component.get('v.Construction.BrokerCommissions_WF__c'));
        if(component.get('v.opportunity.RevenueLine_WF__c') != $A.get("$Label.c.AirportLeasing_WF") && component.get('v.opportunity.Broker_WF__c')==null && BrokerCost>0){
            $A.util.removeClass(brokerError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(brokerError, 'slds-hide');
        }
        // check for Dealmaker is not empty
        if(component.get('v.opportunity.Dealmaker_WF__c')==null){
            $A.util.removeClass(dealmakerError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(dealmakerError, 'slds-hide');
        }
        
        //Operator Validation
        /*if(component.get('v.opportunity.RevenueLine_WF__c') == $A.get("$Label.c.AirportLeasing_WF") && $A.util.isUndefinedOrNull (Operator)){
            $A.util.removeClass(component.find('operErrorId'), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find('operErrorId'), 'slds-hide');
        }*/
        // check for Center Name is not empty
        if(component.get('v.Center.Id')==null){
            $A.util.removeClass(centerNameError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(centerNameError, 'slds-hide');
        }
        // check for Use Type is not empty
        if(component.get('v.opportunity.UseType_WF__c')=='' || component.get('v.opportunity.UseType_WF__c')==null || component.get('v.opportunity.UseType_WF__c')=='--None--'){
            $A.util.removeClass(useTypeError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(useTypeError, 'slds-hide');
        }
        
        // check for Product Family is not empty
        if(component.get('v.opportunity.ProductFamily_WF__c')=='' || component.get('v.opportunity.ProductFamily_WF__c')==null || component.get('v.opportunity.ProductFamily_WF__c')=='--None--'){
            $A.util.removeClass(productFamilyError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(productFamilyError, 'slds-hide');
        }
        
        // check for Unit is not empty
        if(component.get('v.strProducts')==null || component.get('v.strProducts')==''){
            $A.util.removeClass(unitError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(unitError, 'slds-hide');
        }
        //Check for ACDBE fields
        var acdbeFields = false;
        if(component.get('v.opportunity.RevenueLine_WF__c') == $A.get("$Label.c.AirportLeasing_WF") && component.get('v.opportunity.ACDBEParticipation_WF__c')){
            if($A.util.isEmpty(component.get('v.opportunity.ACDBEParticipationPercentage_WF__c'))){
                $A.util.removeClass(component.find("ACDBEParticipationPercentageErr"), 'slds-hide');
                boolIsreqFiledEmpty = true;
                acdbeFields = true;
            }else{
                $A.util.addClass(component.find("ACDBEParticipationPercentageErr"), 'slds-hide');
            }
        }
        
        // check for Remodel Date is not empty
        if(component.get('v.Construction.BuildOutRequired_WF__c') && (component.get('v.Construction.BuildOut_WF__c')=='Mid-Term Remodel' || component.get('v.Construction.BuildOut_WF__c')=='Both')){
            if($A.util.isUndefinedOrNull(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')) || component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='' ){
                component.set('v.workRequiredError',true);
                component.set('v.CON_tenantConstructionReqTempError',true);
                boolIsreqFiledEmpty = true;
            } else{
                component.set('v.workRequiredError',false);
                component.set('v.CON_tenantConstructionReqTempError',false);
            }
            if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c') !='No Work Required' && (component.get('v.Construction.RemodelDueDate_WF__c')==null || component.get('v.Construction.RemodelDueDate_WF__c')=='' )){ //GDM-7370 : updated condition
                component.set('v.RemodelDueDateError',true);
                component.set('v.CON_tenantConstructionReqTempError',true);
                boolIsreqFiledEmpty = true;
            }else{
                component.set('v.RemodelDueDateError',false);
                component.set('v.CON_tenantConstructionReqTempError',false);
            }
        }
        
        // check for Restriction Type is not empty
        
        if(component.get("v.commonArRestriction.CommonAreaRestrictions_WF__c")==true && (component.get('v.commonArRestriction.RestrictionType_WF__c')=='' || component.get('v.commonArRestriction.RestrictionType_WF__c')==null || component.get('v.commonArRestriction.RestrictionType_WF__c')=='--None--')){
            console.log('restrictionType empty-->');
            console.log(component.get("v.commonArRestriction.CommonAreaRestrictions_WF__c"));
            $A.util.removeClass(restrictionTypeError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(restrictionTypeError, 'slds-hide');
        }
        // check for Area Restriction Unit of Measure is not empty
        if(component.get("v.commonArRestriction.CommonAreaRestrictions_WF__c")==true && (component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')=='' || component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')==null || component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')=='--None--')){
            console.log('areaRestUnitOfMeasure empty-->');
            $A.util.removeClass(areaRestUnitOfMeasureError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(areaRestUnitOfMeasureError, 'slds-hide');
        }
        // check for Relocation Rights Description is not empty
        if(component.get('v.llRelocationRight.StandardRelocationRights_WF__c')==false && (component.get('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c')=='' || component.get('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c')==null)){
            console.log('relocRightsDescription empty-->');
            $A.util.removeClass(relocRightsDescriptionError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(relocRightsDescriptionError, 'slds-hide');
        }
        // check for # of is not empty
        if(component.get('v.radiusRestriction.RadiusRestriction_WF__c') == true && (component.get('v.radiusRestriction.of_WF__c')=='' || component.get('v.radiusRestriction.of_WF__c')==null || component.get('v.radiusRestriction.of_WF__c')=='--None--')){
            console.log('noOf empty-->');
            $A.util.removeClass(component.find("noOfErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("noOfErrorId"), 'slds-hide');
        }
        // check for Duration is not empty
        if(component.get('v.radiusRestriction.RadiusRestriction_WF__c') == true && (component.get('v.radiusRestriction.Duration_WF__c')=='' || component.get('v.radiusRestriction.Duration_WF__c')==null || component.get('v.radiusRestriction.Duration_WF__c')=='--None--')){
            console.log('duration empty-->');
            $A.util.removeClass(component.find("durationErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("durationErrorId"), 'slds-hide');
        }
        // check for If Duration is Other is not empty
        if(component.get('v.radiusRestriction.Duration_WF__c')=='Other' && ((component.get('v.radiusRestriction.Duration_Months__c')=='' && component.get('v.radiusRestriction.DurationYears_WF__c')=='') ||
                                                                            (component.get('v.radiusRestriction.Duration_Months__c')==null && component.get('v.radiusRestriction.DurationYears_WF__c')==null))){
            console.log('durationIsOther empty-->');
            $A.util.removeClass(component.find("yearMonthErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(component.find("yearMonthErrorId"), 'slds-hide');
        }
        // check for Termination Rights Description is not empty
        if(component.get('v.landlordTerminationtionRight.StandardTerminationRights_WF__c')==false && (component.get('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c')=='' || component.get('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c')==null)){
            console.log('Termination Rights Desc empty-->');
            $A.util.removeClass(component.find("terminationRightsDescErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("terminationRightsDescErrorId"), 'slds-hide');
        }
        // check for No Build Zone Description is not empty
        if(component.get('v.SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c')==true && component.get('v.SLR.Zone_WF__c')==true && (component.get('v.SLR.DescriptionZone_WF__c')=='' || component.get('v.SLR.DescriptionZone_WF__c')==null)){
            console.log('no build zone Desc empty-->');
            $A.util.removeClass(component.find("descNoBuildErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("descNoBuildErrorId"), 'slds-hide');
        }
        // check for Excl Right Description is not empty
        if(component.get('v.exclusiveRights.DoesTnthaveanExclusiveRight_WF__c')==true && (component.get('v.exclusiveRights.ExclRightDescription_WF__c')=='' || component.get('v.exclusiveRights.ExclRightDescription_WF__c')==null)){
            console.log('exclRightDesc empty-->');
            $A.util.removeClass(component.find("exclRightDescErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("exclRightDescErrorId"), 'slds-hide');
        }
        // check for Excl Duration is not empty
        if(component.get('v.exclusiveRights.DoesTnthaveanExclusiveRight_WF__c')==true && (component.get('v.exclusiveRights.ExclDuration_WF__c')=='' || component.get('v.exclusiveRights.ExclDuration_WF__c')==null)){
            console.log('exclDuration empty-->');
            $A.util.removeClass(component.find("exclDurationErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("exclDurationErrorId"), 'slds-hide');
        }
        // check for Excl Remedy Description is not empty
        if(component.get('v.exclusiveRights.DoesTnthaveanExclusiveRight_WF__c')==true && (component.get('v.exclusiveRights.ExclRemedyDescription_WF__c')=='' || component.get('v.exclusiveRights.ExclRemedyDescription_WF__c')==null)){
            console.log('exclRemedyDesc empty-->');
            $A.util.removeClass(component.find("exclRemedyDescErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("exclRemedyDescErrorId"), 'slds-hide');
        }
        
        //Kickouts section fields
        var kickouts = component.get('v.lstKickouts');
        
        if(kickouts.length >0 && component.get('v.opportunity.KickOuts_WF__c')==true){
            for(var i=0; i<kickouts.length; i++){
                console.log('**********kickout',kickouts);
                //check for Type Of Kickout not empty
                if(kickouts[i].TypeofKickout_WF__c == '' || kickouts[i].TypeofKickout_WF__c == null || kickouts[i].TypeofKickout_WF__c == '--None--'){
                    console.log('type of kickout empty-->');
                    $A.util.removeClass(document.getElementById('kickoutTypeErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('kickoutTypeErrorId' + i), 'slds-hide');
                }
                //check for End Date not empty
                if(kickouts[i].EndDate_WF__c == '' || kickouts[i].EndDate_WF__c == null){
                    console.log('type of end date empty-->');
                    $A.util.removeClass(document.getElementById('endDateErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('endDateErrorId' + i), 'slds-hide');
                }
                //check for Landlord Sales Threshold not empty
                if(kickouts[i].TypeofKickout_WF__c=='Mutual' || kickouts[i].TypeofKickout_WF__c =='Landlord'){
                    if(kickouts[i].LandlordSalesThreshold_WF__c == '' || kickouts[i].LandlordSalesThreshold_WF__c == null){
                        console.log('type of llThreshold empty-->');
                        $A.util.removeClass(document.getElementById('llThresholdErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('llThresholdErrorId' + i), 'slds-hide');
                    }
                }
                //check for Notice Period not empty
                if(kickouts[i].NoticePerioddays_WF__c == '' || kickouts[i].NoticePerioddays_WF__c == null){
                    console.log('type of noticePeriod empty-->');
                    $A.util.removeClass(document.getElementById('noticePeriodErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('noticePeriodErrorId' + i), 'slds-hide');
                }
                //check for Tenant Sales Threshold not empty
                console.log(kickouts[i]);
                if(kickouts[i].TypeofKickout_WF__c=='Mutual' || kickouts[i].TypeofKickout_WF__c =='Tenant'){
                    if(kickouts[i].TenantSalesThreshold_WF__c == '' || kickouts[i].TenantSalesThreshold_WF__c == null){
                        console.log('type of tsThreshold empty-->',kickouts[i].TenantSalesThreshold_WF__c);
                        $A.util.removeClass(document.getElementById('tsThresholdErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('tsThresholdErrorId' + i), 'slds-hide');
                    }
                }
                //Check for Start Date not empty
                if(kickouts[i].StartDate_WF__c == '' || kickouts[i].StartDate_WF__c == null){
                    console.log('Sid Start Date is empty-->',kickouts[i].StartDate_WF__c);
                    $A.util.removeClass(document.getElementById('startDateErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('startDateErrorId' + i), 'slds-hide');
                }
                
                //check for Termination Effective from Notice Date not empty
                if(kickouts[i].TerminationEffectivefromNoticeDate_WF__c == '' || kickouts[i].TerminationEffectivefromNoticeDate_WF__c == null){
                    console.log('type of terminationEffective empty-->');
                    $A.util.removeClass(document.getElementById('terminationEffectiveErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('terminationEffectiveErrorId' + i), 'slds-hide');
                }
                //check for Unamortized payback amount not empty
                if(kickouts[i].Unamortizedpaybacktype_WF__c == '' || kickouts[i].Unamortizedpaybacktype_WF__c == null){
                    console.log('type of paybackAmount empty-->');
                    $A.util.removeClass(document.getElementById('paybackAmountErrorId' + i), 'slds-hide');
                    boolIsreqFiledEmpty = true;
                }else{
                    $A.util.addClass(document.getElementById('paybackAmountErrorId' + i), 'slds-hide');
                }
            }
        }
        //Co-Tenancy section fields
        var coTenants = component.get('v.lstCoTenants');
        
        if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
            for(var i=0; i<coTenants.length; i++){
                if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true)){
                    if(coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].CoTenancyType_WF__c == 'Operating'){
                        //check for Sales Test (decrease by %) not empty
                        if((coTenants[i].SalesTest_WF__c == '' || coTenants[i].SalesTest_WF__c == null) && coTenants[i].SalesTest_WF__c != 0){
                            console.log('salesTestDecrease empty-->',i);
                            $A.util.removeClass(document.getElementById('salesTestDecreaseErrorId' + i), 'slds-hide');
                            boolIsreqFiledEmpty = true;
                        }else{
                            $A.util.addClass(document.getElementById('salesTestDecreaseErrorId' + i), 'slds-hide');
                        }
                        //check for Sales Test Measing Period not empty
                        if(coTenants[i].SalesTestMeasuringPeriod_WF__c != '' || coTenants[i].SalesTestMeasuringPeriod_WF__c != null || coTenants[i].SalesTestMeasuringPeriod_WF__c != '--None--'){
                            if(coTenants[i].SalesTestMeasuringPeriod_WF__c == 'Months'){
                                if((coTenants[i].SalesTestMeasuringPeriodMonths_WF__c == '' || coTenants[i].SalesTestMeasuringPeriodMonths_WF__c == null) && coTenants[i].SalesTestMeasuringPeriodMonths_WF__c !== 0){
                                    console.log('salesTestMeasPeriod empty-->',i);
                                    $A.util.removeClass(document.getElementById('salesTestMeasPeriodMonthsErrorId' + i), 'slds-hide');
                                    boolIsreqFiledEmpty = true;
                                }else{
                                    $A.util.addClass(document.getElementById('salesTestMeasPeriodMonthsErrorId' + i), 'slds-hide');
                                }
                            }
                            else if(coTenants[i].SalesTestMeasuringPeriod_WF__c == 'Days'){
                                if((coTenants[i].SalesTestMeasuringPeriodDays_WF__c == '' || coTenants[i].SalesTestMeasuringPeriodDays_WF__c == null) && coTenants[i].SalesTestMeasuringPeriodDays_WF__c !== 0){
                                    console.log('salesTestMeasPeriod empty-->',i);
                                    $A.util.removeClass(document.getElementById('salesTestMeasPeriodDaysErrorId' + i), 'slds-hide');
                                    boolIsreqFiledEmpty = true;
                                }
                                else{
                                    $A.util.addClass(document.getElementById('salesTestMeasPeriodDaysErrorId' + i), 'slds-hide');
                                }
                            }
                        } 
                    }
                    if(coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].OperatingCoTenancy_WF__c == true || coTenants[i].PosessionCoTenancy_WF__c == true || coTenants[i].ConstructionCoTenancy_WF__c == true)){
                        //check for # of Dept Stores at Center not empty
                        if(coTenants[i].NooofDeptStoresatCenter_WF__c == '' || coTenants[i].NooofDeptStoresatCenter_WF__c == null){
                            console.log('noDeptStoresAtCenter empty-->',i);
                            $A.util.removeClass(document.getElementById('noDeptStoresAtCenterErrorId' + i), 'slds-hide');
                            boolIsreqFiledEmpty = true;
                        }else{
                            $A.util.addClass(document.getElementById('noDeptStoresAtCenterErrorId' + i), 'slds-hide');
                        }
                        //check for # of Dept Stores Required not empty
                        if(coTenants[i].NoofDeptStoresRequired_WF__c == '' || coTenants[i].NoofDeptStoresRequired_WF__c == null){
                            console.log('noDeptStoresReqd empty-->',i);
                            $A.util.removeClass(document.getElementById('noDeptStoresReqdErrorId' + i), 'slds-hide');
                            boolIsreqFiledEmpty = true;
                        }else{
                            $A.util.addClass(document.getElementById('noDeptStoresReqdErrorId' + i), 'slds-hide');
                        }
                    }
                    //check for Department Stores and GLA Required - both can't be false (at least one to be selected). GDM-4274
                    if(coTenants[i].DepartmentStores_WF__c==false && coTenants[i].GLARequired_WF__c==false){
                        $A.util.removeClass(document.getElementById('deptStoreOrGLAReqdLabel1ErrorId' + i), 'slds-hide');
                        $A.util.removeClass(document.getElementById('deptStoreOrGLAReqdLabel2ErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }
                    else{
                        $A.util.addClass(document.getElementById('deptStoreOrGLAReqdLabel1ErrorId' + i), 'slds-hide');
                        $A.util.addClass(document.getElementById('deptStoreOrGLAReqdLabel2ErrorId' + i), 'slds-hide');
                    }
                    
                    if(coTenants[i].DepartmentStores_WF__c==true && coTenants[i].CoTenancyType_WF__c!='Operating')
                    {
                        if(coTenants[i].DescriptionRemedy_WF__c == null || coTenants[i].DescriptionRemedy_WF__c == '')
                        {
                            $A.util.removeClass(document.getElementById('noDeptRemDescReqdErrorId' + i), 'slds-hide');
                            boolIsreqFiledEmpty = true;
                        }
                        else
                        {
                            $A.util.addClass(document.getElementById('noDeptRemDescReqdErrorId' + i), 'slds-hide');
                        }
                    } 
                    
                    /*if(coTenants[i].ReplacementTenantDescription_WF__c == null || coTenants[i].ReplacementTenantDescription_WF__c == '')
                    {
                        $A.util.removeClass(document.getElementById('RepDescReqErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }
                    else
                    {
                        $A.util.addClass(document.getElementById('RepDescReqErrorId' + i), 'slds-hide');
                    }*/
                    //check for Definition of Dept. Store sf not empty
                    if(coTenants[i].DepartmentStores_WF__c==true && coTenants[i].OpeningCoTenancy_WF__c == true && (coTenants[i].DefinitionofDeptStoresf_WF__c == '' || coTenants[i].DefinitionofDeptStoresf_WF__c == null)){
                        console.log('defDeptStore empty-->',i);
                        $A.util.removeClass(document.getElementById('defDeptStoreErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('defDeptStoreErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy not empty
                    if(coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].Remedy_WF__c == '' || coTenants[i].Remedy_WF__c == null || coTenants[i].Remedy_WF__c == '--None--')){
                        console.log('remedy empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyErrorId' + i), 'slds-hide');
                    }
                    //check for Concurrence not empty
                    /*if(coTenants[i].OpeningCoTenancy_WF__c == true && (coTenants[i].Concurrence_WF__c == '' || coTenants[i].Concurrence_WF__c == null || coTenants[i].Concurrence_WF__c == '--None--')){
                        console.log('concurrence empty-->',i);
                        $A.util.removeClass(document.getElementById('concurrenceErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('concurrenceErrorId' + i), 'slds-hide');
                    }*/
                    //check for GLA % not empty
                    if( coTenants[i].GLARequired_WF__c == true && (coTenants[i].GLAPercent_WF__c == '' || coTenants[i].GLAPercent_WF__c == null)){
                        console.log('gla % empty-->',i);
                        $A.util.removeClass(document.getElementById('glaPercentErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('glaPercentErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy GLA Required not empty
                    if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].RemedyGLARequired_WF__c == '' || coTenants[i].RemedyGLARequired_WF__c == null || coTenants[i].RemedyGLARequired_WF__c == '--None--')){
                        console.log('remedyGLAReqd empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyGLAReqdErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyGLAReqdErrorId' + i), 'slds-hide');
                    }
                    //check for Description GLA Required not empty
                    if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].DescriptionGLARequired_WF__c == '' || coTenants[i].DescriptionGLARequired_WF__c == null)){
                        console.log('descGLAReqd empty-->',i);
                        $A.util.removeClass(document.getElementById('descGLAReqdErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('descGLAReqdErrorId' + i), 'slds-hide');
                    }
                    //check for Named Store CT not empty
                    if( coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].NamedStoreCT_WF__c == '' || coTenants[i].NamedStoreCT_WF__c == null)){
                        console.log('namedStoreCT empty-->',i);
                        $A.util.removeClass(document.getElementById('namedStoreCTErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('namedStoreCTErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy Named Store Requirement not empty
                    if(coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].RemedyNamedStoreRequirement_WF__c == '' || coTenants[i].RemedyNamedStoreRequirement_WF__c == null || coTenants[i].RemedyNamedStoreRequirement_WF__c == '--None--')){
                        console.log('remedyNamedStoreReq empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyNamedStoreReqErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyNamedStoreReqErrorId' + i), 'slds-hide');
                    }
                    //check for Description Named Store Requirement not empty
                    if(coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].DescriptionNamedStoreRequirement_WF__c == '' || coTenants[i].DescriptionNamedStoreRequirement_WF__c == null)){
                        console.log('descNamedStoreReq empty-->',i);
                        $A.util.removeClass(document.getElementById('descNamedStoreReqErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('descNamedStoreReqErrorId' + i), 'slds-hide');
                    }
                    //check for Explanation not empty
                    if( coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].Explanation_WF__c == '' || coTenants[i].Explanation_WF__c == null)){
                        console.log('explanation_WF__c empty-->',i);
                        $A.util.removeClass(document.getElementById('explanationErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('explanationErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy Other Requirement not empty
                    if(coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].RemedyotherRequirement_WF__c == '' || coTenants[i].RemedyotherRequirement_WF__c == null || coTenants[i].RemedyotherRequirement_WF__c == '--None--')){
                        console.log('remedyOtherReq empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyOtherReqErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyOtherReqErrorId' + i), 'slds-hide');
                    }
                    //check for Description Other Requirement not empty
                    if(coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].DescriptionOtherRequirement_WF__c == '' || coTenants[i].DescriptionOtherRequirement_WF__c == null)){
                        console.log('descOtherReq empty-->',i);
                        $A.util.removeClass(document.getElementById('descOtherReqErrorId' + i), 'slds-hide');
                        boolIsreqFiledEmpty = true;
                    }else{
                        $A.util.addClass(document.getElementById('descOtherReqErrorId' + i), 'slds-hide');
                    }
                    console.log('coTenants[i].CoTenancyType_WF__c', coTenants[i].CoTenancyType_WF__c);
                    console.log('coTenants[i].OperatingCoTenancy_WF__c', coTenants[i].OperatingCoTenancy_WF__c);
                    console.log('coTenants[i].OpeningCoTenancy_WF__c', coTenants[i].OpeningCoTenancy_WF__c);
                    console.log('coTenants[i].ConstructionCoTenancy_WF__c', coTenants[i].ConstructionCoTenancy_WF__c);
                    console.log('coTenants[i].PosessionCoTenancy_WF__c', coTenants[i].PosessionCoTenancy_WF__c);
                }
            }
        }
        //Check and set the error flags for each section - START
        //what  section
        if(component.get('v.opportunity.Document_Type_WF__c')=='' || component.get('v.opportunity.Document_Type_WF__c')==null || component.get('v.opportunity.Document_Type_WF__c')=='--None--'){
            component.set("v.GI_whatSectionError", true);
        }else{
            component.set("v.GI_whatSectionError", false);
        }
        //who section
        var securityMissing = false;
        if(component.get('v.opportunity.SecurityDepositRequired_WF__c') &&
           (component.get('v.opportunity.SecurityType_WF__c')=='' || 
            component.get('v.opportunity.SecurityType_WF__c')==null || 
            component.get('v.opportunity.SecurityType_WF__c')=='--None--'||
            securityTypeErrorMsg ||
            component.get('v.showErrors') ||
            component.get('v.showGuarantorErrors')
           )){
            securityMissing = true;
            boolIsreqFiledEmpty = true;
        }
        if(securityMissing){
            component.set("v.GI_securitySectionTempError", true);
        }else{
            component.set("v.GI_securitySectionTempError", false);
        }
        if(component.get('v.opportunity.UseClause_WF__c')=='' || acdbeFields ||
           component.get('v.opportunity.UseClause_WF__c')==null ||
           component.get('v.opportunity.B2BCustomer_WF__c')==null || 
           component.get('v.opportunity.LegalEntity_WF__c')==null || 
           component.get('v.opportunity.Dealmaker_WF__c')==null ||
           ((component.get('v.opportunity.RevenueLine_WF__c') != $A.get("$Label.c.AirportLeasing_WF")) && component.get('v.opportunity.Broker_WF__c')==null && BrokerCost>0)){
            component.set("v.GI_whoSectionError", true);
        }else{
            component.set("v.GI_whoSectionError", false);
        }
        //where section
        if(component.get('v.Center.Id')==null || component.get('v.opportunity.UseType_WF__c')=='' || component.get('v.opportunity.UseType_WF__c')==null || component.get('v.opportunity.UseType_WF__c')=='--None--' || component.get('v.strProducts')==null || component.get('v.strProducts')=='' || component.get('v.opportunity.ProductFamily_WF__c')=='' || component.get('v.opportunity.ProductFamily_WF__c')==null || component.get('v.opportunity.ProductFamily_WF__c')=='--None--' || invalidUnitChoosen){
            component.set("v.GI_whereSectionTempError", true);
        }else{
            component.set("v.GI_whereSectionTempError",false);
        }
        //when section
        if(dateError || component.get('v.opportunity.SpaceDeliveryDate__c')=='' || component.get('v.opportunity.SpaceDeliveryDate__c')==null || component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c')=='' || component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c')==null || component.get('v.opportunity.ExpirationDate_WF__c')=='' || component.get('v.opportunity.ExpirationDate_WF__c')==null ||
           (whenContingency.includes('Other') && (component.get('v.opportunity.ContingencyComments_WF__c')=='' || component.get('v.opportunity.ContingencyComments_WF__c')==null))){
            component.set("v.GI_whenSectionTempError", true);
        }else{
            component.set("v.GI_whenSectionTempError", false);
        }
        //Capital Error Section
        var capitalError = false;
        
        
        // Check for Tenant Allowance Amount for Others
        var currTotalTA = component.get('v.Construction.TenantAllowance_WF__c');
        var calcTotalTA = component.get('v.Construction.TAPaymentAmount1_WF__c')+
            component.get('v.Construction.TAPaymentAmount2_WF__c')+
            component.get('v.Construction.TAPaymentAmount3_WF__c')+
            component.get('v.Construction.TAPaymentAmount4_WF__c')+
            component.get('v.Construction.TAPaymentAmount5_WF__c');
        var calcPerTA = component.get('v.Construction.TAPaymentPercent1_WF__c')+
            component.get('v.Construction.TAPaymentPercent2_WF__c')+
            component.get('v.Construction.TAPaymentPercent3_WF__c')+
            component.get('v.Construction.TAPaymentPercent4_WF__c')+
            component.get('v.Construction.TAPaymentPercent5_WF__c');
        console.log('calcPerTA',calcPerTA);
        if(component.get('v.Construction.TAPaymentSchedule_WF__c') == 'Other'){
            if(component.get('v.Construction.TAProgressPaymentOtherType_WF__c')=='$'){
                if(currTotalTA != calcTotalTA){
                    console.log('Termination Rights Desc empty-->');
                    component.set('v.TAPaymentAmountError',true);
                    boolIsreqFiledEmpty = true;
                    capitalError = true;
                }else{
                    component.set('v.TAPaymentAmountError',false);
                }
            }
            if(component.get('v.Construction.TAProgressPaymentOtherType_WF__c')=='%'){
                if(calcPerTA.toFixed(2) != 1){
                    console.log('Termination Rights Desc empty-->');
                    component.set('v.TAPaymentAmountError',true);
                    boolIsreqFiledEmpty = true;
                    capitalError = true;
                }else{
                    component.set('v.TAPaymentAmountError',false);
                }
            }
        }else{
            component.set('v.TAPaymentAmountError',false);
        }
        //Capital Other Landlord Cost
        if(component.get('v.Construction.OtherLandlordCosts_WF__c')>0 && (component.get('v.Construction.OtherCostsDescription_WF__c')=='' || component.get('v.Construction.OtherCostsDescription_WF__c')==null)){
            component.set('v.CapitalOtherCostDescriptionError',true);
            boolIsreqFiledEmpty = true;
            capitalError = true;
        }else{
            component.set('v.CapitalOtherCostDescriptionError',false);
        }
        
        if(component.get('v.Construction.OtherLandlordCosts_WF__c')>0 &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherCostsDescription_WF__c'])&& component.get('v.Construction.OtherCostsDescription_WF__c').length > covenantTextFieldMap['OtherCostsDescription_WF__c']){
            component.set('v.CapitalOtherCostDescriptionLengthError',true);
            boolIsreqFiledEmpty = true;
            capitalError = true;
        }else{
            component.set('v.CapitalOtherCostDescriptionLengthError',false);
        }
        
        if(capitalError){
            component.set('v.CON_capitalTempError',true);
        }else{
            component.set('v.CON_capitalTempError',false);
        }
        //Common Area Restrictions section
        if(component.get("v.commonArRestriction.CommonAreaRestrictions_WF__c")==true && ((component.get('v.commonArRestriction.RestrictionType_WF__c')=='' || component.get('v.commonArRestriction.RestrictionType_WF__c')==null || component.get('v.commonArRestriction.RestrictionType_WF__c')=='--None--') ||
                                                                                         component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')=='' || component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')==null || component.get('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c')=='--None--')){
            component.set("v.commonAreaRestrictionTempError", true);
        }else{
            component.set("v.commonAreaRestrictionTempError", false);
        }
        //Landlord Relocation Rights section
        if(component.get('v.llRelocationRight.StandardRelocationRights_WF__c')==false && (component.get('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c')=='' || component.get('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c')==null)){
            component.set("v.llRelocationRightsTempError", true);
        }else
        {
            component.set("v.llRelocationRightsTempError", false);
        }
        //Radius Restriction section
        if(component.get('v.radiusRestriction.RadiusRestriction_WF__c') == true && (component.get('v.radiusRestriction.of_WF__c')=='' || component.get('v.radiusRestriction.of_WF__c')==null || component.get('v.radiusRestriction.of_WF__c')=='--None--' || component.get('v.radiusRestriction.Duration_WF__c')=='' || component.get('v.radiusRestriction.Duration_WF__c')==null || component.get('v.radiusRestriction.Duration_WF__c')=='--None--' || 
           (component.get('v.radiusRestriction.Duration_WF__c')=='Other' && ((component.get('v.radiusRestriction.Duration_Months__c')=='' && component.get('v.radiusRestriction.DurationYears_WF__c')=='') ||
                                                                             (component.get('v.radiusRestriction.Duration_Months__c')==null && component.get('v.radiusRestriction.DurationYears_WF__c')==null))))){
            component.set("v.COV_radiusRestrictionTempError", true);
        }else{
            component.set("v.COV_radiusRestrictionTempError", false);
        }
        //Landlord Termination Rights section
        if(component.get('v.landlordTerminationtionRight.StandardTerminationRights_WF__c')==false && (component.get('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c')=='' || component.get('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c')==null)){
            component.set("v.llTerminationRightsTempError", true);
        }else{
                component.set("v.llTerminationRightsTempError", false);
        }
        //No Build Zone section
        if(component.get('v.SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c')==true && component.get('v.SLR.Zone_WF__c')==true && (component.get('v.SLR.DescriptionZone_WF__c')=='' || component.get('v.SLR.DescriptionZone_WF__c')==null)){
            component.set("v.noZoneTempError", true);
        }else{
            component.set("v.noZoneTempError", false);
        }
        //Exclusive Right section
        if(component.get('v.exclusiveRights.DoesTnthaveanExclusiveRight_WF__c')==true && 
           (component.get('v.exclusiveRights.ExclRightDescription_WF__c')=='' || component.get('v.exclusiveRights.ExclRightDescription_WF__c')==null || component.get('v.exclusiveRights.ExclDuration_WF__c')=='' || component.get('v.exclusiveRights.ExclDuration_WF__c')==null || component.get('v.exclusiveRights.ExclRemedyDescription_WF__c')=='' || component.get('v.exclusiveRights.ExclRemedyDescription_WF__c')==null)){
            component.set("v.exclusiveRightTempError", true);
        }else{
            component.set("v.exclusiveRightTempError", false);
        }
        //Kickouts section      
        if(kickouts.length >0 && component.get('v.opportunity.KickOuts_WF__c')==true){
            for(var i=0; i<kickouts.length; i++){
                if(kickouts[i].TypeofKickout_WF__c == '' || kickouts[i].TypeofKickout_WF__c == null || kickouts[i].TypeofKickout_WF__c == '--None--' || kickouts[i].StartDate_WF__c == '' || kickouts[i].StartDate_WF__c == null ||kickouts[i].EndDate_WF__c == '' || kickouts[i].EndDate_WF__c == null || kickouts[i].NoticePerioddays_WF__c == '' || kickouts[i].NoticePerioddays_WF__c == null || kickouts[i].TerminationEffectivefromNoticeDate_WF__c == '' || kickouts[i].TerminationEffectivefromNoticeDate_WF__c == null || kickouts[i].Unamortizedpaybacktype_WF__c == '' || kickouts[i].Unamortizedpaybacktype_WF__c == null){
                    component.set("v.COV_kickoutsTempError", true);
                    break;
                }else if(kickouts[i].TypeofKickout_WF__c == 'Mutual' && (kickouts[i].LandlordSalesThreshold_WF__c == '' || kickouts[i].LandlordSalesThreshold_WF__c == null || kickouts[i].TenantSalesThreshold_WF__c == '' || kickouts[i].TenantSalesThreshold_WF__c == null )){
                    component.set("v.COV_kickoutsTempError", true);
                    break;
                }else if(kickouts[i].TypeofKickout_WF__c == 'Landlord' && (kickouts[i].LandlordSalesThreshold_WF__c == '' || kickouts[i].LandlordSalesThreshold_WF__c == null)){
                    component.set("v.COV_kickoutsTempError", true);
                    break;
                }else if(kickouts[i].TypeofKickout_WF__c == 'Tenant' && (kickouts[i].TenantSalesThreshold_WF__c == '' || kickouts[i].TenantSalesThreshold_WF__c == null )){
                    component.set("v.COV_kickoutsTempError", true);
                    break;
                }else{
                    component.set("v.COV_kickoutsTempError", false);
                }
            }
        }
        //Co-Tenancy section        
        if(coTenants.length >0 && component.get('v.opportunity.CoTenancyRights_WF__c')==true){
            for(var i=0; i<coTenants.length; i++){
                if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || 
                   (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true))
                {
                    if((( coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].CoTenancyType_WF__c == 'Operating' ) && (((coTenants[i].SalesTest_WF__c == '' || coTenants[i].SalesTest_WF__c == null) && coTenants[i].SalesTest_WF__c != 0) || 
                                                                          coTenants[i].SalesTestMeasuringPeriod_WF__c == '' || coTenants[i].SalesTestMeasuringPeriod_WF__c == null || coTenants[i].SalesTestMeasuringPeriod_WF__c == '--None--' )) ||
                       (coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].OperatingCoTenancy_WF__c == true || coTenants[i].PosessionCoTenancy_WF__c == true || coTenants[i].ConstructionCoTenancy_WF__c == true) && (coTenants[i].NooofDeptStoresatCenter_WF__c == '' || coTenants[i].NooofDeptStoresatCenter_WF__c == null || coTenants[i].NoofDeptStoresRequired_WF__c == '' || coTenants[i].NoofDeptStoresRequired_WF__c == null)) ||
                       (coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].DefinitionofDeptStoresf_WF__c == '' || coTenants[i].DefinitionofDeptStoresf_WF__c == null)) ||
                       (coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].Remedy_WF__c == '' || coTenants[i].Remedy_WF__c == null || coTenants[i].Remedy_WF__c == '--None--')) ||
                       (coTenants[i].OpeningCoTenancy_WF__c == true && (coTenants[i].Concurrence_WF__c == '' || coTenants[i].Concurrence_WF__c == null || coTenants[i].Concurrence_WF__c == '--None--')) ||
                       (coTenants[i].GLARequired_WF__c == true && (coTenants[i].GLAPercent_WF__c == '' || coTenants[i].GLAPercent_WF__c == null ||
                                                                   coTenants[i].RemedyGLARequired_WF__c == '' || coTenants[i].RemedyGLARequired_WF__c == null || coTenants[i].RemedyGLARequired_WF__c == '--None--' ||
                                                                   coTenants[i].DescriptionGLARequired_WF__c == '' || coTenants[i].DescriptionGLARequired_WF__c == null)) ||
                       (coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].NamedStoreCT_WF__c == '' || coTenants[i].NamedStoreCT_WF__c == null ||
                                                                             coTenants[i].RemedyNamedStoreRequirement_WF__c == '' || coTenants[i].RemedyNamedStoreRequirement_WF__c == null || coTenants[i].RemedyNamedStoreRequirement_WF__c == '--None--' ||
                                                                             coTenants[i].DescriptionNamedStoreRequirement_WF__c == '' || coTenants[i].DescriptionNamedStoreRequirement_WF__c == null)) ||
                       (coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].Explanation_WF__c == '' || coTenants[i].Explanation_WF__c == null ||
                                                                        coTenants[i].RemedyotherRequirement_WF__c == '' || coTenants[i].RemedyotherRequirement_WF__c == null || coTenants[i].RemedyotherRequirement_WF__c == '--None--' ||
                                                                        coTenants[i].DescriptionOtherRequirement_WF__c == '' || coTenants[i].DescriptionOtherRequirement_WF__c == null)) ||
                       (coTenants[i].DepartmentStores_WF__c==false && coTenants[i].GLARequired_WF__c==false)){
                        console.log('iiiiiiiiiiiiiiiiiiiiii',JSON.stringify(coTenants[i]));
                        component.set("v.coTenancyTempError", true);
                        break;
                    }
                    else{
                        component.set("v.coTenancyTempError", false);
                    }                            
                }
                else{
                        component.set("v.coTenancyTempError", false);
                }
            }
        }
        else{
            component.set("v.coTenancyTempError", false);
        }
        
        
        //Charges Validation
        
        var chargesValidationBool = false;
        var mallCharges = {} ;
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Utilities']){
                mallCharges = charges[item];
            }
        }
        if(mallCharges.WaterProposed_WF__c!='' && mallCharges.WaterProposed_WF__c!=null && mallCharges.WaterProposed_WF__c!=0 && mallCharges.WaterProposed_WF__c!='0'  && ( mallCharges.WaterUnitofMeasure_WF__c == '--Select a value--' || mallCharges.WaterUnitofMeasure_WF__c == '') ){
            component.set('v.WaterError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.WaterError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.FDSProposed_WF__c!='' && mallCharges.FDSProposed_WF__c!=null && mallCharges.FDSProposed_WF__c!=0 && mallCharges.FDSProposed_WF__c!='0' && (mallCharges.FDSUnitofMeasure_WF__c == '--Select a value--' || mallCharges.FDSUnitofMeasure_WF__c == '') ){
            component.set('v.FDSError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.FDSError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.ElectricityProposed_WF__c!='' && mallCharges.ElectricityProposed_WF__c!=null && mallCharges.ElectricityProposed_WF__c!=0 && mallCharges.ElectricityProposed_WF__c!='0' && (mallCharges.ElectricityUnitofMeasure_WF__c == '--Select a value--' || mallCharges.ElectricityUnitofMeasure_WF__c == '') ){
            component.set('v.ElectricityError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.ElectricityError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.EncldMallHVACProposed_WF__c!='' && mallCharges.EncldMallHVACProposed_WF__c!=null && mallCharges.EncldMallHVACProposed_WF__c!=0 && mallCharges.EncldMallHVACProposed_WF__c!='0' && (mallCharges.EncldMallHVACUnitofMeasure_WF__c == '--Select a value--' || mallCharges.EncldMallHVACUnitofMeasure_WF__c == '') ){
            component.set('v.EncldMallError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.EncldMallError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.TTHVACCPLChilledWaterProposed_WF__c!='' && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!=null && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!=0 && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!='0' && (mallCharges.TTHVACCPLChilledWaterUnitofMeasure_WF__c == '--Select a value--' || mallCharges.TTHVACCPLChilledWaterUnitofMeasure_WF__c == '') ){
            component.set('v.HVACError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.HVACError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.TrashProposed_WF__c!='' && mallCharges.TrashProposed_WF__c!=null && mallCharges.TrashProposed_WF__c!=0 && mallCharges.TrashProposed_WF__c!='0' && (mallCharges.TrashUnitofMeasure_WF__c == '--Select a value--' || mallCharges.TrashUnitofMeasure_WF__c == '') ){
            component.set('v.TrashError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.TrashError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.ParkingProposed_WF__c !='' && mallCharges.ParkingProposed_WF__c!=null && mallCharges.ParkingProposed_WF__c!=0 && mallCharges.ParkingProposed_WF__c!='0' && (mallCharges.ParkingUnitofMeasure_WF__c == '--Select a Value--' || mallCharges.ParkingUnitofMeasure_WF__c == '') ){
            component.set('v.ParkingError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.ParkingError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge1Proposed_WF__c!='' && mallCharges.OtherCharge1Proposed_WF__c!=null && mallCharges.OtherCharge1Proposed_WF__c!=0 && mallCharges.OtherCharge1Proposed_WF__c!='0' && (mallCharges.OtherCharge1UnitofMeasure_WF__c == '--Select a Value--' || mallCharges.OtherCharge1UnitofMeasure_WF__c == '') ){
            component.set('v.Other1Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other1Error',false);
        } 
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge2Proposed_WF__c!='' && mallCharges.OtherCharge2Proposed_WF__c!=null  && mallCharges.OtherCharge2Proposed_WF__c!=0 && mallCharges.OtherCharge2Proposed_WF__c!='0'  && (mallCharges.OtherCharge2UnitofMeasure_WF__c == '--Select a value--' || mallCharges.OtherCharge2UnitofMeasure_WF__c == '') ){
            component.set('v.Other2Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other2Error',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge3Proposed_WF__c !='' && mallCharges.OtherCharge3Proposed_WF__c !=null  && mallCharges.OtherCharge3Proposed_WF__c !=0 && mallCharges.OtherCharge3Proposed_WF__c !='0'  && (mallCharges.OtherCharge3UnitofMeasure_WF__c == '--Select a value--' || mallCharges.OtherCharge3UnitofMeasure_WF__c == '') ){
            component.set('v.Other3Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other3Error',false);
        }
        console.log(chargesValidationBool);
        if(chargesValidationBool){
            component.set("v.CH_mallChargesTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.CH_mallChargesTempError", false);
        }
        
        //Comments Validation
        if(strDeadReason =='Other' && (strDeadReasonComms ==null || strDeadReasonComms ==''))
        {
            component.set('v.CO_detailsTempError', true);
            component.set('v.oppDeadCommsError', true);
            boolIsreqFiledEmpty=true;
        }
        else
        {           
            component.set('v.CO_detailsTempError', false);
            component.set('v.oppDeadCommsError', false);
            //boolIsreqFiledEmpty=false;
        }
        //Hold Reason Not mentioned 
        if(($A.util.isEmpty(holdReason) || holdReason == undefined) && holdCheck){
            component.set('v.CO_detailsTempError', true);
            component.set('v.CO_detailsError', true);
            component.set('v.oppHoldReasonError', true);
            boolIsreqFiledEmpty=true;    
            boolIsCmntError = true;
        } else {
            component.set('v.CO_detailsTempError', false);
            component.set('v.CO_detailsError', false);
            component.set('v.oppHoldReasonError', false);
        }
        //Check and set the error flags for each section - END
//Rec Comments Error GDM-7505
        if((recApprovalStatus == 'Reject'|| recApprovalStatus == 'On Hold') && recApprovalStatusComments == ''){
            component.set('v.CO_detailsError', true);
            component.set('v.recCommentsRejectError', true);
            component.set('v.CO_detailsTempError', true);
            boolIsreqFiledEmpty=true;    
        } 
        else {
            component.set('v.CO_detailsError', false);
            component.set('v.recCommentsRejectError', false);
            component.set('v.CO_detailsTempError', false);
        }
        //Check and set the error flags for each section - END
        
        
        console.log('v.GI_whatSectionError-->',component.get("v.GI_whatSectionError"));
        console.log('v.GI_whoSectionError-->',component.get("v.GI_whoSectionError"));
        console.log('v.GI_whereSectionTempError-->',component.get("v.GI_whereSectionTempError"));
        console.log('v.GI_whenSectionTempError-->',component.get("v.GI_whenSectionTempError"));
        console.log('v.commonAreaRestrictionTempError-->',component.get("v.commonAreaRestrictionTempError"));
        console.log('v.llRelocationRightsTempError-->',component.get("v.llRelocationRightsTempError"));
        console.log('v.COV_radiusRestrictionTempError-->',component.get("v.COV_radiusRestrictionTempError"));
        console.log('v.COV_llTerminationRightsError-->',component.get("v.COV_llTerminationRightsError"));
        console.log('v.COV_noBuildZoneError-->',component.get("v.COV_noBuildZoneError"));
        console.log('v.COV_exclusiveRightError-->',component.get("v.COV_exclusiveRightError"));
        console.log('v.COV_kickoutsError-->',component.get("v.COV_kickoutsError"));
        console.log('v.COV_coTenancyError-->',component.get("v.COV_coTenancyError"));
        console.log('boolIsreqFiledEmpty-->',boolIsreqFiledEmpty);
        return boolIsreqFiledEmpty;
    },
    
    getSecurityDepositDetails : function(component, validateData){
        if(component.get('v.opportunity.SecurityDepositRequired_WF__c')){
            console.log('selected security items..',component.get('v.opportunity.SecurityType_WF__c'));
            var securityType = component.get('v.opportunity.SecurityType_WF__c');
            if(securityType.includes('Guarantor')){
                //  Event to fetch the guarantor details          
                var guarantorEvent = $A.get("e.c:GuarantorDetailsEvent");
                guarantorEvent.setParams({
                    "showErrors": validateData
                });
                guarantorEvent.fire();
            }
            else{                
                component.set('v.showGuarantorErrors',false);
            }
            if (securityType.includes('Letter of Credit')){
                // Event to fetch the letter of credit details.             
                var letterOfCreditEvent = $A.get("e.c:LOCDetailsEvent");
                letterOfCreditEvent.setParams({
                    "showErrors": validateData
                });
                letterOfCreditEvent.fire();
            }
            else
                {
                 component.set('v.showErrors',false);
                }
        }else{
            component.set('v.showErrors',false);
            component.set('v.showGuarantorErrors',false);
            
        }
    },
    
    saveOpporHelper  : function(component, event,helper){
        var opportunity = component.get('v.opportunity'); 
        var construction = component.get('v.Construction');

        // JIRA ticket GDM-8354 Fix - Arut, 08202018 - Start
        // Root Cause Analysis: Clearing out milestone dates on the existing opportunities sets the date 
        //      fields with '' (empty string) in the aura:attribute 'Construction' instead of null values
        //      and this causes JSON deserialization issues in APEX code. 
        // Fix: Following code checks for empty string for milestone date fields and if found, replaces 
        //      them with null values in the JSON before the APEX method is called.
        var tmpCons = JSON.parse(JSON.stringify(construction));
        tmpCons.CommencementOfTenantWorkDate_WF__c === ''? 
            tmpCons.CommencementOfTenantWorkDate_WF__c = null: 
            tmpCons.CommencementOfTenantWorkDate_WF__c = construction.CommencementOfTenantWorkDate_WF__c;
        tmpCons.TenantBuildingPermitSubmissionDate_WF__c === ''? 
            tmpCons.TenantBuildingPermitSubmissionDate_WF__c = null: 
            tmpCons.TenantBuildingPermitSubmissionDate_WF__c = construction.TenantBuildingPermitSubmissionDate_WF__c;
        tmpCons.TenantFinalPlansSubmissionDate_WF__c === ''? 
            tmpCons.TenantFinalPlansSubmissionDate_WF__c = null: 
            tmpCons.TenantFinalPlansSubmissionDate_WF__c = construction.TenantFinalPlansSubmissionDate_WF__c;
        tmpCons.TenantLicenseSubmissionDate_WF__c === ''? 
            tmpCons.TenantLicenseSubmissionDate_WF__c = null: 
            tmpCons.TenantLicenseSubmissionDate_WF__c = construction.TenantLicenseSubmissionDate_WF__c;
        tmpCons.TenantsPreliminaryDesignDate_WF__c === ''? 
            tmpCons.TenantsPreliminaryDesignDate_WF__c = null: 
            tmpCons.TenantsPreliminaryDesignDate_WF__c = construction.TenantsPreliminaryDesignDate_WF__c;
        construction = tmpCons;
        // JIRA ticket GDM-8354 Fix - Arut, 08202018 - End

        var charges = component.get('v.Charges');
        var account = component.get('v.account');
        var budgets = component.get('v.budgets');
        var lease = component.get('v.lease');
        var securityType = component.get('v.opportunity.SecurityType_WF__c');
        var guarantor = component.get('v.addGuarantor');
        var loc = component.get('v.letterOfCredit');
        var strCreateTasksA3 = component.get('v.strCreateTaskA3');
        var strCreateTasks = component.get('v.strCreateTasks');
        
        var strPercentRate;
        
        if(component.get('v.lstGrowthRateTable').length > 0){
            strPercentRate = JSON.stringify(component.get('v.lstGrowthRateTable'));
        }
        var strOptionsPercentRate;
        
        if(component.get('v.lstOptionsTable').length > 0){
            strOptionsPercentRate = JSON.stringify(component.get('v.lstOptionsTable'));
        }      
        
        var strRenewalOptions;
        
        if(component.get('v.renewalOptions')){
            strRenewalOptions = JSON.stringify(component.get('v.renewalOptions'));
        }
        
        var action = component.get('c.saveOpportunity');
        
        /*if(account!=null && account!='{}'){
                account.CompanyLegalType_WF__c = component.find('LegalEntityType').get("v.value");
                account.StateOfIncorporation_WF__c = component.find('StateOfIncorporation').get('v.value');
            }*/
        if(component.get('v.reconfigBool')){
            opportunity.Reconfiguration_WF__c='Y';
        }else{
            opportunity.Reconfiguration_WF__c='N';
        }
        /*Added as part of GDM-8477 Issue #3*/
        if(component.get('v.reconfigBool') && component.get('v.strProducts') == ''){
            opportunity.Reconfiguration_WF__c='N';            
        }else if(component.get('v.reconfigBool') == false && component.get('v.strProducts') == ''){
            opportunity.Reconfiguration_WF__c='Y';
        }
        
        opportunity.Id = component.get('v.idOpportunity');
        opportunity.StorageUnitNo_WF__c = component.get('v.StorageUnit.Id');                
        opportunity.Unit_WF__c = component.get('v.Unit.Id');
        opportunity.Covenant__r = null;  
        if(component.get('v.DealValidated') == true)
        {
            opportunity.DealValidated_WF__c = true;
        }
        if(opportunity.StageName == $A.get("$Label.c.OpportunityProposalStage_WF") && component.get('v.DealValidated') == false)
        {
            opportunity.DealValidated_WF__c = false;
        } 
        /*opportunity.B2BCustomer_WF__c = component.get('v.DBACustomer.Id');
            opportunity.B2BCustomer_WF__r = component.get('v.DBACustomer');
            opportunity.LegalEntity_WF__c = component.get('v.LegalEntity.Id');                
            opportunity.ParentAccount_WF__c = component.get('v.Parent.Id');                
            opportunity.SuperParent_WF__c = component.get('v.SuperParent.Id');                
            opportunity.Dealmaker_WF__c = component.get('v.Dealmaker.Id');                
            opportunity.Broker_WF__c = component.get('v.Broker.Id');                
    
            opportunity.LeaseCoordinator_WF__c = component.get('v.LeaseCoordinator.Id');
            opportunity.LeaseNegotiator_WF__c = component.get('v.LeaseNegotiator.Id');*/
        
        /*if (typeof lease != 'undefined'){
                lease.Unit_WF__c = component.get('v.Unit.Id');
                lease.Unit_WF__r = component.get('v.Unit');
                lease.B2B_Customer_WF__c = component.get('v.B2BCustomer.Id');
                lease.B2B_Customer_WF__r = component.get('v.B2BCustomer');
            }*/
        
        var addProductArray = [];
        var strProductIds = '';
        
        var addStorageProductArray = [];
        var strStorageProductIds = '';
        
        if(component.get('v.strProductIds') != null && component.get('v.strProductIds') != ''){
            strProductIds = String(component.get('v.strProductIds'));
        }else{
            if(component.get('v.reconfigBool') != true){
                if(component.get('v.addProduct') != null){
                    addProductArray.push(component.get('v.addProduct'));                               
                    strProductIds = JSON.stringify(addProductArray);
                }else
                    strProductIds = null;
            }else{
                if(component.get('v.addProducts') != undefined && component.get('v.addProducts') != null)
                    strProductIds = JSON.stringify(component.get('v.addProducts'));
                else
                    strProductIds = null;
            }                
        }       
        
        var unitConfigs = component.get('v.unitConfig');        
        var strUnitConfig;        
        
        if(unitConfigs !== undefined && unitConfigs !== null){
            if(unitConfigs.length >0 )
                strUnitConfig = JSON.stringify(unitConfigs);
            else
                strUnitConfig = null;
        }else
            strUnitConfig = null;
        
        
        /* Storage Unit Configs */
        if(component.get('v.strStorageProductIds') != null && component.get('v.strStorageProductIds') != ''){
            strStorageProductIds = String(component.get('v.strStorageProductIds'));
        }else{
            
            if(component.get('v.addProductStorage') != null)
            {
                addStorageProductArray.push(component.get('v.addProductStorage'));
            }

                strStorageProductIds = JSON.stringify(addStorageProductArray); console.log('ReservationIds', strStorageProductIds);
            }
        
        var covenants = [];
        covenants = JSON.parse(JSON.stringify(component.get('v.lstKickouts')));
        var radiusRest = component.get('v.radiusRestriction');          
        //if(radiusRest.RadiusRestriction_WF__c == true){
            covenants.push(radiusRest);
            //covenants.push(component.get('v.radiusRestriction'));
        //}
        var cotenants = component.get('v.lstCoTenants');
        
        //if(component.get('v.opportunity.CoTenancyRights_WF__c')==true){
        for(var i=0;i<cotenants.length;i++){
            //if(cotenants[i].OpeningCoTenancy_WF__c || cotenants[i].OperatingCoTenancy_WF__c
            // || cotenants[i].PosessionCoTenancy_WF__c || cotenants[i].ConstructionCoTenancy_WF__c){
            covenants.push(cotenants[i]);
            //}
        }
        //}
        console.log('----exclusiveRights----->'+JSON.stringify(component.get('v.exclusiveRights')));
        //if(component.get('v.exclusiveRights').DoesTnthaveanExclusiveRight_WF__c){
            covenants.push(component.get('v.exclusiveRights'));
        //}
        //if(component.get('v.SLR').NoBdZneSiteLnRestrnLsngRestrn_WF__c){
            covenants.push(component.get('v.SLR'));
        //}
        covenants.push(component.get('v.otherCovenant'));
        covenants.push(component.get('v.landlordTerminationtionRight'));
        covenants.push(component.get('v.commonArRestriction'));
        covenants.push(component.get('v.llRelocationRight'));
        
        var strReservations = [];
        var strTempRes;            
        
        var strStorageReservations = [];
        var strStorageTempRes;            
        
        if(component.get('v.reconfigBool')){
            var reservations  = component.get('v.selectedUnits');
            if(reservations !== undefined && reservations !== null){
                if(reservations.length > 0)
                    strReservations = JSON.stringify(reservations);
                else
                    strReservations = null;
            }else
                strReservations = null;             
        }
        else
        {
            strTempRes = component.get('v.selectedProducts');
            console.log('212', strTempRes);
            if(strTempRes.length != undefined && strTempRes != null){
                if(strTempRes.length > 0){
                    for(var i=0; i<strTempRes.length; i++)
                    {
                        strReservations.push(strTempRes[i]);
                    }                           
                    strReservations = JSON.stringify(strReservations);console.log('213', strReservations);    
                }else
                    strReservations = null;                    
            }else
                strReservations = null;                
        }
        /* Storage */
        /*Added as part of GDM-8477 Issue #3*/
        console.log('opportunity.StorageReconfiguration_WF__c',opportunity.StorageReconfiguration_WF__c);
        if(opportunity.StorageReconfiguration_WF__c && component.get('v.opportunity.ProposedStorageUnitNumber_WF__c') == ''){
            var storageUC  = component.get('v.storageSelectedUnits');
            if($A.util.isUndefinedOrNull(storageUC) || $A.util.isEmpty(storageUC)){
                opportunity.StorageReconfiguration_WF__c = false;                
            }
            console.log('inside if');
        }else if(opportunity.StorageReconfiguration_WF__c == false && component.get('v.opportunity.ProposedStorageUnitNumber_WF__c') == ''){
            var storageProducts  = component.get('v.storageSelectedProducts');
            if($A.util.isUndefinedOrNull(storageProducts) || $A.util.isEmpty(storageProducts)){
                opportunity.StorageReconfiguration_WF__c = true;                
            }
            console.log('inside else');
        }
        console.log('opportunity.StorageReconfiguration_WF__c',opportunity.StorageReconfiguration_WF__c);
        
        if(opportunity.StorageReconfiguration_WF__c){
            var storageReservations  = component.get('v.storageSelectedUnits');
            if(storageReservations !== undefined && storageReservations !== null){
                if(storageReservations.length > 0)
                    strStorageReservations = JSON.stringify(storageReservations);
                else
                    strStorageReservations = null;
            }else
                strStorageReservations = null;              
        }
        else
        {
            strStorageTempRes = component.get('v.storageSelectedProducts');
            
            if(strStorageTempRes.length != undefined && strStorageTempRes != null){
                if(strStorageTempRes.length > 0){
                    for(var i=0; i<strStorageTempRes.length; i++)
                    {
                        strStorageReservations.push(strStorageTempRes[i]);
                    }                           
                    strStorageReservations = JSON.stringify(strStorageReservations);console.log('213', strStorageReservations);    
                }else
                    strStorageReservations = null;                    
            }else
                strStorageReservations = null;                                       
        }
        
        var isCashDeposit = component.get('v.IsCashDeposit');
        if(isCashDeposit){
            if( opportunity.Hold_Cash_Deposit_For_Amendment_WF__c == 'Other'){
                var years = 0;
                if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears')))
                    years = component.find('cashHoldYears').get('v.value');
                var months = 0;
                if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears')))
                    months =  component.find('cashHoldMonths').get('v.value'); 
                
                if(!($A.util.isUndefinedOrNull(years) && $A.util.isUndefinedOrNull(months)))
                    opportunity.Hold_Cash_Deposit_For_WF__c = Number(years  * 12) + Number(months);   
            }            
        }
        
        if(!$A.util.isUndefinedOrNull(opportunity.B2BCustomer_WF__r) && !$A.util.isUndefinedOrNull(opportunity.B2BCustomer_WF__c)){
            opportunity.Name = opportunity.B2BCustomer_WF__r.Name +' '+ opportunity.CenterName_WF__r.Name +' '+ component.get('v.strProducts');
        }else{
            opportunity.Name = opportunity.CenterName_WF__r.Name +' '+ component.get('v.strProducts');
        }
        console.log(JSON.stringify(opportunity));
        console.log(JSON.stringify(component.get('v.lstKickouts')));
        console.log('v.commonArRestriction save oppty-->',JSON.stringify(component.get('v.commonArRestriction')));
        console.log('v.llRelocationRight save oppty-->',JSON.stringify(component.get('v.llRelocationRight')));
        console.log('popup', component.get('v.boolUnitConfig'));
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var saveAndValidate = component.get('v.SaveAndValidateClicked');
        console.log('*** saveAndValidate', saveAndValidate);
        action.setParams({"strOpportunity" : JSON.stringify(opportunity),
                          "strAccount" : JSON.stringify(account),
                          "strLease" : JSON.stringify(lease),
                          "strConstruction" : JSON.stringify(construction),
                          "strCharges":JSON.stringify(charges),
                          "strCovenants":JSON.stringify(covenants),
                          "strBudget":JSON.stringify(budgets),
                          "strProductIds" : strProductIds,           
                          "strUnitConfig": strUnitConfig,
                          "proposedUnitNumber" : String(component.get('v.strProducts')),
                          "strComments" : String(component.get('v.strComments')),
                          "strGuarantor" : JSON.stringify(guarantor),  
                          "strDelGuarantor" : JSON.stringify(component.get('v.guarantorsToDelete')),
                          "strPercentRate" : strPercentRate,
                          "strShowProdPopup" : component.get('v.boolUnitConfig'),
                          "strOptionsPercentRate": strOptionsPercentRate,
                          "strRenewalOptions" : strRenewalOptions,
                          "strReservations" : strReservations,
                          "strStorageProductIds" : strStorageProductIds, 
                          "strStorageUnitConfig" : JSON.stringify(component.get('v.storageUnitConfig')), 
                          "storageProposedUnitNumber" : String(component.get('v.strStorageProducts')), 
                          "strStorageReservations" :strStorageReservations,
                          "isUnitInvoked" : component.get('v.isUnitInvoked'),
                          "isStorageInvoked" : component.get('v.isStorageInvoked'),
                          "kickoutToDelete" : JSON.stringify(component.get("v.kickoutToDelete")),
                          "strCreateTasksA3" : strCreateTasksA3,
                          "strCreateTasksA" : strCreateTasks,
                          "SaveAndValidateClicked" : saveAndValidate
                         });
        action.setCallback(this, function(response){
            var result = response.getReturnValue();                 
            
            if(response.getState() == 'SUCCESS' && result == true){
                
                component.set('v.boolUnitConfig', false);
                if( (typeof sforce != 'undefined') && (sforce != null) ) {                          
                    
                    sforce.one.navigateToSObject(opportunity.Id); 
                }
                /* back up if - sforce.one.navigateToSObject(recordId) code fails */
                else{                           
                    var urlOpptyDetailPage = "/one/one.app#/sObject/"+opportunity.Id+"/view";
                    window.open(urlOpptyDetailPage,"_self");
                }
            }
            else if(response.getState() == 'SUCCESS' && result == false){
                alert($A.get("$Label.c.DealSheetExceptionErrorMessage_WF"));
            }
            
        });
        $A.enqueueAction(action);
    },
    helperUpdateLeaseTerm : function(component, event){
        console.log('update Lease term');
        var rcdDate = component.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c');
        if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
            rcdDate = rcdDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var expDate = component.get('v.opportunity.ExpirationDate_WF__c');    
        if(!$A.util.isUndefinedOrNull(expDate) && expDate !== ''){
            expDate = expDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var drcdDare = new Date(rcdDate);
        var dexpDate = new Date(expDate);
        var noOdDaysinRCDMonth = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
        var diff = (dexpDate.getFullYear()*12 + dexpDate.getMonth()) - (drcdDare.getFullYear()*12 + drcdDare.getMonth());
        if(drcdDare.getDate()!=noOdDaysinRCDMonth){
            diff=diff+1;
        }
        console.log('diff',diff);
        var months = diff%12;    
        var years = Math.floor(diff/12);        
        if((dexpDate-drcdDare)<86400000){
            component.set('v.opportunity.TermYears_WF__c',String(0));
            component.set('v.opportunity.TermMonths_WF__c',String(0));
        }else{
            component.set('v.opportunity.TermYears_WF__c',String(years));
            component.set('v.opportunity.TermMonths_WF__c',String(months));
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermYears'))){            
            component.find('leaseTermYears').reInit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermMonths'))){            
            component.find('leaseTermMonths').reInit();
        }
        //component.find('idOptions').updateRenewalStartDate();
        if(!$A.util.isUndefinedOrNull(component.get('v.optionsComponent'))){
            var optionComponent = component.get('v.optionsComponent');
            if(optionComponent.length > 0 && optionComponent[0]){
                component.get('v.optionsComponent')[0].updateRenewalStartDate();       
            }
        }         
    },
    setSecurityTypeHelper : function(component,event,type,result){       
        var securityType = component.get('v.opportunity.SecurityType_WF__c');
        console.log('****',securityType);
        if(securityType == '--None--'){
            component.set('v.IsCashDeposit', false);
            component.set('v.IsGuarantor', false);
            component.set('v.IsLetterOfCredit', false);
        }else {                          
            if(securityType.includes("Cash Deposit")){
                component.set('v.IsCashDeposit', true); 
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
            }else {
                component.set('v.opportunity.Cash_Deposit_Amount_WF__c',0);
                component.set('v.opportunity.Hold_Cash_Deposit_For_Amendment_WF__c','');
                console.log('sss',component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'));
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
                component.set('v.opportunity.Cash_Deposit_Comments_WF__c','');
                component.set('v.IsCashDeposit', false);
            }
            if(type=='init'){
                console.log('GuasecurityType',securityType);
                console.log('Guatype',type);
                if(securityType.includes("Letter of Credit")){ 
                    var lstLOC ;
                    if(component.get('v.lstLOC') != null && component.get('v.lstLOC')!= undefined)
                    {
                        lstLOC = component.get('v.lstLOC');
                    }
                    else{
                        lstLOC =[] ;
                    }
                    var count = 1;
                    for(var i = 1 ; i <= 5 ; i++){                         
                        var objLOC = {};
                        var letterCredit = 'LetterofCredit_'+i+'_WF__c';  
                        var bankAddress  = 'BankAddress_'+i+'_WF__c';                
                        var hoc          = 'HoldLOCFor_'+i+'_WF__c';
                        var identifyBank = 'IdentifyBank_'+i+'_WF__c';
                        var locComments = 'LOCComments_'+ i+'_WF__c';
                        if(typeof result.opportunity[hoc] !== "undefined" && typeof result.opportunity[letterCredit] !== "undefined" && 
                           result.opportunity[hoc] !== '' && result.opportunity[letterCredit] !== '' && result.opportunity[letterCredit] > 0){
                            objLOC.LetterofCredit = result.opportunity[letterCredit];
                            objLOC.BankAddress =  result.opportunity[bankAddress];
                            if(typeof result.opportunity[hoc] !== "undefined" && result.opportunity[hoc] !== null && result.opportunity[hoc] !== ''){
                                objLOC.years = String(Math.floor(result.opportunity[hoc]/12));
                                objLOC.months = String(result.opportunity[hoc]%12);
                            }
                            objLOC.IdentifyBank = result.opportunity[identifyBank];
                            objLOC.LOCComments = result.opportunity[locComments];
                            objLOC.count = count;
                            lstLOC.push(objLOC);
                            count = count + 1;
                        }
                    }
                    component.set('v.lstLOC', lstLOC);
                    component.set('v.LetterOfCreditBool', true);
                    component.set('v.noOfletterOfCredit' , lstLOC.length);                              
                    component.set('v.IsLetterOfCredit', true);
                }
                else{
                    component.set('v.IsLetterOfCredit', false);
                }
                if(securityType.includes("Guarantor")){   
                    console.log('GuasecurityType',securityType);
                    console.log('Guatype',type);
                    var guarantors = '{}';
                    if (typeof result.guarantors !== "undefined") {
                        guarantors = result.guarantors;
                        var updatedGuarantors = [];
                        for(var each in guarantors){
                            var eachG = {};
                            eachG = JSON.parse(JSON.stringify(guarantors[each]));
                            //Joshna, 18/10/2017 - INC0038047
                            eachG.stateOfIncorp = $A.util.isUndefinedOrNull(guarantors[each].RelatedAccount_WF__r) ? '' : guarantors[each].RelatedAccount_WF__r.StateOfIncorporation_WF__c;
                            //Need to convert this string as the "set" for ui:inputseectOption doesn't work if it's not of the same data type
                            if(guarantors[each].Years_WF__c !== undefined && guarantors[each].Years_WF__c !== null && guarantors[each].Years_WF__c !== '')
                                eachG.Years_WF__c = String(guarantors[each].Years_WF__c);
                            if(guarantors[each].Months_WF__c !== undefined && guarantors[each].Months_WF__c !== null && guarantors[each].Months_WF__c !== '')
                                eachG.Months_WF__c = String(guarantors[each].Months_WF__c);
                            updatedGuarantors.push(eachG);
                        }
                        component.set('v.guarantor', updatedGuarantors);
                        component.set('v.GuarantorBool', true);
                        component.set('v.noOfGuarantor',guarantors.length);         
                    }                    
                    component.set('v.IsGuarantor', true);   
                }
                else{
                    component.set('v.IsGuarantor', false);            
                }
            }
            else{
                if(securityType.includes("Letter of Credit")){
                    component.set('v.IsLetterOfCredit', true);            
                }
                else {
                    component.set('v.IsLetterOfCredit', false);
                    component.set('v.GI_securitySectionTempError',false);
                    var noOfletterOfCredit = component.get('v.noOfletterOfCredit');
                    var lstLOC = component.get('v.lstLOC');
                    var lstToDelete = []
                    for(var i=0 ;i<noOfletterOfCredit; i++){
                        lstLOC.pop();                      
                    }   
                    var action = component.get('c.deleteLoc');
                    action.setParams({
                        "OppId" : component.get('v.idOpportunity')
                    });
                    action.setCallback(this, function(response){
                        var result = response.getReturnValue();  
                        console.log('*************',result);
                        if(result && response.getState() == 'SUCCESS' && component.isValid()){
                            component.set('v.lstLOC',lstLOC);
                            component.set('v.noOfletterOfCredit',0);
                        }
                    });
                    $A.enqueueAction(action);
                }
                if(securityType.includes("Guarantor")){
                    component.set('v.IsGuarantor', true);            
                }
                else {
                    component.set('v.IsGuarantor', false);
                    component.set('v.GI_securitySectionTempError',false);
                    var numberOfGuarantor = component.get('v.noOfGuarantor');
                    var guarantor = component.get('v.guarantor');
                    var lstToDelete = []
                    for(var i=0 ;i<numberOfGuarantor; i++){
                        var deletedGuarantors = guarantor.pop();
                        if(deletedGuarantors.Id !== undefined && deletedGuarantors.Id !== null && deletedGuarantors.Id !== ''){
                            lstToDelete.push(deletedGuarantors.Id);
                        }                        
                    }          
                    var action = component.get('c.deleteGuarantor');
                    action.setParams({
                        "lstToDelete" : JSON.stringify(lstToDelete)
                    });
                    action.setCallback(this, function(response){
                        console.log('gua delete call back');
                        var result = response.getReturnValue();  
                        if(result && response.getState() == 'SUCCESS' && component.isValid()){
                            component.set('v.guarantor',guarantor);
                            component.set('v.noOfGuarantor',0);
                        }
                    });
                    $A.enqueueAction(action);
                }
            }
        }       
    },
    clearOperatingCoTenancy : function(component,event){
        var operatingCoTenancy;
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Operating'){
                operatingCoTenancy = lstCoTenants[item];
            }
        }
        operatingCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        operatingCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        operatingCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        operatingCoTenancy.SalesTest_WF__c=0;
        operatingCoTenancy.DepartmentStores_WF__c = false;
        operatingCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        operatingCoTenancy.NoofDeptStoresRequired_WF__c=0;
        operatingCoTenancy.DefinitionofDeptStoresf_WF__c = '';
        //operatingCoTenancy.SizeofDepartmentStore_WF__c=0;
        operatingCoTenancy.Remedy_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionRemedy_WF__c='';
        operatingCoTenancy.Concurrence_WF__c='Or';
        operatingCoTenancy.NamedStoreCoTenancy_WF__c='';
        operatingCoTenancy.GLARequired_WF__c=false;
        operatingCoTenancy.GLAPercent_WF__c=0;
        operatingCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionGLARequired_WF__c='';
        operatingCoTenancy.NamedStoreCT_WF__c='';
        operatingCoTenancy.NoofNamedStoresRequired_WF__c=0;
        operatingCoTenancy.NamedStoreRequirement_WF__c=false;
        operatingCoTenancy.OtherRequirement_WF__c=false;
        operatingCoTenancy.Explanation_WF__c='';
        operatingCoTenancy.ReplacementTenantDescription_WF__c='';
        operatingCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionOtherRequirement_WF__c='';
        operatingCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        operatingCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        operatingCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
    },
    clearOpeningCoTenancy : function(component,event){
        var openingCoTenancy;
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Opening'){
                openingCoTenancy = lstCoTenants[item];
            }
        }
        openingCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        openingCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        openingCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        openingCoTenancy.SalesTest_WF__c=0;
        openingCoTenancy.DefinitionofDeptStoresf_WF__c=''
        openingCoTenancy.DepartmentStores_WF__c = false;
        openingCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        openingCoTenancy.NoofDeptStoresRequired_WF__c=0;
        //openingCoTenancy.SizeofDepartmentStore_WF__c=0;
        openingCoTenancy.Remedy_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionRemedy_WF__c='';
        openingCoTenancy.Concurrence_WF__c='Or';
        openingCoTenancy.NamedStoreCoTenancy_WF__c='';
        openingCoTenancy.GLARequired_WF__c=false;
        openingCoTenancy.GLAPercent_WF__c=0;
        openingCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionGLARequired_WF__c='';
        openingCoTenancy.NamedStoreCT_WF__c='';
        openingCoTenancy.NoofNamedStoresRequired_WF__c=0;
        openingCoTenancy.NamedStoreRequirement_WF__c=false;
        openingCoTenancy.OtherRequirement_WF__c=false;
        openingCoTenancy.Explanation_WF__c='';
        openingCoTenancy.ReplacementTenantDescription_WF__c='';
        openingCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionOtherRequirement_WF__c='';
        openingCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        openingCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        openingCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        openingCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        openingCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        openingCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        openingCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
    },
    clearConstructionCoTenancy : function(component,event){
        var constructionCoTenancy;
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Construction'){
                constructionCoTenancy = lstCoTenants[item];
            }
        }
        constructionCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        constructionCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        constructionCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        constructionCoTenancy.SalesTest_WF__c=0;
        constructionCoTenancy.DefinitionofDeptStoresf_WF__c=''
        constructionCoTenancy.DepartmentStores_WF__c = false;
        constructionCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        constructionCoTenancy.NoofDeptStoresRequired_WF__c=0;
        //constructionCoTenancy.SizeofDepartmentStore_WF__c=0;
        constructionCoTenancy.Remedy_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionRemedy_WF__c='';
        constructionCoTenancy.Concurrence_WF__c='Or';
        constructionCoTenancy.NamedStoreCoTenancy_WF__c='';
        constructionCoTenancy.GLARequired_WF__c=false;
        constructionCoTenancy.GLAPercent_WF__c=0;
        constructionCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionGLARequired_WF__c='';
        constructionCoTenancy.NamedStoreCT_WF__c='';
        constructionCoTenancy.NoofNamedStoresRequired_WF__c=0;
        constructionCoTenancy.NamedStoreRequirement_WF__c=false;
        constructionCoTenancy.OtherRequirement_WF__c=false;
        constructionCoTenancy.Explanation_WF__c='';
        constructionCoTenancy.ReplacementTenantDescription_WF__c='';
        constructionCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionOtherRequirement_WF__c='';
        constructionCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        constructionCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        constructionCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        constructionCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        constructionCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        constructionCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        constructionCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
        constructionCoTenancy.IsTenantRequiredToStartConstruction_WF__c=false;        
    },
    clearPosessionCoTenancy : function(component,event){
        var posessionCoTenancy;
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            if(lstCoTenants[item].CoTenancyType_WF__c =='Posession'){
                posessionCoTenancy = lstCoTenants[item];
            }
        }
        posessionCoTenancy.SalesTestMeasuringPeriod_WF__c = 'Months';
        posessionCoTenancy.SalesTestMeasuringPeriodMonths_WF__c=0;
        posessionCoTenancy.SalesTestMeasuringPeriodDays_WF__c =0;
        posessionCoTenancy.SalesTest_WF__c=0;
        posessionCoTenancy.DefinitionofDeptStoresf_WF__c=''
        posessionCoTenancy.DepartmentStores_WF__c = false;
        posessionCoTenancy.NooofDeptStoresatCenter_WF__c=0;
        posessionCoTenancy.NoofDeptStoresRequired_WF__c=0;
        //posessionCoTenancy.SizeofDepartmentStore_WF__c=0;
        posessionCoTenancy.Remedy_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionRemedy_WF__c='';
        posessionCoTenancy.Concurrence_WF__c='Or';
        posessionCoTenancy.NamedStoreCoTenancy_WF__c='';
        posessionCoTenancy.GLARequired_WF__c=false;
        posessionCoTenancy.GLAPercent_WF__c=0;
        posessionCoTenancy.RemedyGLARequired_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionGLARequired_WF__c='';
        posessionCoTenancy.NamedStoreCT_WF__c='';
        posessionCoTenancy.NoofNamedStoresRequired_WF__c=0;
        posessionCoTenancy.NamedStoreRequirement_WF__c=false;
        posessionCoTenancy.OtherRequirement_WF__c=false;
        posessionCoTenancy.Explanation_WF__c='';
        posessionCoTenancy.ReplacementTenantDescription_WF__c='';
        posessionCoTenancy.RemedyotherRequirement_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionOtherRequirement_WF__c='';
        posessionCoTenancy.RemedyNamedStoreRequirement_WF__c='Reduction in Rent';
        posessionCoTenancy.DescriptionNamedStoreRequirement_WF__c='';
        posessionCoTenancy.ConcurrenceOpeningGLACTWF__c='Or';
        posessionCoTenancy.IsTntReqdtoOpenNSRqmnt_WF__c=false;
        posessionCoTenancy.IsTntReqdtoOpenOthrRqmnt_WF__c=false;
        posessionCoTenancy.IsTenantRequiredtoOpen_WF__c=false;
        posessionCoTenancy.IsTnntreqdtoopenGLAReqd_WF__c=false;
        posessionCoTenancy.IsTenantRequiredToStartConstruction_WF__c=false;
        posessionCoTenancy.IsTntReqdtoAcceptPosession_WF__c=false;
    },
    setVacateDate : function(component, event) 
    {console.log('vd1');
        var vlease = component.get('v.lease');
        var spDeldate = new Date(component.get('v.opportunity.SpaceDeliveryDate__c'));
        var llConPerDays = component.get('v.Construction.DaysCompleteLLWDrawingsPermits_WF__c');
        var llConWkDays = component.get('v.Construction.DaysCompleteLLWConstruction_WF__c')
        if((vlease[0] != null && vlease[0].Id == null) || vlease[0] == null || vlease[0] == '' || vlease[0] == '{}')
        {
            var objLease = {};
            if(!$A.util.isUndefinedOrNull(spDeldate) && !$A.util.isUndefinedOrNull(llConPerDays) && !$A.util.isUndefinedOrNull(llConWkDays))
            {
                var addDays = Number(llConPerDays) + Number(llConWkDays);
                spDeldate.setDate(spDeldate.getUTCDate() - addDays);
                objLease.VacateDate_WF__c = this.getFormattedDate(spDeldate);
                vlease[0] = objLease;
                component.set('v.lease', vlease); 
            }
        }
    },
    getFormattedDate : function(date) {
            var year = date.getFullYear();
            var month = (1 + date.getMonth()).toString();
            month = month.length > 1 ? month : '0' + month;
            var day = date.getDate().toString();
            day = day.length > 1 ? day : '0' + day;
            return year + '-' + month + '-' + day;
        },
    
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = result.objectList;
        var fieldNames = result.FieldList;
        console.log('picklistMap',picklistMap);
        for(var each in objNames){
            for(var eachField in fieldNames){
                if(!$A.util.isUndefinedOrNull(component.find(objNames[each] + fieldNames[eachField]))){
                    var optionVals = picklistMap[objNames[each] + fieldNames[eachField]];
                    console.log('****',objNames[each] + fieldNames[eachField],optionVals);
                    if(!$A.util.isUndefinedOrNull(optionVals)){
                        component.find(objNames[each] + fieldNames[eachField]).setLocalValues(optionVals);
                    }
                }
            }
        }
        console.log('I am here in helper before fetch picklist is assigned into variable');
        var fetchPickList = $A.get("e.c:fetchPicklist");
        console.log('I am here in helper after fetch picklist is assigned into variable');
        if(fetchPickList !== undefined){
             console.log('I am here in helper before fetch picklist is fired');
            
            fetchPickList.fire();
             console.log('I am here in helper after fetch picklist is fired');
        }
         console.log('I am here in helper before fetch picklist table is assigned into variable');
        var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
         console.log('I am here in helper after fetch picklist table is assigned into variable');
        if(fetchPickListTable !== undefined){
             console.log('I am here in helper before fetch picklist table is fired');
            fetchPickListTable.fire();
            console.log('I am here in helper after fetch picklist table is fired');
        }
    },
    
    secondCallout : function(component, helper, result) {
        var account ={};
        component.set('v.account', account);
        
        var lease = [];               
        component.set('v.lease', lease);
        
        var arrBudget =[];
        component.set('v.budgets', arrBudget);
        
        component.set('v.lstKickouts', []);
        
        var action = component.get('c.getRelatedOpportunityDetails');
        var opportunity = component.get('v.opportunity');
        action.setParams({
            "strOpportunity" : JSON.stringify(opportunity),
            "Disabled" : component.get('v.disabled')
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.opportunity', result.opportunity);
                    component.set('v.relatedRecord',result);
                    if(result)                    
                        if(result.product !== undefined){
                            component.set('v.product', result.product);
                        }
                    if(result.storageProduct !== undefined){
                        component.set('v.product', result.storageProduct);
                    }
                    if(component.get('v.reconfigBool')){
                        if(!$A.util.isUndefinedOrNull(result.unitConfigurations)){
                            if(result.unitConfigurations.length > 0)
                                component.set('v.boolMerge', true);
                            component.set('v.allUnitConfigs', result.unitConfigurations);
                        }
                    }else{
                        if(!$A.util.isUndefinedOrNull(result.reservationsForReconfigNo)){
                            component.set('v.selectedProducts', result.reservationsForReconfigNo);
                        }
                    }
                    
                    if(component.get('v.opportunity.StorageReconfiguration_WF__c')){
                        if(!$A.util.isUndefinedOrNull(result.storageUnitConfigurations)){
                            if(result.storageUnitConfigurations.length > 0)
                                component.set('v.boolStorageMerge', true);
                            component.set('v.allStorageUnitConfigs', result.storageUnitConfigurations);
                        }
                    }else{
                        if(!$A.util.isUndefinedOrNull(result.reservationsForStorageReconfigNo)){
                            component.set('v.storageSelectedProducts', result.reservationsForStorageReconfigNo);
                        }
                    }
                    
                    if(result.lstRentTableWrapper != undefined ){                            
                        component.set('v.lstGrowthRateTable', result.lstRentTableWrapper);
                        console.log(JSON.stringify(result.lstRentTableWrapper));
                        component.set('v.showTable', true);
                    }
                    
                    if(result.lstOptionsRentTableWrapper != undefined ){                            
                        component.set('v.lstOptionsTable', result.lstOptionsRentTableWrapper); 
                        component.set('v.showOptionsTable', true);
                    }
                    if(result.lstLeaseRenewalOptionsWrapper != undefined){
                        component.set('v.renewalOptions', result.lstLeaseRenewalOptionsWrapper)
                    }
                    if(result.charges !== undefined && result.charges.length!=0){
                        component.set('v.Charges',result.charges);
                    }
                    if(result.chargesRecordTypeMap !== undefined && result.chargesRecordTypeMap.length!=0){
                        component.set('v.ChargesRecordType',result.chargesRecordTypeMap);
                    }
                    if(result.standardCharges !== undefined && result.standardCharges.length!=0){
                        component.set('v.StandardCharges',result.standardCharges);
                    }
                    
                    component.set('v.budgets', result.budgets != null ? result.budgets : []);
                    
                    if(result.construction !== undefined ){
                        component.set('v.Construction',result.construction);
                    }                 
                                       
                    component.set('v.account',account);
                    
                    var radiusRestriction = {};
                    radiusRestriction.of_WF__c = 'Miles';
                    radiusRestriction.RR_Other_WF__c = '';
                    radiusRestriction.RadiusDistance_WF__c = 10;
                    radiusRestriction.Duration_WF__c = 'Entire Term incl. any Option(s)';
                    radiusRestriction.DurationYears_WF__c = '0';
                    radiusRestriction.Duration_Months__c = '0';
                    radiusRestriction.RadiusPenalty_WF__c = 'Incl. GS From Competing Location (standard);Any Kickout(s) Removed';
                    radiusRestriction.RadiusAppliesTo_WF__c = '';
                    radiusRestriction.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Radius_Restriction");
                    radiusRestriction.RadiusRestriction_WF__c = true;
                    
                    var ct = {};
                    ct.Remedy_WF__c = 'Reduction in Rent';
                    ct.RemedyGLARequired_WF__c = 'Reduction in Rent';
                    ct.RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
                    ct.RemedyotherRequirement_WF__c = 'Reduction in Rent';
                    ct.Concurrence_WF__c = 'Or';
                    ct.ConcurrenceOpeningGLACTWF__c = 'Or';
                    ct.OpeningCoTenancy_WF__c = false;
                    ct.OperatingCoTenancy_WF__c = false;
                    ct.PosessionCoTenancy_WF__c = false;
                    ct.ConstructionCoTenancy_WF__c = false;
                    ct.DepartmentStores_WF__c = false;
                    ct.NooofDeptStoresatCenter_WF__c = null;
                    ct.DefinitionofDeptStoresf_WF__c = '';
                    ct.NoofDeptStoresRequired_WF__c = null;
                    ct.DescriptionRemedy_WF__c = '';
                    ct.IsTenantRequiredtoOpen_WF__c = false;
                    ct.NamedStoreCoTenancy_WF__c = '';
                    ct.GLARequired_WF__c = false;
                    ct.GLAPercent_WF__c = null;
                    ct.DescriptionGLARequired_WF__c = '';
                    ct.IsTnntreqdtoopenGLAReqd_WF__c = false;
                    ct.NamedStoreRequirement_WF__c = false;
                    ct.NamedStoreCT_WF__c = '';
                    ct.NoofNamedStoresRequired_WF__c = null;
                    ct.DescriptionNamedStoreRequirement_WF__c = '';
                    ct.IsTntReqdtoOpenNSRqmnt_WF__c = false;
                    ct.OtherRequirement_WF__c = false;
                    ct.Explanation_WF__c = '';
                    ct.DescriptionOtherRequirement_WF__c = '';
                    ct.IsTntReqdtoOpenOthrRqmnt_WF__c = false;
                    ct.ReplacementTenantDescription_WF__c = '';
                    ct.IsTntReqdtoAcceptPosession_WF__c = false;
                    ct.IsTenantRequiredToStartConstruction_WF__c = false;
                    ct.SalesTest_WF__c = null;
                    ct.SalesTestMeasuringPeriod_WF__c = 'Months';
                    ct.SalesTestMeasuringPeriodDays_WF__c = null;
                    ct.SalesTestMeasuringPeriodMonths_WF__c = null;
                    //ct.SizeofDepartmentStore_WF__c = 20000;
                    ct.SalesTestMeasuringPeriod_WF__c = 'Months';
                    ct.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Co_Tenancy");
                    var arrCovenants = [];
                    
                    var coTenantOperating = JSON.parse(JSON.stringify(ct));
                    coTenantOperating.CoTenancyType_WF__c = 'Operating';
                    arrCovenants.push(coTenantOperating);
                    var coTenantOpening = JSON.parse(JSON.stringify(ct));
                    coTenantOpening.CoTenancyType_WF__c = 'Opening';
                    arrCovenants.push(coTenantOpening);
                    var coTenantConstruction = JSON.parse(JSON.stringify(ct));
                    coTenantConstruction.CoTenancyType_WF__c = 'Construction';
                    arrCovenants.push(coTenantConstruction);
                    var coTenantPosession = JSON.parse(JSON.stringify(ct));
                    coTenantPosession.CoTenancyType_WF__c = 'Posession';
                    arrCovenants.push(coTenantPosession);
                    
                    if(result.coTenants !== undefined && result.coTenants != null){
                        var opening = false;
                        var posession = false;
                        
                        for(var i=0;i<result.coTenants.length;i++){
                            if(result.coTenants[i].CoTenancyType_WF__c == 'Operating'){                                    
                                arrCovenants[0] = result.coTenants[i];
                            }
                            if(result.coTenants[i].CoTenancyType_WF__c == 'Opening'){
                                arrCovenants[1] = result.coTenants[i];
                                opening = true;
                            }
                            if(result.coTenants[i].CoTenancyType_WF__c == 'Construction'){
                                arrCovenants[2] = result.coTenants[i];
                            }
                            if(result.coTenants[i].CoTenancyType_WF__c == 'Posession'){
                                arrCovenants[3] = result.coTenants[i];
                                posession = true;
                            }
                        }
                        
                        /* Joshna - 3rd October '17 : removing this as its not required
                         *if(posession == false){
                            var coTenant = JSON.parse(JSON.stringify(arrCovenants[1]));
                            coTenant.OpeningCoTenancy_WF__c = false;
                            coTenant.CoTenancyType_WF__c = 'Posession';
                            arrCovenants[3] = coTenant;
                        }*/
                    }
                    var commonAreaRestriction = {};
                    commonAreaRestriction.RestrictionType_WF__c = '--None--';
                    commonAreaRestriction.Description_Restriction_Type_WF__c = '';
                    commonAreaRestriction.IfCompetingUseNoofFt_WF__c = 0;
                    commonAreaRestriction.IfCompetingUseDescription_WF__c = '';
                    commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c = '--None--';
                    commonAreaRestriction.DistancefromStorefront_WF__c = 0;
                    commonAreaRestriction.Duration_of_Restriction_WF__c = 0;
                    commonAreaRestriction.LandlordPenalty_WF__c = 0;
                    commonAreaRestriction.CommonAreaRestrictions_WF__c = false;
                    commonAreaRestriction.Competing_Use_WF__c = false;
                    commonAreaRestriction.LLrighttorenewexisting_WF__c = false;
                    commonAreaRestriction.LLrighttoreplaceexisting_WF__c = false;
                    commonAreaRestriction.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Common_Area_Restrictions_WF");
                    
                    var llRelocationRight = {};
                    llRelocationRight.StandardRelocationRights_WF__c = true;
                    llRelocationRight.Zone_WF__c = false;
                    llRelocationRight.IfNoRelocationRightsDescription_WF__c = '';
                    llRelocationRight.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Landlord_Relocation_Rights_WF");
                    component.set('v.lstCoTenants',arrCovenants);
                    component.set('v.lease', (result.lease != null && result.lease != 'undefined') ? result.lease  : '{}');
                    if($A.util.isUndefinedOrNull(result.lease)){
                        helper.setVacateDate(component);
                    }
    
                    component.set('v.noOfKickouts', result.covenants != null ? result.covenants.length : 0);
                    //component.set('v.boolRadiusRestriction', true);
                    component.set('v.lstKickouts', result.covenants != null ? result.covenants : []);
                    component.set('v.otherCovenant', result.other != null ? result.other:{"CovenantComments_WF__c":"","RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Other")});
                    component.set('v.exclusiveRights', result.exclusiveRight != null ? result.exclusiveRight:{"DoesTnthaveanExclusiveRight_WF__c":false,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Exclusive_Right"),ExclDuration_WF__c:null,ExclRightDescription_WF__c:"",ExclRemedyDescription_WF__c:""});
                    component.set('v.SLR', result.SLR != null ? result.SLR:{"NoBdZneSiteLnRestrnLsngRestrn_WF__c":false,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_SLR"),Zone_WF__c:false,ZoneDetails_WF__c:"",DescriptionZone_WF__c:""});
                    component.set('v.landlordTerminationtionRight', result.landlordTerminationRights != null ? result.landlordTerminationRights:{"StandardTerminationRights_WF__c":true,"RecordTypeId":$A.get("$Label.c.Covenant_Rec_Type_Landlord_Termination_Rights"),TerminationRightsDescription_WF__c:""});
                    component.set('v.radiusRestriction', result.radiusRestrictions != null ? result.radiusRestrictions : radiusRestriction);
                    component.set('v.commonArRestriction',result.commonAreaRestrictions != null ? result.commonAreaRestrictions : commonAreaRestriction);
                    component.set('v.llRelocationRight', result.llRelocationRights != null ? result.llRelocationRights : llRelocationRight);                
                    helper.createComponents(component, helper, result)
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    lazyLoadComponents : function(component, helper, result){
        helper.secondCallout(component, helper, result);
    }, 

validateComponentTextField : function(component){
         var coTenancyError = false;
         var boolIsCmntError=false;
         var boolIsError=false;
         var noBuildZoneerror=false;
         var boolIsUseClauseErr =false;
         var boolIsPatioCommentErr= false;
         var boolIsContigencyCommentErr=false;
         var restrictionTimePeriodError =false;
         var COV_exclusiveRightError= false;
         var boolIsRentStabError=false;
         var boolIsTenantPerfReqError=false;
         var boolIschargesErr= false;
         var boolIsCaptialDescError=false;
         var boolIsLandlordConsError=false;
         var boolIstenatConsCmntErr=false;
         var boolIsRadiusResErr=false;
         var boolIsCmnResError=false;
         var boolIsLLRelocationError =false;
         var boolIsPercRentError=false;
         var boolIsLandlordTermError=false;
         var boolIsCashDepErr =false;
         var OptionRentStabCmntErr=false;
         var rentStabCmntErr=false;
         var boolIsPercentRentNonStdErr =false;
         var minimumCmpNonStdCmntError=false;
         var minimumCmpNonStdOptnCmntError=false;
         var percentRentNonStdCmntError=false;
         var boolIsOptionCommentError=false;
         var optionNotifyOtherCmntErr=false;
         var boolIsKickoutErr=false;
        var percentRentNonStdCmntothrError=false;
        
        var lstGrowthRateTable = component.get('v.lstGrowthRateTable');  
         var useClauseLengthError =component.find('useClauseLengthError');
         var cashDepLengthError =component.find('cashDepLengthError');
         var acdbePartLengthError= component.find('ACDBELengthCommentsErr')
         var conCommsLengthError= component.find('conCommsLengthErrorId');
         var patioCommentError=component.find('patioCommentLengthErrorId');
    
         var coTenants = component.get('v.lstCoTenants');
         var llRelocationRight=component.get('v.llRelocationRight');
         var commonArRestriction=component.get('v.commonArRestriction');
         var landlordTerminationtionRight=component.get('v.landlordTerminationtionRight');
         var exclusiveRights=component.get('v.exclusiveRights');
         var otherCovenant =component.get('v.otherCovenant');
         var SLR =component.get('v.SLR');
         var result =component.get('v.relatedRecord');
        var renewalOptions= component.get('v.renewalOptions');

         console.log('result',result);
         var covenantTextFieldMap = result.covenantTextFieldMap;
         console.log('covenantTextFieldMap n perm',covenantTextFieldMap);
         component.set('v.GI_currentTenantError',false);
     if(!$A.util.isUndefinedOrNull(coTenants) &&coTenants.length >0 && !$A.util.isUndefinedOrNull(component.get('v.opportunity.CoTenancyRights_WF__c')) && component.get('v.opportunity.CoTenancyRights_WF__c')==true)
     {
         for(var i=0; i<coTenants.length; i++)
         {
                 console.log('coTenants',coTenants[i]);
                 if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || 
                    (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true))
                 {
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DefinitionofDeptStoresf_WF__c'])&& !$A.util.isUndefinedOrNull(coTenants[i].DefinitionofDeptStoresf_WF__c) &&
                        coTenants[i].DefinitionofDeptStoresf_WF__c.length > covenantTextFieldMap['DefinitionofDeptStoresf_WF__c'])
                     {
                         $A.util.removeClass(document.getElementById('defDeptStoreLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('defDeptStoreLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionRemedy_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionRemedy_WF__c)&&coTenants[i].DescriptionRemedy_WF__c.length > covenantTextFieldMap['DescriptionRemedy_WF__c'])
                     {
                         $A.util.removeClass(document.getElementById('noDeptRemDescReqdLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                         
                     }
                     else{
                         $A.util.addClass(document.getElementById('noDeptRemDescReqdLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionGLARequired_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionGLARequired_WF__c)&&coTenants[i].DescriptionGLARequired_WF__c.length > covenantTextFieldMap['DescriptionGLARequired_WF__c'])
                     {
                         $A.util.removeClass(document.getElementById('descGLAReqdLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                         
                     }
                     else{
                         $A.util.addClass(document.getElementById('descGLAReqdLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['NamedStoreCoTenancy_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].NamedStoreCoTenancy_WF__c)&&coTenants[i].NamedStoreCoTenancy_WF__c.length > covenantTextFieldMap['NamedStoreCoTenancy_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('namedStoreCotenancyLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('namedStoreCotenancyLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionNamedStoreRequirement_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionNamedStoreRequirement_WF__c)&&coTenants[i].DescriptionNamedStoreRequirement_WF__c.length > covenantTextFieldMap['DescriptionNamedStoreRequirement_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('descNamedStoreReqLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('descNamedStoreReqLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['NamedStoreCT_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].NamedStoreCT_WF__c)&&coTenants[i].NamedStoreCT_WF__c.length > covenantTextFieldMap['NamedStoreCT_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('namedStoreCTLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('namedStoreCTLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ReplacementTenantDescription_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].ReplacementTenantDescription_WF__c)&&coTenants[i].ReplacementTenantDescription_WF__c.length > covenantTextFieldMap['ReplacementTenantDescription_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('RepDescReqLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('RepDescReqLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Explanation_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].Explanation_WF__c)&&coTenants[i].Explanation_WF__c.length > covenantTextFieldMap['Explanation_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('explanationLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('explanationLengthErrorId'+i),'slds-hide');
                     }
                     
                     if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionOtherRequirement_WF__c'])&&!$A.util.isUndefinedOrNull(coTenants[i].DescriptionOtherRequirement_WF__c)&&coTenants[i].DescriptionOtherRequirement_WF__c.length > covenantTextFieldMap['DescriptionOtherRequirement_WF__c']) 
                     {
                         $A.util.removeClass(document.getElementById('descOtherReqLengthErrorId'+i),'slds-hide');
                         coTenancyError=true;
                         boolIsError=true;
                     }
                     else{
                         $A.util.addClass(document.getElementById('descOtherReqLengthErrorId'+i),'slds-hide');
                     }
                     
                 }
                 else
                 {
                     component.set("v.COV_coTenancyError", false);
                 }
         }
         
         if(coTenancyError || component.get("v.coTenancyTempError"))
         {
             console.log('inside cotencancy erooror');
             component.set("v.COV_coTenancyError", true);
         }
         else{
             component.set("v.COV_coTenancyError", false);
         }
         
     }else{
          component.set("v.COV_coTenancyError", false);
     }
         
         console.log('llRelocationRight',llRelocationRight);
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c'])&& !$A.util.isUndefinedOrNull(llRelocationRight.IfNoRelocationRightsDescription_WF__c)
           && llRelocationRight.IfNoRelocationRightsDescription_WF__c.length > covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c']) 
        {
            $A.util.removeClass(document.getElementById('relocRightsDescriptionLengthErrorId'),'slds-hide');
            //component.set("v.COV_llRelocationRightsError", true);
            boolIsLLRelocationError =true;
            boolIsError=true;
        }
        else
        {
            $A.util.addClass(document.getElementById('relocRightsDescriptionLengthErrorId'),'slds-hide');
            
        }
        if(boolIsLLRelocationError || component.get("v.llRelocationRightsTempError"))
        {
            component.set("v.COV_llRelocationRightsError", true);
        }else{
            component.set("v.COV_llRelocationRightsError", false);
        }
    
        console.log('landlordTerminationtionRight',landlordTerminationtionRight);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TerminationRightsDescription_WF__c'])&& !$A.util.isUndefinedOrNull(landlordTerminationtionRight.TerminationRightsDescription_WF__c)&& landlordTerminationtionRight.TerminationRightsDescription_WF__c.length > covenantTextFieldMap['TerminationRightsDescription_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('terminationRightsDescLengthErrorId'),'slds-hide');
             //component.set("v.COV_llTerminationRightsError", true);
             boolIsLandlordTermError =true;
              boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('terminationRightsDescLengthErrorId'),'slds-hide');
         }
    
        if(boolIsLandlordTermError || component.get("v.llTerminationRightsTempError"))
        {
            component.set("v.COV_llTerminationRightsError", true);
        }else{
            component.set("v.COV_llTerminationRightsError", false);
        }
    
        console.log('commonArRestriction',commonArRestriction);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Description_Restriction_Type_WF__c'])&&!$A.util.isUndefinedOrNull(commonArRestriction.Description_Restriction_Type_WF__c)&& commonArRestriction.Description_Restriction_Type_WF__c.length > covenantTextFieldMap['Description_Restriction_Type_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('descriptionRestrictionLengthErrorId'),'slds-hide');
              boolIsError=true;
             boolIsCmnResError=true
         }
         else
         {
             $A.util.addClass(document.getElementById('descriptionRestrictionLengthErrorId'),'slds-hide');
        
         }
          
         console.log('commonArRestriction',commonArRestriction);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['IfCompetingUseDescription_WF__c'])&&!$A.util.isUndefinedOrNull(commonArRestriction.IfCompetingUseDescription_WF__c)&& commonArRestriction.IfCompetingUseDescription_WF__c.length > covenantTextFieldMap['IfCompetingUseDescription_WF__c']) 
         {
             component.set("v.commonArRestrictionError", true);
             boolIsCmnResError=true;
             boolIsError=true;
         }
         else
         {
             component.set("v.commonArRestrictionError",false);
         }
        // Sachin - Added as part of GDM-8230
        if(boolIsCmnResError || component.get("v.commonAreaRestrictionTempError") || component.get("v.COV_commonAreaRestrictionTempError"))
        {
            component.set("v.COV_commonAreaRestrictionError", true);   
        }else
        {
            component.set("v.COV_commonAreaRestrictionError", false);
        }
    
        console.log('SLR',SLR);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionZone_WF__c'])&& !$A.util.isUndefinedOrNull(SLR.DescriptionZone_WF__c)  &&SLR.DescriptionZone_WF__c.length > covenantTextFieldMap['DescriptionZone_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('descNoBuildLengthErrorId'),'slds-hide');
             noBuildZoneerror=true;
              boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('descNoBuildLengthErrorId'),'slds-hide');   
         }
         console.log('SLR',SLR);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ZoneDetails_WF__c'])&& !$A.util.isUndefinedOrNull(SLR.ZoneDetails_WF__c) && SLR.ZoneDetails_WF__c.length > covenantTextFieldMap['ZoneDetails_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('zoneDetailsLengthErrorId'),'slds-hide');
             noBuildZoneerror=true;
             boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('zoneDetailsLengthErrorId'),'slds-hide');
         }
    
         if(noBuildZoneerror || component.get("v.noZoneTempError"))
         {
             component.set("v.COV_noBuildZoneError", true);
         }else{
             component.set("v.COV_noBuildZoneError", false);
         }
    
         console.log('exclusiveRights.ExclDuration_WF__c',exclusiveRights);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclDuration_WF__c'])&& !$A.util.isUndefinedOrNull(exclusiveRights.ExclDuration_WF__c)
            && exclusiveRights.ExclDuration_WF__c.length > covenantTextFieldMap['ExclDuration_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('exclDurationSpecLengthErrorId'),'slds-hide');
             COV_exclusiveRightError= true;
              boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('exclDurationSpecLengthErrorId'),'slds-hide');
             
         }
         console.log('exclusiveRights.ExclRemedyDescription_WF__c',exclusiveRights);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRemedyDescription_WF__c'])&&(!$A.util.isUndefinedOrNull(exclusiveRights.ExclRemedyDescription_WF__c))
            && exclusiveRights.ExclRemedyDescription_WF__c.length > covenantTextFieldMap['ExclRemedyDescription_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('exclRemedyDescLengthErrorId'),'slds-hide');
             COV_exclusiveRightError= true;
              boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('exclRemedyDescLengthErrorId'),'slds-hide');
             
         }
        console.log('exclusiveRights.ExclRightDescription_WF__c',exclusiveRights);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRightDescription_WF__c']) && (!$A.util.isUndefinedOrNull(exclusiveRights.ExclRightDescription_WF__c))
            && exclusiveRights.ExclRightDescription_WF__c.length > covenantTextFieldMap['ExclRightDescription_WF__c']) 
         {
             $A.util.removeClass(document.getElementById('exclRightDescLengthErrorId'),'slds-hide');
             COV_exclusiveRightError=true;
              boolIsError=true;
         }
         else{
             $A.util.addClass(document.getElementById('exclRightDescLengthErrorId'),'slds-hide');
             
         }
        if(COV_exclusiveRightError || component.get("v.exclusiveRightTempError"))
        {
            component.set("v.COV_exclusiveRightError", true);
        }
        else{
            component.set("v.COV_exclusiveRightError", false);
        }
    console.log('otherCovenant',otherCovenant);
         if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['CovenantComments_WF__c']) && !$A.util.isUndefinedOrNull(otherCovenant.CovenantComments_WF__c)
            && otherCovenant.CovenantComments_WF__c.length > covenantTextFieldMap['CovenantComments_WF__c'])
         {
             $A.util.removeClass(document.getElementById('covCommentLengthErrorId'),'slds-hide');
             component.set("v.COV_otherError", true);
              boolIsError=true;
         } 
         else{
             $A.util.addClass(document.getElementById('covCommentLengthErrorId'),'slds-hide');   
                component.set("v.COV_otherError", false);
                  
         }

         //Validate Cash Deposit Comments
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.Cash_Deposit_Comments_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['Cash_Deposit_Comments_WF__c'])
          && component.get('v.opportunity.Cash_Deposit_Comments_WF__c').length > covenantTextFieldMap['Cash_Deposit_Comments_WF__c']){
            $A.util.removeClass(cashDepLengthError, 'slds-hide');
            boolIsCashDepErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(cashDepLengthError, 'slds-hide');
        }
    
        if(boolIsCashDepErr || component.get('v.GI_securitySectionTempError'))
        {
            component.set("v.GI_securitySectionError", true);
        }else{
            component.set("v.GI_securitySectionError", false);
        }
    
        //validate Use Clause and ACDBE participation Length
        console.log(" component.get('v.opportunity.UseClause_WF__c').length");
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.UseClause_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['UseClause_WF__c'])
          && component.get('v.opportunity.UseClause_WF__c').length > covenantTextFieldMap['UseClause_WF__c']){
            $A.util.removeClass(useClauseLengthError, 'slds-hide');
            boolIsUseClauseErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(useClauseLengthError, 'slds-hide');
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.ACDBEDescription_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['ACDBEDescription_WF__c'])
          && component.get('v.opportunity.ACDBEDescription_WF__c').length > covenantTextFieldMap['ACDBEDescription_WF__c']){
            $A.util.removeClass(acdbePartLengthError, 'slds-hide');
            boolIsUseClauseErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(acdbePartLengthError, 'slds-hide');
        }
         
        if(boolIsUseClauseErr)
        {
            component.set("v.GI_whoSectionError", true);
        }
        //validate Patio comments
        if((component.get('v.opportunity.Patio_WF__c')==true) && !$A.util.isUndefinedOrNull(component.get('v.opportunity.PatioComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['PatioComments_WF__c'])
          && component.get('v.opportunity.PatioComments_WF__c').length > covenantTextFieldMap['PatioComments_WF__c']){
            $A.util.removeClass(patioCommentError, 'slds-hide');
            boolIsPatioCommentErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(patioCommentError, 'slds-hide');
        }
        if(boolIsPatioCommentErr || component.get('v.GI_whereSectionTempError'))
        {
            component.set("v.GI_whereSectionError", true);
        }else{
            component.set("v.GI_whereSectionError", false);
        }
    

        //validate RestrictionTimePeriod
        var restrictionTimePeriodEvent = $A.get("e.c:CurrentTenantEvent");
        if(restrictionTimePeriodEvent!=null)
        {
            restrictionTimePeriodEvent.setParams({
                "restrictionTimePeriodError": false
            });
            restrictionTimePeriodEvent.fire();
        }
        restrictionTimePeriodError=  component.get('v.restrictionTimePeriodError');
        if(restrictionTimePeriodError)
        {
            component.set('v.GI_currentTenantError',true);
            boolIsError=true;
        }
        // validate contigency comments
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.ContingencyComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ContingencyComments_WF__c'])
           && component.get('v.opportunity.ContingencyComments_WF__c').length > covenantTextFieldMap['ContingencyComments_WF__c']){
            $A.util.removeClass(conCommsLengthError, 'slds-hide');
            boolIsContigencyCommentErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(conCommsLengthError, 'slds-hide');
        }
        if(boolIsContigencyCommentErr || component.get('v.GI_whenSectionTempError'))
        {
            component.set("v.GI_whenSectionError", true);
        }else{
            component.set("v.GI_whenSectionError", false);
        }
    
    console.log("non stan comments./....././/././/",lstGrowthRateTable);
        var minimumRentCmpEvent = $A.get("e.c:MinimumRentCmpEvent");
        if(minimumRentCmpEvent!=null)
        {
           minimumRentCmpEvent.setParams({
                "nstCommentsErr": false
            });
            minimumRentCmpEvent.fire();
        }
    console.log("imum revent called");
        minimumCmpNonStdCmntError=  component.get('v.nstCommentsErr');
    console.log("minimumCmpNonStdCmntError.......",minimumCmpNonStdCmntError);
        minimumCmpNonStdOptnCmntError=  component.get('v.nstCommentsOptnErr');
     console.log("minimumCmpNonStdCmntError.......",minimumCmpNonStdOptnCmntError);
        if(minimumCmpNonStdCmntError || minimumCmpNonStdOptnCmntError)
        {
            console.log("insde stan commens called");
          boolIsError=true;
        }
        
        //validate Rent Stabilization Comments
        /*if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.Rent_Stabilization_Comments_WF__c')) 
           && component.get('v.opportunity.Rent_Stabilization_Comments_WF__c').length > covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
        {
            
            component.set('v.rentStabCommentError',true);
            boolIsRentStabError = true;
            boolIsError=true;
        }else{
            component.set('v.rentStabCommentError',false);
        }*/
        var OptionRentStabCmntEvent = $A.get("e.c:OptionRentStabCmntEvent");
        if(OptionRentStabCmntEvent!=null)
        {
          
            OptionRentStabCmntEvent.fire();
        }
       OptionRentStabCmntErr=  component.get('v.rentStabOptnCmntErr');
        console.log("OptionRentStabCmntErr",OptionRentStabCmntErr);
        rentStabCmntErr=  component.get('v.rentStabCmntErr');
    console.log("rentStabCmntErr",rentStabCmntErr);
        if(OptionRentStabCmntErr || rentStabCmntErr)
        {
         // boolIsOptionCommentError =true;
          boolIsError=true;
        }    
        
    if(boolIsRentStabError ||rentStabCmntErr|| minimumCmpNonStdCmntError || component.get("v.FI_minimumRentTempError"))
        {
            component.set("v.FI_minimumRentError",true);
        }else{
            component.set("v.FI_minimumRentError",false);
        }
    
    //validate Percentage Rent Non Standard Comments
        var percentageRentCmpEvent = $A.get("e.c:PercentageRentCmpEvent");
        if(percentageRentCmpEvent!=null)
        {
            percentageRentCmpEvent.fire();
        }
    
        percentRentNonStdCmntError=  component.get('v.percentCommentsErr');
        percentRentNonStdCmntothrError=  component.get('v.percentCommentsOthrErr');    
        if(percentRentNonStdCmntError || percentRentNonStdCmntothrError)
        {
         // boolIsPercentRentNonStdErr =true;
          boolIsError=true;
        }
        
        
        //validate Percentage Rent Comments
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.RentCommentsPercent_WF__c'))  && !$A.util.isUndefinedOrNull( covenantTextFieldMap['RentCommentsPercent_WF__c'])
           && component.get('v.opportunity.RentCommentsPercent_WF__c').length > covenantTextFieldMap['RentCommentsPercent_WF__c'])
        {
            component.set('v.RentComntsPertLenErr',true);
            boolIsPercRentError = true;
            boolIsError=true;
        }else{
            component.set('v.RentComntsPertLenErr',false);
        }
    
        if(boolIsPercRentError || percentRentNonStdCmntError  || component.get('v.FI_overageRentTempError'))
        {
            component.set('v.FI_overageRentError',true);
            boolIsError=true;
        }
        else{
            component.set('v.FI_overageRentError',false);       
        }
        //validate Tenant Performance Requirement Description
        if(!$A.util.isUndefinedOrNull(component.get("v.opportunity.TenantPerformanceRequirement_WF__c")) && component.get("v.opportunity.TenantPerformanceRequirement_WF__c"))
        {
            if(!$A.util.isUndefinedOrNull(component.get("v.opportunity.TenantPerformanceRequirementDesc_WF__c"))&& !$A.util.isUndefinedOrNull(covenantTextFieldMap['TenantPerformanceRequirementDesc_WF__c'])
               && component.get("v.opportunity.TenantPerformanceRequirementDesc_WF__c").length > covenantTextFieldMap['TenantPerformanceRequirementDesc_WF__c'] )
            {
                component.set('v.tenantPerfReqDescError',true);  
                boolIsTenantPerfReqError = true;
                boolIsError=true;
            }
            else{
                component.set('v.tenantPerfReqDescError',false);
            }
        }
    
       if(boolIsTenantPerfReqError)
       {
            component.set("v.OP_detailsTempError",true);
       }
   
        
        //validate Measuring Period Comments
        if(component.get('v.opportunity.OptionsMeasuringPeriod_WF__c') =='Other'){
            if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsMeasuringPeriodComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OptionsMeasuringPeriodComments_WF__c'])
               && component.get('v.opportunity.OptionsMeasuringPeriodComments_WF__c').length > covenantTextFieldMap['OptionsMeasuringPeriodComments_WF__c'] )
            {
                component.set("v.measuringPeriodCmntErrorId",true);
                boolIsError=true;
                boolIsTenantPerfReqError = true;;
            }else{
                component.set('v.measuringPeriodCmntErrorId',false);
            }
        }

        //validate option Notifyother comments
        var optionNotifyOtherCmntsEvent = $A.get("e.c:OptionNotifyOtherCmntError");
        if(optionNotifyOtherCmntsEvent!=null)
        {
          
            optionNotifyOtherCmntsEvent.fire();
        }
       optionNotifyOtherCmntErr=  component.get('v.OptionNotifyOtherCmntErr');
        if(optionNotifyOtherCmntErr)
        {
          boolIsOptionCommentError =true;
          boolIsError=true;
        }
    /*console.log("IsOptionsMinimumRent,,,.................",component.get('v.IsOptionsMinimumRent'));
      //Validate isoption minimum rent & option percentage comment
        if(component.get('v.IsOptionsMinimumRent')==true && !$A.util.isUndefinedOrNull(component.get('v.opportunity.Rent_Stabilization_Comments_WF__c')) 
           && component.get('v.opportunity.Rent_Stabilization_Comments_WF__c').length > covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
        {
            console.log("inside if of other minimum rent");
            component.set('v.rentStabOthrCommentError',true);
            boolIsTenantPerfReqError = true;
            boolIsError=true;
        }else{
            console.log("inside else of other minimum rent")
            //component.set('v.rentStabOthrCommentError',false);
        }*/
    console.log("option rent com",component.get("v.opportunity.OptionRentCommentsPercent_WF__c"));
        if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.OptionRentCommentsPercent_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OptionRentCommentsPercent_WF__c'])
           && component.get('v.opportunity.OptionRentCommentsPercent_WF__c').length > covenantTextFieldMap['OptionRentCommentsPercent_WF__c'])
        {
            console.log("inside optionerroror ");
            component.set('v.OptionRentComntsPertLenErr',true);
            boolIsTenantPerfReqError = true;
            boolIsError=true;
        }else{
            component.set('v.OptionRentComntsPertLenErr',false);
        }
        console.log('test');
        if(boolIsTenantPerfReqError || OptionRentStabCmntErr||minimumCmpNonStdOptnCmntError || percentRentNonStdCmntothrError || boolIsOptionCommentError || component.get("v.OP_detailsTempError"))
        {
            component.set("v.OP_detailsError",true);
        }else{
            component.set("v.OP_detailsError",false);
        }
        // validate Real Estate Tax
        console.log("charge type",component.get('v.realEstateTax.Charge_Type_Oth_WF__c'));
    console.log("tax des",covenantTextFieldMap['TaxDescription_WF__c']);
        if(component.get('v.realEstateTax.Charge_Type_Oth_WF__c') == true && ! $A.util.isUndefinedOrNull(component.get('v.realEstateTax.TaxDescription_WF__c'))
           && ! $A.util.isUndefinedOrNull(covenantTextFieldMap['TaxDescription_WF__c']) && component.get('v.realEstateTax.TaxDescription_WF__c').length > covenantTextFieldMap['TaxDescription_WF__c'])
        {
            console.log('inside if');
            component.set('v.taxDescLengthErr',true);
            component.set('v.CH_realEstateTaxError',true);
            boolIsError=true;
        }else{
            component.set('v.taxDescLengthErr',false);
            component.set('v.CH_realEstateTaxError',false);
        }
    
        //validate charges Description
        var mallCharges = {} ;
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Utilities']){
                mallCharges = charges[item];
            }
            
        }
    console.log('mallCharges......',mallCharges);
        if( !$A.util.isUndefinedOrNull(mallCharges.OtherDescription1Proposed_WF__c) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription1Proposed_WF__c'])&&mallCharges.OtherDescription1Proposed_WF__c.length >covenantTextFieldMap['OtherDescription1Proposed_WF__c'])
        {
            console.log('inside des1 error');
            component.set('v.OtherDes1Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes1Error',false);
        }
        
        if(!$A.util.isUndefinedOrNull(mallCharges.OtherDescription2Proposed_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription2Proposed_WF__c'])&&mallCharges.OtherDescription2Proposed_WF__c.length >covenantTextFieldMap['OtherDescription2Proposed_WF__c'])
        {
            component.set('v.OtherDes2Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes2Error',false);
        }
        
        if(!$A.util.isUndefinedOrNull(mallCharges.OtherDescription3Proposed_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription3Proposed_WF__c'])&&mallCharges.OtherDescription3Proposed_WF__c.length >covenantTextFieldMap['OtherDescription3Proposed_WF__c'])
        {
            component.set('v.OtherDes3Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes3Error',false);
        }
        
        if(boolIschargesErr||component.get("v.CH_mallChargesTempError"))
        {
            component.set("v.CH_mallChargesError",true);
        }else{
            component.set("v.CH_mallChargesError",false);
        }
    
        //validate Capital other Cost Desc & tenat allowance comment
        if(component.get('v.Construction.OtherLandlordCosts_WF__c')>0 && !$A.util.isUndefinedOrNull(component.get('v.Construction.OtherCostsDescription_WF__c'))
           && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherCostsDescription_WF__c'])&& component.get('v.Construction.OtherCostsDescription_WF__c').length > covenantTextFieldMap['OtherCostsDescription_WF__c']){
            component.set('v.CapitalOtherCostDescriptionLengthError',true);
             boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.CapitalOtherCostDescriptionLengthError',false);
        }
    
       if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAComments_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAComments_WF__c'))
           && component.get('v.Construction.TAComments_WF__c').length > covenantTextFieldMap['TAComments_WF__c']){
            component.set('v.TACommentsLenError',true);
             boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TACommentsLenError',false);
        }

        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions1Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions1Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions1Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions1Other_WF__c']){
            console.log("inside ta paymrnt other error");
            component.set('v.TAPaymentOptions1OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions1OtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions2Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions2Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions2Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions2Other_WF__c']){
            component.set('v.TAPaymentOptions2OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions2OtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions3Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions3Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions3Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions3Other_WF__c']){
            component.set('v.TAPaymentOptions3OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions3OtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions4Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions4Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions4Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions4Other_WF__c']){
            component.set('v.TAPaymentOptions4OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions4OtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions5Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions5Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions5Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions5Other_WF__c']){
            component.set('v.TAPaymentOptions5OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions5OtherError',false);
        }
    
          
        if(boolIsCaptialDescError||component.get('v.CON_capitalTempError'))
        {
         component.set('v.CON_capitalError',true);   
        }else{
         component.set('v.CON_capitalError',false);   
        }
    
        //validate landlord work at Tenat
       if(!$A.util.isUndefinedOrNull(component.get('v.Construction.TypesofCharges_WF__c'))&& component.get('v.Construction.TypesofCharges_WF__c')=='Individual Charges' && component.get('v.Construction.OtherLandlordWork_WF__c') != 'N/A'
           && component.get('v.Construction.OtherLandlordWork_WF__c') != '' && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherLandlordWorkTxt_WF__c'])
           && !$A.util.isUndefinedOrNull(component.get('v.Construction.OtherLandlordWorkTxt_WF__c')) && component.get('v.Construction.OtherLandlordWorkTxt_WF__c').length > covenantTextFieldMap['OtherLandlordWorkTxt_WF__c'])    
       {
           component.set('v.OtherTextValueErr',true);
           component.set('v.CON_landlordWorkError',true);
           boolIsError=true;
       }else{
           component.set('v.OtherTextValueErr',false);
           component.set('v.CON_landlordWorkError',false);
       }
    
        //validate Landlord Const requirement
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StructuralModificationOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['StructuralModificationOther_WF__c'])
           && component.get('v.Construction.StructuralModificationOther_WF__c').length > covenantTextFieldMap['StructuralModificationOther_WF__c'])
        {
            component.set('v.StructuralModificationOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.StructuralModificationOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DemisingWallOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DemisingWallOther_WF__c'])
           && component.get('v.Construction.DemisingWallOther_WF__c').length > covenantTextFieldMap['DemisingWallOther_WF__c'])
        {
            component.set('v.DemisingWallOtherError',true);
            boolIsError=true;
             boolIsLandlordConsError=true;
        }else{
            component.set('v.DemisingWallOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StoreFrontageOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['StoreFrontageOther_WF__c'])
           && component.get('v.Construction.StoreFrontageOther_WF__c').length > covenantTextFieldMap['StoreFrontageOther_WF__c'])
        {
            component.set('v.storeFrontageOtherError',true);
            boolIsError=true;
             boolIsLandlordConsError=true;
        }else{
            component.set('v.storeFrontageOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.ElectricalOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ElectricalOther_WF__c'])
           && component.get('v.Construction.ElectricalOther_WF__c').length > covenantTextFieldMap['ElectricalOther_WF__c'])
        {
            component.set('v.ElectricalsOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.ElectricalsOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DataOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DataOther_WF__c'])
           && component.get('v.Construction.DataOther_WF__c').length > covenantTextFieldMap['DataOther_WF__c'])
        {
            component.set('v.DataOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.DataOtherError',false);
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DomesticWaterOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DomesticWaterOther_WF__c'])
           && component.get('v.Construction.DomesticWaterOther_WF__c').length > covenantTextFieldMap['DomesticWaterOther_WF__c'])
        {
            component.set('v.DomesticWaterOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.DomesticWaterOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SewerOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SewerOther_WF__c'])
           && component.get('v.Construction.SewerOther_WF__c').length > covenantTextFieldMap['SewerOther_WF__c'])
        {
            component.set('v.SewerOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SewerOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SewerVentOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SewerVentOther_WF__c'])
           && component.get('v.Construction.SewerVentOther_WF__c').length > covenantTextFieldMap['SewerVentOther_WF__c'])
        {
            component.set('v.SewerVentOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SewerVentOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.GreaseWasteOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['GreaseWasteOther_WF__c'])
           && component.get('v.Construction.GreaseWasteOther_WF__c').length > covenantTextFieldMap['GreaseWasteOther_WF__c'])
        {
            component.set('v.GreaseWasteOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.GreaseWasteOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SlabConditionOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SlabConditionOther_WF__c'])
           && component.get('v.Construction.SlabConditionOther_WF__c').length > covenantTextFieldMap['SlabConditionOther_WF__c'])
        {
            component.set('v.SlabConditionOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SlabConditionOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MechanicalOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MechanicalOther_WF__c'])
           && component.get('v.Construction.MechanicalOther_WF__c').length > covenantTextFieldMap['MechanicalOther_WF__c'])
        {
            component.set('v.MechanicalOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.MechanicalOtherError',false);
        }
    
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MiscellaneousOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MiscellaneousOther_WF__c'])
           && component.get('v.Construction.MiscellaneousOther_WF__c').length > covenantTextFieldMap['MiscellaneousOther_WF__c'])
        {
            component.set('v.MiscellaneousOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.MiscellaneousOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.LLWorkDescription_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['LLWorkDescription_WF__c'])
           && component.get('v.Construction.LLWorkDescription_WF__c').length > covenantTextFieldMap['LLWorkDescription_WF__c'])
        {
            component.set('v.LLworkDescriptionError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.LLworkDescriptionError',false);
        }
        
        if(boolIsLandlordConsError)
        {
            component.set('v.CON_landlordConstructionReqError',true);
        }
        else{
           component.set('v.CON_landlordConstructionReqError',false);
        }
        
        //validate TTWorkComments 

        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MidTermTTWorkComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MidTermTTWorkComments_WF__c'])
           && component.get('v.Construction.MidTermTTWorkComments_WF__c').length > covenantTextFieldMap['MidTermTTWorkComments_WF__c'])
        {
            component.set('v.TTWorkCommentsError',true);
            boolIsError=true; 
            boolIstenatConsCmntErr =true;
        }else{
            component.set('v.TTWorkCommentsError',false);
        }

        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.TTWorkComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['TTWorkComments_WF__c'])
           && component.get('v.Construction.TTWorkComments_WF__c').length > covenantTextFieldMap['TTWorkComments_WF__c'])
        {
            component.set('v.TTPriorWorkCommentsError',true);
            boolIsError=true; 
            boolIstenatConsCmntErr =true;
        }else{
            component.set('v.TTPriorWorkCommentsError',false);
        }
    
        if(boolIstenatConsCmntErr || component.get('v.CON_tenantConstructionReqTempError'))
        {
             component.set('v.CON_tenantConstructionReqError',true);
        }else{
             component.set('v.CON_tenantConstructionReqError',false);
        }
           console.log('check point 6');
    //validate kickouts
    var kickouts = component.get('v.lstKickouts');
        
        if(kickouts.length >0 && component.get('v.opportunity.KickOuts_WF__c')==true){
            for(var i=0; i<kickouts.length; i++){
                
                 if(!$A.util.isUndefinedOrNull(kickouts[i].OtherDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription_WF__c'])
                    && kickouts[i].OtherDescription_WF__c.length > covenantTextFieldMap['OtherDescription_WF__c'])
                 {
                     console.log("inside if of kicko");
                      $A.util.removeClass(document.getElementById('kickoutOtherErrorId'+i),'slds-hide');
                      boolIsKickoutErr = true;
                      boolIsError=true;
                  }else{
                       $A.util.addClass(document.getElementById('kickoutOtherErrorId'+i),'slds-hide');
                  }
    
            }
        }

   
     if(boolIsKickoutErr || component.get('v.COV_kickoutsTempError'))
     {
        component.set('v.COV_kickoutsError',true);
     }
     else{
        component.set('v.COV_kickoutsError',false);
     }
   
    
     //Validate Radius Restriction
      if( component.get('v.radiusRestriction.RadiusRestriction_WF__c') == true &&component.get('v.radiusRestriction.of_WF__c') == 'Other'
         && !$A.util.isUndefinedOrNull(component.get('v.radiusRestriction.RR_Other_WF__c ')) &&component.get('v.radiusRestriction.RR_Other_WF__c ').length> covenantTextFieldMap['RR_Other_WF__c'])
      {
          component.set("v.RR_OtherError", true);
          boolIsRadiusResErr = true;
          boolIsError=true;
      }else{
          component.set("v.RR_OtherError", false);
      }
    
     if(boolIsRadiusResErr || component.get('v.COV_radiusRestrictionTempError'))
     {
        component.set('v.COV_radiusRestrictionError',true);
     }
     else{
        component.set('v.COV_radiusRestrictionError',false);
     }
   
     //validate Comments
     if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Comments_WF__c'])
        && component.get('v.opportunity.Comments_WF__c').length > covenantTextFieldMap['Comments_WF__c'])
      {
          component.set("v.CommentsError", true);
          boolIsCmntError = true;
          boolIsError=true;
      }else{
          component.set("v.CommentsError", false);
      } 
    
     if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.OtherReasonOpportunityDead_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        && component.get('v.opportunity.OtherReasonOpportunityDead_WF__c').length > covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
      {
          component.set("v.oppDeadCommsLenError", true);
          boolIsCmntError = true;
          boolIsError=true;
      }else{
          component.set("v.oppDeadCommsLenError", false);
      }
    
     if(!$A.util.isUndefinedOrNull(component.get('v.opportunity.REC_Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['REC_Comments_WF__c'])
        && component.get('v.opportunity.REC_Comments_WF__c').length > covenantTextFieldMap['REC_Comments_WF__c'])
      {
          component.set("v.recCommentsLenError", true);
          boolIsCmntError = true;
          boolIsError=true;
      }else{
          component.set("v.recCommentsLenError", false);
      } 
    
      if(boolIsCmntError || component.get('v.CO_detailsTempError'))
      {
          component.set('v.CO_detailsError',true);
      }
      else{
         component.set('v.CO_detailsError',false);
      }
    
    
      return boolIsError;
     },
    
        
    
    createComponents : function(component, helper, result){
        //Initialize minimum rent
        window.setTimeout(
            $A.getCallback(function() {
                console.log(' Component values ----> ', component);
                console.log(' Component Ref ----> ', component.getReference('v.lstGrowthRateTable'));
                $A.createComponent(
                    "c:MinimumRent_WF",
                    {
                        "opportunity": component.getReference("v.opportunity"),
                        "yearsVal": component.getReference("v.opportunity.TermYears_WF__c"),
                        "monthsVal": component.getReference("v.opportunity.TermMonths_WF__c"),
                     //   "WeaAmdType_2_WF__c": component.getReference("v.opportunity.WeaAmdType_2_WF__c"),
                        "rentStabCmntErr":component.getReference("v.rentStabCmntErr"),
                        "lstMinRentTable": component.getReference('v.lstGrowthRateTable'),
                        "nstCommentsErr":component.getReference('v.nstCommentsErr'),
                        "IsMinimumRent": component.getReference("v.IsMinimumRent"),
                        "IsOptions": component.getReference("v.IsOptions"),
                        "hasErrors": component.getReference("v.FI_minimumRentTempError"),
                        "MinRentDesc": "Minimum Rent Information",
                        "IsNegativeValue": component.getReference("v.IsNegativeValue"),
                        "disabled": component.getReference("v.disabled"),
                        "rentStabCommentError":component.getReference("v.rentStabCommentError"),
                        //"rentStabOthrCommentError":component.getReference("v.rentStabOthrCommentError"),
                        "unitOfMeasure": component.getReference("v.unitOfMeasure"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newMinRentComp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var minRentCmp
                            if(component.get('v.minRentComponent') != null && component.get('v.minRentComponent') != undefined){
                                 minRentCmp = component.get('v.minRentComponent');
                            }
                            else{
                                
								minRentCmp =[];                                
                            }
                            minRentCmp.push(newMinRentComp);
                            component.set('v.minRentComponent', minRentCmp);
                        }
                    }
                );
                
                $A.createComponent(
                    "c:PercentRentComponent_WF",
                    {
                        "IsNegativeValue": component.getReference("v.IsPercentNegativeValue"),
                        "startDate": component.getReference("v.opportunity.RCDEarlierOfOpeningOf_WF__c"),
                        "endDate": component.getReference("v.opportunity.ExpirationDate_WF__c"),
                        "showTable": component.getReference("v.showTable"),
                        "opportunity": component.getReference("v.opportunity"),
                        "IsOptions": false,
                        "defaultDate": component.getReference("v.defaultDate"),
                        "RentComntsPertLenErr":component.getReference("v.RentComntsPertLenErr"),
                        "OptionRentComntsPertLenErr":component.getReference("v.OptionRentComntsPertLenErr"),
                        "IsMinimumRent": component.getReference("v.IsMinimumRent"),
                        "lstGrowthRateTable": component.getReference("v.lstGrowthRateTable"),
                        "lstMinRentTable": component.getReference("v.lstMinPercentRentTable"),
                        "lstOtherTable": component.getReference("v.lstOtherPercentRentTable"),
                        "hasErrors": component.getReference("v.FI_overageRentError"),
                        "percentCommentsErr":component.getReference('v.percentCommentsErr'),
                        "PercentRentDescription": "Percentage Rent Information",
                        "disabled": component.getReference("v.disabled"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newPercRentComp, status, errorMessage){
                        if(status === "SUCCESS"){
                        //var percRentCmp = component.get('v.percRentComponent');
                        //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var percRentCmp;
                        if(component.get('v.percRentComponent') != null && component.get('v.percRentComponent') != undefined){
                            percRentCmp = component.get('v.percRentComponent'); 
                        }
                            else{
                                percRentCmp=[];
                            }
                            percRentCmp.push(newPercRentComp);
                            component.set('v.percRentComponent', percRentCmp);
                        }
                    }
                );
                
                $A.createComponent(
                    "c:OptionsComponent_WF",
                    {
                        "aura:id": "idOptions",
                        "IsOptionsMiniNegativeValue": component.getReference("v.IsOptionsMiniNegativeValue"),
                        "IsOptionsPerNegativeValue": component.getReference("v.IsOptionsPerNegativeValue"),
                        "hasMinErrors": component.getReference("v.hasMinErrors"),
                        "opportunity": component.getReference("v.opportunity"),
                        "IsOptions": component.getReference("v.IsOptions"),
                        "optionsCommentsErrors": component.getReference("v.optionsCommentsErrors"),
                        "OptionNotifyOtherCmntErr":component.getReference("v.OptionNotifyOtherCmntErr"),
                        "IsOptionsMinimumRent": component.getReference("v.IsOptionsMinimumRent"),
                        "rentStabOptnCmntErr":component.getReference("v.rentStabOptnCmntErr"),
                        "lstOptionsTable": component.getReference("v.lstOptionsTable"),
                        "renewalOptions": component.getReference("v.renewalOptions"),
                        "showOptionsTable": component.getReference("v.showOptionsTable"),
                        "hasErrors": component.getReference("v.optionsErrors"),
                        "measuringPeriodCmntErrorId":component.getReference("v.measuringPeriodCmntErrorId"),
                        "hasPercentErrors": component.getReference("v.hasPercentErrors"),
                         "nstCommentsOptnErr":component.getReference("v.nstCommentsOptnErr"),
                        "disabled": component.get("v.disabled"),
                        "percentCommentsOthrErr":component.getReference("v.percentCommentsOthrErr"),
                        "tenantPerfReqDescError":component.getReference("v.tenantPerfReqDescError"),
                        "IsOptionsMeasuringPeriod": component.getReference("v.opportunity.OptionsMeasuringPeriod_WF__c"),
                        "IsTenantPerformanceRequirement": component.getReference("v.opportunity.TenantPerformanceRequirement_WF__c"),
                        "OptionRentComntsPertLenErr":component.getReference("v.OptionRentComntsPertLenErr"),
                        "unitOfMeasure": component.getReference("v.optionsUnitOfMeasure"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newOptComp, status, errorMessage){
                        if(status === "SUCCESS"){
                        // var renOptCmp = component.get('v.optionsComponent');
                        //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var renOptCmp;
                        if(component.get('v.optionsComponent') != null && component.get('v.optionsComponent') != undefined){
                            renOptCmp = component.get('v.optionsComponent'); 
                        }
                            else{
                                renOptCmp =[];
                            }
                            renOptCmp.push(newOptComp);                                                        
                            component.set('v.optionsComponent', renOptCmp);
                            newOptComp.reInit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHoperatingExpense",
                    {
                        "aura:id": "CH_operatingExpenseComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "error": component.getReference("v.CH_operatingExpenseError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(opChargesCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            //var opChCmp = component.get('v.opChargeComponent');
                            //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var opChCmp;
                        if(component.get('v.opChargeComponent') != null && component.get('v.opChargeComponent') != undefined){
                            opChCmp = component.get('v.opChargeComponent'); 
                        }
                            else{
                                opChCmp =[];
                                
                            }
                            opChCmp.push(opChargesCmp);
                            component.set('v.opChargeComponent', opChCmp);
                            opChargesCmp.reInit();
                            if(!component.get('v.disabled'))
                                opChargesCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHinsurance",
                    {
                        "aura:id": "CH_insuranceComp",
                        "disabled": component.getReference("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "error": component.getReference("v.CH_insuranceError")
                    },
                    function(insuranceCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                           // var insCmp = component.get('v.insuranceComponent');
                                //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var insCmp;
                        if(component.get('v.insuranceComponent') != null && component.get('v.insuranceComponent') != undefined){
                            insCmp = component.get('v.insuranceComponent'); 
                        }
                            else{
                                insCmp = [];
                            }
                            insCmp.push(insuranceCmp);
                            component.set('v.insuranceComponent', insCmp);
                            insuranceCmp.reInit();
                            if(!component.get('v.disabled'))
                                insuranceCmp.calculateVariance();
                        }
                    }
                );
                
              $A.createComponent(
                    "c:CHfoodCourtExpense",
                    {
                        "aura:id": "CH_foodCourtExpenseComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "error": component.getReference("v.CH_foodCourtExpenseError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(fcCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            //var fdCrtCmp = component.get('v.fcComponent');
                            //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var fdCrtCmp;
                        if(component.get('v.fcComponent') != null && component.get('v.fcComponent') != undefined){
                            fdCrtCmp = component.get('v.fcComponent'); 
                        }
                            else{
                                fdCrtCmp = [];
                            }
                            fdCrtCmp.push(fcCmp);
                            component.set('v.fcComponent', fdCrtCmp);
                            fcCmp.reInit();
                            if(!component.get('v.disabled'))
                                fcCmp.calculateVariance();
                        }
                    }
                );
                
            }), 100
        );


        //Initialize food court
        window.setTimeout(
            $A.getCallback(function() {
                $A.createComponent(
                    "c:CHpromotionalCharges",
                    {
                        "aura:id": "CH_promotionalChargesComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "error": component.getReference("v.CH_promotionalChargesError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(pCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                          //  var promoCmp = component.get('v.promoComponent');
                          //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var promoCmp;
                        if(component.get('v.promoComponent') != null && component.get('v.promoComponent') != undefined){
                            promoCmp = component.get('v.promoComponent'); 
                        }
                            else{
                                promoCmp = [];
                            }
                            promoCmp.push(pCmp);
                            component.set('v.promoComponent', promoCmp);
                            pCmp.reInit();
                            if(!component.get('v.disabled'))
                                pCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHrealEstateTax",
                    {
                        "aura:id": "CH_realEstateTaxComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "realEstateTax":component.getReference("v.realEstateTax"),
                        "taxDescLengthErr":component.getReference("v.taxDescLengthErr"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "error": component.getReference("v.CH_realEstateTaxError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(reCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                           // var rEstateCmp = component.get('v.realEstComponent');
                           //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var rEstateCmp;
                        if(component.get('v.realEstComponent') != null && component.get('v.realEstComponent') != undefined){
                            rEstateCmp = component.get('v.realEstComponent'); 
                        }
                            else{
                                rEstateCmp = [];
                            }
                            rEstateCmp.push(reCmp);
                            component.set('v.realEstComponent', rEstateCmp);
                            reCmp.reInit();
                            if(!component.get('v.disabled'))
                                reCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHmallCharges",
                    {
                        "aura:id": "CH_mallChargesComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "error": component.getReference("v.CH_mallChargesError"),
                        "result": component.getReference("v.relatedRecord"),
                        "WaterError": component.getReference("v.WaterError"),
                        "FDSError": component.getReference("v.FDSError"),
                        "ElectricityError": component.getReference("v.ElectricityError"),
                        "TrashError": component.getReference("v.TrashError"),
                        "EncldMallError": component.getReference("v.EncldMallError"),
                        "HVACError": component.getReference("v.HVACError"),
                        "ParkingError": component.getReference("v.ParkingError"),
                        "Other1Error": component.getReference("v.Other1Error"),
                        "Other2Error": component.getReference("v.Other2Error"),
                        "OtherDes1Error": component.getReference("v.OtherDes1Error"),
                         "OtherDes2Error": component.getReference("v.OtherDes2Error"),
                         "OtherDes3Error": component.getReference("v.OtherDes3Error"),
                        "Other3Error": component.getReference("v.Other3Error")
                    },
                    function(mallCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                       //  var mCmp = component.get('v.mallComponent');
                       //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var mCmp;
                        if(component.get('v.mallComponent') != null && component.get('v.mallComponent') != undefined){
                            mCmp = component.get('v.mallComponent'); 
                        }
                            else{
                                mCmp = [];
                            }
                            mCmp.push(mallCmp);
                            component.set('v.mallComponent', mCmp);
                            mallCmp.reInit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHother",
                    {
                        "aura:id": "CH_otherComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "error": component.getReference("v.CH_otherError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(otherCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                           // var oCmp = component.get('v.otherChargeComponent');
                           //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var oCmp;
                        if(component.get('v.otherChargeComponent') != null && component.get('v.otherChargeComponent') != undefined){
                            oCmp = component.get('v.otherChargeComponent'); 
                        }
                            else{
                                oCmp = [];
                            }
                            oCmp.push(otherCmp);
                            component.set('v.otherChargeComponent', oCmp);
                            otherCmp.reInit();
                        }
                    }
                );
                
               $A.createComponent(
                    "c:CON_capital_WF",
                    {
                        "aura:id": "CON_capitalComp",
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "GLA": component.getReference("v.opportunity.GLAUsed_WF__c"),
                        "TAPaymentAmountError": component.getReference("v.TAPaymentAmountError"),
                        "CapitalOtherCostDescriptionError": component.getReference("v.CapitalOtherCostDescriptionError"),
                        "CapitalOtherCostDescriptionLengthError": component.getReference("v.CapitalOtherCostDescriptionLengthError"),
                        "TACommentsLenError":component.getReference("v.TACommentsLenError"),
                        "TAPaymentOptions1OtherError":component.getReference("v.TAPaymentOptions1OtherError"),
                        "TAPaymentOptions2OtherError":component.getReference("v.TAPaymentOptions2OtherError"),
                        "TAPaymentOptions3OtherError":component.getReference("v.TAPaymentOptions3OtherError"),
                        "TAPaymentOptions4OtherError":component.getReference("v.TAPaymentOptions4OtherError"),
                        "TAPaymentOptions5OtherError":component.getReference("v.TAPaymentOptions5OtherError"),
                        "error": component.getReference("v.CON_capitalTempError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(capCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            //var cpCmp = component.get('v.capitalComponent');
                            //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var cpCmp;
                        if(component.get('v.capitalComponent') != null && component.get('v.capitalComponent') != undefined){
                            cpCmp = component.get('v.capitalComponent'); 
                        }
                            else{
                                cpCmp = [];
                            }
                            cpCmp.push(capCmp);
                            component.set('v.capitalComponent', cpCmp);
                            capCmp.init();
                            capCmp.changeUnit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_landlordWork_WF",
                    {
                        "Construction": component.getReference('v.Construction'),
                        "disabled": component.get("v.disabled"),
                        "error": component.getReference('v.CON_landlordWorkError'),
                        "OtherTextValueErr":component.getReference("v.OtherTextValueErr"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(llwCmp, status, errorMessage){
                       
                         if(status === "SUCCESS"){
                           // var llWrkCmp = component.get('v.llWorkComponent');
                           //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var llWrkCmp;
                        if(component.get('v.llWorkComponent') != null && component.get('v.llWorkComponent') != undefined){
                            llWrkCmp = component.get('v.llWorkComponent'); 
                        }
                            else{
                                llWrkCmp = [];
                            }
                             llWrkCmp.push(llwCmp);
                            component.set('v.llWorkComponent', llWrkCmp);
                            //Joshna - 3rd oct 2017 - added below line to fix a training issue
                            llwCmp.init();
                            
                        }
                    }
                );

            }), 200
        );
        
        //Initialize landlord construction
        window.setTimeout(
            $A.getCallback(function() {
                $A.createComponent(
                    "c:CON_landlordConstructionReq_WF",
                    {
                        "aura:id": "CON_landlordConstructionReqComp",
                        "disabled": component.get('v.disabled'), 
                        "Construction": component.getReference('v.Construction'),
                        "spaceDeliveryDate": component.getReference('v.opportunity.SpaceDeliveryDate__c'),
                         "StructuralModificationOtherError":component.getReference('v.StructuralModificationOtherError'),
                         "DemisingWallOtherError":component.getReference('v.DemisingWallOtherError'),
                         "storeFrontageOtherError":component.getReference('v.storeFrontageOtherError'),
                         "ElectricalsOtherError":component.getReference('v.ElectricalsOtherError'),
                         "DataOtherError":component.getReference('v.DataOtherError'),
                         "DomesticWaterOtherError":component.getReference('v.DomesticWaterOtherError'),
                         "SewerOtherError":component.getReference('v.SewerOtherError'),
                         "SewerVentOtherError":component.getReference('v.SewerVentOtherError'),
                         "GreaseWasteOtherError":component.getReference('v.GreaseWasteOtherError'),
                         "SlabConditionOtherError":component.getReference('v.SlabConditionOtherError'),
                         "MechanicalOtherError":component.getReference('v.MechanicalOtherError'),
                         "MiscellaneousOtherError":component.getReference('v.MiscellaneousOtherError'),
                         "LLworkDescriptionError":component.getReference('v.LLworkDescriptionError'),
                         "error": component.getReference('v.CON_landlordConstructionReqError'),
                         "result": component.getReference('v.relatedRecord')
                    },
                    function(llCCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                           //var llConCmp = component.get('v.llConsComponent');
                           //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var llConCmp;
                        if(component.get('v.llConsComponent') != null && component.get('v.llConsComponent') != undefined){
                            llConCmp = component.get('v.llConsComponent'); 
                        }
                            else{
                                llConCmp = [];
                            }
                            llConCmp.push(llCCmp);
                            component.set('v.llConsComponent', llConCmp);
                            llCCmp.updateStartDate();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_tenantConstructionReq_WF",
                    {
                        "aura:id": "CON_tenantConstructionReqComp",
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "workRequiredError": component.getReference("v.workRequiredError"),
                        "RemodelDueDateError": component.getReference("v.RemodelDueDateError"),
                        "TTWorkCommentsError":component.getReference("v.TTWorkCommentsError"),
                        "TTPriorWorkCommentsError":component.getReference("v.TTPriorWorkCommentsError"),
                        "error": component.getReference("v.CON_tenantConstructionReqError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(tcCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            //var tConCmp = component.get('v.tenConsComponent');
                            //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var tConCmp;
                        if(component.get('v.tenConsComponent') != null && component.get('v.tenConsComponent') != undefined){
                            tConCmp = component.get('v.tenConsComponent'); 
                        }
                            else{
                                tConCmp = [];
                            }
                            tConCmp.push(tcCmp);
                            component.set('v.tenConsComponent', tConCmp);
                            tcCmp.init();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_milestones_WF",
                    {
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "error": component.getReference("v.CON_milestonesError")
                    },
                    function(milestoneCmp, status, errorMessage){
                        
                        if(status === "SUCCESS"){
                        // var mCmp = component.get('v.msComponent');
                       //Sahil:09/26/2018:added to check null or undefined value for component.get method
                        var mCmp;
                        if(component.get('v.msComponent') != null && component.get('v.msComponent') != undefined){
                            mCmp = component.get('v.msComponent'); 
                        }
                            else{
                                mCmp = [];
                            }
                            mCmp.push(milestoneCmp);
                            component.set('v.msComponent', mCmp);
                        }
                    }
                );
                
                if(component.find('GI_CurrentTenant_WF') !== undefined){
                    component.find('GI_CurrentTenant_WF').reInit();  
                }
                helper.setPicklistValues(component, result);
                if(component.get('v.disabled') !== true){
                    component.set('v.BoolSaveDisable', false);    
                    component.set('v.BoolValidateDisable', false);
                }
                
            }), 300
        );
    },
    updateBudgetData : function (component, event){        
        var action = component.get('c.updateBudgetDataBasedOnRCD');
       
        /*Getting Reservation or UnitConfig data if any */
        var isReconfig = component.get('v.reconfigBool');
        var strTempRes;
        var strUnitConfig;
        var strReservations = [];
         if(isReconfig){
             var unitConfigs = component.get('v.unitConfig');        
             var strUnitConfig;        
             if(unitConfigs !== undefined && unitConfigs !== null){
                 if(unitConfigs.length >0 )
                     strUnitConfig = JSON.stringify(unitConfigs);
                 else
                     strUnitConfig = null;
             }else
                 strUnitConfig = null;
        }else{
            strTempRes = component.get('v.selectedProducts');
            if(strTempRes.length != undefined && strTempRes != null){
                if(strTempRes.length > 0){
                    for(var i=0; i<strTempRes.length; i++)
                    {
                        strReservations.push(strTempRes[i]);
                    }                           
                    strReservations = JSON.stringify(strReservations);console.log('213', strReservations);    
                }else
                    strReservations = null;                    
            }else
                strReservations = null;                
        }
        action.setParams({
            "oppty" : JSON.stringify(component.get('v.opportunity')),
            "strOpportunityBudgets" :JSON.stringify(component.get('v.budgets')),
            "isReconfig" : JSON.stringify(isReconfig),
            "selectedUnits" : isReconfig ? ($A.util.isUndefinedOrNull(strUnitConfig) ? null : JSON.stringify(JSON.parse(strUnitConfig))) : ($A.util.isUndefinedOrNull(strReservations) ? null : JSON.stringify(JSON.parse(strReservations)))
        });
        action.setCallback(this, function(response){
            var result = response.getReturnValue();
            if(result != null){
                component.set('v.budgets', result);
                console.log('budgets data ', component.get('v.budgets'));
            }
        });
        $A.enqueueAction(action);
    }
})