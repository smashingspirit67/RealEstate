({
	doInitHelper : function(cmp, eve, helper){
        cmp.set("v.intStepNum", 1);
		cmp.set("v.idOpportunity", null);
    }   
})