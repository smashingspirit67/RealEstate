({
    doInit : function(cmp, eve, helper){
		helper.doInitHelper(cmp, eve, helper);       
    }    
})