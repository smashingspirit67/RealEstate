({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
    passSection : function(component, event, helper){
        helper.passSectionHelper(component, event);
    },
    saveAmendments : function(component, event, helper){
        var validationError=false;
    	//helper.validateHelper(component, event, helper);
    	component.set('v.DealValidated', false);
        if(helper.validateSaveAsDraft(component))
        {
            validationError=true;
        }
        if(helper.validateSendDocsToLength(component))
        {
             validationError=true;
        }
        if(helper.validateComments(component))
        {
             validationError=true;
        }        
        if(validationError)
        {
            return;
        }
        helper.saveHelper(component, event, helper);
    },
    saveAndValidateAmendments : function(component, event, helper){
    	component.set('v.SaveAndValidateClicked', true);
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var validationError=false;
        if(helper.validateComments(component))  
        {
             validationError=true;
        }
        if(helper.validateHelper(component, event, helper))
        {
            validationError=true;
        }
        if(helper.validateSendDocsToLength(component))
        {
            validationError=true;
        }
        if(validationError)
        {
            return;
        }
        component.set('v.DealValidated', true);
        helper.saveHelper(component, event, helper);
    },
    handleCancel : function(component, event, helper){
    	helper.cancelHelper(component, event);
    },
    changeRightToTerminate:function(component, event, helper){
        var rightToTerminate = component.get("v.Amendment.sObj.RighttoTerminate_WF__c");
        console.log('rightToTerminate',rightToTerminate);
        console.log('v.showTerminationRights',component.get("v.showTerminationRights"));
        
        if(rightToTerminate == "No"){
            component.set("v.Amendment.sObj.TerminationRightPeriod_WF__c",null);
            component.set("v.Amendment.sObj.NoticePeriod_WF__c",null);
            component.set("v.showTerminationRights",false);
            console.log('v.showTerminationRights',component.get("v.showTerminationRights"));
        }else{
            component.set("v.showTerminationRights",true);
            console.log('v.showTerminationRights',component.get("v.showTerminationRights"));
        }
    }
})