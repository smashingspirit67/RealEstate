({
    doInitHelper : function(component,event,helper) {
        console.log('^^^^^^');
        var idLease = component.get('v.idLease');
        var idAmdOpp = component.get('v.idAmdOpp');
        var recordId = component.get('v.sObjName')=='Lease_WF__c' ? component.get('v.idLease') : component.get('v.idAmdOpp');
        
        var action = component.get('c.getAmendmentRentReliefData');
        action.setParams({
            "recordId": recordId,
            "sObj" : component.get('v.sObjName')
        });
        action.setCallback(this, function(response){
            if(component.isValid()){
                var isSuccess = response.getState();
                if(isSuccess){
                    var result = response.getReturnValue();
                    console.log('result',result);                  
                    if(result != null){
                        component.set('v.Amendment', result);
                        console.log('covenant on load', result.covenant);
                        component.set('v.Parent', result.sObj.ParentAccount_WF__c != null ? result.sObj.ParentAccount_WF__r : null);
                        if(!$A.util.isUndefinedOrNull(result.sObj.LegalEntity_WF__r)){
                            component.set('v.LegalEntityType', result.sObj.LegalEntity_WF__r.CompanyLegalType_WF__c);
                            component.set('v.StateOfIncorporation', result.sObj.LegalEntity_WF__r.StateOfIncorporation_WF__c);
                        }
                        if(!$A.util.isUndefinedOrNull('coDetailsComp')){
                            component.find('coDetailsComp').reInit();
                        }
                        component.find('RentReliefMinimumRent').reInit();
                        component.find('RentReliefCharges').reInit();                 
                        component.find('COV_kickoutsComp').reInit();
                        component.find('COV_radiusRestrictionComp').reInit();
                        component.find('COV_coTenancyComp').reInit();
                        component.find('COV_commonAreaRestrictionComp').reInit();
                        component.find('COV_llRelocationRightsComp').reInit();
                        component.find('COV_llTerminationRightsComp').reInit();
                        component.find('COV_noBuildZoneComp').reInit();
                        component.find('COV_exclusiveRightComp').reInit();
                        component.find('COV_otherComp').reInit();
                        component.find('COsendDocument').reInit();
                        helper.setPicklistValues(component, result);
                        var fetchPickList = $A.get("e.c:fetchPicklist");
                        fetchPickList.fire(); 
                        var fetchPickTableList = $A.get("e.c:fetchPicklistTable");
                        fetchPickTableList.fire(); 
                        $A.util.toggleClass(component.find("spinner"), "slds-hide");
                    }
                }
            }
        });
        $A.enqueueAction(action);
    }, 
    passSectionHelper : function(component, event){
        var sectionName = event.getParam("section");
        if(component.get('v.'+sectionName)){
            component.set('v.'+sectionName,false); 
            $A.util.addClass(component.find(sectionName), 'slds-hide'); 
        }else{
            component.set('v.'+sectionName,true);   
            $A.util.removeClass(component.find(sectionName), 'slds-hide'); 
        }
    },
    cancelHelper : function(component, event){
        if(component.get('v.idAmdOpp') != null){
            if((typeof sforce != 'undefined') && (sforce != null)) {
                sforce.one.navigateToSObject(component.get('v.idAmdOpp')); 
            } else{
                var urlOppDetailPage = "/one/one.app#/sObject/"+component.get('v.idAmdOpp')+"/view";
                window.open(urlOppDetailPage,"_self");
            }
        } else{
            if((typeof sforce != 'undefined') && (sforce != null)) {
                sforce.one.navigateToSObject(component.get('v.idLease')); 
            } else{
                var urlLeaseDetailPage = "/one/one.app#/sObject/"+component.get('v.idLease')+"/view";
                window.open(urlLeaseDetailPage,"_self");
            }
        }
    },
    saveHelper : function(component, event, helper){
        console.log("inside helper");
        // DealMaker is required and has to be validated even when saving as draft
        var validWho = true;
        if (($A.util.isEmpty(component.get('v.Amendment.sObj.Opportunity__r.Dealmaker_WF__c')) 
            && component.get('v.sObjName')=='Lease_WF__c')
            || ($A.util.isEmpty(component.get('v.Amendment.sObj.Dealmaker_WF__c')) 
                && component.get('v.sObjName')=='Opportunity')) {
            validWho = false;
        }

        if(validWho == false){
            component.set("v.GI_whoSectionError", true);
        }else{
            var recordId = component.get('v.sObjName')=='Lease_WF__c' ? component.get('v.idLease') : component.get('v.idAmdOpp');
		
        console.log('*** v.boolKickout', component.get('v.boolKickout'), '*** v.boolCoTenancyRights', component.get('v.boolCoTenancyRights'));
		if (component.get('v.sObjName')=='Opportunity'){
        	component.set('v.Amendment.sObj.KickOuts_WF__c', component.get('v.boolKickout'));
            component.set('v.Amendment.sObj.CoTenancyrights_WF__c', component.get('v.boolCoTenancyRights'));
        }            
        var sObjString = typeof component.get('v.Amendment.sObj')!=="undefined" ? JSON.stringify(component.get('v.Amendment.sObj')) : '';
        var charges = typeof component.get('v.Amendment.charges')!=="undefined" ? JSON.stringify(component.get('v.Amendment.charges')) : '';
        var covenant = typeof component.get('v.Amendment.covenant')!=="undefined" ? JSON.stringify(component.get('v.Amendment.covenant')) : '';
        var rentTableString = typeof component.get('v.Amendment.rentTable')!=="undefined" ? JSON.stringify(component.get('v.Amendment.rentTable')) : '';
        
        /* Start KW */
        var currentPriorYearMonths = typeof component.get('v.Amendment.currentPriorYearMonths')!=="undefined" ? component.get('v.Amendment.currentPriorYearMonths').toString() : '0';
        var futureYearsMonths = typeof component.get('v.Amendment.futureYearsMonths')!=="undefined" ? component.get('v.Amendment.futureYearsMonths').toString() : '0';
        var reliefStartDate = typeof component.get('v.Amendment.reliefStartDate')!=="undefined" ? JSON.stringify(component.get('v.Amendment.reliefStartDate')) : '';
        var reliefEndDate = typeof component.get('v.Amendment.reliefEndDate')!=="undefined" ? JSON.stringify(component.get('v.Amendment.reliefEndDate')) : '';
        var uncommittedBudgetRelief = typeof component.get('v.Amendment.uncommittedBudgetRelief')!=="undefined" ? component.get('v.Amendment.uncommittedBudgetRelief').toString() : '0';
        var rolling12AnnualSales = typeof component.get('v.Amendment.rolling12AnnualSales')!=="undefined" ? component.get('v.Amendment.rolling12AnnualSales').toString() : '0';
        var rolling12AnnualSalesPSF = typeof component.get('v.Amendment.rolling12AnnualSalesPSF')!=="undefined" ? component.get('v.Amendment.rolling12AnnualSalesPSF').toString() : '0';
        

        var relatedOpp = typeof component.get('v.Amendment.relatedOpp')!=="undefined" ? JSON.stringify(component.get('v.Amendment.relatedOpp')) : '';
        var productFamily = typeof component.get('v.Amendment.sObj.ProductFamily_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.ProductFamily_WF__c') : '';
        var useType = typeof component.get('v.Amendment.sObj.UseType_WF__c')!=="undefined" ? JSON.stringify(component.get('v.Amendment.sObj.UseType_WF__c')) : '';
        var expirationDate = typeof component.get('v.Amendment.sObj.ExpirationDate_WF__c')!=="undefined" ? JSON.stringify(component.get('v.Amendment.sObj.ExpirationDate_WF__c')) : '';
        
        var commments = typeof component.get('v.Amendment.sObj.Comments_WF__c')!=="undefined" ? JSON.stringify(component.get('v.Amendment.sObj.Comments_WF__c')) : '';

        var sendDocsToName = typeof component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c') : '';
        var sendDocsToEmail = typeof component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c') : '';
        var sendDocsToPhone = typeof component.get('v.Amendment.sObj.Send_Docs_To_Phone_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.Send_Docs_To_Phone_WF__c') : '';
        var sendDocsToAddress = typeof component.get('v.Amendment.sObj.Send_Docs_To_Mailing_Address_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.Send_Docs_To_Mailing_Address_WF__c') : '';

        var rightToTerminate = typeof component.get('v.Amendment.sObj.RighttoTerminate_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.RighttoTerminate_WF__c').toString() : '';
        var terminationRightPeriod = typeof component.get('v.Amendment.sObj.TerminationRightPeriod_WF__c')!=="undefined" && component.get('v.Amendment.sObj.TerminationRightPeriod_WF__c') != null ? component.get('v.Amendment.sObj.TerminationRightPeriod_WF__c').toString() : '';
        var noticePeriod = typeof component.get('v.Amendment.sObj.NoticePeriod_WF__c')!=="undefined" && component.get('v.Amendment.sObj.NoticePeriod_WF__c')!= null ? component.get('v.Amendment.sObj.NoticePeriod_WF__c').toString() : '0';
        var includeReleaseLanguage = typeof component.get('v.Amendment.sObj.IncludeReleaseLanguage_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.IncludeReleaseLanguage_WF__c').toString() : '';
        var paybackTACommission = typeof component.get('v.Amendment.sObj.PaybackTA_Commission_WF__c')!=="undefined" ? component.get('v.Amendment.sObj.PaybackTA_Commission_WF__c').toString() : '';
        var dealValidated = typeof component.get('v.DealValidated')!=="undefined" ? component.get('v.DealValidated').toString() : 'false';
        var dealMakerId = component.get('v.sObjName')=='Lease_WF__c' ? component.get('v.Amendment.sObj.Opportunity__r.Dealmaker_WF__c') : component.get('v.Amendment.sObj.Dealmaker_WF__c');
        
        relatedOpp.Priority_WF__c = typeof component.get('v.Amendment.sObj.Priority_WF__c') !=="undefined" ? component.get('v.Amendment.sObj.Priority_WF__c') : null;
        relatedOpp.Comments_WF__c = typeof component.get('v.Amendment.sObj.Comments_WF__c') !=="undefined" ? component.get('v.Amendment.sObj.Comments_WF__c') : null;
        relatedOpp.JV_Partner_Approval_Required_WF__c = typeof component.get('v.Amendment.sObj.JV_Partner_Approval_Required_WF__c') !=="undefined" ? component.get('v.Amendment.sObj.JV_Partner_Approval_Required_WF__c') : null;
        relatedOpp.JV_Partner_Approval_WF__c = component.get('v.Amendment.sObj.JV_Partner_Approval_WF__c');
        relatedOpp.LeaseNegotiator_WF__c = component.get('v.Amendment.sObj.LeaseNegotiator_WF__c');
        relatedOpp.LeaseCoordinator_WF__c = component.get('v.Amendment.sObj.LeaseCoordinator_WF__c');
        relatedOpp.HoldReason_WF__c = component.get('v.Amendment.sObj.HoldReason_WF__c');
        relatedOpp.HoldStartDate_WF__c = component.get('v.Amendment.sObj.HoldStartDate_WF__c');
        relatedOpp.HoldEndDate_WF__c = component.get('v.Amendment.sObj.HoldEndDate_WF__c');
        relatedOpp.LossReason_WF__c = component.get('v.Amendment.sObj.LossReason_WF__c');

        /* End KW */
        console.log('test',component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c'));
        console.log('test',sObjString,charges,charges,rentTableString);
        console.log('sendDocsToName',sendDocsToName);
        console.log('sendDocsToEmail',sendDocsToEmail);
        console.log('sendDocsToPhone',sendDocsToPhone);
        console.log('sendDocsToAddress',sendDocsToAddress);
        console.log('covenant', covenant);
		console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
		var saveAndValidate = component.get('v.SaveAndValidateClicked');
		console.log('*** saveAndValidate', saveAndValidate);            
        var action = component.get('c.saveAmendmentRentReliefData');
        action.setParams({
            "recordId": recordId,
            "relatedOpp": relatedOpp,
            "productFamily": productFamily,
            "useType": useType,
            "expirationDate": JSON.parse(expirationDate),
            "commments": commments,
            "sendDocsToName": sendDocsToName,
            "sendDocsToEmail": sendDocsToEmail,
            "sendDocsToPhone": sendDocsToPhone,
            "sendDocsToAddress": sendDocsToAddress,
            "sObjName" : component.get('v.sObjName'),
            "sObjString" : sObjString,
            "charges" : charges,
            "covenant" : covenant,
            "rentTableString" : rentTableString,
            "currentPriorYearMonths": currentPriorYearMonths,
            "futureYearsMonths": futureYearsMonths,
            "reliefStartDate": reliefStartDate != '' ? JSON.parse(reliefStartDate) : '',
            "reliefEndDate": reliefEndDate != '' ? JSON.parse(reliefEndDate) : '',
            "uncommittedBudgetRelief": uncommittedBudgetRelief,
            "rolling12AnnualSales": rolling12AnnualSales,
            "rolling12AnnualSalesPSF": rolling12AnnualSalesPSF,
            "rightToTerminate": rightToTerminate,
            "terminationRightPeriod": terminationRightPeriod,
            "noticePeriod": noticePeriod,
            "includeReleaseLanguage": includeReleaseLanguage,
            "paybackTACommission": paybackTACommission,
            "dealValidated": dealValidated,
            "dealMakerId": dealMakerId,
            "kickoutToDelete" : JSON.stringify(component.get('v.kickoutToDelete')),
            "SaveAndValidateClicked" : saveAndValidate
        });
        action.setCallback(this, function(response){
            console.log('response',response);
            var isSuccess = response.getState();
            console.log('isSuccess',isSuccess);
            if(isSuccess){
                var result = response.getReturnValue();
                if(result != null){
                    //alert('insert pass');
                    console.log('result',result);
                    //component.set('v.idAmdOpp', result);
                    //helper.cancelHelper(component, event);

                    // component.set('v.Amendment', result);
                    // component.set('v.Parent', result.sObj.ParentAccount_WF__c != null ? result.sObj.ParentAccount_WF__r : null);
                    // component.set('v.LegalEntityType', result.sObj.LegalEntity_WF__r.CompanyLegalType_WF__c);
                    // component.set('v.StateOfIncorporation', result.sObj.LegalEntity_WF__r.StateOfIncorporation_WF__c);
                    // component.find('RentReliefMinimumRent').reInit();
                    // component.find('RentReliefCharges').reInit();                 
                    // component.find('COV_kickoutsComp').reInit();
                    // component.find('COV_radiusRestrictionComp').reInit(); 
                    // component.find('COV_coTenancyComp').reInit();
                    // component.find('COV_commonAreaRestrictionComp').reInit();
                    // component.find('COV_llRelocationRightsComp').reInit();
                    // component.find('COV_llTerminationRightsComp').reInit();
                    // component.find('COV_noBuildZoneComp').reInit();
                    // component.find('COV_exclusiveRightComp').reInit();
                    // component.find('COV_otherComp').reInit();
                    // var fetchPickList = $A.get("e.c:fetchPicklist");
                    // fetchPickList.fire(); 
                    // var fetchPickTableList = $A.get("e.c:fetchPicklistTable");
                    // fetchPickTableList.fire();
                    // $A.util.toggleClass(component.find("spinner"), "slds-hide");

                    //redirect to new opportunity
                    if((typeof sforce != 'undefined') && (sforce != null)){                                                
                        sforce.one.navigateToSObject(result.relatedOpp.Id); 
                    }
                     //back up if - sforce.one.navigateToSObject(recordId) code fails 
                    else{                           
                        var urlOpptyDetailPage = "/one/one.app#/sObject/"+result.relatedOpp.Id+"/view";
                        window.open(urlOpptyDetailPage,"_self");
                    }
                } else{
                    console.log('failed result',result);
                    alert('insert failed');
                }
            }
        });
        $A.util.toggleClass(component.find("spinner"), "slds-hide");
        $A.enqueueAction(action);
        }  
    },
    validateHelper : function(component, event, helper){
        var validWho = true;
        var validSummary = true;
        var validMinRent = true;
        var validSendDocsTo = true;
        var validForm = true;
        var validKickouts = true;
        var validRadius = true;
        var validAreaRestriction = true;
        var validCoTenancy = true;
        var validRelocation = true;
        var validTermination = true;
        var validNoBuildZone = true;
        var validExclusiveRights = true;
        var boolIsError =true;
        var result= component.get('v.Amendment');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        component.set("v.GI_whoSectionError", false);
        component.set("v.GI_rentReliefError", false);
        component.set("v.MR_minimumRentError", false);
        component.set("v.CH_chargesError", false);
        component.set("v.CO_sendDocsToError", false);
       
        
        component.set("v.COV_coTenancyError", false);
       
       
       
       


        // Validate Who section
        
        // if Rent Relief is being created from the Lease then validate Lease_WF__r.Opportunity__r.Dealmaker_WF__c
        // if Rent Relief is just being updated (editing opportunity) then validate Opporutniy.Dealmaker_WF__c
        if (($A.util.isEmpty(component.get('v.Amendment.sObj.Opportunity__r.Dealmaker_WF__c')) 
            && component.get('v.sObjName')=='Lease_WF__c')
            || ($A.util.isEmpty(component.get('v.Amendment.sObj.Dealmaker_WF__c')) 
                && component.get('v.sObjName')=='Opportunity')) {
            validWho = false;
        }

        // Validate Rent Relief Summary section
        if ($A.util.isEmpty(component.get('v.Amendment.uncommittedBudgetRelief')) ){
            validSummary = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.rolling12AnnualSales')) ){
            validSummary = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.rolling12AnnualSalesPSF')) ){
            validSummary = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.reliefStartDate')) ){
            validSummary = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.reliefEndDate')) ){
            validSummary = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.sObj.RighttoTerminate_WF__c')) ){
            validSummary = false;
        }
        if (component.get('v.Amendment.sObj.RighttoTerminate_WF__c') != 'No' 
            && $A.util.isEmpty(component.get('v.Amendment.sObj.TerminationRightPeriod_WF__c')) ){
            validSummary = false;
        }

        /*if ($A.util.isEmpty(component.get('v.Amendment.currentYearVarBudgetvsActual')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.occupancyCost')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.occupancyCostProposedRentRelief')) ){
            validForm = false;
            
         //   var nameField = component.find("OccupancyCostProposedRentRelief2");
          //  console.log('+++ nameField '+nameField);
           // nameField.set("v.errors", [{message:"Enter a Name"}]);
        }*/
        
        
        /*if ($A.util.isEmpty(component.get('v.Amendment.currentPriorYearMonths')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.futureYearsMonths')) ){
            
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.totalRentReliefImpact')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.currentPriorYearImpact')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.futureYearsImpact')) ){
            validForm = false;
        }*/
// var charges = typeof component.get('v.Amendment.charges')!=="undefined" ? JSON.stringify(component.get('v.Amendment.charges')) : '';
//  charges =        component.get('v.Amendment.charges');
       
//         console.log('+++ charges 4'+component.get('v.Amendment.charges')[0].OperatingExpenseRentRelief_Propsed_WF__c);
        
        // Validate Min Rent Table against overlapping steps and partially filled dates
        validMinRent = this.isMinRentValid(component);
        
        ///Charges fields
        var validFormCharges = true;

        if(!$A.util.isEmpty(component.get('v.Amendment.charges'))){

            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].OperatingExpenseRentRelief_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge OperatingExpenseRentRelief_WF__c');
            }
            
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].InsuranceRentRelief_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge InsuranceRentRelief_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].FoodCourtExpenseRentRelief_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge FoodCourtExpenseRentRelief_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].PromotionalChargesRentRelief_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge PromotionalChargesRentRelief_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].RealEstateTaxRentRelief_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge RealEstateTaxRentRelief_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].Water_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge Water_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].EncldMallHVAC_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge EncldMallHVAC_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].Electricity_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge Electricity_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].Parking_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge Parking_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].StateSalesTax_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge StateSalesTax_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].FDS_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge FDS_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].TTHVACCPLChilledWater_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge TTHVACCPLChilledWater_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].Trash_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge Trash_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].Gas_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge Gas_WF__c');
            }
            if ($A.util.isEmpty(component.get('v.Amendment.charges')[0].OtherCharge1_WF__c) ){
                validFormCharges = false;
                console.log('expecting charge OtherCharge1_WF__c');
            }
        }

        // Validate Covenants section
            // Validate Kickouts covenants
            var kickoutEvent = $A.get("e.c:KickoutDetailsEvent");
            if(!$A.util.isUndefinedOrNull(kickoutEvent)){ 
                kickoutEvent.fire();
            }
            if(component.get('v.kickoutError')){validKickouts=false;}
            
            // Validate Radius Restriction covenant
            var radiusRestriction = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Radius Restriction']){
                    radiusRestriction = covenant[item];
                }
            }
            if(radiusRestriction.RadiusRestriction_WF__c){   
                // check for # of is not empty
                if(radiusRestriction.of_WF__c =='' || radiusRestriction.of_WF__c == null || radiusRestriction.of_WF__c =='--None--'){
                    component.set('v.noOfError',true);
                    validRadius = false;
                }else{
                    component.set('v.noOfError',false);
                }
                // check for Duration is not empty
                if(radiusRestriction.Duration_WF__c =='' || radiusRestriction.Duration_WF__c ==null || radiusRestriction.Duration_WF__c =='--None--'){
                    component.set('v.durationError',true);
                    validRadius = false;
                }else{
                    component.set('v.durationError',false);
                }
                // check for If Duration is Other is not empty
                if(radiusRestriction.Duration_WF__c =='Other' 
                    && 
                    (
                        (radiusRestriction.Duration_Months__c ==0 && radiusRestriction.DurationYears_WF__c ==0) 
                        ||
                        (radiusRestriction.Duration_Months__c =='' && radiusRestriction.DurationYears_WF__c =='') 
                        ||
                        (radiusRestriction.Duration_Months__c ==null && radiusRestriction.DurationYears_WF__c ==null)
                    )
                ){
                    component.set('v.yearMonthError',true);
                    validRadius = false;
                }else{          
                    component.set('v.yearMonthError',false);
                }
            }
            
            // Validate Co-Tenancy covenants
            var coTenancyEvent = $A.get("e.c:CoTenancyDetailsEvent");
            if(!$A.util.isUndefinedOrNull(coTenancyEvent)){ 
                coTenancyEvent.fire();
            }
            if(component.get('v.CoTenancyError')){validCoTenancy=false;}

            // Validate Common Area Restriction
            var commonAreaRestriction = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Common Area Restrictions']){
                    commonAreaRestriction = covenant[item];
                }
            }
            
            // check for Restriction Type is not empty       
            if(commonAreaRestriction.CommonAreaRestrictions_WF__c==true && (commonAreaRestriction.RestrictionType_WF__c =='' || commonAreaRestriction.RestrictionType_WF__c ==null || commonAreaRestriction.RestrictionType_WF__c=='--None--')){
                component.set('v.restrictionTypeError',true);
                validAreaRestriction = false;
            }else{          
                component.set('v.restrictionTypeError',false);
            }
            
            // check for Area Restriction Unit of Measure is not empty
            if(commonAreaRestriction.CommonAreaRestrictions_WF__c==true && (commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c =='' || commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c==null || commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c=='--None--')){
                component.set('v.areaRestUnitOfMeasureError',true);
                validAreaRestriction = false;
            }else{          
                component.set('v.areaRestUnitOfMeasureError',false);
            }

            // Validate Landlord Relocation Rights covenants
            var llRelocationRight = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Landlord Relocation Rights']){
                    llRelocationRight = covenant[item];
                }
            }
            
            // check for Relocation Rights Description is not empty
            if(llRelocationRight.StandardRelocationRights_WF__c==false && (llRelocationRight.IfNoRelocationRightsDescription_WF__c =='' || llRelocationRight.IfNoRelocationRightsDescription_WF__c ==null)){
                component.set('v.relocRightsDescriptionError',true);
                validRelocation = false;
            }else{          
                component.set('v.relocRightsDescriptionError',false);
            }

            // Validate Landlord Termination Rights covenants
            var landlordTerminationtionRight = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Landlord Termination Rights']){
                    landlordTerminationtionRight = covenant[item];
                }
            }
            
            // check for Termination Rights Description is not empty
            if(landlordTerminationtionRight.StandardTerminationRights_WF__c==false && (landlordTerminationtionRight.TerminationRightsDescription_WF__c ==='' || landlordTerminationtionRight.TerminationRightsDescription_WF__c ===null)){
                component.set('v.terminationRightsDescError',true);
                validTermination = false;
            }else{          
                component.set('v.terminationRightsDescError',false);
            }

            // Validate No Build Zone/Site Line Restriction/Leasing Restriction
            var SLR = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['SLR']){
                    SLR = covenant[item];
                }
            }
            
            // check for Relocation Rights Description is not empty
            if(SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c ==true && SLR.Zone_WF__c ==true && ( SLR.DescriptionZone_WF__c =='' || SLR.DescriptionZone_WF__c ==null)){
                component.set('v.descNoBuildError',true);
                validNoBuildZone = false;
            }else{          
                component.set('v.descNoBuildError',false);
            }

            // Validate Exclusive Rights covenants.
            var exclusiveRights = {} ;
            var covenant = component.get('v.Amendment.covenant');
            for(var item in covenant){
                if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Exclusive Right']){
                    exclusiveRights = covenant[item];
                }
            }
            // check for Excl Right Description is not empty
            if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclRightDescription_WF__c =='' ||  exclusiveRights.ExclRightDescription_WF__c ==null)){
                component.set('v.exclRightDescError',true);
                validExclusiveRights = false;
            }else{
                component.set('v.exclRightDescError',false);
            }
            // check for Excl Duration is not empty
            if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclDuration_WF__c =='' ||  exclusiveRights.ExclDuration_WF__c ==null)){
                component.set('v.exclDurationError',true);
                validExclusiveRights = false;
            }else{
                component.set('v.exclDurationError',false);
            }
            // check for Excl Remedy Description is not empty
            if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclRemedyDescription_WF__c =='' ||  exclusiveRights.ExclRemedyDescription_WF__c ==null)){
                component.set('v.exclRemedyDescError',true);
                validExclusiveRights = false;
            }else{
                component.set('v.exclRemedyDescError',false);
            }
            


        // Validate Send Documents To section
        if ($A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c'))){
            validSendDocsTo = false;           
            component.set('v.SendDocumentToNameError',true);
        }else{
            component.set('v.SendDocumentToNameError',false);
        }
        if ($A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c'))){
            validSendDocsTo = false;
            component.set('v.SendDocumentToEmailAddressError',true);
        }else{
            component.set('v.SendDocumentToEmailAddressError',false);
        }
        if ($A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Phone_WF__c'))){
            validSendDocsTo = false;
            component.set('v.SendDocumentToPhoneNoError',true);
        }else{
            component.set('v.SendDocumentToPhoneNoError',false);
        }
        if ($A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Mailing_Address_WF__c'))){
            validSendDocsTo = false;
            component.set('v.SendDocumentToMailingAddressError',true);
        }else{
            component.set('v.SendDocumentToMailingAddressError',false);
        }   

        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c').length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {console.log('inside if');
            validSendDocsTo=false;
            component.set('v.SendDocumentToNameLengthError',true);
        }else{
            component.set('v.SendDocumentToNameLengthError',false);
        }
        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c').length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            validSendDocsTo=false;
            component.set('v.SendDocumentToEmailAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToEmailAddressLengthError',false);
        }
        
        // Set sections errors, if any
        if(validWho == false){component.set("v.GI_whoSectionError", true);}
        if(validSummary == false){component.set("v.GI_rentReliefError", true);}
        if(validMinRent == false){component.set("v.MR_minimumRentError", true);}
        if(validFormCharges == false ){component.set("v.CH_chargesError", true);}
        if(validKickouts == false){component.set("v.COV_kickoutsError", true);}
        if(validRadius == false){component.set("v.COV_radiusRestrictionError", true);}
        if(validCoTenancy == false){component.set("v.COV_coTenancyError", true);}
        if(validAreaRestriction == false){component.set("v.COV_commonAreaRestrictionError", true);}
        if(validRelocation == false){component.set("v.COV_llRelocationRightsError", true);}
        if(validTermination == false){component.set("v.COV_llTerminationRightsError", true);}
        if(validNoBuildZone == false){component.set("v.COV_noBuildZoneError", true);}
        if(validExclusiveRights == false){component.set("v.COV_exclusiveRightError", true);}
        if(validSendDocsTo == false){component.set("v.CO_sendDocsToTempError", true);}
        
        if (validWho && validSummary && validMinRent && validFormCharges && validSendDocsTo && validKickouts && validRadius 
            && validCoTenancy && validAreaRestriction && validRelocation && validTermination && validNoBuildZone && validExclusiveRights){        
            boolIsError=false;
        }
        return boolIsError;
    },
    isMinRentValid:function(component){
        if (!$A.util.isEmpty(component.get('v.Amendment.rentTable'))) {
            component.set('v.minRentErrors', "[]");
            var minRentErrors = [];
            var listMinRent = component.get('v.Amendment.rentTable.minRent');
            //clear out any previous errors
            for (x = 0; x < listMinRent.length; x++) {
                listMinRent[x].StartDateInvalid_WF__c = false;
                listMinRent[x].EndDateInvalid_WF__c = false;
                listMinRent[x].StartDateProposedInvalid_WF__c = false;
                listMinRent[x].EndDateProposedInvalid_WF__c = false;
            }
            //validate Contract side
            for (x = 0; x < listMinRent.length; x++) {
                if (listMinRent[x].StartDate_WF__c == null && listMinRent[x].EndDate_WF__c != null) {
                    minRentErrors.push('CONTRACT side is missing the START DATE in step ' + (x + 1) + '.');
                    listMinRent[x].StartDateInvalid_WF__c = true;
                } else if (listMinRent[x].StartDate_WF__c != null && listMinRent[x].EndDate_WF__c == null) {
                    minRentErrors.push('CONTRACT side is missing the END DATE in step ' + (x + 1) + '.');
                    listMinRent[x].EndDateInvalid_WF__c = true;
                } else if (listMinRent[x].StartDate_WF__c > listMinRent[x].EndDate_WF__c) {
                    minRentErrors.push('CONTRACT side has a START DATE that is greater than the END DATE in step ' + (x + 1) + '.');
                    listMinRent[x].StartDateInvalid_WF__c = true;
                    listMinRent[x].EndDateInvalid_WF__c = true;
                } else if (listMinRent[x].StartDate_WF__c != null && listMinRent[x].EndDate_WF__c != null) {
                    for (y = 0; y < listMinRent.length; y++) {
                        if ((y > x) && (listMinRent[y].StartDate_WF__c != null && listMinRent[y].EndDate_WF__c != null)) {
                            if (listMinRent[x].StartDate_WF__c < listMinRent[y].StartDate_WF__c &&
                                listMinRent[x].EndDate_WF__c >= listMinRent[y].StartDate_WF__c) {
                                minRentErrors.push('CONTRACT side OVERLAPS between step ' + (x + 1) + ' and step ' + (y + 1) + '.');
                                listMinRent[y].StartDateInvalid_WF__c = true;
                                listMinRent[x].EndDateInvalid_WF__c = true;
                            } else if (listMinRent[x].StartDate_WF__c >= listMinRent[y].StartDate_WF__c &&
                                listMinRent[x].StartDate_WF__c <= listMinRent[y].EndDate_WF__c) {
                                minRentErrors.push('CONTRACT side OVERLAPS between step ' + (x + 1) + ' and step ' + (y + 1) + '.');
                                listMinRent[x].StartDateInvalid_WF__c = true;
                                listMinRent[y].EndDateInvalid_WF__c = true;
                            }
                        }
                    }
                }
            }
            //validate Proposed side
            for (x = 0; x < listMinRent.length; x++) {
                if (listMinRent[x].StartDateProposed_WF__c == null && listMinRent[x].EndDateProposed_WF__c != null) {
                    minRentErrors.push('PROPOSED side is missing the START DATE in step ' + (x + 1) + '.');
                    listMinRent[x].StartDateProposedInvalid_WF__c = true;
                } else if (listMinRent[x].StartDateProposed_WF__c != null && listMinRent[x].EndDateProposed_WF__c == null) {
                    minRentErrors.push('PROPOSED side is missing the END DATE in step ' + (x + 1) + '.');
                    listMinRent[x].EndDateProposedInvalid_WF__c = true;
                } else if (listMinRent[x].StartDateProposed_WF__c > listMinRent[x].EndDateProposed_WF__c) {
                    minRentErrors.push('PROPOSED side has a START DATE that is greater than the END DATE in step ' + (x + 1) + '.');
                    listMinRent[x].StartDateProposedInvalid_WF__c = true;
                    listMinRent[x].EndDateProposedInvalid_WF__c = true;
                } if (listMinRent[x].StartDateProposed_WF__c != null && listMinRent[x].EndDateProposed_WF__c != null) {
                    for (y = 0; y < listMinRent.length; y++) {
                        if ((y > x) && (listMinRent[y].StartDateProposed_WF__c != null && listMinRent[y].EndDateProposed_WF__c != null)) {
                            if (listMinRent[x].StartDateProposed_WF__c < listMinRent[y].StartDateProposed_WF__c &&
                                listMinRent[x].EndDateProposed_WF__c >= listMinRent[y].StartDateProposed_WF__c) {
                                minRentErrors.push('PROPOSED side OVERLAPS between step ' + (x + 1) + ' and step ' + (y + 1) + '.');
                                listMinRent[y].StartDateProposedInvalid_WF__c = true;
                                listMinRent[x].EndDateProposedInvalid_WF__c = true;
                            } else if (listMinRent[x].StartDateProposed_WF__c >= listMinRent[y].StartDateProposed_WF__c &&
                                listMinRent[x].StartDateProposed_WF__c <= listMinRent[y].EndDateProposed_WF__c) {
                                minRentErrors.push('PROPOSED side OVERLAPS between step ' + (x + 1) + ' and step ' + (y + 1) + '.');
                                listMinRent[x].StartDateProposedInvalid_WF__c = true;
                                listMinRent[y].EndDateProposedInvalid_WF__c = true;
                            }
                        }
                    }
                }
            }
            component.set('v.minRentErrors', minRentErrors);
            if (minRentErrors != '') {
                component.set('v.Amendment.rentTable.minRent', listMinRent);
                return false;
            }
        }
        return true;
	},
    handleError:function(cmp,event,helper){
        var comp = event.getSource();
        $A.util.addClass(comp, "error");   
    },
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = result.objectList;
        var fieldNames = result.FieldList;
        console.log('picklistMap',picklistMap);
        for(var each in objNames){
            for(var eachField in fieldNames){
                if(!$A.util.isUndefinedOrNull(component.find(objNames[each] + fieldNames[eachField]))){
                    var optionVals = picklistMap[objNames[each] + fieldNames[eachField]];
                    if(!$A.util.isUndefinedOrNull(optionVals)){
                        component.find(objNames[each] + fieldNames[eachField]).setLocalValues(optionVals);
                    }
                }
            }
        }
    },
    validateSendDocsToLength:function(component)
    {
        var sendDocsLengthErr=false;
        var result= component.get('v.Amendment');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        component.set("v.CO_sendDocsToError", false);
        
        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Name_WF__c').length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {console.log('inside if');
            sendDocsLengthErr=true;
            component.set('v.SendDocumentToNameLengthError',true);
        }else{
            component.set('v.SendDocumentToNameLengthError',false);
        }
        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Email_WF__c').length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            sendDocsLengthErr=true;
            component.set('v.SendDocumentToEmailAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToEmailAddressLengthError',false);
        }
        
        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Phone_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Phone_WF__c').length > covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])
        {
            sendDocsLengthErr=true;
            component.set('v.SendDocumentToPhoneLengthError',true);
        }else{
            component.set('v.SendDocumentToPhoneLengthError',false);
        }
        
        if(!$A.util.isEmpty(component.get('v.Amendment.sObj.Send_Docs_To_Mailing_Address_WF__c')) && component.get('v.Amendment.sObj.Send_Docs_To_Mailing_Address_WF__c').length > covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])
        {
            console.log("inside Sned docs Rent relief");
            sendDocsLengthErr=true;
            component.set('v.SendDocumentToMailingAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToMailingAddressLengthError',false);
        }
        
        if(sendDocsLengthErr || component.get('v.CO_sendDocsToTempError'))
           {
            component.set("v.CO_sendDocsToError", true);
           }
        return sendDocsLengthErr;
    },
    validateSaveAsDraft:function(component){
        var boolIsError =false;
        var coTenancyEvent = $A.get("e.c:CoTenancyDetailsEvent");
            if(!$A.util.isUndefinedOrNull(coTenancyEvent)){ 
                coTenancyEvent.fire();
            }
            if(component.get('v.CoTenancyError'))
        {
            boolIsError=true;
        }
        return boolIsError;
    },
    validateComments : function(component){
        var boolIsError = false;
        var result= component.get('v.Amendment');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        console.log("covenantTextFieldMap",covenantTextFieldMap);
	component.set("v.CO_detailsError", false);
        component.set("v.COV_otherError", false);   
        component.set("v.COV_radiusRestrictionError", false);
        component.set("v.COV_kickoutsError", false);
        component.set("v.COV_commonAreaRestrictionError",false);
        component.set("v.COV_llTerminationRightsError", false);
        component.set("v.COV_llRelocationRightsError", false);
        component.set("v.COV_noBuildZoneError", false);
        component.set("v.COV_exclusiveRightError", false);        
        console.log("sobj",component.get('v.sObjName'));
        var sObj = (component.get('v.sObjName')=='Lease_WF__c')? component.get('v.Amendment.relatedOpp') : component.get('v.Amendment.sObj');

        if(!$A.util.isUndefinedOrNull(sObj.Comments_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Comments_WF__c'])
        && sObj.Comments_WF__c.length > covenantTextFieldMap['Comments_WF__c'])
        {
          component.set("v.CommentsError", true);
          component.set("v.CO_detailsError", true);
          boolIsError=true;
        }
        else
        {
          component.set("v.CommentsError", false);
        } 
    
        if(!$A.util.isUndefinedOrNull(sObj.OtherReasonOpportunityDead_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        && sObj.OtherReasonOpportunityDead_WF__c.length > covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        {
          component.set("v.oppDeadCommsLenError", true);
          component.set("v.CO_detailsError", true);
          boolIsError=true;
        }
        else
        {
          component.set("v.oppDeadCommsLenError", false);
        }
        
        var strDeadReasonComms = sObj.OtherReasonOpportunityDead_WF__c;
        var strDeadReason = sObj.LossReason_WF__c;
        if(strDeadReason =='Other' && (strDeadReasonComms ==null || strDeadReasonComms ==''))
        {
            component.set('v.oppDeadCommsError', true);
            component.set("v.CO_detailsError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.oppDeadCommsError', false);
        }
		//Added Condition for On Holf
		var onHoldCheck =  sObj.On_Hold_WF__c ;
        var onHoldReason = sObj.HoldReason_WF__c;
        if(onHoldCheck == true && onHoldReason == ''){
            component.set("v.CO_detailsError", true);
            component.set('v.oppOnHoldValidation', true);
            boolIsError = true;
        } 
        else{
            component.set("v.CO_detailsError", false);
            component.set('v.oppOnHoldValidation', false);
        }
        console.log('++++onHoldCheck+++',onHoldCheck,'+++onHoldReason++',onHoldReason);
        //onHold Condition End
        if(!$A.util.isUndefinedOrNull(sObj.HoldOtherReasonComment_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['HoldOtherReasonComment_WF__c'])
        && sObj.HoldOtherReasonComment_WF__c.length > covenantTextFieldMap['HoldOtherReasonComment_WF__c'])
        {
            component.set('v.holdCommsError', true);
            component.set("v.CO_detailsError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.holdCommsError', false);
        }
        var covenant = component.get('v.Amendment.covenant');
        var covenantother = '';
        var covenantexcRight = '';
        var covenantSLR = '';
        var covenantllRel = '';
        var covenantCAR = '';
        var covenantKick = '';
        
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Other']){
                covenantother = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Exclusive Right']){
                covenantexcRight = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['SLR']){
                covenantSLR = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Landlord Relocation Rights']){
                covenantllRel = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Landlord Termination Rights']){
                covenantTermRel = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Common Area Restrictions']){
                covenantCAR = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Kickout']){
                covenantKick = covenant[item];
            }
            if(covenant[item].RecordTypeId==component.get('v.Amendment.covenantRecordType')['Radius Restriction']){
                covenantRR = covenant[item];
            }
        }
        if(!$A.util.isUndefinedOrNull(covenantother.CovenantComments_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['CovenantComments_WF__c'])
        && covenantother.CovenantComments_WF__c.length > covenantTextFieldMap['CovenantComments_WF__c'])
        {
            component.set('v.covCommentLengthError', true);
            component.set("v.COV_otherError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.covCommentLengthError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantexcRight.ExclRightDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRightDescription_WF__c'])
        && covenantexcRight.ExclRightDescription_WF__c.length > covenantTextFieldMap['ExclRightDescription_WF__c'])
        {
            component.set('v.exclRightDescLenError', true);
            component.set("v.COV_exclusiveRightError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.exclRightDescLenError', false);
        }
        if(!$A.util.isUndefinedOrNull(covenantexcRight.ExclDuration_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclDuration_WF__c'])
        && covenantexcRight.ExclDuration_WF__c.length > covenantTextFieldMap['ExclDuration_WF__c'])
        {
            component.set('v.exclDurationLenError', true);
            component.set("v.COV_exclusiveRightError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.exclDurationLenError', false);
        }
        if(!$A.util.isUndefinedOrNull(covenantexcRight.ExclRemedyDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRemedyDescription_WF__c'])
        && covenantexcRight.ExclRemedyDescription_WF__c.length > covenantTextFieldMap['ExclRemedyDescription_WF__c'])
        {
            component.set('v.exclRemedyDescLenError', true);
            component.set("v.COV_exclusiveRightError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.exclRemedyDescLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantSLR.ZoneDetails_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ZoneDetails_WF__c'])
        && covenantSLR.ZoneDetails_WF__c.length > covenantTextFieldMap['ZoneDetails_WF__c'])
        {
            component.set('v.ZoneDetailsLenError', true);
            component.set("v.COV_noBuildZoneError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.ZoneDetailsLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantSLR.DescriptionZone_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionZone_WF__c'])
        && covenantSLR.DescriptionZone_WF__c.length > covenantTextFieldMap['DescriptionZone_WF__c'])
        {
            component.set('v.DescriptionLenError', true);
            component.set("v.COV_noBuildZoneError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.DescriptionLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantllRel.IfNoRelocationRightsDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c'])
        && covenantllRel.IfNoRelocationRightsDescription_WF__c.length > covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c'])
        {
            component.set('v.DescriptionLenLLError', true);
            component.set("v.COV_llRelocationRightsError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.DescriptionLenLLError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTermRel.TerminationRightsDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['TerminationRightsDescription_WF__c'])
        && covenantTermRel.TerminationRightsDescription_WF__c.length > covenantTextFieldMap['TerminationRightsDescription_WF__c'])
        {
            component.set('v.DescriptionLenTermError', true);
            component.set("v.COV_llTerminationRightsError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.DescriptionLenTermError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantCAR.Description_Restriction_Type_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Description_Restriction_Type_WF__c'])
        && covenantCAR.Description_Restriction_Type_WF__c.length > covenantTextFieldMap['Description_Restriction_Type_WF__c'])
        {
            component.set('v.DescriptionCARLenError', true);
            component.set("v.COV_commonAreaRestrictionError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.DescriptionCARLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantCAR.IfCompetingUseDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['IfCompetingUseDescription_WF__c'])
        && covenantCAR.IfCompetingUseDescription_WF__c.length > covenantTextFieldMap['IfCompetingUseDescription_WF__c'])
        {
            component.set('v.CompDescCARLenError', true);
            component.set("v.COV_commonAreaRestrictionError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.CompDescCARLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantKick.OtherDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription_WF__c'])
        && covenantKick.OtherDescription_WF__c.length > covenantTextFieldMap['OtherDescription_WF__c'])
        {
            component.set('v.OtherLenError', true);
            component.set("v.COV_kickoutsError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.OtherLenError', false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantRR.RR_Other_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['RR_Other_WF__c'])
        && covenantRR.RR_Other_WF__c.length > covenantTextFieldMap['RR_Other_WF__c'])
        {
            component.set('v.RR_OtherError', true);
            component.set("v.COV_radiusRestrictionError", true);
            boolIsError = true;
        }
        else
        {
            component.set('v.RR_OtherError', false);
        }
        return boolIsError;
        }
    }
})