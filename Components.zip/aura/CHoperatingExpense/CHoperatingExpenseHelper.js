({
	setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = 'Charges_WF__c';
        var fieldNames = result.FieldList;
        console.log('picklistMap',picklistMap);
        console.log('fieldNames',fieldNames);
        console.log('result',result);
        for(var eachField in fieldNames){
            console.log('I am inside CHoperatingExpenseHelper' +eachField);
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                console.log('****',objNames + fieldNames[eachField],optionVals);
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    }
})