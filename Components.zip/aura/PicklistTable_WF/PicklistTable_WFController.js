({	
    init: function(component, event, helper) {     
        var picklist = component.get('v.pickListValue');
        var selectedItems = component.get('v.selectedItems');
        if(typeof selectedItems != 'undefined' && selectedItems !=null){
            component.set('v.selectedItemsWithoutNull',selectedItems);
        }
        if(picklist.length<=0){
            
            console.log('I am reaching here inside picklistTable 1.1');
            var action = component.get("c.fetchPicklist");
            action.setParams({
                "objectName" : component.get('v.objectName'),
                "fieldName" : component.get('v.fieldName')
            });
            action.setCallback(this, function(response) {
                var selectedItems = component.get('v.selectedItemsWithoutNull');
                var state = response.getState();
                if (state === "SUCCESS") {
                    var opts=[];
                    for(var i=0;i< response.getReturnValue().length;i++){ 
                        
                        if(typeof selectedItems != 'undefined' && selectedItems !=''){
                            if(response.getReturnValue()[i].label===selectedItems)
                                opts.push({label: response.getReturnValue()[i].label, value: response.getReturnValue()[i].value, selected : true});
                            else
                                opts.push({label: response.getReturnValue()[i].label, value: response.getReturnValue()[i].value});
                        }else{
                            if(response.getReturnValue()[i].defaultValue != null){
                                opts.push({label: response.getReturnValue()[i].label, value: response.getReturnValue()[i].value, selected : true});
                                component.set('v.selectedItemsWithoutNull',response.getReturnValue()[i].defaultValue);
                                component.set('v.selectedItems',response.getReturnValue()[i].defaultValue)
                            }
                            else{
                                opts.push({label: response.getReturnValue()[i].label, value: response.getReturnValue()[i].value});
                            }
                        }
                    }
                    component.set("v.options", opts);
                }
                else if (state === "INCOMPLETE") {
                }
                    else if (state === "ERROR") {
                        var errors = response.getError();
                        if (errors) {
                            if (errors[0] && errors[0].message) {
                                console.log("Error message: " + errors[0].message);
                            }
                        } else {
                            console.log("Unknown error");
                        }
                    }
            });
            $A.enqueueAction(action);
            console.log('I am reaching here inside picklistTable 1.2');
        }
        else{
            console.log('I am reaching here inside picklistTable2.1');
            var opts=[];
            var selectedItems = component.get('v.selectedItemsWithoutNull');
            for(var i=0;i< picklist.length;i++){  
                 
                if(typeof selectedItems != 'undefined' && selectedItems !=''){
                    if(picklist[i].label===String(selectedItems))
                        opts.push({label: picklist[i].label, value: picklist[i].value, selected : true});
                    else
                        opts.push({label: picklist[i].label, value: picklist[i].value});
                }else{
                    if(picklist[i].defaultValue != null){
                        opts.push({label: picklist[i].label, value: picklist[i].value, selected : true});
                        component.set('v.selectedItemsWithoutNull',picklist[i].defaultValue);
                        component.set('v.selectedItems',picklist[i].defaultValue)
                    }
                    else{
                        opts.push({label: picklist[i].label, value: picklist[i].value});
                    }
                }
            }
            component.set("v.options", opts);
            console.log('I am reaching here inside picklistTable2.2');
        }
    },
    onSelectChange : function(component, event, helper) {
         console.log('I am reaching here inside onSelectChange 3.1');
        component.set('v.selectedItems',component.find('selectList').get('v.value'));
        var compEvent = component.getEvent("onChange");
        var  name = component.get('v.name') != undefined ? component.get('v.name') : 'name';
        compEvent.setParams({ 
            "values": component.get('v.selectedItems') ,
            "name" : name
        });
        compEvent.fire();
         console.log('I am reaching here inside onSelectChange 3.2');
    }
})