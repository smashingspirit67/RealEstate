({
	doInit : function(component, event, helper) {
        var refreshAddress = $A.get("e.c:RefreshLightningComponentEvent");
        if(!$A.util.isUndefinedOrNull(refreshAddress)){
            refreshAddress.fire();   
        }
	}
})