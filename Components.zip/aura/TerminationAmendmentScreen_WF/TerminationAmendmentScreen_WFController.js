({
	doInit : function(component, event, helper) {
		helper.doInitHelper(component, event, helper);
	},
    
    checkTerminationFee : function(component, event, helper) {
		helper.checkTerminationFeeHelper(component, event);           
	},
    
    passSection : function(component,event){
        var sectionName = event.getParam("section");
        if(component.get('v.'+sectionName)){
            component.set('v.'+sectionName,false); 
            $A.util.addClass(component.find(sectionName), 'slds-hide'); 
        }else{
            component.set('v.'+sectionName,true);   
            $A.util.removeClass(component.find(sectionName), 'slds-hide'); 
        }
    },
    
    passAccount : function(component,event){
        var record = event.getParam("record");
        var fieldValue = event.getParam("fieldValue");
        component.set('v.'+ fieldValue , record);
        console.log(component.get('v.LegalEntity'));
    },
    
    saveAmendments : function(component, event, helper){
            console.log('inside save and validate');
            var boolIsError = true;
            boolIsError = helper.validateCovenantTextField(component, event, helper);
            	if(boolIsError)
                {
                    console.log('inside save if');
                    return;
                }
            	else
                {
                	console.log('inside save else'); 
                    component.set('v.BoolSaveDisable',true);
                	component.set('v.DealValidated', false);
                    helper.saveHelper(component, event, helper);
            	}
        },
    
    saveAndValidateAmendments : function(component, event, helper){
            console.log('inside save-->');
        	component.set('v.SaveAndValidateClicked', true);
        	console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
            /*check if all the required fields are filled*/
			var boolIsLengthError = helper.validateCovenantTextField(component, event, helper);
            var boolIsFieldError = helper.checkRequiredFieldsHelper(component, event, helper);
            if(!boolIsLengthError && !boolIsFieldError){
                component.set('v.BoolValidateDisable',true);
                component.set('v.DealValidated', true);
                helper.saveHelper(component, event, helper);
            }
            else{
                return;	          
            }
        },
    
    handleCancel : function(cmp,eve){
        //redirect to lease
        if(cmp.get('v.idLease') != null){
            if( (typeof sforce != 'undefined') && (sforce != null) ) {
                sforce.one.navigateToSObject(cmp.get('v.idLease')); 
            }
            /*back up if - sforce.one.navigateToSObject(recordId) code fails */
            else{
                var urlLeaseDetailPage = "/one/one.app#/sObject/"+cmp.get('v.idLease')+"/view";
                window.open(urlLeaseDetailPage,"_self");
            }
    	}
        //redirect to opportunity
        else{
            if( (typeof sforce != 'undefined') && (sforce != null) ) {
                sforce.one.navigateToSObject(cmp.get('v.idAmdOpp')); 
            }
            /*back up if - sforce.one.navigateToSObject(recordId) code fails */
            else{
                var urlOppDetailPage = "/one/one.app#/sObject/"+cmp.get('v.idAmdOpp')+"/view";
                window.open(urlOppDetailPage,"_self");
            }
        }
    },
    
    addTerminationRepaymentRows : function(component, event, helper){
        var lstTerminationRepayment = [];
        var terminationRepayment = {};
        var boolTermRepaymentDisable = false;
        var boolTermRepaymentRemoveDisable = false;
        
        lstTerminationRepayment = JSON.parse(JSON.stringify(component.get('v.lstTerminationRepayment')));
                
        terminationRepayment.RentStep_WF__c = lstTerminationRepayment.length + 1;
        console.log('RentStep_WF__c-->',terminationRepayment.RentStep_WF__c);  
        terminationRepayment.Repayment_Amount_WF__c = null;
        terminationRepayment.StartDate_WF__c = null;
        terminationRepayment.EndDate_WF__c = null;
        terminationRepayment.Repayment_Frequency_WF__c = 'Monthly';
        terminationRepayment.RecordTypeId = $A.get("$Label.c.Rent_Table_Rec_Type_Termination_Repayment");
        
        lstTerminationRepayment.push(terminationRepayment);        
        console.log('lstTerminationRepayment',lstTerminationRepayment);
        
        component.set('v.lstTerminationRepayment', lstTerminationRepayment);        
        
        if(lstTerminationRepayment.length >= 10){
            boolTermRepaymentDisable = true;
        }
        if(lstTerminationRepayment.length <= 1){
            boolTermRepaymentRemoveDisable = true;
			console.log('inside add method-- list length <= 1 -- boolTermRepaymentRemoveDisable-->',boolTermRepaymentRemoveDisable);            
        }
        component.set('v.boolTermRepaymentDisable', boolTermRepaymentDisable);
        component.set('v.boolTermRepaymentRemoveDisable', boolTermRepaymentRemoveDisable);
        console.log('inside add method-- boolTermRepaymentRemoveDisable-->',boolTermRepaymentRemoveDisable);
        
        var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
        fetchPickListTable.fire();
                
        for(var each in component.get('v.lstTerminationRepayment')){
            console.log(lstTerminationRepayment[each].Repayment_Frequency_WF__c);
        }
    },
    
    removeTerminationRepaymentRows : function(component, event, helper){
        var lstTerminationRepayment = JSON.parse(JSON.stringify(component.get('v.lstTerminationRepayment')));
        var boolTermRepaymentRemoveDisable = false;
        var boolTermRepaymentDisable = false;
        
        lstTerminationRepayment.pop();
        component.set('v.lstTerminationRepayment', lstTerminationRepayment);
        
        if(lstTerminationRepayment.length >= 10){
            boolTermRepaymentDisable = true;
        }
        if(lstTerminationRepayment.length <= 1){            
            boolTermRepaymentRemoveDisable = true;
            console.log('inside remove method-- list length <= 1 -- boolTermRepaymentRemoveDisable-->',boolTermRepaymentRemoveDisable);            
        }
        component.set('v.boolTermRepaymentDisable', boolTermRepaymentDisable);
        component.set('v.boolTermRepaymentRemoveDisable', boolTermRepaymentRemoveDisable);
        console.log('inside remove method-- boolTermRepaymentRemoveDisable-->',boolTermRepaymentRemoveDisable);
        
        var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
        fetchPickListTable.fire();
        },
         clearValues : function(component, event, helper){
            //Clearing out logic for Outstanding fields --START--
            if(component.get('v.newAmdOpportunity.Outstanding_A_R_WF__c')){
                component.set('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c','v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c');   
                component.set('v.newAmdOpportunity.A_R_Amount_As_Of_WF__c','v.newAmdOpportunity.A_R_Amount_As_Of_WF__c');   
            }else{
                component.set('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c','');      
                component.set('v.newAmdOpportunity.A_R_Amount_As_Of_WF__c',null);   
            }
            //--END--
         },
        clearTenantVacated : function(component, event, helper){
    	 component.set('v.newAmdOpportunity.Date_Tenant_Vacated_WF__c','');
     },
    clearReconciliations  : function(component, event, helper){
         console.log('Reconc Set');
    	 component.set('v.newAmdOpportunity.Reconcilitations_Applies_To_WF__c','');
         component.find('OpportunityReconcilitations_Applies_To_WF__c').reInit();
     },
    clearLandlordBuyout : function(component, event, helper){
    	 component.set('v.newAmdOpportunity.Amount_Due_to_Tenant_WF__c','');
         component.set('v.newAmdOpportunity.Paid_Within_How_Many_Days_WF__c','');
     },
    clearReplacementTenant : function(component, event, helper){
    	 component.set('v.newAmdOpportunity.Replacement_Tenant_Name_WF__c','');
     },
    clearOutstandingAR : function(component, event, helper){
    	 component.set('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c',0);
         component.set('v.newAmdOpportunity.A_R_Amount_As_Of_WF__c',null);
         component.set('v.newAmdOpportunity.Tenant_Responsible_for_Outstanding_AR_WF__c',false);
         component.set('v.newAmdOpportunity.How_will_AR_be_resolved_WF__c','');
     },
    clearOutstandingARTenant : function(component, event, helper){
    	 component.set('v.newAmdOpportunity.How_will_AR_be_resolved_WF__c','');
     },
    clearSecurity  : function(component, event, helper){
        component.set('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c','');
        component.set('v.newAmdOpportunity.LetterofCredit_1_WF__c','');
        component.set('v.newAmdOpportunity.Security_Comments_Amd_WF__c','');
        component.set('v.newAmdOpportunity.Guarantor_Comments_Amd_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('guarantor'))){
            component.find('guarantor').clear();
        }
        if(!$A.util.isUndefinedOrNull(component.find('guarantorNoValue'))){
            component.find('guarantorNoValue').clear();
        }
        //component.set('v.Guarantor.Name',null);
        //component.set('v.guarantorId',null);
     },
})