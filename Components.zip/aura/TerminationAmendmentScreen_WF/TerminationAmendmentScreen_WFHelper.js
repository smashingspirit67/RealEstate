({
	doInitHelper : function(component, event,helper) {
        var lease = {};               
        component.set('v.lease', lease);
        
        var relatedOpportunity = {};
        component.set('v.relatedOpportunity', relatedOpportunity);
        
        var idLease = component.get('v.idLease');
        var idAmdOpp = component.get('v.idAmdOpp');
        
        var action = component.get('c.getRelatedLeaseDetails');
        action.setParams({"strLeaseId":idLease,
                          "strExistingAmendmentOppId" : idAmdOpp
                         });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess){
            	var result = response.getReturnValue();
                
                if(result != null){
                    component.set('v.result',result);
                    var lease = result.lease;
                    var existingAmendmentOpp = result.existingAmendmentOpp;
                    var relatedOpportunity = result.relatedOpportunity;
                    if(existingAmendmentOpp != null && existingAmendmentOpp.Id != null){
                        component.set('v.newAmdOpportunity', existingAmendmentOpp);
                        
                        //updating other attributes
                        component.set('v.DBACustomer', existingAmendmentOpp.B2BCustomer_WF__r);
						component.set('v.LegalEntity', existingAmendmentOpp.LegalEntity_WF__r);
						component.set('v.Parent', existingAmendmentOpp.ParentAccount_WF__r);
                        component.set('v.parentPrepopulated', existingAmendmentOpp.ParentAccount_WF__r !== undefined && existingAmendmentOpp.ParentAccount_WF__r !== null ? true : false);
                        component.set('v.SuperParent', existingAmendmentOpp.SuperParent_WF__r);
                        component.set('v.superParentPrepopulated', existingAmendmentOpp.SuperParent_WF__r !== undefined && existingAmendmentOpp.SuperParent_WF__r !== null ? true : false);
						component.set('v.Dealmaker', existingAmendmentOpp.Dealmaker_WF__r);
						component.set('v.Center', existingAmendmentOpp.CenterName_WF__c != null ? existingAmendmentOpp.CenterName_WF__r : null);
                        component.set('v.Unit', existingAmendmentOpp.Unit_WF__c != null ? existingAmendmentOpp.Unit_WF__r : null);
                        component.set('v.Guarantor', existingAmendmentOpp.Guarantor_WF__r);
                         
                        component.set('v.dbaCustomerId', existingAmendmentOpp.B2BCustomer_WF__c);
                        component.set('v.legalEntityId', existingAmendmentOpp.LegalEntity_WF__c);
                        component.set('v.dealMakerId', existingAmendmentOpp.Dealmaker_WF__c);
                        component.set('v.parentId', existingAmendmentOpp.ParentAccount_WF__c);
                        component.set('v.superParentId', existingAmendmentOpp.SuperParent_WF__c);
                        component.set('v.guarantorId', existingAmendmentOpp.Guarantor_WF__c);

						
                        var lstTerminationRepayment = [];
                        if(existingAmendmentOpp.Installment_Frequency_WF__c == 'Other' && result.lstRentTables != null){
                            lstTerminationRepayment = result.lstRentTables;
                        }
                        
                        component.set('v.lstTerminationRepayment', lstTerminationRepayment);
                    } else if(lease != null){
                        //updating attributes
                        component.set('v.DBACustomer', lease.B2BCustomer_WF__r);
						component.set('v.LegalEntity', lease.LegalEntity_WF__r);
						component.set('v.Parent', lease.ParentAccount_WF__r);
                        component.set('v.parentPrepopulated', lease.ParentAccount_WF__r !== undefined && lease.ParentAccount_WF__r !== null ? true : false);
						if(!$A.util.isUndefinedOrNull(lease.B2BCustomer_WF__r) && !$A.util.isUndefinedOrNull(lease.B2BCustomer_WF__r.SuperParent_WF__r)){
							component.set('v.SuperParent', lease.B2BCustomer_WF__r.SuperParent_WF__r);
                            component.set('v.superParentPrepopulated', true);
						} else{
							component.set('v.SuperParent', {});
                            component.set('v.superParentPrepopulated', false);
						}
						component.set('v.Center', lease.CenterName_WF__c != null ? lease.CenterName_WF__r : null);
						component.set('v.Unit', lease.Unit_WF__c != null ? lease.Unit_WF__r : null);
						
                        if(relatedOpportunity != null && relatedOpportunity.Dealmaker_WF__c != null){
                                component.set('v.Dealmaker', relatedOpportunity.Dealmaker_WF__r);
                                component.set('v.dealMakerId', relatedOpportunity.Dealmaker_WF__c);
                        } else{
                            component.set('v.Dealmaker', result.dealmakerFromLease);                                
                            component.set('v.dealMakerId', result.dealmakerFromLease.Id);
                        }
                        
                        component.set('v.dbaCustomerId', lease.B2BCustomer_WF__c);
                        component.set('v.legalEntityId', lease.LegalEntity_WF__c);
                        
                        
                        //creating new opp instance with default values for some fields which shouldn't be undefined
                        var newAmdOpportunity = {};
                        newAmdOpportunity.Tenant_Resp_Unbilled_Reconcilliations_WF__c = true;
                        newAmdOpportunity.Of_Days_After_Full_Execution_WF__c = null;
                        newAmdOpportunity.Paid_Within_How_Many_Days_WF__c = null;
                        newAmdOpportunity.Termination_Effective_Date_WF__c = null;
                        newAmdOpportunity.Termination_Fee_WF__c = null;
                        newAmdOpportunity.Payment_Type_WF__c = '';
                        newAmdOpportunity.Send_Docs_To_Phone_WF__c = null;
                        newAmdOpportunity.Send_Docs_To_Email_WF__c = null;
                        newAmdOpportunity.Send_Docs_To_Name_WF__c = null;
                        
                        component.set('v.newAmdOpportunity', newAmdOpportunity);
                        
                        //create termination repayment table data
                        var lstTerminationRepayment = [];
                        var terminationRepayment = {};                        
                        terminationRepayment.RentStep_WF__c = 1;
                        terminationRepayment.Repayment_Amount_WF__c = null;
                        terminationRepayment.StartDate_WF__c = null;
                        terminationRepayment.EndDate_WF__c = null;
                        terminationRepayment.Repayment_Frequency_WF__c = 'Monthly';
                        terminationRepayment.RecordTypeId = $A.get("$Label.c.Rent_Table_Rec_Type_Termination_Repayment");
                        
                        lstTerminationRepayment.push(terminationRepayment);            
                        component.set('v.lstTerminationRepayment', JSON.parse(JSON.stringify(lstTerminationRepayment)));
                        
                        var boolTermRepaymentRemoveDisable = true;
            			component.set('v.boolTermRepaymentRemoveDisable', boolTermRepaymentRemoveDisable);
                    }
                    
                    var relatedOpportunity = result.relatedOpportunity;
                    helper.setPicklistValues(component, result);                      
                    component.set('v.lease', lease);
                    component.set('v.relatedOpportunity',relatedOpportunity);
                    helper.checkTerminationFeeHelper(component, event);    
                    var fetchPickList = $A.get("e.c:fetchPicklist");
					fetchPickList.fire();
                    var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
                    fetchPickListTable.fire();
                    var addressEvent = $A.get("e.c:RefreshLightningComponentEvent");
                    addressEvent.fire();
                     if(!$A.util.isUndefinedOrNull('coDetailsComp')){
                        component.find('coDetailsComp').reInit();
                    }
                }
				console.log('*****issue', component.get('v.DBACustomer'));
			}
        });
        $A.enqueueAction(action);
	},
    
    commonValidations : function(component) {
        var hasError = false;
        if(!$A.util.isUndefinedOrNull(component.get('v.SuperParent')) && !component.get('v.superParentNonDBA')){
			$A.util.removeClass(component.find("superParentErrorId"), 'slds-hide');
			hasError = true;
			component.set('v.GI_whoSectionError', true);
		} else{
			$A.util.addClass(component.find("superParentErrorId"), 'slds-hide');
			component.set('v.GI_whoSectionError', false);
		}
		if(!$A.util.isUndefinedOrNull(component.get('v.Parent')) && !component.get('v.parentNonDBA')){
			$A.util.removeClass(component.find("parentErrorId"), 'slds-hide');
			hasError = true;
			component.set('v.GI_whoSectionError', true);
		} else{
			$A.util.addClass(component.find("parentErrorId"), 'slds-hide');
			component.set('v.GI_whoSectionError', false);
		}
        return hasError;
    }, 
    
    saveHelper : function(component, event, helper){
        var lease = {};
        var newAmdOpportunity = {};
        var lstTerminationRepayment = [];
		//creating new amendment
        if(component.get('v.idLease') != null){
            lease = component.get('v.lease');
            lease.B2BCustomer_WF__c = component.get('v.DBACustomer.Id') == null ? null : component.get('v.DBACustomer.Id');
            lease.B2BCustomer_WF__r = component.get('v.DBACustomer') == null ? {} : component.get('v.DBACustomer');
            lease.ParentAccount_WF__c = component.get('v.Parent.Id') == null ? null : component.get('v.Parent.Id');
            lease.LegalEntity_WF__c = component.get('v.LegalEntity.Id') == null ? null : component.get('v.LegalEntity.Id');
            lease.CenterName_WF__c = component.get('v.Center.Id');
            lease.CenterName_WF__r = component.get('v.Center');
            
            newAmdOpportunity = component.get('v.newAmdOpportunity');
			newAmdOpportunity.Guarantor_WF__c = component.get('v.guarantorId') == null ? null : component.get('v.Guarantor.Id');
            newAmdOpportunity.Unit_WF__c = component.get('v.Unit.Id');
            newAmdOpportunity.SuperParent_WF__c = component.get('v.SuperParent.Id') == null ? null : component.get('v.SuperParent.Id');
            newAmdOpportunity.Dealmaker_WF__c = component.get('v.Dealmaker.Id') == null ? null : component.get('v.Dealmaker.Id');
            if(component.get('v.DealValidated') == true)
        	{
        		newAmdOpportunity.DealValidated_WF__c = true;
        	}
        	if(newAmdOpportunity.StageName == $A.get("$Label.c.OpportunityProposalStage_WF") && component.get('v.DealValidated') == false)
        	{
	        	newAmdOpportunity.DealValidated_WF__c = false;
        	}
            if(newAmdOpportunity.Installment_Frequency_WF__c == 'Other'){
                lstTerminationRepayment = JSON.parse(JSON.stringify(component.get('v.lstTerminationRepayment')));
            }   
        }
        //editing amendment opportunity
        else{
            newAmdOpportunity = component.get('v.newAmdOpportunity');
            newAmdOpportunity.B2BCustomer_WF__c = component.get('v.dbaCustomerId') == null ? null : component.get('v.DBACustomer.Id');
			//commenting out __r lines as they cause exceptions in upsert statements
            //newAmdOpportunity.B2BCustomer_WF__r = component.get('v.dbaCustomerId') == null ? {} : component.get('v.DBACustomer');
            newAmdOpportunity.ParentAccount_WF__c = component.get('v.parentId') == null ? null : component.get('v.Parent.Id');
            newAmdOpportunity.SuperParent_WF__c = component.get('v.superParentId') == null ? null : component.get('v.SuperParent.Id');
            newAmdOpportunity.Dealmaker_WF__c = component.get('v.dealMakerId') == null ? null : component.get('v.Dealmaker.Id');
            newAmdOpportunity.LegalEntity_WF__c = component.get('v.legalEntityId') == null ? null : component.get('v.LegalEntity.Id');
            newAmdOpportunity.CenterName_WF__c = component.get('v.Center.Id');
            //newAmdOpportunity.CenterName_WF__r = component.get('v.Center');
			newAmdOpportunity.Guarantor_WF__c = component.get('v.guarantorId') == null ? null : component.get('v.Guarantor.Id');
            newAmdOpportunity.Unit_WF__c = component.get('v.Unit.Id');
            if(component.get('v.DealValidated') == true)
        	{
        		newAmdOpportunity.DealValidated_WF__c = true;
        	}
        	if(newAmdOpportunity.StageName == $A.get("$Label.c.OpportunityProposalStage_WF") && component.get('v.DealValidated') == false)
        	{
	        	newAmdOpportunity.DealValidated_WF__c = false;
        	}
            if(newAmdOpportunity.Installment_Frequency_WF__c == 'Other'){
                lstTerminationRepayment = JSON.parse(JSON.stringify(component.get('v.lstTerminationRepayment')));
            }
        }
                /*Added By sachin for the defect GDM-6520*/
        newAmdOpportunity.Covenant__r = null;
		console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var saveAndValidate = component.get('v.SaveAndValidateClicked');
        console.log('*** saveAndValidate', saveAndValidate);
        var action = component.get('c.saveAmendment');
        action.setParams({"strLease" : JSON.stringify(lease),
                          "strAmdOpportunity" : JSON.stringify(newAmdOpportunity),
                          "strAmendmentType" : "Termination",
                          "strTerminationRepayment" : JSON.stringify(lstTerminationRepayment),
                          "SaveAndValidateClicked" : saveAndValidate
                     });
        action.setCallback(this, function(response){
        	var resultOppId = response.getReturnValue();                 
                
                if(response.getState() == 'SUCCESS' && resultOppId != null){
                    if( (typeof sforce != 'undefined') && (sforce != null) ) {
                        sforce.one.navigateToSObject(resultOppId); 
                    }
                    /* back up if - sforce.one.navigateToSObject(recordId) code fails */
                    else{                    		
                        var urlOpptyDetailPage = "/one/one.app#/sObject/"+resultOppId+"/view";
                        window.open(urlOpptyDetailPage,"_self");
                    }
                }
        });
        $A.enqueueAction(action);
    },
    
    checkRequiredFieldsHelper : function(component, event, helper) {
        var boolIsreqFiledEmpty = false;
        var boolIsRepLenErr=false;
        var boolIsSendDocNameError=false;
        var boolIsSendDocEmailError=false;
        boolTermRepaymentEmpty = false;
        var result=component.get('v.result');
        console.log('result in termination',result);
        component.set('v.CO_detailsTempError',false);
        var covenantTextFieldMap=result.covenantTextFieldMap;
        var newAmdOpportunity = component.get('v.newAmdOpportunity');
        var whoSectionError = false; 
        component.set('v.CO_detailsTempError',false);
        //helper.commonValidations(component);
		// check for DBA Customer is not empty
        if(component.get('v.dbaCustomerId') == null){
            $A.util.removeClass(component.find("dbaCustomerErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("dbaCustomerErrorId"), 'slds-hide');
        }
        // check for Legal Entity is not empty
        if(component.get('v.legalEntityId') == null){
            $A.util.removeClass(component.find("legalEntityErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("legalEntityErrorId"), 'slds-hide');
        }
        // check for Dealmaker is not empty
        if(component.get('v.dealMakerId') == null){
            $A.util.removeClass(component.find("dealmakerErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("dealmakerErrorId"), 'slds-hide');
        }
        //check for Replacement Tenant Name
         if(!$A.util.isUndefinedOrNull(newAmdOpportunity.Replacement_Tenant_Name_WF__c) && newAmdOpportunity.Replacement_Tenant_Name_WF__c.length > covenantTextFieldMap['Replacement_Tenant_Name_WF__c'])
         {
            $A.util.removeClass(component.find("replTenantNameErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
             boolIsRepLenErr=true;
        }else{
            $A.util.addClass(component.find("replTenantNameErrorId"), 'slds-hide');
            boolIsRepLenErr=false;
        }
        // check for Termination Effective Date is not empty
        if(newAmdOpportunity.Termination_Effective_Date_WF__c==undefined || newAmdOpportunity.Termination_Effective_Date_WF__c=='' || newAmdOpportunity.Termination_Effective_Date_WF__c==null){
            $A.util.removeClass(component.find("terminationEffectDateErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("terminationEffectDateErrorId"), 'slds-hide');
        }
        // check for Termination Fee is not empty
        if(newAmdOpportunity.Termination_Fee_WF__c===undefined || newAmdOpportunity.Termination_Fee_WF__c==='' || newAmdOpportunity.Termination_Fee_WF__c===null){
            $A.util.removeClass(component.find("terminationFeeErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("terminationFeeErrorId"), 'slds-hide');
        }
        // check for Reconciliations Applies To is not empty
        if(newAmdOpportunity.Tenant_Resp_Unbilled_Reconcilliations_WF__c &&(newAmdOpportunity.Reconcilitations_Applies_To_WF__c=='' || newAmdOpportunity.Reconcilitations_Applies_To_WF__c==null)){
            $A.util.removeClass(component.find("reconcilitationsAppliesErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("reconcilitationsAppliesErrorId"), 'slds-hide');
        }
        // check for Payment Type is not empty
        if(component.get('v.hasTerminationFee') && (newAmdOpportunity.Payment_Type_WF__c==undefined || newAmdOpportunity.Payment_Type_WF__c=='' || newAmdOpportunity.Payment_Type_WF__c==null)){
            $A.util.removeClass(component.find("payTypeErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("payTypeErrorId"), 'slds-hide');
        }
        // check for Send Documents to Name is not empty
        if(newAmdOpportunity.Send_Docs_To_Name_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Name_WF__c=='' || newAmdOpportunity.Send_Docs_To_Name_WF__c==null){
            $A.util.removeClass(component.find("nameErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("nameErrorId"), 'slds-hide');
        }
        
        if(!$A.util.isUndefinedOrNull(newAmdOpportunity.Send_Docs_To_Name_WF__c) && newAmdOpportunity.Send_Docs_To_Name_WF__c.length > covenantTextFieldMap['Send_Docs_To_Name_WF__c']){
            $A.util.removeClass(component.find("nameLengthErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
            boolIsSendDocNameError=true;
        }else{
            $A.util.addClass(component.find("nameLengthErrorId"), 'slds-hide');
            boolIsSendDocNameError=false;
        }
        // check for Send Documents to Phone is not empty
        if(newAmdOpportunity.Send_Docs_To_Phone_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Phone_WF__c=='' || newAmdOpportunity.Send_Docs_To_Phone_WF__c==null){
            $A.util.removeClass(component.find("phoneErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("phoneErrorId"), 'slds-hide');
        }
        // check for Send Documents to Mailing Address is not empty
        if(newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c=='' || newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c==null){
            $A.util.removeClass(component.find("mailingErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("mailingErrorId"), 'slds-hide');
        }
        // check for Send Documents to Email Address is not empty
        if(newAmdOpportunity.Send_Docs_To_Email_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Email_WF__c=='' || newAmdOpportunity.Send_Docs_To_Email_WF__c==null){
            $A.util.removeClass(component.find("emailAddressErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("emailAddressErrorId"), 'slds-hide');
        }
         		
		if(!$A.util.isUndefinedOrNull(newAmdOpportunity.Send_Docs_To_Email_WF__c) && newAmdOpportunity.Send_Docs_To_Email_WF__c.length > covenantTextFieldMap['Send_Docs_To_Email_WF__c']){
            $A.util.removeClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
            boolIsSendDocEmailError=true;
        }else{
            $A.util.addClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
            boolIsSendDocEmailError=false;
        }
        //Validation for onhold Reason and Description
        if(newAmdOpportunity.On_Hold_WF__c && $A.util.isEmpty(newAmdOpportunity.HoldReason_WF__c)){
            component.set('v.oppOnHoldValidation',true);
            component.set('v.CO_detailsTempError',true);
			component.set('v.CO_detailsError',true);
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.oppOnHoldValidation',false);
            component.set('v.CO_detailsTempError',false);
			component.set('v.CO_detailsError',false);	
        }

        
        
        //Validation for Termination Repayment Table - START
        var boolTermRepaymentEmpty = false;
        console.log('v.lstTerminationRepayment', component.get('v.lstTerminationRepayment'));
		var startDateLess = false;
		var endDateLess = false;
        if(component.get('v.hasTerminationFee') && newAmdOpportunity.Payment_Type_WF__c=='Installments, as follows' &&  newAmdOpportunity.Installment_Frequency_WF__c=='Other'){
            var lstTermRepayment = component.get('v.lstTerminationRepayment');            
            for(var i=0 ; i<lstTermRepayment.length ; i++){
                if(lstTermRepayment[i].Repayment_Amount_WF__c == null || lstTermRepayment[i].StartDate_WF__c == null || lstTermRepayment[i].EndDate_WF__c == null){
                    boolTermRepaymentEmpty = true;
                }
				if(lstTermRepayment[i].StartDate_WF__c >= lstTermRepayment[i].EndDate_WF__c){
					endDateLess = true;
				}
				if(i != 0 && lstTermRepayment[i-1].EndDate_WF__c >= lstTermRepayment[i].StartDate_WF__c){
					startDateLess = true;
				}
            }
            if(lstTermRepayment.length==0){
                boolTermRepaymentEmpty = true;
            }
        }
        if(boolTermRepaymentEmpty){
            $A.util.removeClass(component.find("tableEmptyErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("tableEmptyErrorId"), 'slds-hide');
        }
		if(endDateLess){
            $A.util.removeClass(component.find("endDateLessErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("endDateLessErrorId"), 'slds-hide');
        }
		if(startDateLess){
            $A.util.removeClass(component.find("startDateLessErrorId"), 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(component.find("startDateLessErrorId"), 'slds-hide');
        }
        
        if(whoSectionError)	boolIsreqFiledEmpty = true;
        //Validation for Termination Repayment Table - END
        
        //Check and set the error flags for each section - START
        //Who Section
        if(whoSectionError || component.get('v.GI_whoSectionTempError') ||component.get('v.dbaCustomerId') == null || component.get('v.legalEntityId') == null || component.get('v.dealMakerId') == null){
            component.set("v.GI_whoSectionError", true);
        }else{
            component.set("v.GI_whoSectionError", false);
        }
        
        //Amendment Information section
        if(newAmdOpportunity.Termination_Effective_Date_WF__c==undefined || newAmdOpportunity.Termination_Effective_Date_WF__c=='' || newAmdOpportunity.Termination_Effective_Date_WF__c==null ||
           newAmdOpportunity.Termination_Fee_WF__c===undefined || newAmdOpportunity.Termination_Fee_WF__c==='' || newAmdOpportunity.Termination_Fee_WF__c===null ||
          (component.get('v.hasTerminationFee')&&(newAmdOpportunity.Payment_Type_WF__c==undefined || newAmdOpportunity.Payment_Type_WF__c=='' || newAmdOpportunity.Payment_Type_WF__c==null))||
          (component.get('v.hasTerminationFee')&&(newAmdOpportunity.Payment_Type_WF__c=='Installments, as follows' &&  newAmdOpportunity.Installment_Frequency_WF__c=='Other' && (boolTermRepaymentEmpty || endDateLess || startDateLess)))||
           (newAmdOpportunity.Tenant_Resp_Unbilled_Reconcilliations_WF__c && (newAmdOpportunity.Reconcilitations_Applies_To_WF__c=='' || boolIsRepLenErr ||newAmdOpportunity.Reconcilitations_Applies_To_WF__c==null))){
            component.set("v.GI_amendmentInfoSectionError", true);
        }else{
            component.set("v.GI_amendmentInfoSectionError", false);
        }
        
        //Send Documents To section
        if(newAmdOpportunity.Send_Docs_To_Phone_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Phone_WF__c=='' || newAmdOpportunity.Send_Docs_To_Phone_WF__c==null ||
          		newAmdOpportunity.Send_Docs_To_Email_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Email_WF__c=='' || newAmdOpportunity.Send_Docs_To_Email_WF__c==null ||
          		newAmdOpportunity.Send_Docs_To_Name_WF__c==undefined || newAmdOpportunity.Send_Docs_To_Name_WF__c=='' || newAmdOpportunity.Send_Docs_To_Name_WF__c==null||
          		newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c==undefined || boolIsSendDocNameError || boolIsSendDocEmailError ||newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c=='' || newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c==null){
            component.set("v.CO_sendDocsToError", true);
        }else{
            component.set("v.CO_sendDocsToError", false);
        }
        //Check and set the error flags for each section - END
        
        return boolIsreqFiledEmpty;
    },
    
    checkTerminationFeeHelper : function(component, event ) {
        var terminationFee = component.get('v.newAmdOpportunity.Termination_Fee_WF__c');
        var intTerminationFee = parseFloat(terminationFee);
        if(isNaN(intTerminationFee)){
            intTerminationFee = 0 ;
        }
        if(intTerminationFee!=0)
            component.set('v.hasTerminationFee',true);
        else
            component.set('v.hasTerminationFee',false);  
    },
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = result.objectList;
        var fieldNames = result.FieldList;
        for(var each in objNames){
            for(var eachField in fieldNames){
                if(!$A.util.isUndefinedOrNull(component.find(objNames[each] + fieldNames[eachField]))){
                    var optionVals = picklistMap[objNames[each] + fieldNames[eachField]];
                    if(!$A.util.isUndefinedOrNull(optionVals)){
                        component.find(objNames[each] + fieldNames[eachField]).setLocalValues(optionVals);
                    }
                }
            }
        }
    },
    validateCovenantTextField : function(component,event,helper){
        var whoSectionError = false;
        var amendmentError = false;
        var coTenancyError = false;
        var sdtoError = false;
        var commError = false;
        var result =component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        var boolIsError=false;
        var newAmdOpportunity = component.get('v.newAmdOpportunity');
        console.log('Inside Helper error flag val ',boolIsError);
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Conditions_of_Termination_WF__c'])&&!$A.util.isUndefinedOrNull(newAmdOpportunity.Conditions_of_Termination_WF__c)&& newAmdOpportunity.Conditions_of_Termination_WF__c.length > covenantTextFieldMap['Conditions_of_Termination_WF__c'])
             {
                 $A.util.removeClass(component.find("conditionsOfTerminationErrorId"), 'slds-hide');
                 coTenancyError=true;
                 boolIsError=true;
				 amendmentError = true;                 
             }
             else{
                 $A.util.addClass(component.find("conditionsOfTerminationErrorId"),'slds-hide');
             }
        
        var guarantorError = component.get('v.newAmdOpportunity.Guarantor_Comments_Amd_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Guarantor_Comments_Amd_WF__c'])&&!$A.util.isUndefinedOrNull(guarantorError)&& guarantorError.length > covenantTextFieldMap['Guarantor_Comments_Amd_WF__c'])
             {
                 //console.log('IF GUr value : ',guarantorError);
                 $A.util.removeClass(component.find("guarantorCommentsErrorId"),'slds-hide');
                 coTenancyError=true;
                 boolIsError=true;
                 whoSectionError = true;
             }
             else{
                 //console.log('else GUr value : ',guarantorError);
                 $A.util.addClass(component.find("guarantorCommentsErrorId"),'slds-hide');
             }
        
        var arError = component.get('v.newAmdOpportunity.How_will_AR_be_resolved_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['How_will_AR_be_resolved_WF__c'])&&!$A.util.isUndefinedOrNull(arError)&& arError.length > covenantTextFieldMap['How_will_AR_be_resolved_WF__c'])
             {
                 $A.util.removeClass(component.find("howWillARBeResolvedErrorId"),'slds-hide');
                 coTenancyError=true;
                  boolIsError=true;
                 amendmentError = true;
             }
             else{
                 $A.util.addClass(component.find("howWillARBeResolvedErrorId"),'slds-hide');
             }
        
        var secCommError = component.get('v.newAmdOpportunity.Security_Comments_Amd_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Security_Comments_Amd_WF__c'])&&!$A.util.isUndefinedOrNull(secCommError)&& secCommError.length > covenantTextFieldMap['Security_Comments_Amd_WF__c'])
             {
                 $A.util.removeClass(component.find("securityCommentsErrorId"),'slds-hide');
                 coTenancyError=true;
                 boolIsError=true;
				 whoSectionError = true;                
             }
             else{
                 $A.util.addClass(component.find("securityCommentsErrorId"),'slds-hide');
             }
        var replTenError = component.get('v.newAmdOpportunity.Replacement_Tenant_Name_WF__c');
		if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Replacement_Tenant_Name_WF__c'])&&!$A.util.isUndefinedOrNull(replTenError)&& replTenError.length > covenantTextFieldMap['Replacement_Tenant_Name_WF__c'])
         {
            $A.util.removeClass(component.find("replTenantNameErrorId"), 'slds-hide');
            boolIsError=true;
            amendmentError = true;
        }else{
            $A.util.addClass(component.find("replTenantNameErrorId"), 'slds-hide');
        }
        
        var mailAddError = component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Email_WF__c'])&&!$A.util.isUndefinedOrNull(mailAddError)&& mailAddError.length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            $A.util.removeClass(component.find("emailAddressLengthErrorId"),'slds-hide');
            boolIsError=true;
            sdtoError = true;                 
        }
        else{
            $A.util.addClass(component.find("emailAddressLengthErrorId"),'slds-hide');
        }
        
        var docPhoneError = component.get('v.newAmdOpportunity.Send_Docs_To_Phone_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])&&!$A.util.isUndefinedOrNull(docPhoneError)&& docPhoneError.length > covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])
        {
            $A.util.removeClass(component.find("phoneNoErrorId"),'slds-hide');
            boolIsError=true;
            sdtoError = true;
        }
        else{
            $A.util.addClass(component.find("phoneNoErrorId"),'slds-hide');
        }
        
        var nameError = component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Name_WF__c'])&&!$A.util.isUndefinedOrNull(nameError)&& nameError.length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {
            $A.util.removeClass(component.find("nameLengthErrorId"), 'slds-hide');
            boolIsError=true;
            sdtoError = true;
        }
        else{
            $A.util.addClass(component.find("nameLengthErrorId"), 'slds-hide');
        }
        
        var MailAddError = component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])&&!$A.util.isUndefinedOrNull(MailAddError)&& MailAddError.length > covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])
        {
            $A.util.removeClass(component.find("MailingAddressErrorId"), 'slds-hide');
            boolIsError=true;
            sdtoError = true;
        }
        else{
            $A.util.addClass(component.find("MailingAddressErrorId"), 'slds-hide');
        }
        
        if(!$A.util.isUndefinedOrNull(newAmdOpportunity.Comments_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Comments_WF__c'])
        && newAmdOpportunity.Comments_WF__c.length > covenantTextFieldMap['Comments_WF__c'])
      	{
          component.set("v.CommentsError", true);
          commError = true;
          boolIsError=true;
      	}
        else
        {
          component.set("v.CommentsError", false);
      	} 
    
     	if(!$A.util.isUndefinedOrNull(newAmdOpportunity.OtherReasonOpportunityDead_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        && newAmdOpportunity.OtherReasonOpportunityDead_WF__c.length > covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        {
          component.set("v.oppDeadCommsLenError", true);
          commError = true;
          boolIsError=true;
      	}
        else
        {
          component.set("v.oppDeadCommsLenError", false);
      	}
                
     	if(!$A.util.isUndefinedOrNull(newAmdOpportunity.HoldOtherReasonComment_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['HoldOtherReasonComment_WF__c'])
        && newAmdOpportunity.HoldOtherReasonComment_WF__c.length > covenantTextFieldMap['HoldOtherReasonComment_WF__c'])
        {
            component.set('v.holdCommsError', true);
            commError = true;
            boolIsError = true;
        }
        else
        {
            component.set('v.holdCommsError', false);
        } 
		component.set('v.GI_whoSectionTempError',whoSectionError);
        component.set('v.GI_amendmentInfoSectionError',amendmentError);
        component.set('v.CO_sendDocsToError',sdtoError);
        if(commError || component.set('v.CO_detailsTempError'))
        {
            component.set('v.CO_detailsError',true);
        }
        console.log('Inside Helper error flag val ',boolIsError);
        return boolIsError;
    }
})