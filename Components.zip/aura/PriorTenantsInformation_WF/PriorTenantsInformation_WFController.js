({
    doInit : function(component, event, helper) {
        console.log('select ---> ', component.get('v.selectedProducts'));        
        if(!component.get('v.isSplit')){
            helper.doInitHelper(component, event);
        }
    },    
    createRemainingGLA : function (component, event , helper){
        if(component.get('v.isSplit')){
            var remainingGLAProducts = [];
            var remainingGLAProduct;
            var createEmpty = JSON.parse(JSON.stringify(component.get('v.selectedProducts')));
            remainingGLAProducts = JSON.parse(JSON.stringify(component.get('v.remainingGLAProducts')));
            remainingGLAProduct = createEmpty[0];                      
            remainingGLAProduct.idProduct = "";
            remainingGLAProduct.unitNo = "";
            remainingGLAProduct.productType = "";
            remainingGLAProduct.GLA = '';
            remainingGLAProduct.tenantName = "";
            remainingGLAProduct.proposedGLA = '';
            remainingGLAProduct.remainingGLA = '';
            remainingGLAProducts.push(remainingGLAProduct);
            component.set('v.remainingGLAProducts',remainingGLAProducts);          
        }
    },
    addRemainingGLARows : function(cmp, eve, helper){
        var remainingGLAProducts = [];
        var remainingGLAProduct;
        var createEmpty1 = JSON.parse(JSON.stringify(cmp.get('v.selectedProducts')));
        remainingGLAProducts = JSON.parse(JSON.stringify(cmp.get('v.remainingGLAProducts')));
        remainingGLAProduct = createEmpty1[0];
        remainingGLAProduct.idProduct = "";
        remainingGLAProduct.selected = false;
        remainingGLAProduct.unitNo = "";
        remainingGLAProduct.productType = "";
        remainingGLAProduct.occupied = "";
        remainingGLAProduct.expirationDate = null;
        remainingGLAProduct.GLA = null;
        remainingGLAProduct.tenantName = "";
        remainingGLAProduct.proposedGLA = null;
        remainingGLAProduct.remainingGLA = null;
        remainingGLAProducts.push(remainingGLAProduct);
        cmp.set('v.remainingGLAProducts',remainingGLAProducts);
    },
    createUnitConfigs : function(component, event, helper){
         var strSelectedProducts = JSON.stringify(component.get('v.selectedProducts'));
        var selectedProducts = [];
        var remainingGLAProducts = [];
        var remainingGLAProductsNonEmpty = [];
        var errors = [];
        var errorBlankFields = '';
        var errorGLANotConsumed = '';
        var errorFillAllProposedGLAs = '';
        var errorProposedGLAZeroforRemainingUnits = '';
        remainingGLAProducts = JSON.parse(JSON.stringify(component.get('v.remainingGLAProducts')));
        selectedProducts = JSON.parse(JSON.stringify(component.get('v.selectedProducts')));
        var sumSelectedRemainingGLA = 0;
        var countNumberOfDealUnits = 0;
        for(i=0;i<selectedProducts.length;i++){
            sumSelectedRemainingGLA = sumSelectedRemainingGLA + selectedProducts[i].remainingGLA;
            if(selectedProducts[i].proposedGLA == null && errorFillAllProposedGLAs == ''){
                errorFillAllProposedGLAs = 'Please fill Proposed GLA for all selected units';
            }
            if(selectedProducts[i].selectedDealUnit == true){
                countNumberOfDealUnits = countNumberOfDealUnits + 1;
            }
        }
        if(errorFillAllProposedGLAs != ''){
        	errors.push(errorFillAllProposedGLAs);
        }
        
        var intCountnullfields;
        var sumRemainingGLA = 0;
        for(var i=0;i<remainingGLAProducts.length;i++){
            intCountnullfields = 0;
            if(remainingGLAProducts[i].unitNo == ""){                
                intCountnullfields = Number(intCountnullfields) + 1;
            }
            if(remainingGLAProducts[i].proposedGLA == null){                
                intCountnullfields = Number(intCountnullfields) + 1;
            }
            if(intCountnullfields>=0 && intCountnullfields<2){
                if(remainingGLAProducts[i].proposedGLA != null){
                	sumRemainingGLA = sumRemainingGLA + remainingGLAProducts[i].proposedGLA;
                }
                if(remainingGLAProducts[i].proposedGLA == 0 && errorProposedGLAZeroforRemainingUnits == ''){
                	errorProposedGLAZeroforRemainingUnits = 'Please enter non-zero values for proposed GLA in all units for remaining GLAs';
                }
                remainingGLAProductsNonEmpty.push(remainingGLAProducts[i]);
            }
            if(intCountnullfields>0 && intCountnullfields<2 && errorBlankFields == ''){
                errorBlankFields = 'Please fill all the fields of units to be created for Remaining GLA.';
            }
            
        }
        if(errorProposedGLAZeroforRemainingUnits != ''){
            errors.push(errorProposedGLAZeroforRemainingUnits);
        }
        if(errorBlankFields != ''){
        	errors.push(errorBlankFields);
        }
        
        if(sumSelectedRemainingGLA != sumRemainingGLA){
                errorGLANotConsumed = 'Please consume GLA for all selected units in Units for Remaining GLA.';
        }
        if(errorGLANotConsumed != ''){
        	errors.push(errorGLANotConsumed);
        }
        if(errors.length>0){
        	component.set('v.errors',errors);
        }
        else{
            var action = component.get('c.getUnitConfigs');
            action.setParams({
                "strSelectedProducts":strSelectedProducts,
                "strUnitsForRemainingGLAs":JSON.stringify(remainingGLAProductsNonEmpty),
                "boolIsMerge":Boolean(component.get('v.boolIsMerge'))
            });
            action.setCallback(this, function(response){
                var result;
                var state = response.getState();
                
                if( state == 'SUCCESS'){
                    result = response.getReturnValue();                    
                    component.set('v.unitConfig',result);                    
                    component.set('v.showProductsPopup','false');
                    component.set('v.errors',[]);
                    component.set('v.errors',[]);
                    
                    
                }
                
            });
            $A.enqueueAction(action);
        }
        var selectedPro = component.get('v.selectedProducts');
        for(var i = 0; i< selectedPro.length; i++){
            console.log('str str--> ',selectedPro[i].proposedGLA);
            console.log('str str--> ',selectedPro[i].unitNo);
            component.set('v.GLAUsed', selectedPro[i].proposedGLA);
            component.set('v.strProducts',selectedPro[i].dealUnitNumber);
        }
    },
    closeTenantInfoPopup : function(component, event, helper) {
        
        var isSplit = component.get('v.isSplit');        
        if(isSplit){
            component.set('v.showPriorTenantInfoPopup', 'false');      
            component.set('v.showProductsPopup', 'false');                    
        }
        else{            
            component.set('v.showPriorTenantInfoPopup', 'false');        
        }        
    },
    populateRemainingGLA : function(cmp, eve, helper){
        var selectedProducts = [];
        var obj = JSON.parse(JSON.stringify(cmp.get('v.selectedProducts')));
        var hasAllRowsPopulated = true;
        var totalProposedGLA = 0;
        var totalGLA = 0;
        
        for(var i=0;i<obj.length;i++){            
            if(obj[i].proposedGLA != null){
                obj[i].remainingGLA = obj[i].GLA - obj[i].proposedGLA;
                totalProposedGLA = totalProposedGLA + obj[i].proposedGLA;
                totalGLA = totalGLA + obj[i].GLA;
            }
            if(obj[i].proposedGLA == null){
                hasAllRowsPopulated = false;
            }
        }
        if(hasAllRowsPopulated == true){
            cmp.set('v.intTotalGLA',totalGLA);
            cmp.set('v.intGLAUsed',totalProposedGLA);
            cmp.set('v.totalProposedGLA',totalProposedGLA);
        }
        cmp.set('v.selectedProducts',obj);        
    },
})