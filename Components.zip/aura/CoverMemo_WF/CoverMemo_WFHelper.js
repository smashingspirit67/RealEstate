({
	fetchData: function(component) {
		var oppId = component.get("v.opportunityId");
		var action = component.get("c.fetchDetails");
        action.setParams({
            "oppId": oppId
        });
    	action.setCallback(this, function(response){
	        var state = response.getState();
	        if (component.isValid() && state === "SUCCESS") {
	            component.set("v.details", response.getReturnValue());
	        } else {
	        	component.set("v.messages", [{"message":"Error retrieving data for cover memo", "severity":"error"}]);
	        }
    	});
    	$A.enqueueAction(action);
	},

	saveData: function(component) {
		var opp = component.get("v.details.opp");
		var action = component.get("c.saveOpportunity");
        action.setParams({
            "opp": opp
        });
        action.setCallback(this, function(response){
	        var state = response.getState();
	        if (component.isValid() && state === "SUCCESS") {
            	component.set("v.messages", response.getReturnValue());
            	component.set("v.details.isBeingEdited", false);
                component.set("v.isApprvrCmntEditable",false);
	        } else {
	        	component.set("v.messages", [{"message":"Error saving data for cover memo", "severity":"error"}]);
	        }
    	});
    	$A.enqueueAction(action);
		
	}
})