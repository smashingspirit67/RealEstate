({
	handleInit: function(component, event, helper) {
		helper.fetchData(component);
	},

	handleEdit: function(component, event, helper) {
		if(component.get("v.details.isApproveCmntsEditable"))
        {
            component.set("v.isApprvrCmntEditable",true);
        }else{
			component.set("v.details.isBeingEdited", true);
        }
	},

	handleSave: function(component, event, helper) {
		helper.saveData(component);
	}
})