({
    getTasks : function(component) {
        var action = component.get("c.getSubTaskList");
        action.setParams({
            "recordLimit": component.get("v.initialRows"),
            "recordOffset": component.get("v.rowNumberOffset"),
            "TaskId": component.get("v.taskRecordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS" ) {
                var resultData = response.getReturnValue();
                component.set("v.data", resultData);
                component.set("v.currentCount", component.get("v.initialRows"));
                
            }
        });
        $A.enqueueAction(action);
    },
    getTotalNumberOfTasks : function(component) {
        var action = component.get("c.getTotalSubTasks");
        action.setParams({
            "TaskId": component.get("v.taskRecordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS" ) {
                var resultData = response.getReturnValue();
                component.set("v.totalNumberOfRows", resultData);
            }
        });
        $A.enqueueAction(action);
    },
     
    getColumnAndAction : function(component) {
        var actions = [
            //{label: 'New', name: 'new'},
            {label: 'Edit', name: 'edit'},
            {label: 'Delete', name: 'delete'},
            {label: 'View', name: 'view'}
        ];
        component.set('v.columns', [
            {label: 'Subject', fieldName: 'Subject', type: 'text', sortable:true},
            {label: 'Description', fieldName: 'Description', type: 'text', sortable:true},
            {label: 'Status', fieldName: 'Status', type: 'text', sortable:true},
            {label: 'Due Date', fieldName: 'ActivityDate', type: 'Date', sortable:true},
            {type: 'action', typeAttributes: { rowActions: actions } } 
        ]);
    },
     
    getMoreTasks: function(component , rows){
        return new Promise($A.getCallback(function(resolve, reject) {
            var action = component.get('c.getTaskList');
            var recordOffset = component.get("v.currentCount");
            var recordLimit = component.get("v.initialRows");
            action.setParams({
                "recordLimit": recordLimit,
                "recordOffset": recordOffset,
                "TaskId": component.get("v.recordId")
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if(state === "SUCCESS"){
                    var resultData = response.getReturnValue();
                    resolve(resultData);
                    recordOffset = recordOffset+recordLimit;
                    component.set("v.currentCount", recordOffset);   
                }                
            });
            $A.enqueueAction(action);
        }));
    },
     
    sortData: function (component, fieldName, sortDirection) {
        var data = component.get("v.data");
        var reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse))
        component.set("v.data", data);
    },
     
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
        function(x) {return x[field]};
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
     
    viewTaskRecord : function(component, event) {
        var row = event.getParam('row');
        var recordId = row.Id;
        var navEvt = $A.get("event.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recordId,
            "slideDevName": "detail"
        });
        navEvt.fire();
    },
     
    deleteTaskRecord : function(component, event) {
        var action = event.getParam('action');
        var row = event.getParam('row');
         
        var action = component.get("c.deleteTask");
        action.setParams({
            "tsk": row
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS" ) {
                var rows = component.get('v.data');
                var rowIndex = rows.indexOf(row);
                rows.splice(rowIndex, 1);
                component.set('v.data', rows);
                 
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been deleted successfully."
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
     
    editTaskRecord : function(component, event) {
        var row = event.getParam('row');
        var recordId = row.Id;
        var editRecordEvent = $A.get("e.force:editRecord");
        editRecordEvent.setParams({
            "recordId": recordId
        });
        editRecordEvent.fire();
    },
     createTaskRecord : function (component, event) {        
        
        var action = component.get("c.saveTask");
        action.setParams({
            "task": component.get("v.newTask")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log(state);
            if (state === "SUCCESS" ) {
             var toastEvent = $A.get("e.force:showToast");
       		
             toastEvent.setParams({
             title : 'Success',
             message: 'Task Created Successfully',
             messageTemplate: 'Template',
             duration:' 5000',
             key: 'alt',
             type: 'success',   // success/Warning/Error
             mode: 'sticky'    // pester/sticky
             });
            }
        	toastEvent.fire(); 
            //Calling to show the new task and updated record count
            this.getTasks(component);
            this.getTotalNumberOfTasks(component);
            component.set("v.createTask","false");
                
            
        });
        $A.enqueueAction(action);
    },
    
    fetchPickListVal: function(component, fieldName, elementId) {
        var action = component.get("c.getselectOptions");
        action.setParams({
            "objObject": component.get("v.newTask"),
            "fld": fieldName
        });
        var opts = [];
        action.setCallback(this, function(response) {
           
            if (response.getState() == "SUCCESS") {
                var allValues = response.getReturnValue();
 				if (allValues != undefined && allValues.length > 0) {
                    opts.push({
                        class: "optionClass",
                        label: "--- None ---",
                        value: ""
                    });
                }
                for (var i = 0; i < allValues.length; i++) {
                    opts.push({
                        class: "optionClass",
                        label: allValues[i],
                        value: allValues[i]
                    });
                }
                component.find(elementId).set("v.options", opts);
            }
        });
        $A.enqueueAction(action);
    },
    viewptaskRecord : function() {
      
        window.history.back();
        /*var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
          "url": "https://leasemanagement-dev-ed.lightning.force.com/lightning/r/Opportunity/0060b00000ngYsxAAE/view"
        });
        urlEvent.fire();*/
    
            /*var url = window.location.href; 
            console.log(url);
            var value = url.substr(0,url.lastIndexOf('/') + 1);
            value= value;
            console.log(value);
            //window.open(value, '_self');
            return false;
*/
    
   }
 })