({
    enforceFormat: function(component, event, helper){
        if(component.get('v.country').includes('United States')){
            helper.enforceGeneral(component); 
        }
    }, 
    displayAnyErrors: function(component, event, helper){
        var sendError=component.find("badPhoneNumber");
        if(component.get('v.hasError')){
			$A.util.removeClass(sendError, 'slds-hide');
        }else{
            $A.util.addClass(sendError, 'slds-hide');
        }
    }
})