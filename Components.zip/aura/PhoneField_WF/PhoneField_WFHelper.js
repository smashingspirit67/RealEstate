({
	isNumber : function(testIt){
		return (testIt>-1 && testIt<10 && testIt!=' '); 
	},
	enforceGeneral : function(component) {
		var value=component.get('v.value');
        if($A.util.isEmpty(value)){
            component.set('v.hasError',false);
			return; 
        }
		var stagger=0; 
		if(value.charAt(0)=='+'){
			stagger++; 
		}
		var error=false; 
		for(var i=stagger;i<value.length;i++){
			if(!this.isNumber(value.charAt(i))){
                component.set('v.hasError',true);
                error=true; 
            }
		}
		if(!error){
            component.set('v.hasError',false);
		}
	},
	enforceFormatUS : function(component) {
        component.set('v.hasError', true);
        var value=component.get('v.value'); 
        var rawValue=''; 
        
        for(var i=0;i<value.length;i++){
            if(value.charAt(i)>-1 && value.charAt(i)<10 && value.charAt(i)!=' '){
                rawValue+=value.charAt(i);
            }
        }
        var backupValue=component.get('v.backupValue');
        if(value.length-backupValue.length==1&&value.charAt(value.length-1)>-1 && value.charAt(value.length-1)<10 && value.charAt(value.length-1)!=' '){
			return; 
        }
        for(var i=value.length;i<backupValue.length;i++){
            var value=backupValue.charAt(i);
        }
        if(rawValue.length<3){
            var error = component.find("longPhoneNumber");
        	$A.util.addClass(error, 'slds-hide');
            component.set('v.value',rawValue);
            component.set('v.backupValue',rawValue);
			return; 
        }
        if(rawValue.length==3){
            var error = component.find("longPhoneNumber");
        	$A.util.addClass(error, 'slds-hide');
			component.set('v.value', '('+rawValue+')');
            component.set('v.backupValue',rawValue);
            return; 
        }
        if(rawValue.length<=6){
            var error = component.find("longPhoneNumber");
        	$A.util.addClass(error, 'slds-hide');
            var areaCode=rawValue.substring(0,3); 
            var theRest=rawValue.substring(3,rawValue.length); 
            component.set('v.value', '('+areaCode+') '+theRest);
            component.set('v.backupValue',rawValue);
            return; 
        }
        if(rawValue.length<10){
            //(123) 456-789
            var error = component.find("longPhoneNumber");
        	$A.util.addClass(error, 'slds-hide');
            var areaCode=rawValue.substring(0,3); 
            var firstThree=rawValue.substring(3,6); 
            var theRest=rawValue.substring(6,rawValue.length); 
            component.set('v.value', '('+areaCode+') '+firstThree+'-'+theRest);
            component.set('v.backupValue',rawValue);
            return; 
        }
        if(rawValue.length<11){
            //(123) 456-7890
            var error = component.find("longPhoneNumber");
        	$A.util.addClass(error, 'slds-hide');
            var areaCode=rawValue.substring(0,3); 
            var firstThree=rawValue.substring(3,6); 
            var theRest=rawValue.substring(6,rawValue.length); 
            component.set('v.hasError', false);
            component.set('v.value', '('+areaCode+') '+firstThree+'-'+theRest);
            component.set('v.backupValue',rawValue);
            return; 
        }
		var error = component.find("longPhoneNumber");
        $A.util.removeClass(error, 'slds-hide');
	}
})