({
    
    cancelHelper : function(component, event){
        component.set("v.hidePopout",false);	
        var newUnitArray = component.get('v.newProductDetails');
        if(newUnitArray.length > 0){
            var newUnits = JSON.parse(JSON.stringify(component.get('v.newProductDetails'))); 
            console.log('newUnits++',newUnits); 
        }    
    },
    saveProductHelper : function(component, event){
        var timezone = $A.get("$Locale.timezone");
        console.log('Time Zone Preference in Salesforce ORG :'+timezone);
        var mydate = new Date().toLocaleString("en-US", {timeZone: timezone});        
        component.set('v.newButtonName','Edit Unit');                                
        component.set('v.windowName','Edit Unit');                                
        var newUnits =[];
        var centerId = component.get("v.center");
        var buId = component.get("v.BusinessUnit.Id");
        var businessUnitName = component.get('v.BusinessUnit.Name');        
        // var comments = component.get('v.strComments');
        
        newUnits = JSON.parse(JSON.stringify(component.get('v.newProductDetails')));
        console.log('++newUnits+++',newUnits);
        if(newUnits.length > 0){
            var objNewUnitDetails = newUnits[0];
            objNewUnitDetails.idCenter = centerId;
            objNewUnitDetails.BusinessUnitId = buId;
            
            objNewUnitDetails.BusinessUnitName = businessUnitName;
            objNewUnitDetails.productStartDate = mydate;
            objNewUnitDetails.virVacancy = "1-Vacant";
            objNewUnitDetails.newUnit = true;
            objNewUnitDetails.isActive = true;
            component.set('v.newProductDetails', objNewUnitDetails);   
            var action = component.get("c.validateProposedUnitName_Validation_forNewUnit");
            action.setParams({
                "productDetails" : JSON.stringify(component.get('v.newProductDetails'))               
            });
            
            action.setCallback(this, function(response){
                var result;
                var state = response.getState();
                if( state == 'SUCCESS'){
                    result = response.getReturnValue();
                    console.log('++result++',result);
                    if(!$A.util.isUndefinedOrNull(result)){
                        if(result)
                            component.set('v.duplicateProductNameExists', true);
                        else{
                            component.set('v.duplicateProductNameExists', false);
                            component.set("v.isNewUnit", true);
                            component.set('v.reconfigBool', false);
                            component.set("v.hidePopout",false);    
                            var newUnitWrapper = component.get('v.newProductDetails');
                            if(!$A.util.isUndefinedOrNull(newUnitWrapper)){
                                if(newUnitWrapper.length > 0){
                                    component.set('v.proposedGLA', newUnitWrapper[0].proposedGLA);
                                    component.set('v.proposedUnitNumber', newUnitWrapper[0].unitNo);                                
                                    component.set('v.strProducts', newUnitWrapper[0].unitNo);  
                                    component.set('v.intGLAUsed', newUnitWrapper[0].proposedGLA);
                                    component.set('v.obj.AmendmentProposedUnitNumber_WF__c', newUnitWrapper[0].proposedGLA);                                                
                                    component.set('v.obj.AmendmentGLAUsed_WF__c', newUnitWrapper[0].unitNo);                                    
                                }
                            }
                            
                        }
                        
                    }
                    
                }    
            });
            $A.enqueueAction(action);    
            
        }
    },    
    
    checkRequiredFields : function(component, event){
        
        var boolIsRequired = true;
        var newProductDetails = component.get('v.newProductDetails');
        var businessUnit = component.get('v.BusinessUnitId');
        
        if(!$A.util.isUndefinedOrNull(newProductDetails)){
            if(newProductDetails[0].unitNo == '' || newProductDetails[0].unitNo == null || newProductDetails[0].unitNo == undefined){
                boolIsRequired = false;
                $A.util.removeClass(component.find('proposedUnitErrorId'), 'slds-hide');               
            }else{
                $A.util.addClass(component.find('proposedUnitErrorId'), 'slds-hide');               
            }
            
            if(newProductDetails[0].proposedGLA == '' || newProductDetails[0].proposedGLA == null || newProductDetails[0].proposedGLA == undefined){
                boolIsRequired = false;
                $A.util.removeClass(component.find('proposedGLAErrorId'), 'slds-hide');               
            }else{
                $A.util.addClass(component.find('proposedGLAErrorId'), 'slds-hide');               
                //GDM-7877 to add a validation to chek proposed GLA should not have any Numbers
                console.log('++is Number Check+ ',isNaN(newProductDetails[0].proposedGLA));
                if(isNaN(newProductDetails[0].proposedGLA)){
                    boolIsRequired = false;
                    $A.util.removeClass(component.find('proposedGLANameError'), 'slds-hide');
                }else{
                    $A.util.addClass(component.find('proposedGLANameError'), 'slds-hide');             
                }   
            }
            
            if(!$A.util.isUndefinedOrNull(newProductDetails[0].unitNo) && newProductDetails[0].unitNo.indexOf(' ') >= 0){
                boolIsRequired = false;
                $A.util.removeClass(component.find('proposedUnitSpaceErrorId'), 'slds-hide');               
            }else{
                $A.util.addClass(component.find('proposedUnitSpaceErrorId'), 'slds-hide');               
            }
            
            //Center validation
            if($A.util.isUndefinedOrNull(businessUnit)){
                $A.util.removeClass(component.find('businessUnitErrorId'), 'slds-hide');
                boolIsRequired = false;
            }
            else{
                $A.util.addClass(component.find('businessUnitErrorId'), 'slds-hide');
            }
            
            //Floor Validation
            if($A.util.isUndefinedOrNull(newProductDetails[0].floor) || $A.util.isEmpty(newProductDetails[0].floor)){
                boolIsRequired = false;
                $A.util.removeClass(component.find('FloorErrorId'), 'slds-hide');               
            }else{
                $A.util.addClass(component.find('FloorErrorId'), 'slds-hide');               
            }
            
            if($A.util.isUndefinedOrNull(newProductDetails[0].unitType) || $A.util.isEmpty(newProductDetails[0].unitType)){
                boolIsRequired = false;
                $A.util.removeClass(component.find('unitTypeErrorId'), 'slds-hide');               
            }else{
                $A.util.addClass(component.find('unitTypeErrorId'), 'slds-hide');               
            }
            
            //Building number validation
            if(component.get('v.isAirportDealCheck')){
                if($A.util.isUndefinedOrNull(newProductDetails[0].buildingNumber) || $A.util.isEmpty(newProductDetails[0].buildingNumber)){
                    $A.util.removeClass(component.find('buildingNoMissing'), 'slds-hide');
                    boolIsRequired = false;
                }
                else{
                    $A.util.addClass(component.find('buildingNoMissing'), 'slds-hide');
                }
            }
            if($A.util.isUndefinedOrNull(newProductDetails[0].comments)  ||  $A.util.isEmpty(newProductDetails[0].comments))
            {
                $A.util.removeClass(component.find('commentEmptyId'), 'slds-hide');   
                boolIsRequired = false;
            }
            else
            {
                $A.util.addClass(component.find('commentEmptyId'), 'slds-hide'); 
             }
        }
        return boolIsRequired;
    },
    getNewUnitDetails : function(component){
        
        var queriedUnitData = component.get('v.newProductDetails');
        if(!$A.util.isUndefinedOrNull(queriedUnitData)){
            console.log('++++v.queriedUnitData+++',queriedUnitData);
            if(queriedUnitData.length > 0){
                console.log('+++queriedUnitData.unitNo++',queriedUnitData[0].unitNo);
                if(!$A.util.isUndefinedOrNull(queriedUnitData[0].unitNo))
                    component.set('v.getUnitInfoDetailsCheck',true);
            }
        }
        if(!component.get('v.getUnitInfoDetailsCheck')){
            var action = component.get('c.getNewUnitDetails');
            action.setParams({ 
                "opptyId" : component.get('v.opportunityId'), 
                "centerId"  : component.get("v.center")
            });    
            action.setCallback(this, function(response){
                if(response.getReturnValue() != null){
                    var createdUnit = response.getReturnValue();
                    if(!$A.util.isUndefinedOrNull(createdUnit)){
                        if(createdUnit.length > 0){
                            component.set('v.newButtonName','Edit Unit');                                
                            component.set('v.windowName','Edit Unit');                                
                            console.log('+++Newly Created Unit Details',createdUnit[0]);                        	           
                            component.set('v.BusinessUnit',createdUnit[0].BusinessUnit);
                            component.set('v.BusinessUnitId',createdUnit[0].BusinessUnitId);
                            component.set('v.newProductDetails', createdUnit); 
                        }else{
                            component.set('v.newButtonName','Create New Unit');                                 
                        }    
                    }
                }
            });
            $A.enqueueAction(action);
        }    
    },
    accessSaveandDraftHelper:function(component)
    {
        
        var action = component.get('c.saveAndDraftAccess');
        console.log('newProductDetails +++',component.get('v.newProductDetails'));
        var newUnitArray = component.get('v.newProductDetails');
        if(newUnitArray.length > 0){
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var newUnits = JSON.parse(JSON.stringify(component.get('v.newProductDetails'))); 
                    component.set("v.accessSaveandDraft", response.getReturnValue());
                    //component.set('v.newButtonName','Edit Unit');                                
                    //component.set('v.windowName','Edit Unit');  
                    component.set('v.strCreateTasks','true');
                    if(!$A.util.isUndefinedOrNull(newUnits[0].unitType) && newUnits[0].unitType == $A.get("$Label.c.StorageLeasing_WF"))
                    {
                        component.set('v.strCreateTaskA3','true');
                    }
                } else {
                    component.set("v.messages", [{"message":"Error retrieving roles for user", "severity":"error"}]);
                }
            });
            $A.enqueueAction(action);
        }    
    },
    accessSaveandValidateHelper:function(component)
    {
        var action = component.get('c.saveAndValidateAccess');
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                console.log("AaccessSaveandValidate,.....",response.getReturnValue());
                component.set("v.accessSaveandValidate", response.getReturnValue());
                //component.set('v.newButtonName','Edit Unit');                                
                //component.set('v.windowName','Edit Unit');                                
            } else {
                component.set("v.messages", [{"message":"Error retrieving roles for user", "severity":"error"}]);
            }
        });
        $A.enqueueAction(action);
    }
})