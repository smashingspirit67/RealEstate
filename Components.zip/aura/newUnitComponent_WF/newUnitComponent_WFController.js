({
    doInit : function(component, event, helper) {
        helper.accessSaveandDraftHelper(component); 
        helper.accessSaveandValidateHelper(component);   
        var fetchPickList = $A.get("e.c:fetchPicklist");
        console.log('+++opportunityId++ ',component.get('v.opportunityId'));
        var oppId = component.get('v.opportunityId');
        if(!$A.util.isUndefinedOrNull(oppId)){
            helper.getNewUnitDetails(component);
        }
        fetchPickList.fire(); 		        
    },
    handleCancel : function(component, event, helper){
        helper.cancelHelper(component, event);
    },
    saveProduct : function(component, event, helper){
        if(helper.checkRequiredFields(component,event)){
            component.set('v.saveAndValidateClicked',true);
            helper.saveProductHelper(component, event);    
        }
    },
    saveProductandCreatetask:function(component,event,helper)
    {
        var newProductDetails = component.get('v.newProductDetails');   
        if(helper.checkRequiredFields(component,event)){
            component.set('v.strCreateTasks','true');
            if(!$A.util.isUndefinedOrNull(newProductDetails[0].unitType) && newProductDetails[0].unitType == $A.get("$Label.c.StorageLeasing_WF"))
            {
                component.set('v.strCreateTaskA3','true');
            }
            component.set('v.saveAsDraftClicked',true);
            component.set('v.saveAndValidateClicked',false);
            helper.saveProductHelper(component, event);    
        }
    }
    
})