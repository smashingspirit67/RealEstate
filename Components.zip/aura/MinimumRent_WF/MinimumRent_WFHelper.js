({

    updateAmdTypes : function(weaAmdTypes, cmp) {
        if (typeof(weaAmdTypes) == "undefined" || weaAmdTypes == null ) return;
        cmp.set("v.isExtension", weaAmdTypes.includes("Extension"));
        cmp.set("v.isReloReconfig", weaAmdTypes.includes("Relo/Reconfig"));
        cmp.set("v.isOther", weaAmdTypes.includes("Other"));
    }
    
})