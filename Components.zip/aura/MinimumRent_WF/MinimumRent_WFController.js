({
    
    handleAmdTypesChange : function(component, event, helper) {
        var newValue = event.getParam("value");
        if( (typeof newValue === "object") && (newValue !== null) && newValue.WeaAmdType_2_WF__c) {
            helper.updateAmdTypes(newValue.WeaAmdType_2_WF__c, component);
        } else if (typeof newValue === "string") {
            helper.updateAmdTypes(newValue, component);
        }
    },
    updateCheckbox : function(cmp, eve){        
        var isMin = cmp.get('v.IsMinimumRent');
        var opp = cmp.get('v.opportunity');   
        if(cmp.get("v.IsOptions") !== true){
            opp.IsMinimumRent_WF__c = isMin;
            if(!isMin){
                cmp.set('v.opportunity.BreakpointStepType_WF__c', '--None--');
                cmp.set('v.opportunity.PercentRentRate_WF__c', '--None--');
            }
            if(isMin){
                if(cmp.get('v.isRenewals')){
                    cmp.find('cmp1').handleMinimumRentChange(isMin);
                }else
                    cmp.find('cmp2').handleMinimumRentChange(isMin);    
            }
            
        }else{
            opp.IsOptionsMinimumRent_WF__c = isMin;
            if(!isMin){
                cmp.set('v.opportunity.OptionsBreakpointStepType_WF__c', '--None--');
                cmp.set('v.opportunity.OptionsPercentRentRate_WF__c', '--None--');
            }
            if(isMin){
                if(cmp.get('v.isRenewals')){
                    cmp.find('cmp3').handleMinimumRentChange(isMin);
                }else
                    cmp.find('cmp4').handleMinimumRentChange(isMin);    
            }
            
        }
        
        cmp.set('v.opportunity', opp);
        var isOptions = cmp.get('v.IsOptions');
		var isRenewals = cmp.get('v.isRenewals');
        if(isMin && !isRenewals && !isOptions){
	        cmp.set('v.opportunity.SubjecttoRentStabilization_WF__c', true);
            if($A.util.isUndefinedOrNull(cmp.get('v.opportunity.Rent_Stabilization_Comments_WF__c')) || cmp.get('v.opportunity.Rent_Stabilization_Comments_WF__c') == ''){
	        	cmp.set('v.opportunity.Rent_Stabilization_Comments_WF__c', $A.get("$Label.c.Stabilization_Comments_Default"));   
            }
        } 
		//GDM-8394 : Author Sachin - Commented as part of this ticket fix.
		/*else if(!isMin) {
        	cmp.set('v.opportunity.SubjecttoRentStabilization_WF__c', false);
	        cmp.set('v.opportunity.Rent_Stabilization_Comments_WF__c', '');
        }*/
        

    }
    
})