({
	saveAddressHelper : function(component, helper){
		var addressRec = component.get("v.addressRec");
		var delim = ';';
		var dDelim = ', ';
        var allValuesList = [];
        var nonBlankValuesList = [];
        //var fields = ['StreetLine1_WF__c', 'StreetLine2_WF__c', 'StreetLine3_WF__c', 'City_WF__c', 'State_WF__c', 'PostalCode_WF__c', 'Country_WF__c'];
        //var reqFields = ['StreetLine1_WF__c', 'City_WF__c', 'PostalCode_WF__c', 'Country_WF__c'];
        for(var i = 0; i < fields.length; i++){
            if(addressRec[fields[i]] === undefined || addressRec[fields[i]] === null || addressRec[fields[i]] === ''){
                allValuesList.push('');
            } else{
                allValuesList.push(addressRec[fields[i]]);
                nonBlankValuesList.push(addressRec[fields[i]]);
            }
        }
        
        var showErrors = false;
        if(component.get("v.required")){
            for(var i = 0; i < reqFields.length; i++){
                if($A.util.isUndefinedOrNull(addressRec[reqFields[i]]) || addressRec[reqFields[i]] === ''){
                    addressRec[reqFields[i]] = '';
                    showErrors = true;
                }
            }
            if(($A.util.isUndefinedOrNull(addressRec.State_WF__c) || addressRec.State_WF__c === '') && !component.get("v.noState")){
                showErrors = true;
            }
            component.set('v.showError', showErrors);
        }
        if(!showErrors){
            component.set("v.returnText", allValuesList.join(";"));
        	component.set("v.displayValue", nonBlankValuesList.join(", "));
            helper.hideModalHelper(component);
        }
	}, 
	hideModalHelper : function(component) {
		component.set("v.showPopup", false);
	}
})