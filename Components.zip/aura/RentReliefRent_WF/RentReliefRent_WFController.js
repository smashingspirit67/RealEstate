({
	doInit : function(component, event, helper) {
		console.log('Testing Rent',component.get('v.Rent'));
		
		if(component.get('v.Rent.minRent') != null){
			var lstMinRent = component.get('v.Rent.minRent');
			component.set('v.noOfMinRent', lstMinRent.length);
			for(var item in lstMinRent){
				lstMinRent[item].RecordTypeId = component.get('v.Rent.rentTableRecordType')['Rent Relief Min Rent']; 
			}
		}

		if(component.get('v.Rent.perRent') != null){
			var lstPerRent = component.get('v.Rent.perRent');
			component.set('v.noOfPerRent', lstPerRent.length);
			for(var item in lstPerRent){
				lstPerRent[item].RecordTypeId = component.get('v.Rent.rentTableRecordType')['Rent Relief Percent Rent'];
				if(component.get('v.parentObj') == 'Lease_WF__c'){
					lstPerRent[item].RentRate_WF__c = lstPerRent[item].RentRate_WF__c/100;
				}
			}
			//TODO: this is not going to work given the re-use of the percent rent for 2 sections
			component.set('v.noOfBreakPointRent', lstPerRent.length);
		}
	},

	addMinRent: function(component, event){
        var objMinRent = {};    
        var lstMinRent = component.get('v.Rent.minRent');

        //update min rent count
		component.set('v.noOfMinRent',component.get('v.noOfMinRent')+1);

        //setup min rent object
        objMinRent.Id = null;
        objMinRent.Name = "New Minimum Rent";
        objMinRent.RecordTypeId = component.get('v.Rent.rentTableRecordType')['Rent Relief Min Rent']; 
        //objMinRent.Lease_WF__c = component.get('v.Rent.minRent')[0].Lease_WF__c;
        objMinRent.AnnualizedRent_WF__c = 0.0;
        objMinRent.StartDate_WF__c = null;
        objMinRent.EndDate_WF__c = null;
        objMinRent.AnnualizedRentProposed_WF__c = 0.0;
        objMinRent.StartDateProposed_WF__c = null;
        objMinRent.EndDateProposed_WF__c = null;

        //push new object into list
        lstMinRent.push(objMinRent);

        //reset list
        component.set('v.Rent.minRent',lstMinRent);

	},

	deleteMinRent: function(component, event){
		if(component.get('v.noOfMinRent')>0){
			var lstMinRent = component.get('v.Rent.minRent');
	        //lstMinRent.pop();

	        var minRentToDelete = lstMinRent.pop();
	        if(!$A.util.isUndefinedOrNull(minRentToDelete.Id)){
	            var minRentToDeleteList = component.get('v.lstMinRentToDelete');
	            minRentToDeleteList.push(minRentToDelete.Id)
	            component.set('v.lstMinRentToDelete',minRentToDeleteList);
	            component.set('v.Rent.minRentToDelete',minRentToDeleteList);
	        }

	        //reset list
	        component.set('v.Rent.minRent',lstMinRent);

	        //update min rent count
	        component.set('v.noOfMinRent',component.get('v.noOfMinRent')-1);
		}
	},

	addPerRent: function(component, event){
		var objPerRent = {};    
        var lstPerRent = component.get('v.Rent.perRent');

        //update per rent count
		component.set('v.noOfPerRent',component.get('v.noOfPerRent')+1);

        //setup percent rent object
        objPerRent.Id = null;
        objPerRent.Name = "New Percent Rent";
        objPerRent.RecordTypeId = component.get('v.Rent.rentTableRecordType')['Rent Relief Percent Rent'];
        //objPerRent.Lease_WF__c = component.get('v.Rent.perRent')[0].Lease_WF__c; 
        objPerRent.BrkptCalcpercent_WF__c = 0.0;
        objPerRent.BreakpointAmount_WF__c = 0.0;
        objPerRent.StartDate_WF__c = null;
        objPerRent.EndDate_WF__c = null;
        objPerRent.RentRate_WF__c = 0.0;
        objPerRent.BrkptCalcpercentProposed_WF__c = 0.0;
        objPerRent.BreakpointAmountProposed_WF__c = 0.0;
        objPerRent.StartDateProposed_WF__c = null;
        objPerRent.EndDateProposed_WF__c = null;

        //push new object into list
        lstPerRent.push(objPerRent);

        //reset list
        component.set('v.Rent.perRent',lstPerRent);
	},

	deletePerRent: function(component, event){
		//remove from percent rent list
		if(component.get('v.noOfPerRent')>0){
			var lstPerRent = component.get('v.Rent.perRent');
	        //lstMinRent.pop();

	        var perRentToDelete = lstPerRent.pop();
	        if(!$A.util.isUndefinedOrNull(perRentToDelete.Id)){
	            var perRentToDeleteList = component.get('v.lstPercentRentToDelete');
	            perRentToDeleteList.push(perRentToDelete.Id)
	            component.set('v.lstMinRentToDelete',perRentToDeleteList);
	            component.set('v.Rent.perRentToDelete',perRentToDeleteList);
	        }

	        //reset list
	        component.set('v.Rent.perRent',lstPerRent);

	        //update per rent count
	        component.set('v.noOfPerRent',component.get('v.noOfPerRent')-1);
		}
	},

	addBreakPointRent: function(component, event){
		//TODO: add to breakpoint rent list....issue here with percent rent and breakpoint amount coming from the same table
	},

	deleteBreakPointRent: function(component, event){
		//TODO: remove from breakpoint rent list
	},
	nullifyBlankDatesMinRent: function(component, event){
		var lstRentTable = component.get('v.Rent.minRent');
		for(var item in lstRentTable){
			if(lstRentTable[item].StartDate_WF__c == ''){lstRentTable[item].StartDate_WF__c = null;}
			if(lstRentTable[item].EndDate_WF__c == ''){lstRentTable[item].EndDate_WF__c = null;}
			if(lstRentTable[item].StartDateProposed_WF__c == ''){lstRentTable[item].StartDateProposed_WF__c = null;}
			if(lstRentTable[item].EndDateProposed_WF__c == ''){lstRentTable[item].EndDateProposed_WF__c = null;}
		}
		component.set('v.Rent.minRent',lstRentTable);
	},
	nullifyBlankDatesPercentRent: function(component, event){
		var lstRentTable = component.get('v.Rent.perRent');
		for(var item in lstRentTable){
			if(lstRentTable[item].StartDate_WF__c == ''){lstRentTable[item].StartDate_WF__c = null;}
			if(lstRentTable[item].EndDate_WF__c == ''){lstRentTable[item].EndDate_WF__c = null;}
			if(lstRentTable[item].StartDateProposed_WF__c == ''){lstRentTable[item].StartDateProposed_WF__c = null;}
			if(lstRentTable[item].EndDateProposed_WF__c == ''){lstRentTable[item].EndDateProposed_WF__c = null;}
		}
		component.set('v.Rent.perRent',lstRentTable);
	},
})