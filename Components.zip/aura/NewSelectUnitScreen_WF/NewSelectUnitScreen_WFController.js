({
	doInit : function(component, event, helper) {
		var centerId = component.get('v.center');
        
	},
     closeProductsPopup : function(component, event, helper) {
        
        component.set('v.showProductsPopup', 'false');
       
    }
})