({
	doInitHelper : function(component) {
    	var idCenter = component.get('v.idCenter');
        component.set('v.addProduct', []);
    	var unitType = "";
    	var strInvType = "";
    	unitType = component.get('v.unitType');
    	strInvType = component.get('v.strInvType');
        console.log(idCenter);
        
        var action = component.get('c.getProductDetailforReconfig');
        action.setParams({
        	"strCenter":idCenter,
        	"strUnitType":unitType,
        	"strInvType":strInvType
        });
        action.setCallback(this, function(response){
        	var result;
            
        	var state = response.getState();            
            if( state == 'SUCCESS'){
                var productDetailsToShow = [];
                result = response.getReturnValue();
            	component.set('v.intPage', 1);
                component.set('v.intPages', (Math.ceil(result.length/10)));
                component.set('v.intTotal', result.length);
                if(result[0] != null)
                {
                	component.set('v.strcenterName',result[0].strCenter);
                }
               	var pageSize = 0;
                var j=0;
                if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
                    pageSize = Number(component.get('v.intPage'))*10;
                }
            	else{
                	pageSize = result.length-(Number(component.get('v.intPage'))-1)*10;
            	}
                for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
                    productDetailsToShow[j] = result[i];
                    j++;
                }
				for(var key in productDetailsToShow){
                	if(!$A.util.isUndefinedOrNull(productDetailsToShow[key].popoutGLA))
                    productDetailsToShow[key].popoutGLARounded = Math.round(productDetailsToShow[key].popoutGLA);
                    if(!$A.util.isUndefinedOrNull(productDetailsToShow[key].GLA))
                    productDetailsToShow[key].remainingGLARounded = Math.round(productDetailsToShow[key].GLA);
                    console.log('++++popoutGLA+++',productDetailsToShow[key].popoutGLA,'+++popoutGLARounded++',productDetailsToShow[key].popoutGLARounded,'++remainingGLARounded++',productDetailsToShow[key].remainingGLARounded,'+++Actual GLA++',productDetailsToShow[key].GLA);
                }
                for(var key in result){
                	if(!$A.util.isUndefinedOrNull(result[key].popoutGLA))
                    result[key].popoutGLARounded = Math.round(result[key].popoutGLA);
                    if(!$A.util.isUndefinedOrNull(result[key].GLA))
                    result[key].remainingGLARounded = Math.round(result[key].GLA);
                    console.log('++++popoutGLA+++',result[key].popoutGLA,'+++popoutGLARounded++',result[key].popoutGLARounded,'++remainingGLARounded++',result[key].remainingGLARounded,'+++Actual GLA++',result[key].GLA);
                }
				component.set('v.productDetailsToShow', productDetailsToShow);                
                component.set('v.productDetails', result);  
            }
            var hideSpinner = $A.get("e.c:hideSpinnerEvent_WF");
            if(!$A.util.isUndefinedOrNull(hideSpinner)){
                hideSpinner.fire(); 
            }
        });
        $A.enqueueAction(action);
    },
    previousPageHelper : function(component){
        if(Number(component.get('v.intPage')) > 1){	
    		component.set('v.intPage', Number(component.get('v.intPage'))-1);
        }
        var productDetails = [];
        productDetails = JSON.parse(JSON.stringify(component.get('v.productDetails')));
        console.log(productDetails);
        var productDetailsToShow = [];
        productDetailsToShow = JSON.parse(JSON.stringify(component.get('v.productDetailsToShow')));
        console.log(productDetailsToShow);
        for(var i=0;i<productDetailsToShow.length;i++){
            for(j=0;j<productDetails.length;j++){
                if(productDetailsToShow[i].unitNo == productDetails[j].unitNo){
                    productDetails[j] = productDetailsToShow[i];
                    break;
                }
            }
        }
        component.set('v.productDetails',productDetails);
        var j=0;
        var productDetailsToShow = [];
        var pageSize = 0;
        if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
        	pageSize = Number(component.get('v.intPage'))*10;
        }
        else{
        	//@Joshna - replaced result.length with v.intTotal
        	pageSize = component.get('v.intTotal')-(Number(component.get('v.intPage'))-1)*10;
        }
        for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
        	productDetailsToShow[j] = productDetails[i];
            j++;
        }
        component.set('v.productDetailsToShow', productDetailsToShow);
    },
    nextPageHelper : function(component){
        if(Number(component.get('v.intPage')) < Number(component.get('v.intPages'))){	
    		component.set('v.intPage', Number(component.get('v.intPage'))+1);
        }
        var productDetails = JSON.parse(JSON.stringify(component.get('v.productDetails')));
        var productDetailsToShow = JSON.parse(JSON.stringify(component.get('v.productDetailsToShow')));
        
        for(var i=0;i<productDetailsToShow.length;i++){
            for(j=0;j<productDetails.length;j++){
                if(productDetailsToShow[i].unitNo == productDetails[j].unitNo){
                    productDetails[j] = productDetailsToShow[i];
                    break;
                }
            }
        }
        console.log(productDetails.length);
        component.set('v.productDetails',productDetails);
        var j=0;
        var productDetailsToShow = [];
        var pageSize = 0;
        if(Number(component.get('v.intPage'))<Number(component.get('v.intPages'))){
        	pageSize = Number(component.get('v.intPage'))*10;
        }
        else{
        	//@Joshna - replaced result.length with v.intTotal
        	pageSize = component.get('v.intTotal');//-(Number(component.get('v.intPage'))-1)*10;
        }
        for(var i=(Number(component.get('v.intPage'))-1)*10; i < pageSize; i++){
        	productDetailsToShow[j] = productDetails[i];
            j++;
        }
        component.set('v.productDetailsToShow', productDetailsToShow);
    },
    getFilteredUnitsHelper : function(cmp){console.log('PK13', cmp.get('v.productDetails'));
        if(cmp.get('v.productDetails') != null && (cmp.get('v.idCenterName') != null || cmp.get('v.intUnitArea') != null || cmp.get('v.intUnitAreaTo') != null || 
        		cmp.get('v.intFloor') != null || cmp.get('v.strCurrTenant') != null || cmp.get('v.strUnitNumberFrom') != null ||
        		cmp.get('v.virVacancy') != null)){
            var action = cmp.get('c.getFilteredUnitsBasedOnCenter');
            var productDetails = [];
            var productDetailsToShow = [];
            var filterUnits = {};        
            var centerOnOfferScreen = cmp.get('v.idCenter');
            var filterCenter = cmp.get('v.idCenterName');
            var isSameCenter;
            var arrExistingProductIds = [];
            filterUnits.intFloor = cmp.get('v.intFloor') == '' ? null : cmp.get('v.intFloor');
            filterUnits.intArea = cmp.get('v.intUnitArea') == '' ? null : cmp.get('v.intUnitArea');
            filterUnits.intAreaTo = cmp.get('v.intUnitAreaTo') == '' ? null : cmp.get('v.intUnitAreaTo');
            filterUnits.strCurrTenantName = cmp.get('v.strCurrTenant');
            filterUnits.strUnitNumberFrom = cmp.get('v.strUnitNumberFrom') == '' ? null : cmp.get('v.strUnitNumberFrom');
            filterUnits.virVacancy = cmp.get('v.selVirVacancy') == '' ? null : cmp.get('v.selVirVacancy');
            filterUnits.unitType = cmp.get('v.unitType') == '' ? null : cmp.get('v.unitType');
            filterUnits.InvType = cmp.get('v.strInvType') == ''? 'GLA' : cmp.get('v.strInvType');
            filterUnits.buildingNumber = cmp.get('v.strBuildingNumber') == ''? null : cmp.get('v.strBuildingNumber');

            console.log('-----filterCenter------>'+filterCenter);
            if(filterCenter != null && filterCenter != centerOnOfferScreen){
                filterUnits.idCenterName = filterCenter;
            }else if((filterCenter != null && filterCenter == centerOnOfferScreen) || filterCenter == null){ 
                 filterUnits.idCenterName = centerOnOfferScreen; 
                 isSameCenter = true;
            }else{
                filterUnits.idCenterName = null;
            }                    
            action.setParams({"strFilterUnits": JSON.stringify(filterUnits)});
            action.setCallback(this, function(response){
                var isSuccess = response.getState();
                if(isSuccess){
                    var exProds = cmp.get('v.addProduct');
                    console.log('Dil Unit',exProds);
                    var result = response.getReturnValue();
                    console.log('result',result);
                    if(result != null && result.length != 0){
                        
                        if(isSameCenter){
                            for(var i=0; i< result.length; i++){
                				//GDM-8345 Changes
                				if(!$A.util.isUndefinedOrNull(result[i].popoutGLA))
                                	result[i].popoutGLARounded = Math.round(result[i].popoutGLA);
                                if(!$A.util.isUndefinedOrNull(result[i].GLA))
                                	result[i].remainingGLARounded = Math.round(result[i].GLA);
	                        if(!$A.util.isUndefinedOrNull(exProds)){
					if(exProds.length > 0){
				for(var j=0; j < exProds.length ; j++){
	                            if(result[i].unitNo == exProds[j].unitNo){
	                                result[i].selected = true;
	                            }
	                        }
				}
				}
                				productDetails.push(result[i]);
            				}
                            cmp.set('v.productDetails', productDetails);
                        }else{
            				for(var i=0; i< cmp.get('v.productDetails').length; i++){
                				productDetails.push(cmp.get('v.productDetails')[i]);
                                arrExistingProductIds.push((cmp.get('v.productDetails')[i]).idProduct);
            				}
                            for(var i = 0; i< result.length; i++){
                                var index = arrExistingProductIds.indexOf(result[i].idProduct);
                                if( index == -1){
                                	productDetails.push(result[i]);
                                }
                            }
                            cmp.set('v.productDetails', productDetails);   
                        }
                        cmp.set('v.intPage', 1);
                		cmp.set('v.intPages', (Math.ceil(productDetails.length/10)));
                		cmp.set('v.intTotal', productDetails.length);
                        var pageSize = 0;
                        var j=0;
                        if(Number(cmp.get('v.intPage'))<Number(cmp.get('v.intPages'))){
                            pageSize = Number(cmp.get('v.intPage'))*10;
                        }
                        else{
                            pageSize = productDetails.length-(Number(cmp.get('v.intPage'))-1)*10;
                        }
                        
                        for(var i=(Number(cmp.get('v.intPage'))-1)*10; i < pageSize; i++){
                            productDetailsToShow.push(productDetails[i]);
                        }
                        cmp.set('v.productDetailsToShow', productDetailsToShow);
                        console.log('****',cmp.get('v.productDetails'));
                    }
                    else
                    {
                    	cmp.set('v.productDetailsToShow', []);
                        cmp.set('v.intPage', 1);
                		cmp.set('v.intPages', 1);
                		cmp.set('v.intTotal', 1);
                    }
                
                }
                var hideSpinner = $A.get("e.c:hideSpinnerEvent_WF");
                if(!$A.util.isUndefinedOrNull(hideSpinner)){
                    hideSpinner.fire(); 
                }
            });
            $A.enqueueAction(action);            
        }
    }
})