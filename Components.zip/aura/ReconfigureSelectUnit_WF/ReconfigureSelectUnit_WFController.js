({
	doInit : function(component, event, helper) {
        helper.doInitHelper(component);
    },
    previousPage : function(component, event, helper) {
        helper.previousPageHelper(component);
	},
	nextPage : function(component, event, helper) {
        helper.nextPageHelper(component);
	},
    showFilters : function(cmp, eve, helper){
        var showFilters = cmp.get('v.strShowFilter');
        
        if(showFilters == 'Yes'){
            cmp.set('v.boolFilterUnits', true);
            if(!$A.util.isUndefinedOrNull(cmp.find('vvpickval'))){
                cmp.find('vvpickval').reInit();
            }
        }else{
            var showSpinner = $A.get("e.c:showSpinnerEvent_WF");
            if(!$A.util.isUndefinedOrNull(showSpinner)){
                showSpinner.fire(); 
            }
            cmp.set('v.boolFilterUnits', false);
            cmp.set('v.intFloor', '');
            cmp.set('v.intUnitArea', '');
            cmp.set('v.intUnitAreaTo', '');
            cmp.set('v.selVirVacancy', '');
            cmp.set('v.strUnitNumberFrom', '');
            cmp.set('v.datStartDate', '');
            cmp.set('v.datExpiryDate', '');
            cmp.set('v.strCurrTenant', '');
            helper.doInitHelper(cmp);
        }
    },
    getFilteredUnits : function(component, event, helper){
        var showSpinner = $A.get("e.c:showSpinnerEvent_WF");
        component.set('v.GLAZero',false)
        if(!$A.util.isUndefinedOrNull(showSpinner)){
            showSpinner.fire(); 
        }
        helper.getFilteredUnitsHelper(component);
    },
    
    validateAreaFromTo : function(component, event, helper){
        var unitFrom = component.get('v.intUnitArea');
        var unitTo = component.get('v.intUnitAreaTo');
        var regErrorFrom = false;
        var regErrorTo = false;
        
        if(!$A.util.isUndefinedOrNull(unitFrom) && unitFrom.match(/^[0-9]*$/))
        {
            $A.util.addClass(component.find("areaFromErrorId"), 'slds-hide');
            regErrorFrom = false;
        }
        else
        {
            if(!$A.util.isUndefinedOrNull(unitFrom))
            {
                $A.util.removeClass(component.find("areaFromErrorId"), 'slds-hide');
            	regErrorFrom = true;
            }
        }
        
        if(!$A.util.isUndefinedOrNull(unitTo) && unitTo.match(/^[0-9]*$/))
        {
            $A.util.addClass(component.find("areaToErrorId"), 'slds-hide');
            regErrorTo = false;
        }
        else
        {
            if(!$A.util.isUndefinedOrNull(unitTo))
            {
                $A.util.removeClass(component.find("areaToErrorId"), 'slds-hide');
            	regErrorTo = true;
            }
        }
        
        if(regErrorFrom == true || regErrorTo == true)
        {
        	component.set('v.regErrorUnits', true);
        }
        else
        {
        	component.set('v.regErrorUnits', false);
        }
    },
    
    onChangeChildCheckbox : function( cmp, eve, helper){
        var unitToAdd=cmp.get('v.addProduct'); 
        
        if($A.util.isUndefinedOrNull(unitToAdd))
        {
        	unitToAdd = [];
        } 
        var productId = eve.getSource().get('v.text');  
        var product =  eve.getSource().get('v.name'); 
        var prodSel = eve.getSource().get('v.value'); 
        
        if(prodSel == true)
        {
        	unitToAdd.push(product);
        	cmp.set('v.addProduct',unitToAdd);
        } 
        
        if(prodSel == false){
            var products = cmp.get('v.addProduct');
            var newProduct = [];
            for(var i=0; i <products.length; i++){
                if(products[i].selected == true){
                    newProduct.push(products[i]);
                }
            }
            cmp.set('v.addProduct',newProduct); 
        }      
    }
})