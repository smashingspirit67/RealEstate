({
    doInit: function(component) {  
        /*
    	var grt = component.get("v.lstGuarantor");
        var action = component.get("c.getTermofguanantor");
        var opts=[];
        action.setCallback(this, function(a) {
            for(var i=0;i< a.getReturnValue().length;i++){
                opts.push({"class": "optionClass", label: a.getReturnValue()[i], value: a.getReturnValue()[i]});
            }
            component.set("v.termOfGuarantorOptions", opts);
        });
        $A.enqueueAction(action);
        var action = component.get("c.getTypeofguanantor");
        var opts1=[];
        action.setCallback(this, function(a) {
            for(var i=0;i< a.getReturnValue().length;i++){
                opts1.push({"class": "optionClass", label: a.getReturnValue()[i], value: a.getReturnValue()[i]});
            }
            component.set("v.typeOfGuarantorOptions", opts1);
        });
        $A.enqueueAction(action);
        
        */
    },
    getPicklistValues : function(cmp, eve){
        var fetchPickList = $A.get("e.c:fetchPicklist");
          fetchPickList.fire();
    },
    passAccount : function(component,event){
        var record = event.getParam("record");
        var cntRecord = event.getParam("cntRecord");
        var fieldValue = event.getParam("fieldValue");
        var lstGuarantor = component.get("v.lstGuarantor");
        for(var i = 0; i < lstGuarantor.length ; i++){
        	if(fieldValue === 'Guarantor'+i){
        		lstGuarantor[i].RelatedAccount_WF__r = record;
        		lstGuarantor[i].ContactName_WF__r = cntRecord;
        		lstGuarantor[i].TypeofGuarantee_WF__c = record.CompanyLegalType_WF__c;
        		lstGuarantor[i].stateOfIncorp = record.StateOfIncorporation_WF__c;
        		break;
        	}
        }
        component.set("v.lstGuarantor", lstGuarantor);
    },
    addGuarantors : function(cmp){        
        if(cmp.get('v.noOfGuarantor')<5){
            cmp.set('v.noOfGuarantor',cmp.get('v.noOfGuarantor')+1);        
            
            var objGuarantor = {};    
            var lstGuarantor = JSON.parse(JSON.stringify(cmp.get('v.lstGuarantor')));            
            var account = cmp.get('v.B2BCustomer');
            
            objGuarantor.Account_WF__c = cmp.get('v.B2BCustomer.Id');            
			objGuarantor.Term_of_Guanantor__c = '';
            objGuarantor.Years_WF__c =0 ;
            objGuarantor.Months_WF__c =0 ;
            objGuarantor.Type_WF__c = '' ;
            if(cmp.get('v.isAmendment')){
            	objGuarantor.Rolling_WF__c = false;
            	objGuarantor.Unamortized_TA_Payback_WF__c = '100';
            }
            objGuarantor.stateOfIncorp = '' ;          
            objGuarantor.Guarantor_Comments__c = '';
			objGuarantor.ContactName_WF__r = '';
            objGuarantor.RelatedAccount_WF__r='';
            objGuarantor.Opportunity_WF__c=cmp.get('v.opportunity');
            
            lstGuarantor.push(objGuarantor);
            cmp.set('v.lstGuarantor', lstGuarantor);
            var fetchPickList = $A.get("e.c:fetchPicklist");
            fetchPickList.fire();
        }
    },

    deleteGuarantor : function(component,event){ 
        if(component.get('v.noOfGuarantor')>0){
            var lstGuarantor = component.get("v.lstGuarantor");
            var lstToDelete = JSON.parse(JSON.stringify(component.get("v.guarantorsToDelete")));                      
            var deletedGuarantors = lstGuarantor.pop();
            if(deletedGuarantors.Id !== undefined && deletedGuarantors.Id !== null && deletedGuarantors.Id !== ''){
            	lstToDelete.push(deletedGuarantors.Id);
            }
            component.set('v.guarantorsToDelete', lstToDelete);
            component.set("v.lstGuarantor", lstGuarantor);
            component.set('v.noOfGuarantor',component.get('v.noOfGuarantor')-1);
        }
    },
    displayGuarantor : function (component, event){   
        var result= component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        console.log('covenantTextFieldMap',covenantTextFieldMap);
    	var validate = event.getParam('showErrors');
        var guarantors = JSON.parse(JSON.stringify(component.get('v.lstGuarantor')));
        var lstGuarantor = [];
        var amendment = component.get("v.isAmendment");
        var showError = false;
        
        for(var i = 0 ; i < guarantors.length; i++){
            var objGuarantor ={};
            if(guarantors[i].hasOwnProperty('Id') && guarantors[i].Id != undefined)
                objGuarantor.Id = guarantors[i].Id;
            if(guarantors[i].hasOwnProperty('RelatedAccount_WF__r') && guarantors[i].RelatedAccount_WF__r.Id !== undefined && guarantors[i].RelatedAccount_WF__c !== null && guarantors[i].RelatedAccount_WF__c !== undefined && guarantors[i].RelatedAccount_WF__c !== ''){
            	objGuarantor.RelatedAccount_WF__c =  guarantors[i].RelatedAccount_WF__r.Id ;
			}
			else{
				objGuarantor.RelatedAccount_WF__c = null;
			}
            if( guarantors[i].hasOwnProperty('ContactName_WF__r') && guarantors[i].ContactName_WF__r !== undefined && guarantors[i].ContactName_WF__r.Id !== undefined){
                objGuarantor.ContactName_WF__c = guarantors[i].ContactName_WF__r.Id ;
            }else{
                objGuarantor.ContactName_WF__c = null;
            }
            
            objGuarantor.Account_WF__c = component.get('v.B2BCustomer.Id');
            
            /*GDM-7254*/
            if(!$A.util.isUndefinedOrNull(guarantors[i].Guarantor_Comments__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Guarantor_Comments__c'])
               && guarantors[i].Guarantor_Comments__c.length > covenantTextFieldMap['Guarantor_Comments__c'])
            {
                showError = true;
                $A.util.removeClass(document.getElementById('guarantorLengthError'+i), 'slds-hide');
                objGuarantor.Guarantor_Comments__c ='';
            }
            else{
                $A.util.addClass(document.getElementById('guarantorLengthError'+i), 'slds-hide');
                objGuarantor.Guarantor_Comments__c = guarantors[i].Guarantor_Comments__c;
            }
           
            if(validate){
	            if(guarantors[i].Term_of_Guanantor__c =='' || guarantors[i].Term_of_Guanantor__c == null || guarantors[i].Term_of_Guanantor__c == undefined){
	                showError = true;
	                $A.util.removeClass(document.getElementById('termOfGuarantyId'+i), 'slds-hide');
	                //$A.util.addClass(document.getElementById('termOfGuarantyId'+i), 'slds-show');
	            }else{
	                $A.util.addClass(document.getElementById('termOfGuarantyId'+i), 'slds-hide');
	                component.set('v.showGuarantorErrors', showError);
	            }
				if(objGuarantor.RelatedAccount_WF__c =='' || objGuarantor.RelatedAccount_WF__c == null || objGuarantor.RelatedAccount_WF__c == undefined){
	                showError = true;
	                $A.util.removeClass(document.getElementById('guarantorVal'+i), 'slds-hide');
	                //$A.util.addClass(document.getElementById('termOfGuarantyId'+i), 'slds-show');
	            }else{
	                $A.util.addClass(document.getElementById('guarantorVal'+i), 'slds-hide');
	                component.set('v.showGuarantorErrors', showError);
	            }
            }
               
            
            component.set('v.showGuarantorErrors', showError);
            objGuarantor.Term_of_Guanantor__c = guarantors[i].Term_of_Guanantor__c;
            objGuarantor.Years_WF__c =guarantors[i].Years_WF__c ;
            objGuarantor.Months_WF__c =guarantors[i].Months_WF__c ;
            objGuarantor.TypeofGuarantee_WF__c = guarantors[i].TypeofGuarantee_WF__c;      
            objGuarantor.Type_WF__c = 'Guarantor';                     
            //objGuarantor.Guarantor_Comments__c = guarantors[i].Guarantor_Comments__c;
            objGuarantor.Rolling_WF__c = guarantors[i].Rolling_WF__c;
            objGuarantor.Unamortized_TA_Payback_WF__c = guarantors[i].Unamortized_TA_Payback_WF__c;
            objGuarantor.Opportunity_WF__c=component.get('v.opportunity');
            lstGuarantor.push(objGuarantor);
        }
        if(showError == false){
            component.set('v.addGuarantor' , lstGuarantor);
            component.set('v.guarantorsToDelete', component.get('v.guarantorsToDelete'));        
        }
    }
})