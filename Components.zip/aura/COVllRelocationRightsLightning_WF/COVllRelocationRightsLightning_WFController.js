({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Relocation Rights']){
                component.set('v.llRelocationRight',covenant[item]);
                isPresent = true;
            }
        }
        
        if(!isPresent){
            var llRelocationRight = {};
            llRelocationRight.RecordTypeId =component.get('v.CovenantRecordType')['Landlord Relocation Rights'];
            llRelocationRight.StandardRelocationRights_WF__c=true;
            component.set('v.llRelocationRight',llRelocationRight);
            covenant.push(component.get('v.llRelocationRight'));
            component.set('v.Covenant',covenant);
        }
	},
    enableHelpTextSRR : function(component, event, helper){
        component.set('v.showHelpTextSRR',true);
    },
    disableHelpText : function(component, event, helper){
        component.set('v.showHelpTextSRR',false);
    },
    changeLLRelocation : function(component, event, helper){
        component.set('v.llRelocationRight.Zone_WF__c',false);
        component.set('v.llRelocationRight.IfNoRelocationRightsDescription_WF__c','');
    },
})