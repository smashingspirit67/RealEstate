({
    requiredValidation : function(component,event) {
        // get all task.. 	
        var allRecords = component.get("v.TaskList");
        var isValid = true;
        // play a for loop on all task list and check that task subject is not null,   
      /*  for(var i = 0; i < allRecords.length;i++){
            if(allRecords[i].Name == null || allRecords[i].Name.trim() == ''){
                alert('Complete this field : Row No ' + (i+1) + ' Subject is null' );
                isValid = false;
            }  
        } */
        return isValid;
    },
})