({
    doInit : function(component, event, helper) {
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Real Estate Tax']){
                component.set('v.realEstateTax',charges[item]);
            }
        }
        helper.setPicklistValues(component,component.get('v.result'));
    },    
    changeUnit : function(component,event){
        var psf = component.get('v.realEstateTax.Exp_Initial_Rate_PSF_WF__c');
        console.log('sss',component.get('v.GLAUsed'));
        var GLA = isNaN(parseFloat(component.get('v.GLAUsed'))) ? 1 : parseFloat(component.get('v.GLAUsed'));
        if(GLA==0){
            GLA = 1;
        }
        var total = psf * GLA;
        component.set('v.realEstateTax.Exp_Initial_Annual_Amount_WF__c',total);
    },
    calculateVariance : function(component,event){
        var originalpsf = component.get('v.realEstateTax.Exp_Initial_Rate_PSF_WF__c');
        var standardpsf = component.get('v.realEstateTax.Standard_Exp_Initial_Rate_PSF_WF__c');
        var originalAmount = component.get('v.realEstateTax.Exp_Initial_Annual_Amount_WF__c');
        var standardAmount = component.get('v.realEstateTax.Standard_Exp_Initial_Annual_Amount_WF__c');
        var variancePSFAmount = (originalpsf-standardpsf).toFixed(2);
        var variancePSFPercentage = (variancePSFAmount/standardpsf*100).toFixed(2);
        var varianceAnnualAmount = (originalAmount-standardAmount).toFixed(2);
        var varianceAnnualPercentage = (varianceAnnualAmount/standardAmount*100).toFixed(2);
        if(!isNaN(variancePSFAmount)){
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_Var_Amo_WF__c','$'+variancePSFAmount);
        }
        if(isFinite(variancePSFPercentage)&&!isNaN(variancePSFPercentage)){
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_Var_Per_WF__c',variancePSFPercentage+'%');
        }else{
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_Var_Per_WF__c','100%');
        }
        if(!isNaN(varianceAnnualAmount)){
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_Var_Amo_WF__c','$'+varianceAnnualAmount);
        }
        if(isFinite(varianceAnnualPercentage)&&!isNaN(varianceAnnualPercentage)){
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_Var_Per_WF__c',varianceAnnualPercentage+'%');
        }else{
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_Var_Per_WF__c','100%');
        }
    },
    changeCharges : function(component,event){
        var original = isNaN(parseFloat(event.getSource().get('v.value'))) ? 0 : parseFloat(event.getSource().get('v.value'));  
        var GLA = isNaN(parseFloat(component.get('v.GLAUsed'))) ? 1 : parseFloat(component.get('v.GLAUsed'));
        if(GLA==0){
            GLA = 1;
        }
        if(event.getSource().get('v.name').indexOf('PSF')>-1){
            component.find(event.getSource().get('v.name').split('PSF')[0]+'Total').set('v.value',(original*GLA).toFixed(2));
            //For Main
            var standard = parseFloat(component.find('standard'+event.getSource().get('v.name')).get('v.value'));
            var dollar = (original-standard).toFixed(2);
            var percentage= parseFloat((dollar)/(standard)*100).toFixed(2);
            if(!isNaN(dollar)){
                component.find('varDollar'+event.getSource().get('v.name')).set('v.value','$ '+dollar);
            }
            if(isFinite(percentage)&&!isNaN(percentage)){
                component.find('varPer'+event.getSource().get('v.name')).set('v.value',percentage+' %');
            }
            //For Dependent
            var newOriginal = component.find(event.getSource().get('v.name').split('PSF')[0]+'Total').get('v.value');
            var standard = parseFloat(component.find('standard'+event.getSource().get('v.name').split('PSF')[0]+'Total').get('v.value'));
            var dollar = (newOriginal-standard).toFixed(2);
            var percentage= parseFloat((dollar)/(standard)*100).toFixed(2);
            if(!isNaN(dollar)){
                component.find('varDollar'+event.getSource().get('v.name').split('PSF')[0]+'Total').set('v.value','$ '+dollar);
                console.log('varPer'+event.getSource().get('v.name').split('PSF')[0]+'Total');
            }  
            if(isFinite(percentage)&&!isNaN(percentage)){
                component.find('varPer'+event.getSource().get('v.name').split('PSF')[0]+'Total').set('v.value',percentage+' %'); 
            }
        }
        if(event.getSource().get('v.name').indexOf('Total')>-1){
            component.find(event.getSource().get('v.name').split('Total')[0]+'PSF').set('v.value',(original/GLA).toFixed(2));
            //For Main
            var standard = parseFloat(component.find('standard'+event.getSource().get('v.name')).get('v.value'));
            var dollar = (original-standard).toFixed(2);
            var percentage= parseFloat((dollar)/(standard)*100).toFixed(2);
            if(!isNaN(dollar)){
                component.find('varDollar'+event.getSource().get('v.name')).set('v.value','$ '+dollar);
            }
            if(isFinite(percentage)&&!isNaN(percentage)){
                component.find('varPer'+event.getSource().get('v.name')).set('v.value',percentage+' %');
            }
            //For Dependent
            var newOriginal = component.find(event.getSource().get('v.name').split('Total')[0]+'PSF').get('v.value');
            var standard = parseFloat(component.find('standard'+event.getSource().get('v.name').split('Total')[0]+'PSF').get('v.value'));
            var dollar = (newOriginal-standard).toFixed(2);
            var percentage= parseFloat((dollar)/(standard)*100).toFixed(2);
            if(!isNaN(dollar)){
                component.find('varDollar'+event.getSource().get('v.name').split('Total')[0]+'PSF').set('v.value','$ '+dollar);
            }
            if(isFinite(percentage)&&!isNaN(percentage)){
                component.find('varPer'+event.getSource().get('v.name').split('Total')[0]+'PSF').set('v.value',percentage+' %');       
            }
        }
    },
    changeChargeBool : function(component,event){
        if(!component.get('v.realEstateTax.Charge_Type_Oth_WF__c')){
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_WF__c',0);
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_Var_Amo_WF__c','');
            component.set('v.realEstateTax.Exp_Initial_Rate_PSF_Var_Per_WF__c','');
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_WF__c',0);
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_Var_Amo_WF__c','');
            component.set('v.realEstateTax.Exp_Initial_Annual_Amount_Var_Per_WF__c','');
            component.set('v.realEstateTax.Exp_Rate_TaxAdjustment_Type__c','');
            component.set('v.realEstateTax.Exp_Fixed_Increase_Curr_WF__c',0);
            component.set('v.realEstateTax.Exp_Fixed_Increase_WF__c',0);
            component.set('v.realEstateTax.Tax_Income_Type_WF__c','$');
            component.set('v.realEstateTax.Tax_Initial_Rate_Details_WF__c','');
            component.set('v.realEstateTax.Exp_Pro_Rata_Adjustment_WF__c','');
            component.set('v.realEstateTax.Exp_Annual_Cap__c',0);
            component.set('v.realEstateTax.TaxDescription_WF__c','');
            component.set('v.taxDescLengthErr',false);
        }else{
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cExp_Rate_TaxAdjustment_Type__c'))){ 
                console.log('1');
                component.find('Charges_WF__cExp_Rate_TaxAdjustment_Type__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c'))){    
                console.log('2');
                component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cExp_Pro_Rata_Adjustment_WF__c'))){  
                console.log('3');
                component.find('Charges_WF__cExp_Pro_Rata_Adjustment_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Income_Type_WF__c'))){  
                console.log('4');
                component.find('Charges_WF__cTax_Income_Type_WF__c').reInit();
            }
            component.set('v.taxDescLengthErr',false);
        }
    },
    changeTaxInitialRateDetails : function(component, event, helper) {
        component.set('v.realEstateTax.Tax_Initial_Rate_Fixed_For_WF__c',0);
    },
    changeExpRateAdjType : function(component,event){
        var value = component.get('v.realEstateTax.Exp_Rate_TaxAdjustment_Type__c');
        if(value=='Fixed'){
            component.set('v.realEstateTax.Tax_Initial_Rate_Details_WF__c','');
            component.set('v.realEstateTax.Exp_Pro_Rata_Adjustment_WF__c','');
            component.set('v.realEstateTax.Exp_Annual_Cap__c',0);
            component.set('v.realEstateTax.Tax_Initial_Rate_Fixed_For_WF__c',0);
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c'))){            
                component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cExp_Pro_Rata_Adjustment_WF__c'))){            
                component.find('Charges_WF__cExp_Pro_Rata_Adjustment_WF__c').reInit();
            }
        }else if(value=='Pro Rata'||value=='Proportionately by Pro Rata Incr.'){
            component.set('v.realEstateTax.Exp_Fixed_Increase_WF__c',0);
            component.set('v.realEstateTax.Exp_Fixed_Increase_Curr_WF__c',0);
            component.set('v.realEstateTax.Tax_Income_Type_WF__c','$');
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Income_Type_WF__c'))){                            
                component.find('Charges_WF__cTax_Income_Type_WF__c').reInit();
            }
        }else{
            component.set('v.realEstateTax.Exp_Fixed_Increase_WF__c',0);
            component.set('v.realEstateTax.Exp_Fixed_Increase_Curr_WF__c',0);
            component.set('v.realEstateTax.Tax_Initial_Rate_Details_WF__c','');
            component.set('v.realEstateTax.Exp_Pro_Rata_Adjustment_WF__c','');
            component.set('v.realEstateTax.Exp_Annual_Cap__c',0);
            component.set('v.realEstateTax.Tax_Income_Type_WF__c','$');
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c'))){                            
                component.find('Charges_WF__cTax_Income_Type_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c'))){                            
                component.find('Charges_WF__cExp_Pro_Rata_Adjustment_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c'))){                            
                component.find('Charges_WF__cTax_Initial_Rate_Details_WF__c').reInit();
            }
        }       
    },
    changeTaxProRataAdj : function(component,event){
        var value = component.get('v.realEstateTax.Exp_Pro_Rata_Adjustment_WF__c');
        if(value=='No Cap'){
            component.set('v.realEstateTax.Exp_Annual_Cap__c',0);
        }
    },
    changeTaxType : function(component,event){
        var value = component.get('v.realEstateTax.Tax_Income_Type_WF__c');
        if(value=='$'){
            component.set('v.realEstateTax.Exp_Fixed_Increase_WF__c',0);
        }else if(value=='%'){
            component.set('v.realEstateTax.Exp_Fixed_Increase_Curr_WF__c',0);
        }else{
            component.set('v.realEstateTax.Exp_Fixed_Increase_WF__c',0);
            component.set('v.realEstateTax.Exp_Fixed_Increase_Curr_WF__c',0);
        }
    }
})