({
    doInit :function (component, event, helper){
        var isOptions = component.get('v.IsOptions');
        if(!isOptions){
            //If it's not min rent, then it's definitely unnatural and other (by default)... so getting rid of the other if clauses
            if(!component.get('v.IsMinimumRent')){// && component.get('v.opportunity.BreakpointType_WF__c') === 'Unnatural' && component.get('v.opportunity.RentTypeBasis_WF__c') === 'Other'){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointStepType_WF__c')) || component.get('v.opportunity.BreakpointStepType_WF__c') === '' || component.get('v.opportunity.BreakpointStepType_WF__c') === 'none'){
                    component.set('v.opportunity.BreakpointStepType_WF__c', 'none');
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.PercentRentRate_WF__c')) || component.get('v.opportunity.PercentRentRate_WF__c') === ''){
                    component.set('v.opportunity.PercentRentRate_WF__c', '--None--');
                }
            }
            helper.checkRows(component);
            helper.handleEstimateHelper(component, false);
            if(component.get('v.opportunity.BreakpointType_WF__c') == 'Unnatural'){
                if(component.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF") || component.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                    component.set('v.unitOfMeasure', '$');
                }else if(component.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || component.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){
                    component.set('v.unitOfMeasure', '%');
                }
            }
        }else{
            if(!component.get('v.IsMinimumRent')){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsBreakpointStepType_WF__c')) || component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === '' || component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === '--None--'){
                    component.set('v.opportunity.OptionsBreakpointStepType_WF__c', '--None--');
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsPercentRentRate_WF__c')) || component.get('v.opportunity.OptionsPercentRentRate_WF__c') === '' || component.get('v.opportunity.OptionsPercentRentRate_WF__c') === '--None--'){
                    component.set('v.opportunity.OptionsPercentRentRate_WF__c', '--None--');
                }    
            }
            helper.checkRows(component);
            helper.handleEstimateHelper(component, false);
            if(component.get('v.opportunity.OptionsBreakpointType_WF__c') == 'Unnatural'){
                if(component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF") || component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                    component.set('v.unitOfMeasure', '$');
                }else if(component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || component.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){
                    component.set('v.unitOfMeasure', '%');
                }
            }
        }
    },
    calculateBreakpoint : function(cmp, eve, helper){
        helper.updateTable(cmp, eve, false);
    },
    calculateRentRate : function(cmp,eve,helper){
        helper.calculateRentRate(cmp,eve, false);
        
    },
    handleEstimate : function(component, event, helper){
        helper.handleEstimateHelper(component, true);
    },
    updateBreakPointPercent : function(cmp, eve, helper){  
        var rentTable = cmp.get('v.lstGrowthRateTable');
        var isOptions = cmp.get('v.IsOptions');
        helper.updateColumns(cmp, "col3"); 
        if(rentTable !== undefined && rentTable.length === 0 && !isOptions && !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.BreakpointStepType_WF__c') !== '--None--' && cmp.get('v.opportunity.PercentRentRate_WF__c') !== '--None--'){
            helper.getNextRow(cmp, eve);
        }
        if(rentTable !== undefined && rentTable.length === 0 && isOptions && !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') !== '--None--' && cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') !== '--None--'){
            helper.getNextRow(cmp, eve);
        }
    },
    updatedRentRatePercent : function(cmp, eve, helper){
        var rentTable = cmp.get('v.lstGrowthRateTable');
        var isOptions = cmp.get('v.IsOptions');
        helper.updateRentRateColumns(cmp, "col5");   
        if(rentTable !== undefined && rentTable.length === 0 && !isOptions && !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.BreakpointStepType_WF__c') !== '--None--' && cmp.get('v.opportunity.PercentRentRate_WF__c') !== '--None--'){
            helper.getNextRow(cmp, eve);
        }
        if(rentTable !== undefined && rentTable.length === 0 && isOptions && !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') !== '--None--' && cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') !== '--None--'){
            helper.getNextRow(cmp, eve);
        }
    },
    getDetails : function(cmp,eve){       
        cmp.set('v.lstGrowthRateTable', cmp.get('v.lstGrowthRateTable'));
    },
    updateEndDate : function(cmp, eve,helper){
        helper.getNextRow(cmp,eve);
    },
    updateTheList : function (cmp, eve, helper){
        helper.clearColumnsInTheList(cmp, eve);
    },
    updateTable : function(cmp, eve, helper){
        if(cmp.get('v.IsMinimumRent')){
            helper.updateTable(cmp, eve, true);
            
            helper.calculateRentRate(cmp,eve, true);
            
        }
        
    },
    updateTableBasedOnChangeEvent : function(cmp, eve, helper){
        if( cmp.get('v.IsMinimumRent') === false){
            helper.updateTable(cmp, eve, true);
            helper.calculateRentRate(cmp,eve, true);
        }
    },
    udpateTableBasedOnAmount : function(cmp, eve, helper){
        var errorCmp = cmp.find('errorId');
        var rentTable = cmp.get('v.lstGrowthRateTable');
        var amount;
        if(eve.target != undefined){
            amount = eve.target.value !== "" ? eve.target.value : 0.00;
        if(amount < 0)
        {    
            $A.util.removeClass(errorCmp , 'slds-hide');
            cmp.set('v.IsNegativeValue', true);
        }
        else{
            $A.util.addClass(errorCmp , 'slds-hide');
            cmp.set('v.IsNegativeValue', false);
            var opp = cmp.get('v.opportunity');
            var isOptions = cmp.get('v.IsOptions');        
            var breakPointStepType;
            if(!isOptions){
                breakPointStepType = cmp.get('v.opportunity.BreakpointStepType_WF__c');
            }else{
                breakPointStepType = cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c');
            }
            var rentTable = cmp.get('v.lstGrowthRateTable');
            if(!$A.util.isUndefinedOrNull(rentTable)){
                if(rentTable.length > 0){                                
                    if(breakPointStepType === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                        for(var i = 0; i < rentTable.length; i++){            
                            if( i === 0){
                                rentTable[i].decBreakpointAmount = amount;    
                            }else{
                                 console.log('rentTable[i]'+rentTable[i].decBrkptCalcpercent);
                                 console.log('rentTable[i-1]'+rentTable[i-1].decBrkptCalcpercent);
                                 console.log('rentTable[i-1]'+rentTable[i-1].decBreakpointAmount);
                                 console.log('rentTable[i-1]'+rentTable[i-1].decBreakpointAmount);
                                if(rentTable[i].decBrkptCalcpercent!==undefined){//7699  
                                rentTable[i].decBrkptCalcpercent = rentTable[i-1].decBrkptCalcpercent; //7699  
                                rentTable[i].decBreakpointAmount = parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i-1].decBrkptCalcpercent) / 100)).toFixed(2);//7699
                                }
                                //else{
                               // rentTable[i].decBrkptCalcpercent = 0; //7699  
                                //rentTable[i].decBreakpointAmount =  parseFloat(Number(rentTable[i-1].decBreakpointAmount)).toFixed(2);;
                                //}
                                }
                                    // rentTable[i].decBrkptCalcpercent = rentTable[i-1].decBrkptCalcpercent; //7699   
                            }
                            
                        
                    }else if(breakPointStepType === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                            
                        
                        for(var i = 0; i < rentTable.length; i++){                                                             
                            if( i === 0 ){
                                rentTable[i].decBreakpointAmount = amount;                                
                            }else
                                rentTable[i].decBreakpointAmount = parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100)).toFixed(2);
                                rentTable[i].decBrkptCalcpercent = rentTable[i].decBrkptCalcpercent;
                        }
                    }else if(breakPointStepType === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                        for(var i = 0; i < rentTable.length; i++){   
                            if( i === 0)
                                rentTable[i].decBreakpointAmount = amount;
                            else
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                                rentTable[i].decBrkptCalcpercent = rentTable[i].decBrkptCalcpercent;
                        }
                    }else if(breakPointStepType === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){                            
                        var step = eve.target.getAttribute('data-id');
                        for(var i = step; i < rentTable.length; i++){   
                            if( i == step ){
                                rentTable[i].decBreakpointAmount = amount;
                            }else{
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                            }  
                        
                            rentTable[step].decBrkptCalcpercent = rentTable[step].decBreakpointAmount - rentTable[step-1].decBreakpointAmount;                            
                        }                        
                    }
                    cmp.set('v.lstGrowthRateTable', rentTable);
                }                
                }                
            }
        }
    },
    handleCmnts:function(cmp,eve)
    {
        console.log("inside handler cmnts");
        var lstGrowthRateTable = cmp.get('v.lstGrowthRateTable');
         for(var i=0;i<lstGrowthRateTable.length;i++)
         {
             if(lstGrowthRateTable[i].boolEstimatedPercent == false)
             {
                lstGrowthRateTable[i].percentComments="";
                $A.util.addClass(document.getElementById('percentCommentsErrId'+i),'slds-hide');
             }
             
         }
    
    },
    handleOtherCmnts:function(cmp,eve)
    {
        console.log("inside handler cmnts");
        var lstGrowthRateTable = cmp.get('v.lstGrowthRateTable');
         for(var i=0;i<lstGrowthRateTable.length;i++)
         {
             if(lstGrowthRateTable[i].boolEstimatedPercent == false)
             {
                lstGrowthRateTable[i].percentComments="";
                $A.util.addClass(document.getElementById('percentCommentsOthrErrId'+i),'slds-hide');
             }
             
         }
    
    },
    resetErrorBanner : function(cmp,eve){
        var errorCmp = cmp.find('errorId');
        $A.util.addClass(errorCmp, 'slds-hide');
        cmp.set('v.IsNegativeValue', false);
    },
    validateNonStdCmnts:function(cmp,eve,helper)
    {
        helper.validateNonStdCmnts(cmp,eve);
    }
})