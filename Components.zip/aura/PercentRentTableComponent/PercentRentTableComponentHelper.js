({
    updateColumns : function(cmp, column) {
        //console.log(cmp.getElements());
        var rentTable = cmp.get('v.lstGrowthRateTable');    
        var isOptions = cmp.get('v.IsOptions');
        if(!isOptions){
            if(cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Minimum Rent' && cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){
                cmp.set('v.unitOfMeasure', '%');
                if(rentTable.length > 1){
                    var decPercVal = $A.util.isUndefinedOrNull(rentTable[0].decBrkptCalcpercent) ? 0 : rentTable[0].decBrkptCalcpercent;
                    for(var i = 1; i < rentTable.length; i++){  
                        rentTable[i].decBreakpointAmount = decPercVal != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / decPercVal) : 0;
                        rentTable[i].decBrkptCalcpercent = decPercVal;
                    }
                    }
            } else if(cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Minimum Rent' && cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){
                cmp.set('v.unitOfMeasure', '%');
            } else if(cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Other' &&  (cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF") || cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF"))){
                if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                    cmp.set('v.unitOfMeasure', '$');
                    if(rentTable.length > 1){
                        var decPercVal = $A.util.isUndefinedOrNull(rentTable[1].decBrkptCalcpercent) ? 0 : rentTable[1].decBrkptCalcpercent;
                        for( var i =1 ; i< rentTable.length; i++){
                            rentTable[i].decBrkptCalcpercent = decPercVal;
                            if( rentTable[i].decBreakpointAmount >= 0){
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                            }
                        }
                    }
                }else{
                    cmp.set('v.unitOfMeasure', '%');
                    if(rentTable.length > 1){
                        var decPercVal = $A.util.isUndefinedOrNull(rentTable[1]) ? 0 : rentTable[1].decBrkptCalcpercent;
                        for(var i = 1; i < rentTable.length; i++){  
                            rentTable[i].decBrkptCalcpercent = decPercVal;
                            if(rentTable[0].decBreakpointAmount >= 0){
                                var amount = Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100);
                                rentTable[i].decBreakpointAmount = parseFloat(amount).toFixed(2);                                
                            }
                        }
                    }
                }
            }else if(cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Other' && (cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")) ){                       
                if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                    cmp.set('v.unitOfMeasure', '$');
                    if(rentTable.length > 1){                        
                        for( var i =1 ; i< rentTable.length; i++){
                            if( rentTable[i].decBreakpointAmount >= 0){
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                            }
                        }
                    }
                }else{
                    cmp.set('v.unitOfMeasure', '%');
                    if(rentTable.length > 0){
                        for(var i = 1; i < rentTable.length; i++){                                                            
                            var amount = Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100);
                            rentTable[i].decBreakpointAmount= parseFloat(amount).toFixed(2);
                            //   rentTable[step].decBrkptCalcpercent = breakPointPercent;                                                                                                            
                        }
                    }

                }
            }
            cmp.set('v.lstGrowthRateTable', rentTable);
        }else{             
            if(cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Minimum Rent' && cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){
                cmp.set('v.unitOfMeasure', '%');
                if(rentTable.length > 1){
                    var decPercVal = $A.util.isUndefinedOrNull(rentTable[0].decBrkptCalcpercent) ? 0 : rentTable[0].decBrkptCalcpercent;
                    for(var i = 1; i < rentTable.length; i++){  
                        rentTable[i].decBreakpointAmount = decPercVal != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / decPercVal) : 0;
                        rentTable[i].decBrkptCalcpercent = decPercVal;
                }
                    }
            } else if(cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Minimum Rent' && cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){
                cmp.set('v.unitOfMeasure', '%');
            } else if(cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Other' &&  (cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF") || cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF"))){
                if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                    cmp.set('v.unitOfMeasure', '$');
                    if(rentTable.length > 1){                        
                        var decPercVal = $A.util.isUndefinedOrNull(rentTable[1].decBrkptCalcpercent) ? 0 : rentTable[1].decBrkptCalcpercent;
                        for( var i =1 ; i< rentTable.length; i++){
                            rentTable[i].decBrkptCalcpercent = decPercVal;
                            if( rentTable[i].decBreakpointAmount >= 0){
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                            }
                        }
                    }
                }else{
                    cmp.set('v.unitOfMeasure', '%');
                    if(rentTable.length > 1){
                        var decPercVal = $A.util.isUndefinedOrNull(rentTable[1]) ? 0 : rentTable[1].decBrkptCalcpercent;
                        for(var i = 1; i < rentTable.length; i++){                            
                            rentTable[i].decBrkptCalcpercent = decPercVal;
                            if(rentTable[0].decBreakpointAmount >= 0){
                                var amount = Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100);
                                rentTable[i].decBreakpointAmount = parseFloat(amount).toFixed(2);
                            }
                        }
                    }
                }
            }else if(cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Other' && (cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")) ){                       
                if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                     cmp.set('v.unitOfMeasure', '$');
                    if(rentTable.length > 1){                        
                        for( var i =1 ; i< rentTable.length; i++){
                            if( rentTable[i].decBreakpointAmount >= 0){
                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);
                            }
                        }
                    }
                }else{
                    cmp.set('v.unitOfMeasure', '%');
                    if(rentTable.length > 0){
                        var amount;
                        for(var i = 1; i < rentTable.length; i++){                                                            
                            amount =  Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100);
                                rentTable[i].decBreakpointAmount= parseFloat(amount).toFixed(2);
                            }
                    }

                
                }
            }
            cmp.set('v.lstGrowthRateTable', rentTable);
        }
    },
    
    updateRentRateColumns : function(cmp, column) {
        var rentTable = cmp.get('v.lstGrowthRateTable');    
        var isOptions = cmp.get('v.IsOptions');
        if(!isOptions){
            if(cmp.get('v.opportunity.PercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Same_WF")){                                
                if(rentTable.length > 0){
                    for(var i = 0; i<rentTable.length; i++){
                        rentTable[i].decRentRate = $A.util.isUndefinedOrNull(rentTable[0].decRentRate) ? 0 : rentTable[0].decRentRate;
                    }   
                }                
            }
            cmp.set('v.lstGrowthRateTable', rentTable); 
        } else {
            if(cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Same_WF")){                                
                for(var i = 1; i<rentTable.length; i++){
                     rentTable[i].decRentRate = $A.util.isUndefinedOrNull(rentTable[0].decRentRate) ? 0 : rentTable[0].decRentRate;
                }
            }
            cmp.set('v.lstGrowthRateTable', rentTable);             
        }
    },
    getNextRow : function( cmp, eve){
        var lstGrowthRates = cmp.get('v.lstGrowthRateTable');        
        var leaseExpiryDate;
        if(cmp.get('v.IsOptions') !== true)
            leaseExpiryDate = cmp.get('v.opportunity.ExpirationDate_WF__c');
        else
            leaseExpiryDate = cmp.get('v.opportunity.LeaseOptionsEndDate_WF__c');
        //Joshna, 1st Jul, commenting this out as WLMS allows more than 5
        //if(lstGrowthRates.length <5 ){
            var arrGrowthRates = JSON.parse(JSON.stringify(lstGrowthRates));
            var objGrowthRates = {};        
            var objPercentRent ={};         
            
            if(lstGrowthRates.length === 0){
                if(cmp.get('v.IsOptions') !== true)
                objGrowthRates.datStartDate=  cmp.get('v.opportunity.RCDEarlierOfOpeningOf_WF__c');   
                else
                    objGrowthRates.datStartDate=  cmp.get('v.opportunity.LeaseOptionsStartDate_WF__c');   
                objGrowthRates.datEndDate= objGrowthRates.datStartDate;
                objGrowthRates.decAmount= null;
                objGrowthRates.decBreakpointAmount= null;
                objGrowthRates.decBrkptCalcpercent= null;
                objGrowthRates.decRentRate= null;
                objGrowthRates.boolEstimatedPercent= false;
                objGrowthRates.objPercentRent = objPercentRent;
                arrGrowthRates.push(objGrowthRates);
                cmp.set('v.lstGrowthRateTable', arrGrowthRates); 
            }else if(lstGrowthRates.length > 0){
                //check existing data to ensure there's no incorrect date values
                var currentEndDate = eve.getSource().get('v.value');
                var currentStartDate;
                var lastRowEndDate;
                if(!$A.util.isUndefinedOrNull(lstGrowthRates[lstGrowthRates.length - 1])){
                    currentStartDate = lstGrowthRates[lstGrowthRates.length - 1].datStartDate;
                    lastRowEndDate = lstGrowthRates[lstGrowthRates.length - 1].datEndDate;
                }
                if($A.util.isUndefinedOrNull(currentEndDate) || currentEndDate === '' || 
                   currentStartDate > currentEndDate || $A.util.isUndefinedOrNull(lastRowEndDate)) {
                    var validatedRates = this.validateData(arrGrowthRates, leaseExpiryDate);
                    cmp.set('v.lstGrowthRateTable', validatedRates);
                    return;
                }
                if(currentEndDate > leaseExpiryDate){
                    eve.getSource().set('v.value', leaseExpiryDate) ; 
                    var validatedRates = this.validateData(arrGrowthRates, leaseExpiryDate);
                    cmp.set('v.lstGrowthRateTable', validatedRates);
                } else if(currentEndDate < currentStartDate){
                    eve.getSource().set('v.value', currentStartDate);                     
                } else {
                    
                    objGrowthRates.decAmount= null;
                   objGrowthRates.decBrkptCalcpercent= lstGrowthRates[lstGrowthRates.length - 1].decBrkptCalcpercent;
                    if(cmp.get('v.IsOptions') == false){
                        if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF") || cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF"))
                            objGrowthRates.decBreakpointAmount = Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) + Number(lstGrowthRates[lstGrowthRates.length - 1].decBrkptCalcpercent) ;
                        
                        else if (cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF"))
                            objGrowthRates.decBreakpointAmount= parseFloat(Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) + (( Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) * lstGrowthRates[lstGrowthRates.length - 1].decBrkptCalcpercent) / 100)).toFixed(2) ; 
                    }else{
                        if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF") || cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF"))
                            objGrowthRates.decBreakpointAmount = Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) + Number(lstGrowthRates[lstGrowthRates.length - 1].decBrkptCalcpercent) ;
                        
                        else if (cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF") || cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF"))
                            objGrowthRates.decBreakpointAmount= parseFloat(Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) + (( Number(lstGrowthRates[lstGrowthRates.length - 1].decBreakpointAmount) * lstGrowthRates[lstGrowthRates.length - 1].decBrkptCalcpercent) / 100)).toFixed(2) ; 
                    }
                    objGrowthRates.decRentRate= lstGrowthRates[lstGrowthRates.length - 1].decRentRate;
                    objGrowthRates.boolEstimatedPercent= false;
                    objGrowthRates.objPercentRent = objPercentRent;
                    objGrowthRates.datStartDate = this.getNextDay(currentEndDate);
                    objGrowthRates.datEndDate= objGrowthRates.datStartDate;
                    arrGrowthRates.push(objGrowthRates);
                    var validatedRates = this.validateData(arrGrowthRates, leaseExpiryDate);
                    cmp.set('v.lstGrowthRateTable', validatedRates);
                }
            }
        //}
    },
    
    validateData : function(growthRates, expiryDate){
        var allRows = [];
        var prevEndDate;
        for(var i = 0; i < growthRates.length; i++){
            if( i > 0){
                prevEndDate = growthRates[i-1].datEndDate;
            }
            if(prevEndDate != null){
                var newStartDate = this.getNextDay(prevEndDate);
                if(growthRates[i].datStartDate != newStartDate){
                    growthRates[i].datStartDate = newStartDate;
                }
                prevEndDate = growthRates[i].datEndDate;
            }
            if(growthRates[i].datEndDate != null){
                if(growthRates[i].datEndDate >= expiryDate){
                    growthRates[i].datEndDate = expiryDate;
                    allRows.push(growthRates[i]);
                    break;
                }else if(growthRates[i].datStartDate > growthRates[i].datEndDate){
                    growthRates[i].datEndDate = growthRates[i].datStartDate;
                    allRows.push(growthRates[i]);
                    break;
                }
            }
            allRows.push(growthRates[i]);
        }
        return allRows;
    },
    
    clearColumnsInTheList : function(cmp, eve){
        var params = eve.getParam('arguments');
        var lstGrowthRates = params.lstGrowthRate;
        if( lstGrowthRates != undefined){
            for ( var i = 0 ; i < lstGrowthRates.length; i++ ){
                lstGrowthRates[i].decBrkptCalcpercent = null;
                lstGrowthRates[i].decBreakpointAmount = null;
                lstGrowthRates[i].boolEstimatedPercent = false;
                lstGrowthRates[i].decRentRate = null;
            }
            cmp.set('v.lstGrowthRateTable', lstGrowthRates);    
        }        
    },
    
    getNextDay : function(prevDate) {
        var newDate = new Date(prevDate);
        newDate.setDate(newDate.getUTCDate() + 1);
        newDate = this.getFormattedDate(newDate);
        return newDate;
    },
    
    getFormattedDate : function(date) {
        var year = date.getFullYear();
        var month = (1 + date.getMonth()).toString();
        month = month.length > 1 ? month : '0' + month;
        var day = date.getDate().toString();
        day = day.length > 1 ? day : '0' + day;
        return year + '-' + month + '-' + day;
    },
    
    handleEstimateHelper : function(component, setComments){
        var recList = component.get('v.lstGrowthRateTable');
        var showEst = false;
        for(var each in recList){
            if(recList[each].boolEstimatedPercent){
                showEst = true;
                break;
            }
        }
        if(setComments && showEst){
            component.set('v.showComments', showEst);
        }       
    },
    
    checkRows : function(component){
        var recList = component.get('v.lstGrowthRateTable');
        if(recList.length > 0 && $A.util.isUndefinedOrNull(recList[0].objPercentRent)){
            var newRows = [];
            for(var i = 0; i < recList.length; i++){
                var currentRow = this.getNewRow(recList[i]);
                newRows.push(currentRow);
            }
            component.set('v.lstGrowthRateTable', newRows);
            console.log('*****', newRows);
        }
    },
    
    getNewRow : function(aRec){
        return {
            "datStartDate"                          : aRec.datStartDate,
            "datEndDate"                            : aRec.datEndDate,                              
            "decAmount"                             : aRec.decAmount, 
            "decAnnualizedRentPSF"                  : aRec.decAnnualizedRentPSF,
            "boolEstimated"                         : aRec.boolEstimated,
            "decRentStep"                           : aRec.decRentStep,
            "decBreakpointAmount"                   : null,
            "decBrkptCalcpercent"                   : null,
            "decRentRate"                           : null,  
            "nstComments"                           : '',
            "objMinRent" : 
            {
                
                "AnnualizedRent_WF__c" : aRec.decAmount,        
                "AnnualizedRentPSF_WF__c": aRec.decAnnualizedRentPSF,
                "EndDate_WF__c" : aRec.datEndDate,
                "StartDate_WF__c" : aRec.datStartDate,
                "Estimated_WF__c" : aRec.boolEstimated,
                "Increase_WF__c": aRec.decRentStep,              
                "Non_Standard_Comments_WF__c": '',
                "Id" : aRec.objMinRent !== undefined ? aRec.objMinRent.Id : null
            },
            "objPercentRent" : 
            {                        
                "AnnualizedRent_WF__c" : null,
                "BrkptCalcpercent_WF__c" : null,
                "BreakpointAmount_WF__c" : null,
                "EndDate_WF__c" : aRec.datEndDate,
                "StartDate_WF__c" : aRec.datStartDate,
                "Estimated_WF__c" : false,
                "RentRate_WF__c": null,                        
                "Id" : null
            }
        }
    },
    updateTable : function(cmp, eve, isDateUpdate){
        var rentTable = cmp.get('v.lstGrowthRateTable');    
        var isOptions = cmp.get('v.IsOptions');
        var errorCmp = cmp.find('errorId');
        var breakPointPercent;
        if(eve.target !== undefined){
            breakPointPercent = eve.target.value !== '' ? eve.target.value : 0;
            var step = eve.target.getAttribute("data-id");                
        }else {
            if(cmp.get('v.opportunity.BreakpointType_WF__c') == 'Unnatural' && cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Other' ){                                                     
                if(rentTable.length > 1)
                    breakPointPercent = $A.util.isUndefinedOrNull(rentTable[1].decBrkptCalcpercent) ? 0 : rentTable[1].decBrkptCalcpercent;    
            }else{
                if(!$A.util.isUndefinedOrNull(rentTable)){
                    if(rentTable.length > 0 ){
                        breakPointPercent = $A.util.isUndefinedOrNull(rentTable[0].decBrkptCalcpercent) ? 0 : rentTable[0].decBrkptCalcpercent;    
                    }
                }
            }
            
        }
        
        console.log('rentTable.length-->',JSON.stringify(rentTable));
        if(rentTable.length > 0){
            //Changes made by sachin for -ve value validations..                
            if(!isOptions){                
                
                if(cmp.get('v.opportunity.BreakpointType_WF__c') == 'Natural' ){
                    if(rentTable[0].decBrkptCalcpercent >= 0){                        
                        $A.util.addClass(errorCmp , 'slds-hide');            
                        cmp.set('v.IsNegativeValue', false);
                        var breakPointPercentValue = $A.util.isUndefinedOrNull(rentTable[0].decBrkptCalcpercent) ? 0 : rentTable[0].decBrkptCalcpercent;    
                        
                        for(var i = 0; i< rentTable.length ; i++){                    
                            rentTable[i].decBreakpointAmount = breakPointPercentValue != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / breakPointPercentValue) : 0.00;
                            rentTable[i].decBrkptCalcpercent = breakPointPercentValue;                    
                            rentTable[i].decRentRate = breakPointPercentValue;
                        }        
                    }else if(rentTable[0].decBrkptCalcpercent < 0){
                        $A.util.removeClass(errorCmp , 'slds-hide'); 
                        cmp.set('v.IsNegativeValue', true);
                    }
                }else if(cmp.get('v.opportunity.BreakpointType_WF__c') == 'Unnatural' && cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Minimum Rent' ){                                                               
                    
                    if(rentTable.length > 0){
                        if(breakPointPercent >= 0){
                            $A.util.addClass(errorCmp , 'slds-hide');    
                            cmp.set('v.IsNegativeValue', false);
                            if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                
                                for(var i = 0; i < rentTable.length; i++){
                                    rentTable[i].decBreakpointAmount = breakPointPercent != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / breakPointPercent) : 0;
                                    rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                }
                            }else if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                                                      
                                if(step != undefined){
                                    rentTable[step].decBreakpointAmount= breakPointPercent != 0 ? (( Number(rentTable[step].decAmount) * 100 ) / breakPointPercent) : 0;                                                
                                    rentTable[step].decBrkptCalcpercent = breakPointPercent;    
                                }else{
                                    for(var i = 0; i < rentTable.length; i++){
                                        rentTable[i].decBreakpointAmount = rentTable[i].decBrkptCalcpercent != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / rentTable[i].decBrkptCalcpercent) : 0;
                                        //rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                    }
                                }
                                
                            }                         
                        }else if( breakPointPercent < 0 ){
                            $A.util.removeClass(errorCmp , 'slds-hide');            
                            cmp.set('v.IsNegativeValue', true);
                        }                           
                    }                                
                }else if(cmp.get('v.opportunity.BreakpointType_WF__c') == 'Unnatural' && cmp.get('v.opportunity.RentTypeBasis_WF__c') ==='Other' ){                                                     
                    
                    if(rentTable.length > 0){
                        if(breakPointPercent >= 0 && rentTable[0].decBreakpointAmount >= 0){
                                
                                $A.util.addClass(errorCmp , 'slds-hide');  
                                cmp.set('v.IsNegativeValue', false);
                                if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                    for(var i = 1; i < rentTable.length; i++){                            
                                        var breakAmount = Number(rentTable[i-1].decBreakpointAmount) + (Number(rentTable[i-1].decBreakpointAmount) * breakPointPercent) / 100;
                                        rentTable[i].decBreakpointAmount = parseFloat(breakAmount).toFixed(2);
                                        rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                    }
                                }else if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                            
                                    for(var i = step; i < rentTable.length; i++){                                                            
                                            console.log(' break point value ----> ', rentTable[i].decBrkptCalcpercent);
                                            if(i == step){
                                                rentTable[i].decBreakpointAmount= breakPointPercent !== 0 ? parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * breakPointPercent) / 100)).toFixed(2) : Number(rentTable[i-1].decBreakpointAmount);    
                                            }else{
                                                rentTable[i].decBreakpointAmount= rentTable[i].decBrkptCalcpercent !== 0 ? parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100)).toFixed(2) : Number(rentTable[i-1].decBreakpointAmount);    
                                            }                                        
                                        rentTable[step].decBrkptCalcpercent = breakPointPercent;                                                                                                            
                                    }
                                }else if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                                    for(var i = 1; i < rentTable.length; i++){                            
                                        rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(breakPointPercent);
                                        rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                    }
                                }else if(cmp.get('v.opportunity.BreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                                    for(var i = step; i < rentTable.length; i++){  
                                        if(i == step)
                                            rentTable[i].decBreakpointAmount = breakPointPercent !== 0 ? Number(rentTable[i-1].decBreakpointAmount) + Number(breakPointPercent) : Number(rentTable[i-1].decBreakpointAmount);
                                        else
                                            rentTable[i].decBreakpointAmount = rentTable[i].decBrkptCalcpercent !== 0 ? Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent) : Number(rentTable[i-1].decBreakpointAmount);
                                        rentTable[step].decBrkptCalcpercent = breakPointPercent;
                                    }
                                }
                            }else if( breakPointPercent < 0 ){
                                $A.util.removeClass(errorCmp , 'slds-hide');  
                                cmp.set('v.IsNegativeValue', true);
                            }                           
                        
                        
                    }             
                }
                cmp.set('v.lstGrowthRateTable', rentTable);                 
                // Changes by sachin for -ve value validation's                            
            }else{
                
                if(cmp.get('v.opportunity.OptionsBreakpointType_WF__c') == 'Natural' ){
                    if(rentTable[0].decBrkptCalcpercent >= 0){
                        $A.util.addClass(errorCmp , 'slds-hide');
                        cmp.set('v.IsNegativeValue', false);
                        var breakPointPercentValue = rentTable[0].decBrkptCalcpercent;                        
                        
                        for(var i = 0; i< rentTable.length ; i++){                    
                            rentTable[i].decBreakpointAmount = breakPointPercentValue != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / breakPointPercentValue) : 0.00;
                            rentTable[i].decBrkptCalcpercent = breakPointPercentValue;                    
                            rentTable[i].decRentRate = breakPointPercentValue;
                        }        
                    }else if(rentTable[0].decBrkptCalcpercent < 0){
                        $A.util.removeClass(errorCmp , 'slds-hide');  
                        cmp.set('v.IsNegativeValue', true);
                    }
                }else if(cmp.get('v.opportunity.OptionsBreakpointType_WF__c') == 'Unnatural' && cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Minimum Rent' ){                                                               
                    
                    if(rentTable.length > 0){
                        if(breakPointPercent >= 0 ){
                            $A.util.addClass(errorCmp , 'slds-hide');  
                            cmp.set('v.IsNegativeValue', false);
                            if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                
                                for(var i = 0; i < rentTable.length; i++){
                                    rentTable[i].decBreakpointAmount = breakPointPercent != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / breakPointPercent) : 0.00;
                                    rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                }
                            }else if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                       
                                if(step != undefined){
                                    rentTable[step].decBreakpointAmount= breakPointPercent != 0 ? (( Number(rentTable[step].decAmount) * 100 ) / breakPointPercent) : 0.00;                                                
                                    rentTable[step].decBrkptCalcpercent = breakPointPercent;    
                                }else{
                                    for(var i = 0; i < rentTable.length; i++){
                                        rentTable[i].decBreakpointAmount = rentTable[i].decBrkptCalcpercent != 0 ? (( Number(rentTable[i].decAmount) * 100 ) / rentTable[i].decBrkptCalcpercent) : 0.00;
                                        rentTable[i].decBrkptCalcpercent = rentTable[i].decBrkptCalcpercent;
                                    }   
                                }
                                
                            }                          
                        }else if(breakPointPercent < 0){                            
                            $A.util.removeClass(errorCmp , 'slds-hide');  
                            cmp.set('v.IsNegativeValue', true);
                        }                   
                    }                                
                }else if(cmp.get('v.opportunity.OptionsBreakpointType_WF__c') == 'Unnatural' && cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') ==='Other' ){                                                     
                    
                    if(rentTable.length > 0){
                        
                            if(breakPointPercent >= 0 && rentTable[0].decBreakpointAmount >= 0){
                                $A.util.addClass(errorCmp , 'slds-hide');  
                                cmp.set('v.IsNegativeValue', false);
                                if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                    for(var i = 1; i < rentTable.length; i++){                            
                                        rentTable[i].decBreakpointAmount = parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * breakPointPercent) / 100)).toFixed(2);
                                        rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                    }
                                }else if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                            
                                    if(step != undefined){
                                        for(var i = step; i < rentTable.length; i++){                                                            
                                            if( i == step)
                                            rentTable[i].decBreakpointAmount= i > 0 ? parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * breakPointPercent) / 100)).toFixed(2) : 0.00;
                                            else
                                                rentTable[i].decBreakpointAmount= rentTable[i].decBrkptCalcpercent !== 0 ? parseFloat(Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100)).toFixed(2) : 0.00;
                                            rentTable[step].decBrkptCalcpercent = breakPointPercent;                                                                                                            
                                        }    
                                    }else{
                                        for(var i = 1; i < rentTable.length; i++){                                                                                              
                                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + (( Number(rentTable[i-1].decBreakpointAmount) * rentTable[i].decBrkptCalcpercent) / 100);                                            
                                        }   
                                    }
                                }else if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                                    for(var i = 0; i < rentTable.length; i++){ 
                                        if(i==0){
                                            rentTable[i].decBreakpointAmount = Number(rentTable[i].decBreakpointAmount);
                                        }else{
                                        rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(breakPointPercent);
                                        rentTable[i].decBrkptCalcpercent = breakPointPercent;
                                        }
                                    }
                                }else if(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                                    if(step != undefined){
                                        for(var i = step; i < rentTable.length; i++){                            
                                            if( i == step)
                                            rentTable[i].decBreakpointAmount = i > 0 ? Number(rentTable[i-1].decBreakpointAmount) + Number(breakPointPercent) : 0.00;
                                            else
                                                rentTable[i].decBreakpointAmount = rentTable[i].decBrkptCalcpercent !== 0 ? Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent) : 0.00;
                                            rentTable[step].decBrkptCalcpercent = breakPointPercent;
                                        }    
                                    }else{
                                        for(var i = 0; i < rentTable.length; i++){                            
                                            if(i==0){
                                                rentTable[i].decBreakpointAmount = Number(rentTable[i].decBreakpointAmount);                                            
                                            }else
                                                rentTable[i].decBreakpointAmount = Number(rentTable[i-1].decBreakpointAmount) + Number(rentTable[i].decBrkptCalcpercent);                                            
                                        }  
                                    }
                                    
                                }
                            }else if( breakPointPercent < 0){
                                $A.util.removeClass(errorCmp , 'slds-hide');  
                                cmp.set('v.IsNegativeValue', true);
                            }
                        
                    }               
                }
                cmp.set('v.lstGrowthRateTable', rentTable); 
            }
        }
    },
    calculateRentRate : function(cmp,eve, isDateUpdate){
        var rentPercent;
        var rentList = cmp.get('v.lstGrowthRateTable');
        var isOptions = cmp.get('v.IsOptions');
        var errorCmp = cmp.find('errorId');
        
         if(eve.target != undefined){
             rentPercent = eve.target.value !== "" ? eve.target.value : 0;
         }else if(isDateUpdate){
             if(!$A.util.isUndefinedOrNull(rentList)){
                 if(rentList.length > 0){
                     rentPercent = $A.util.isUndefinedOrNull(rentList[0].decRentRate) ? 0 : rentList[0].decRentRate;
                 }
             }          
         }
        
        if(rentList.length > 0){
            if(rentPercent >= 0){
                var isBreakPointAmountNegative = false;
                var isBreakPointPercentNegative = false;
                for( var i = 0; i < rentList.length; i++){
                    if(rentList[i].decBreakpointAmount < 0){
                        isBreakPointAmountNegative = true;
                    }
                    if(rentList[i].decBrkptCalcpercent < 0){
                        isBreakPointPercentNegative = true;
                    }
                }
                if(!(isBreakPointPercentNegative || isBreakPointAmountNegative)){
                    $A.util.addClass(errorCmp, 'slds-hide');   
                    cmp.set('v.IsNegativeValue', false);
                }
                if(!isOptions){
                    
                    
                    if(cmp.get('v.opportunity.PercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Same_WF")){                    
                        for(var i = 0; i < rentList.length; i++){                           
                            rentList[i].decRentRate = rentPercent;
                        }
                    } else if(cmp.get('v.opportunity.PercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Diff_WF")){
                        for(var i = 0; i < rentList.length; i++){
                            if(eve.target != undefined){
                                if(i == eve.target.getAttribute("data-id") ){
                                    rentList[i].decRentRate = rentPercent;
                                }   
                            }                            
                        }
                    }
                    cmp.set('v.lstGrowthRateTable', rentList); 
                    
                }else{
                    if(cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Same_WF")){                    
                        for(var i = 0; i < rentList.length; i++){                           
                            rentList[i].decRentRate = rentPercent;
                        }
                    }else if(cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') === $A.get("$Label.c.Percent_Rent_Rate_Diff_WF")){
                        for(var i = 0; i < rentList.length; i++){
                            if(eve.target != undefined){
                                if(i == eve.target.getAttribute("data-id") ){                                
                                    rentList[i].decRentRate = rentPercent;
                                }    
                            }
                                                                    
                        }
                    }                                                                        
                    cmp.set('v.lstGrowthRateTable', rentList);                  
                }                
            }
            else if(rentPercent < 0){
                $A.util.removeClass(errorCmp, 'slds-hide');
                cmp.set('v.IsNegativeValue', true);
            }
        }
        
    },
    validateNonStdCmnts:function(cmp,eve)
    {
       console.log("inside helper");
	   if(cmp.get('v.result')!== undefined || cmp.get('v.result')== null){
        var result = cmp.get('v.result');        
       console.log("rsult");
        if(result.covenantTextFieldMa!== undefined || result.covenantTextFieldMa!== null){
        var covenantTextFieldMap =result.covenantTextFieldMap;
        }
	   }
        if(cmp.get('v.lstGrowthRateTable') !== undefined || cmp.get('v.lstGrowthRateTable') !== null){
        var lstGrowthRateTable = cmp.get('v.lstGrowthRateTable');
        }
       // console.log("lstGrowthRateTable...././././.",lstGrowthRateTable);
        var isError=false;
        var isOptnError=false;

         for(var i=0;i<lstGrowthRateTable.length;i++)
         {
           
             //console.log("inside this method",lstGrowthRateTable[i].nstComments);
             if(!$A.util.isUndefinedOrNull(lstGrowthRateTable[i].percentComments) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['PercentNonStandardComments_WF__c']) 
                & lstGrowthRateTable[i].percentComments.length > covenantTextFieldMap['PercentNonStandardComments_WF__c'])
             {
                  console.log("INSIDE LEGTH ERRO");
                 if(cmp.get('v.IsOptions')==true)
                 {
                     console.log("OPTION INSIDE IF");
                     $A.util.removeClass(document.getElementById('percentCommentsOthrErrId'+i),'slds-hide');
                    isOptnError=true;
                 }else{
                       console.log("OPTION INSIDE NORML PER");
                      $A.util.removeClass(document.getElementById('percentCommentsErrId'+i),'slds-hide');
                     isError=true;
                 }
                 
                
             }else{
                
                if(cmp.get('v.IsOptions')==true)
                 {
                     console.log("OPTION INSIDE ELSE OF OPTION");
                    $A.util.addClass(document.getElementById('percentCommentsOthrErrId'+i),'slds-hide');
                      cmp.set("v.percentCommentsOthrErr",false);
                 }else{
                     console.log("OPTION INSIDE ELSE OF NORMAL");
                      $A.util.addClass(document.getElementById('percentCommentsErrId'+i),'slds-hide');
                     cmp.set("v.percentCommentsErr",false);
                 }
             }
         }
        if(isError)
        {
              cmp.set("v.percentCommentsErr",true);
        }
        if(isOptnError)
        {

            cmp.set("v.percentCommentsOthrErr",true);            
        }

    }
})