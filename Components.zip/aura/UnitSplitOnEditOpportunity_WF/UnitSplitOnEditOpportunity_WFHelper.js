({
    doInitHelper : function(component, event) {
        
        var idCenter = component.get('v.center');
        var idOpportunity = component.get('v.idOpportunity');
        var action = component.get('c.getUnitConfigurationsOnOppty');
        action.setParams({
            "idOpportunity":idOpportunity,
            "boolIsMerge":Boolean(component.get('v.boolIsMerge'))
        });
        action.setCallback(this, function(response){
            var result;
            
            var state = response.getState();
            if( state == 'SUCCESS'){
                result = response.getReturnValue(); 
                component.set('v.productDetails', result);   
                var selectedProducts = [];
                //var remainingGLAProducts = [];
                var unitConfigs =[];
                var remainingGLAProduct;
                var productIds = [];
                var obj = JSON.parse(JSON.stringify(component.get('v.productDetails')));
                if(obj!=null){
                    for(var i=0;i<obj.length;i++){
                        if(obj[i].selected == true){
                            selectedProducts.push(obj[i]);
                            productIds.push(obj[i].idProduct);
                        }
                        else{
                            unitConfigs.push(obj[i]);
                            productIds.push(obj[i].idProduct);
                        }
                    }
                    var errors = [];
                    if(selectedProducts.length>=1){
                        component.set('v.selectedProducts',selectedProducts);
                        component.set('v.strProductIds',JSON.stringify(productIds));
                    }
                    if(unitConfigs.length>=1){
                        component.set('v.remainingGLAProducts',unitConfigs);                    
                    }
                    
                    else{
                        errors.push('No prior Tenant\'s information present!');
                        component.set('v.errors',errors);
                    }
                }
            }
        });
        $A.enqueueAction(action);
        
    },
    
    getRelatedUnits : function(component, event, invokedFrom) {
        var page = component.get("v.page") || 1;
        if(invokedFrom == 'getUnits'){
            var direction = event.getParam("direction");
            page = direction === "previous" ? (page - 1) : (page + 1);
        }
        var idCenter = component.get('v.center');
        var action = component.get('c.getProductDetails');
        var selectedUnit = component.get('v.addProduct');
        action.setParams({
            "strCenter":idCenter,
            "pageNumber": page
        });
        action.setCallback(this, function(response){            
            var state = response.getState();
            if( state == 'SUCCESS'){
                var result = response.getReturnValue();                
                component.set('v.page', result.page);
                component.set('v.pages', (Math.ceil(result.total/result.pageSize)));
                component.set('v.total', result.total);               
                component.set('v.products', result.lstProduct);
            }
            
        });
        $A.enqueueAction(action);
    }
    
})