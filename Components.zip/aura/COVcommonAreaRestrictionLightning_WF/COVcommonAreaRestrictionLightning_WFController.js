({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        console.log('common',covenant);
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Common Area Restrictions']){
                console.log('common',covenant[item]);
                component.set('v.commonArRestriction',covenant[item]);
                isPresent = true;
            }
        }
        if(!isPresent){
            var commonArRestriction = {};
            commonArRestriction.RecordTypeId =component.get('v.CovenantRecordType')['Common Area Restrictions'];
            component.set('v.commonArRestriction',commonArRestriction);
            covenant.push(component.get('v.commonArRestriction'));
            component.set('v.Covenant',covenant);
        }
        helper.setPicklistValues(component,component.get('v.result'));
	},
    enableHelpTextCAR : function(component, event, helper){
        component.set('v.showHelpTextCAR',true);
    },
    disableHelpText : function(component, event, helper){
        component.set('v.showHelpTextCAR',false);
    },
    changeCommonAreaRestriction: function(component, event, helper){
        component.set('v.commonArRestriction.Competing_Use_WF__c',false);
        component.set('v.commonArRestriction.IfCompetingUseNoofFt_WF__c',0);
        component.set('v.commonArRestriction.IfCompetingUseDescription_WF__c','');
        component.set('v.commonArRestriction.RestrictionType_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cRestrictionType_WF__c'))){
            component.find('Covenant_WF__cRestrictionType_WF__c').reInit();
        }
        component.set('v.commonArRestriction.Description_Restriction_Type_WF__c','');
        
		component.set('v.commonArRestriction.AreaRestrictionUnitofMeasure_WF__c','');
		if(!$A.util.isUndefinedOrNull(component.find('Covenant_WF__cAreaRestrictionUnitofMeasure_WF__c'))){
            component.find('Covenant_WF__cAreaRestrictionUnitofMeasure_WF__c').reInit();
        }
        component.set('v.commonArRestriction.LLrighttorenewexisting_WF__c',false);
        component.set('v.commonArRestriction.DistancefromStorefront_WF__c',0);
        component.set('v.commonArRestriction.LLrighttoreplaceexisting_WF__c',false);
        component.set('v.commonArRestriction.Duration_of_Restriction_WF__c',0);
        component.set('v.commonArRestriction.LandlordPenalty_WF__c',0);
    },
    changeCompetingUse : function(component, event, helper){
        component.set('v.commonArRestriction.IfCompetingUseNoofFt_WF__c',0);
        component.set('v.commonArRestriction.IfCompetingUseDescription_WF__c','');
    },
})