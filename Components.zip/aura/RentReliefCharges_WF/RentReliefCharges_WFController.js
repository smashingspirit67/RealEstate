({
    doInit : function(component, event, helper) {
        var charges = component.get('v.Charges');
        if(charges.OperatingExpenseRentRelief_WF__c == null || typeof charges.OperatingExpenseRentRelief_WF__c == "undefined"){
            charges.OperatingExpenseRentRelief_WF__c = 0;
        }
        if(charges.InsuranceRentRelief_WF__c == null || typeof charges.InsuranceRentRelief_WF__c == "undefined"){
            charges.InsuranceRentRelief_WF__c = 0;
        }
        if(charges.FoodCourtExpenseRentRelief_WF__c == null || typeof charges.FoodCourtExpenseRentRelief_WF__c == "undefined"){
            charges.FoodCourtExpenseRentRelief_WF__c = 0;
        }
        if(charges.PromotionalChargesRentRelief_WF__c == null || typeof charges.PromotionalChargesRentRelief_WF__c == "undefined"){
            charges.PromotionalChargesRentRelief_WF__c = 0;
        }
        if(charges.RealEstateTaxRentRelief_WF__c == null || typeof charges.RealEstateTaxRentRelief_WF__c == "undefined"){
            charges.RealEstateTaxRentRelief_WF__c = 0;
        }
        if(charges.Water_WF__c == null || typeof charges.Water_WF__c == "undefined"){
            charges.Water_WF__c = 0;
        }
        if(charges.EncldMallHVAC_WF__c == null || typeof charges.EncldMallHVAC_WF__c == "undefined"){
            charges.EncldMallHVAC_WF__c = 0;
        }
        if(charges.Electricity_WF__c == null || typeof charges.Electricity_WF__c == "undefined"){
            charges.Electricity_WF__c = 0;
        }
        if(charges.Parking_WF__c == null || typeof charges.Parking_WF__c == "undefined"){
            charges.Parking_WF__c = 0;
        }
        if(charges.StateSalesTax_WF__c == null || typeof charges.StateSalesTax_WF__c == "undefined"){
            charges.StateSalesTax_WF__c = 0;
        }
        if(charges.FDS_WF__c == null || typeof charges.FDS_WF__c == "undefined"){
            charges.FDS_WF__c = 0;
        }
        if(charges.TTHVACCPLChilledWater_WF__c == null || typeof charges.TTHVACCPLChilledWater_WF__c == "undefined"){
            charges.TTHVACCPLChilledWater_WF__c = 0;
        }
        if(charges.Trash_WF__c == null || typeof charges.Trash_WF__c == "undefined"){
            charges.Trash_WF__c = 0;
        }
        if(charges.Gas_WF__c == null || typeof charges.Gas_WF__c == "undefined"){
            charges.Gas_WF__c = 0;
        }
        if(charges.OtherCharge1_WF__c == null || typeof charges.OtherCharge1_WF__c == "undefined"){
            charges.OtherCharge1_WF__c = 0;
        }
        component.set('v.Charges',charges);
    },
})