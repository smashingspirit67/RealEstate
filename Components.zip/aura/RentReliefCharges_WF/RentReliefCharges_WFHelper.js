({
	helperMethod : function() {
		
	},
	validateHelper : function(component, event, helper){
        
        
        console.log('+++ currentPriorYearMonths '+component.get('v.Amendment.uncommittedBudgetRelief'));
        var validForm = true;
        if ($A.util.isEmpty(component.get('v.Amendment.uncommittedBudgetRelief')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.rolling12AnnualSales')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.rolling12AnnualSalesPSF')) ){
            validForm = false;
        }
        
        if ($A.util.isEmpty(component.get('v.Amendment.reliefEndDate')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.reliefEndDate')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.currentYearVarBudgetvsActual')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.occupancyCost')) ){
            validForm = false;
        }
        if ($A.util.isEmpty(component.get('v.Amendment.occupancyCostProposedRentRelief')) ){
            validForm = false;
        }
        
        if(validForm == true ){        
			helper.saveHelper(component, event);
        }
	},
	handleError:function(cmp,event,helper){
        var comp = event.getSource();
        $A.util.addClass(comp, "error");   
    },
})