({
    selectProductsforReconfigHelper : function(cmp){
        var selectedProducts = [];
        var remainingGLAProducts = [];
        var remainingGLAProduct = [];
        var productIds = [];
        var GLASum = 0;
        var obj = JSON.parse(JSON.stringify(cmp.get('v.addProduct')));
        for(var i=0;i<obj.length;i++){          
            if(obj[i].selected == true){
                selectedProducts.push(obj[i]);
                productIds.push(obj[i].idProduct);
                GLASum = GLASum + obj[i].GLA;
            }
        }
        if(GLASum==0){
            cmp.set('v.GLAZero',true);
            cmp.set('v.boolMerge', 'false');
            return;
        }else{
            cmp.set('v.GLAZero',false);
        }      
        
        var strErrors = [];
        if(selectedProducts.length>0){
            remainingGLAProduct = JSON.parse(JSON.stringify(selectedProducts))[0];
            remainingGLAProduct.idProduct = "";
            remainingGLAProduct.selected = false;
            remainingGLAProduct.unitNo = "";
            remainingGLAProduct.dealUnitNumber = "";
            remainingGLAProduct.productType = "";
            remainingGLAProduct.occupied = "";
            remainingGLAProduct.expirationDate = null;
            remainingGLAProduct.GLA = null;
            remainingGLAProduct.tenantName = "";
            remainingGLAProduct.proposedGLA = null;
            remainingGLAProduct.remainingGLA = null;
            remainingGLAProduct.IsRemainingGLA = true;
            remainingGLAProducts.push(remainingGLAProduct);
            var allUnitConfigs = [];
            if(!$A.util.isUndefinedOrNull(remainingGLAProducts) && !$A.util.isUndefinedOrNull(selectedProducts)){
                if(remainingGLAProducts.length > 0 && selectedProducts.length >  0){
                    allUnitConfigs = selectedProducts.concat(remainingGLAProducts);
                    cmp.set('v.allUnitConfigs', allUnitConfigs);
                }else if (selectedProducts.length > 0){
                    cmp.set('v.allUnitConfigs', selectedProducts);
                }else if( remainingGLAProducts.length >  0 ){
                    cmp.set('v.allUnitConfigs', remainingGLAProducts);
                }
            }else if (!$A.util.isUndefinedOrNull(selectedProducts)){
                if (selectedProducts.length > 0)
                    cmp.set('v.allUnitConfigs', selectedProducts);
            }else if(!$A.util.isUndefinedOrNull(remainingGLAProducts)){
                if (remainingGLAProducts.length > 0)
                    cmp.set('v.allUnitConfigs', remainingGLAProducts);
            }             
            cmp.set('v.selectedProducts',selectedProducts);
            cmp.set('v.strProductIds',JSON.stringify(productIds));
            cmp.set('v.boolMerge', true);
            cmp.set('v.remainingGLAProducts',remainingGLAProducts);
            cmp.set('v.strErrors',[]);
            cmp.set('v.boolChangeOpportunity', false);
            cmp.set('v.intTotalProposedGLA',null);
            console.log('selectedProducts',selectedProducts);
            console.log('productIds',productIds);
        }
        else{
            strErrors.push('Please select atleast one product.');
            cmp.set('v.strErrors',strErrors);
        }
        
    },
    createUnitConfigsHelper : function(component){
        var strSelectedProducts = JSON.stringify(component.get('v.selectedProducts'));
        var selectedProducts = [];
        var remainingGLAProducts = [];
        var remainingGLAProductsNonEmpty = [];
        var strErrors = [];
        var errorBlankFields = '';
        var errorGLANotConsumed = '';
        var errorFillAllProposedGLAs = '';
        var errorFillProposedUnitNumber = '';
        var errorProposedGLAZeroforRemainingUnits = '';
        var errorNegativeProposedGLA = '';
        var errorUnitNoPattern = '';
        var allZeros = true;
        var selectedProductNames = ''; //GDM-8240-#7
        var errorInvalidParentUnit = ''; //GDM-8240-#7
        remainingGLAProducts = JSON.parse(JSON.stringify(component.get('v.remainingGLAProducts')));
        selectedProducts = JSON.parse(JSON.stringify(component.get('v.selectedProducts')));
        
        var sumSelectedRemainingGLA = 0;
        var countNumberOfDealUnits = 0;
        if(selectedProducts.length > 1){
            for(i=0;i<selectedProducts.length;i++){
                selectedProductNames += selectedProducts[i].unitNo+';'; //GDM-8240-#7
                sumSelectedRemainingGLA = sumSelectedRemainingGLA + selectedProducts[i].remainingGLA;
                if(selectedProducts[i].proposedGLA == null && errorFillAllProposedGLAs == ''){
                    errorFillAllProposedGLAs = 'Please fill Proposed GLA for all selected units';
                }
                else if(selectedProducts[i].proposedGLA != null && selectedProducts[i].proposedGLA < 0){
                    errorNegativeProposedGLA = 'Please select positive values for Proposed GLA';
                }
                if(selectedProducts[i].selectedDealUnit === true){
                    component.set('v.productSelected', selectedProducts[i].prodRecord);
                    if((selectedProducts[i].dealUnitNumber === null || selectedProducts[i].dealUnitNumber === '') && errorFillProposedUnitNumber == ''){
                        errorFillProposedUnitNumber = 'Proposed Unit Number is mandatory for the unit selected for deal.'
                    }
                    component.set('v.strProducts',selectedProducts[i].dealUnitNumber);
                    countNumberOfDealUnits = countNumberOfDealUnits + 1;
                }
                if(selectedProducts[i].dealUnitNumber != null && selectedProducts[i].dealUnitNumber.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]")){
                    errorUnitNoPattern = 'Please enter alphanumeric values for Unit Number';
                }
                //Joshna, 26/2/18 - added this if block to fix GDM-7905
                if(!$A.util.isUndefinedOrNull(selectedProducts[i].proposedGLA) && selectedProducts[i].proposedGLA > 0){
                    allZeros = false;
                }
            }
        }
        else{
            sumSelectedRemainingGLA = sumSelectedRemainingGLA + selectedProducts[0].remainingGLA;
            selectedProductNames += selectedProducts[0].unitNo+';'; //GDM-8240-#7
            //setting the IsPrimary to true as this is the only selected componenet for split
            selectedProducts[0].selectedDealUnit = true;            
            if(selectedProducts[0].proposedGLA == null && errorFillAllProposedGLAs == ''){
                errorFillAllProposedGLAs = 'Please fill Proposed GLA for all selected units';
            }
            else if(selectedProducts[0].proposedGLA != null && selectedProducts[0].proposedGLA < 0){
                errorNegativeProposedGLA = 'Please select positive values for Proposed GLA';
            }
            //Joshna, 26/2/18 - added this if block to fix GDM-7905
            if(!$A.util.isUndefinedOrNull(selectedProducts[0].proposedGLA) && selectedProducts[0].proposedGLA > 0){
            	allZeros = false;
            }
            if(selectedProducts[0].dealUnitNumber == '' && errorFillProposedUnitNumber == ''){
                errorFillProposedUnitNumber = 'Proposed Unit Number is mandatory for the unit selected for deal.';
            }
            component.set('v.strProducts',selectedProducts[0].dealUnitNumber);
            if(selectedProducts[0].dealUnitNumber != null && selectedProducts[0].dealUnitNumber.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]")){
                errorUnitNoPattern = 'Please enter alphanumeric values for Unit Number';
            }
            component.set('v.productSelected', selectedProducts[0].prodRecord);
        }
        console.log(component.get('v.strProducts'));
        if(errorFillAllProposedGLAs != ''){
            strErrors.push(errorFillAllProposedGLAs);
        }
        //Joshna, 26/2/18 - added this if block to fix GDM-7905
        if(allZeros){
        	strErrors.push($A.get("$Label.c.GLA_Mandatory_WF"));
        }
        if(errorNegativeProposedGLA != ''){
            strErrors.push(errorNegativeProposedGLA);
        }
        if(selectedProducts.length > 1 && (countNumberOfDealUnits == 0 || countNumberOfDealUnits > 1)){
            strErrors.push('Please select one unit number for deal');
        }
        if(errorFillProposedUnitNumber != ''){
            strErrors.push(errorFillProposedUnitNumber);
        }
        var intCountnullfields;
        var sumRemainingGLA = 0;
        var productNames ;
        productNames = selectedProductNames.split(";"); //GDM-8240-#7

        for(var i=0;i<remainingGLAProducts.length;i++){
            intCountnullfields = 0;
            if(remainingGLAProducts[i].unitNo == ""){
                intCountnullfields = Number(intCountnullfields) + 1;
            }
            if(remainingGLAProducts[i].proposedGLA == null){                
                intCountnullfields = Number(intCountnullfields) + 1;              
            }
            if(remainingGLAProducts[i].dealUnitNumber == "" && remainingGLAProducts[i].productType != "Common Area" && remainingGLAProducts[i].productType != "Void"){                
                intCountnullfields = Number(intCountnullfields) + 1;                
            }
            else if(remainingGLAProducts[i].dealUnitNumber != null && remainingGLAProducts[i].dealUnitNumber.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]")){
                errorUnitNoPattern = 'Please enter alphanumeric values for Unit Number';
            }            
            if(intCountnullfields>=0 && intCountnullfields<3){
                if(remainingGLAProducts[i].proposedGLA != null){
                    sumRemainingGLA = sumRemainingGLA + remainingGLAProducts[i].proposedGLA;console.log('15');
                }
                if(remainingGLAProducts[i].proposedGLA == 0 && errorProposedGLAZeroforRemainingUnits == ''){
                    errorProposedGLAZeroforRemainingUnits = 'Please enter non-zero values for proposed GLA in all units for remaining GLAs';console.log('16');
                }
                remainingGLAProducts[i].IsRemainingGLA = true;
                remainingGLAProductsNonEmpty.push(remainingGLAProducts[i]);
            }
            if(intCountnullfields>0 && intCountnullfields<3 && errorBlankFields == ''){console.log('16');
                                                                                       errorBlankFields = 'Please fill all the fields of units to be created for Remaining GLA.';
                                                                                      }
            if (productNames.length!=0 && productNames.indexOf(remainingGLAProducts[i].unitNo)<0 && errorInvalidParentUnit == ''){
                errorInvalidParentUnit = 'Please enter the valid Parent Unit #';
            }   //added this if block to fix GDM-8240-#7                                                              
            
        }
        
        if (errorInvalidParentUnit != ''){
            strErrors.push(errorInvalidParentUnit); //GDM-8240-#7
        }
        if(errorProposedGLAZeroforRemainingUnits != ''){
            strErrors.push(errorProposedGLAZeroforRemainingUnits);
        }
        if(errorBlankFields != ''){
            strErrors.push(errorBlankFields);
        }
        sumSelectedRemainingGLA = Math.floor(sumSelectedRemainingGLA);
        if(sumSelectedRemainingGLA > sumRemainingGLA){
            errorGLANotConsumed = 'Please use all remaining GLA for selected units.';
        }
        if(errorGLANotConsumed != ''){
            strErrors.push(errorGLANotConsumed);
        }
        if(errorUnitNoPattern != ''){
            strErrors.push(errorUnitNoPattern);
        }
        if(strErrors.length>0){
            component.set('v.strErrors',strErrors);
        }
        else{
            
            if(component.get('v.datStartDate') != null && component.get('v.datStartDate') != ''){
                component.set('v.datUCStart', component.get('v.datStartDate'));                                                
            }
            if(component.get('v.datExpiryDate') != null && component.get('v.datExpiryDate') != ''){
                component.set('v.datUCEnd', component.get('v.datExpiryDate'));
            } 
            if(component.get('v.idCenterName') != null && component.get('v.idCenter') != component.get('v.idCenterName')){                                                
                component.set('v.idCenter', selectedProducts[0].idCenter);
                component.set('v.strcenterName', selectedProducts[0].strCenter);
            }
            var action = component.get('c.getUnitConfigs');
            action.setParams({
                "strSelectedProducts":JSON.stringify(selectedProducts),
                "strUnitsForRemainingGLAs":JSON.stringify(remainingGLAProductsNonEmpty),
                "boolIsMerge":Boolean(component.get('v.boolIsMerge'))
            });
            
            action.setCallback(this, function(response){
                var result;
                var state = response.getState();
                
                if( state == 'SUCCESS'){
                    result = response.getReturnValue();
                    var unitNumberToSave = component.get('v.strProducts');
                    var centerOnOffer = component.get('v.centerOnOffer');
                    var centerRec = component.get('v.centerRec');
                    
					if(!$A.util.isUndefinedOrNull(centerOnOffer) && !$A.util.isUndefinedOrNull(centerRec) && centerOnOffer != centerRec){
                        //component.set('v.centerOnOffer', centerRec);
                    }                    
                    var allUnitConfigs = [];
                    if(!$A.util.isUndefinedOrNull(remainingGLAProducts) && !$A.util.isUndefinedOrNull(selectedProducts)){
                        if(remainingGLAProducts.length > 0 && selectedProducts.length >  0){
                            allUnitConfigs = selectedProducts.concat(remainingGLAProducts);
                            component.set('v.allUnitConfigs', allUnitConfigs);
                        }else if (selectedProducts.length > 0){
                            component.set('v.allUnitConfigs', selectedProducts);
                        }else if( remainingGLAProducts.length >  0 ){
                            component.set('v.allUnitConfigs', remainingGLAProducts);
                        }
                    }else if (!$A.util.isUndefinedOrNull(selectedProducts)){
                        if (selectedProducts.length > 0)
                            component.set('v.allUnitConfigs', selectedProducts);
                    }else if(!$A.util.isUndefinedOrNull(remainingGLAProducts)){
                        if (remainingGLAProducts.length > 0)
                            component.set('v.allUnitConfigs', remainingGLAProducts);
                    }                    

                    component.set('v.strProducts', unitNumberToSave);
                    component.set('v.unitConfig',result);                    
                    var opty = component.get('v.opportunity');
                    var sObjOppBU;
                    var sObjOppRefBU;
                    
					if(!$A.util.isUndefinedOrNull(opty)){
						if($A.util.isUndefinedOrNull(opty.StageName) || opty.StageName != 'Offer'){
							/* Author - Sachin. Added the below logic as part of defect GDM-7729. When we are trying to create a new Renewal Amendment 
		            from a lease which has an opportunity linked via Opportunity__c variable it was failing whilie deserializing the opportunity in PrepareBudgetData method 
			    in the offer details controller */
                            if(!$A.util.isUndefinedOrNull(opty.Opportunity__c)){
                            	sObjOppBU = opty.Opportunity__c;
                            	sObjOppRefBU = opty.Opportunity__r;
                                opty.Opportunity__c = '';
                                opty.Opportunity__r = null;
                            }
							var budgetAction = component.get('c.prepareBudgetDataForReconfig');
							budgetAction.setParams({
								"opp" : JSON.stringify(opty),
								"unitConfigs" : JSON.stringify(component.get('v.unitConfig')),
								"strOpportunityBudgets" : JSON.stringify(component.get('v.budgets')),
                                "objName":component.get('v.objName')                                
							});
							budgetAction.setCallback(this, function(resp){
								var res = resp.getReturnValue();
								if(res != null){
									component.set('v.budgets', res);
								}
                    component.set('v.boolShowProductsPopup','false');
							});
							$A.enqueueAction(budgetAction);    
                            opty.Opportunity__c = sObjOppBU;
        					opty.Opportunity__r = sObjOppRefBU;
						}else
							component.set('v.boolShowProductsPopup','false');
					}else
						component.set('v.boolShowProductsPopup','false');
                    component.set('v.strErrors',[]);
                }
                
            });
            $A.enqueueAction(action);
            if(component.get('v.unitType') != null && component.get('v.unitType') != '')  
            {
                component.set('v.isStorageInvoked', true);
            }
            else
            {
                component.set('v.isUnitInvoked', true);
            }
        }
    },

    /*GDM-8413 (Author - Sachin) : Below method is used to validate and display error messages when user tries to select an active product 
    			 with the lease term on the deal is not in between the Activation Start Date and Activation End Date of the product.*/ 
    
    validateExpirationDate: function(cmp, eve){
        var opportunityExpirationDate = cmp.get('v.datUCEnd');
        var opportunityRCDDate = cmp.get('v.datUCStart');
        var productDetails = cmp.get('v.addProduct');
        var strErrors =[];
        var NoExpError = true;
        var NoRCDError = true;
        if(productDetails.length > 0){
            for(var i = 0; i < productDetails.length; i++){                 
                // Validating the lease term on the deal with the product start and end date only if the unit status is active
                if(productDetails[i].unitStatus == 'Active' && productDetails[i].selected == true){
                    if(!$A.util.isUndefinedOrNull(opportunityExpirationDate) && !$A.util.isUndefinedOrNull(productDetails[i].activationEndDate)){
                        if(opportunityExpirationDate > productDetails[i].activationEndDate){
                            strErrors.push('Expiration date on the deal cannot be after the End Date '+ productDetails[i].activationEndDate +' of the unit '+ productDetails[i].unitNo +'. Please change the Expiration Date or select a different unit.');   
                        	NoExpError = false;
                        }                            
                    }
                    if(!$A.util.isUndefinedOrNull(opportunityRCDDate) && !$A.util.isUndefinedOrNull(productDetails[i].activationStartDate)){
                        if(opportunityRCDDate < productDetails[i].activationStartDate){
                            strErrors.push('RCD date on the deal cannot be before the Start Date '+ productDetails[i].activationStartDate +' of the unit '+ productDetails[i].unitNo +'. Please change the RCD Date or select a different unit.');     
                            NoRCDError = false;
                        }                            
                    }
                }
            }    
            if(NoExpError && NoRCDError){
                strErrors =[];
                cmp.set('v.strErrors', strErrors);
            }
            if(strErrors.length > 0){
                cmp.set('v.strErrors', strErrors);                          
                return false;
            }else 
                return true;
        }
    },
    validateNewlySelctedProducts : function(cmp, eve){
        var strErrors = [];
        var obj = JSON.parse(JSON.stringify(cmp.get('v.addProduct')));
        var newLyselectedProducts = [];
        for(var i=0;i<obj.length;i++){          
            if(obj[i].selected == true){
                newLyselectedProducts.push(obj[i]);
            }
        }
        if(newLyselectedProducts.length == 0){
            cmp.set('v.unitsSelected', false);            
        }else{
            cmp.set('v.unitsSelected', true);            
        }
        console.log('++newLyselectedProducts++',newLyselectedProducts);
    },
})