({
    doInit : function(component, event, helper) {
        
        //console.log('Center changed?'+component.get('v.centerChanged'));
       /* if(!component.get('v.centerChanged')){
            if(component.get('v.idOpportunity') != null){
                console.log('D3');
                component.set('v.boolMerge','true');
            }
            else{
                console.log('D4');
                component.set('v.boolMerge','false');
            } 
        }
        else{
            console.log('D5');
            component.set('v.boolMerge','false');
        }
        //GDM-8240: Defect FIX
        if(component.get('v.selectedProducts').length > 0){
            component.set('v.boolMerge',true);
        }else{
             component.set('v.boolMerge',false);
        }*/
    },
    hideSpinner : function(component, event, helper) {
        var spinner = component.find("spinner");
        $A.util.addClass(spinner, "slds-hide");
    },
    showSpinner : function(component, event, helper) {
        var spinner = component.find("spinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
    closeProductsPopup : function(component, event, helper) {        
        component.set('v.boolShowProductsPopup', 'false');
        var selectedProd = component.get('v.selectedProducts');
        
        console.log('Selected Products ---> ', selectedProd);
        if(selectedProd.length === undefined){
        	component.set('v.selectedProducts', []);            
            component.set('v.addProduct', []);
            component.set('v.unitConfig', null);
            component.set('v.remainingGLAProducts', []);
        	component.set('v.intTotalProposedGLA', null);
        }
		if(!component.get('v.saveClicked')){
            component.set('v.addProduct', []);
        }        
      
    },
    saveAndCreateTasks : function(component, event, helper){
        component.set('v.saveClicked', true);
        component.get('v.strComments');
        var strErrors = [];
        if( component.get('v.strComments') == null || component.get('v.strComments') == '')
        {
            console.log('Comment NULL');
            strErrors.push('Please Enter Comments to Send to Task to RPM');
            component.set('v.strErrors',strErrors);
             
        }
        else
        {
        	component.set('v.strCreateTasks','true');
        	console.log('typeunit', component.get('v.unitType'));
        	if(component.get('v.unitType') == $A.get("$Label.c.StorageLeasing_WF"))
        	{
        		component.set('v.strCreateTaskA3','true');
        	}
        	
        	helper.createUnitConfigsHelper(component); 
        }       
    },
    selectProductsforReconfig : function(cmp, eve, helper){
	 var strErrors = [];
        console.log('+++cmp++',cmp.get('v.selectedProducts'));
        helper.validateNewlySelctedProducts(cmp);
        if(cmp.get('v.unitsSelected') == false){
            strErrors.push('Please select atleast one product.');
            cmp.set('v.strErrors', strErrors);            
        }
        else {            
            if(helper.validateExpirationDate(cmp, eve)){
                cmp.set('v.strErrors',[]);
				helper.selectProductsforReconfigHelper(cmp);	
            }else{
                strErrors.push('Please select a unit with expiration date');
                cmp.set('v.strErrors', strErrors);            
	}
	}
    },
    createUnitConfigs : function(component, event, helper){
        component.set('v.saveClicked', true);
        helper.createUnitConfigsHelper(component);
        
    },    
})