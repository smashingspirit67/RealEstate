({
    //typeahead already initialized
    typeaheadInitStatus : {},
    //"old value" to trigger reload on "v.value" change
    typeaheadOldValue : {},
    //suggestione function returned after a successful match
    cb: null,
    /*
    	Creates the typeahead component using RequireJS, jQuery, Bootstrap and Bootstrap Typeahead
    */
    createTypeaheadComponent: function(component){
        
        var self = this;
        var globalId = component.getGlobalId();
        //loading libraries sequentially
        var inputElement = jQuery('[id="'+globalId+'_typeahead"]');
        //init the input element
        inputElement.val(component.get("v.nameValue"));
        
        //handles the change function
        inputElement.keyup(function(){
            if(inputElement.val() !== component.get('v.nameValue')){
                console.log('hi1');
                component.set('v.nameValue',inputElement.val());
                component.set('v.value', null);                
                //self.typeaheadOldValue[component.getGlobalId()] = null;
            }
        });
        
        //inits the typeahead
        inputElement.typeahead({
            hint: false,
            highlight: true,
            minLength: 2,
        },
                               {
                                   name: 'objects',
                                   displayKey: 'value',
                                   templates: {
                                       empty: [                  					                                                                              
                                       ].join('\n'),
                                       
                                   },   
                                   source: function(q,cb){
                                       
                                       self.cb = cb;
                                       q = (q || '').replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
                                       var compEvent = component.getEvent("inputLookupEvent");
                                       compEvent.setParams({"searchString" : q });
                                       compEvent.fire();
                                   },
                               })
        //selects the element
        .bind('typeahead:selected', 
              function(evnt, suggestion){
                  if(suggestion.id=='New Lease'){                           
                      component.set('v.boolShowPopup', 'true');
                  }else{
                      component.set('v.value', suggestion.id);
                      component.set('v.nameValue', suggestion.value); 
                      component.set('v.nameTitle', 'Hello    '+suggestion.value); 
                  }                  
              });		
    },
    
    /*
     * Searches objects (server call)
     */
    searchAction : function(component, q){
        if(!component.isValid()) return;
        
        var self = this;
        var action = component.get("c.searchSObject");
        action.setParams({
            'type' : component.get('v.type'),
            'searchString' : q,
        });
        
        action.setCallback(this, function(a) {
            if(a.error && a.error.length){
                return $A.error('Unexpected error: '+a.error[0].message);
            }
            var result = a.getReturnValue();
            var matches, substrRegex;
            
            // an array that will be populated with substring matches
            var matches = [];
            
            // regex used to determine if a string contains the substring `q`
            var substrRegex = new RegExp(q, 'i');
            var strs = JSON.parse(result);            
            if(strs.length == 0){      
                //if(component.get("v.isLegal"))
                matches.push({value: '+ New Account', id :'New Lease'});  
                console.log('hi2 new');
            }
            // iterate through the pool of strings and for any string that
            // contains the substring `q`, add it to the `matches` array
            jQuery.each(strs, function(i, str) {
                if (substrRegex.test(str.value)) {
                    // the typeahead jQuery plugin expects suggestions to a
                    // JavaScript object, refer to typeahead docs for more info
                    matches.push({ value: str.value , id: str.id});    
                }
            });
            if(!strs || !strs.length){
                component.set('v.value', null);
                component.set('v.nameValue','');
            }
            self.cb(matches);
        });
        $A.enqueueAction(action);
    },
    
    
    /*
     * Method used on initialization to get the "name" value of the lookup
     */
    loadFirstValue : function(component) {
        //this is necessary to avoid multiple initializations (same event fired again and again)
        if(this.typeaheadInitStatus[component.getGlobalId()]){ 
            return;
        }
        
        this.typeaheadInitStatus[component.getGlobalId()] = true;
        this.loadValue(component);
        
    },
    
    /*
     * Method used to load the initial value of the typeahead 
     * (used both on initialization and when the "v.value" is changed)
     */
    loadValue : function(component, skipTypeaheadLoading){
        this.typeaheadOldValue[component.getGlobalId()] = component.get('v.value');
        
        var action = component.get("c.getCurrentValue");
        var self = this;        
        action.setParams({
            'type' : component.get('v.type'),
            'value' : component.get('v.value')
        });
        
        action.setCallback(this, function(a) {            
            if(a.error && a.error.length){
                return $A.error('Unexpected error: '+a.error[0].message);
            }
            var result = a.getReturnValue();            
            var globalId = component.getGlobalId();
            component.set('v.isLoading',false);
            if(component.get('v.type')=='Center_WF__c'){component.set('v.strCenterName', result);}
            component.set('v.nameValue',result || '');
            if(result)jQuery('[id="'+globalId+'_typeahead"]').val(result || '');
            if(!skipTypeaheadLoading) self.createTypeaheadComponent(component);
            var type = component.get('v.type');
            var value = component.get('v.value');
             /*If lookup value for Unit/Product is changed - these fields get changed*/
            if(type != null && value != null && type == 'Product2'){
                var act = component.get("c.getProductFields");
                act.setParams({
                    'strType' : type,
                    'idProduct' : value
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set('v.strCurrTenant',result.strTenantName==null?'':result.strTenantName);
                    component.set('v.datTenantLeaseExpDate',result.datExpiryDate);
                    component.set('v.intTotalGLA',result.intTotalGLA);
                    component.set('v.intGLAUsed',result.intGLAUsed);
                });
                $A.enqueueAction(act);
            }
            /*If lookup value for User is changed - these fields get changed -- mallik*/
            if(type != null && value != null && type == 'User'){
                var act = component.get("c.getDealMakerFields");
                act.setParams({
                    'strType' : type,
                    'idDealMaker' : value
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set('v.strLeasingDivision',result==null?'':result.strDivision);
                });
                $A.enqueueAction(act);
            }
           /*If lookup value for B2BCustomer is changed - these fields get changed */
            if(type != null && value != null && type == 'Account' && component.get('v.boolIsChanged') == true){
                var act = component.get("c.getRelatedAccountDetails");
                act.setParams({
                    'strType' : type,
                    'strAccountId' : value
                });
                act.setCallback(this, function(a) {
                    var result = a.getReturnValue();
                    component.set('v.idB2BCustomer',result.idAccount);
                    component.set('v.strB2BCustomerName',result.strB2BCustomer);
                    component.set('v.idB2BCustomerParent',result.idAccountParent);
                    component.set('v.idB2BCustomerSuperParent',result.idAccountSuperParent);
                    component.set('v.idLegalEntity',result.idLegalEntity);
                   // component.set('v.idDealMaker',result.idDealMaker);
                    component.set('v.datExpiryDate',result.datExpiryDate);
                    component.set('v.datRcd',result.datRcd);
                    component.set('v.intLeaseTerm',result.intLeaseTerm);
                  //  component.set('v.strLeasingDivision',result.strLeasingDivision);
                    component.set('v.boolIsChanged',true);
                });
                $A.enqueueAction(act);
            }
            
        });
        $A.enqueueAction(action);
    }
})