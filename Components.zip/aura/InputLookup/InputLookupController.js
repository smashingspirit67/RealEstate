({
    
    /*
     * Executes the search server-side action when the c:InputLookupEvt is thrown
     */
    handleInputLookupEvt: function(component, event, helper){
		helper.searchAction(component, event.getParam('searchString')); 
    },
    
    /*
    	Loads the typeahead component after JS libraries are loaded
    */
    initTypeahead : function(component, event, helper){
        //first load the current value of the lookup field and then
        //creates the typeahead component
        helper.loadFirstValue(component);
    },
      /*
    	checks if user hasn't entered any value
    */
    doVerify : function(component, event, helper){                
		var type = component.get('v.type');
        var value = component.get('v.value');
        var boolIsB2BCustEmpty = component.get('v.idB2BCustomer')==null?true:false;
        if(type=='User'&& value==null){
            component.set('v.strLeasingDivision','');
        }
          if(type=='Product2'&& value==null){
            component.set('v.strCurrTenant','');
            component.set('v.datTenantLeaseExpDate','');
            component.set('v.intTotalGLA','');
            component.set('v.intGLAUsed','');
        }
        console.log('boolIsB2BCustEmpty: '+boolIsB2BCustEmpty);
        if(type=='Account'&& value==null && boolIsB2BCustEmpty){
            //component.set('v.B2BCustomer','');
            component.set('v.strB2BCustomerName','');
            component.set('v.idB2BCustomerParent',null);
            component.set('v.idB2BCustomerSuperParent',null);
            component.set('v.idLegalEntity',null);
            component.set('v.idDealMaker',null);
            component.set('v.strLeasingDivision','');
            component.set('v.datExpiryDate','');
            component.set('v.datRcd','');
            component.set('v.intLeaseTerm','');            
        }
        
        if(type=='Account' && component.get('v.idLegalEntity')==null && component.get('v.boolIsLegalEmpty')){
            
            component.set('v.nameValue','');            
        }        
    },    
})