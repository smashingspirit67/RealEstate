({
	doInit : function(component, event, helper) {
		var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Utilities']){
                component.set('v.mallCharges',charges[item]);
            }
        }
        helper.setPicklistValues(component,component.get('v.result'));
	},
    changeUnitOfMeasureWater : function(component, event, helper) {
        component.set('v.mallCharges.WaterProposed_WF__c',0);
    },
    changeUnitOfMeasureFDS : function(component, event, helper) {
        component.set('v.mallCharges.FDSProposed_WF__c',0);
    },
    changeUnitOfMeasureElectricity : function(component, event, helper) {
        component.set('v.mallCharges.ElectricityProposed_WF__c',0);
    },
    changeUnitOfMeasureEncldMallHVAC : function(component, event, helper) {
        component.set('v.mallCharges.EncldMallHVACProposed_WF__c',0);
    },
    changeUnitOfMeasureTTHVACCPLChilledWater : function(component, event, helper) {
        component.set('v.mallCharges.TTHVACCPLChilledWaterProposed_WF__c',0);
    },
    changeUnitOfMeasureTrash : function(component, event, helper) {
        component.set('v.mallCharges.TrashProposed_WF__c',0);
    },
    changeUnitOfMeasureParking : function(component, event, helper) {
        component.set('v.mallCharges.ParkingProposed_WF__c',0);
    }
})