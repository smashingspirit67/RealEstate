({
    doInit : function(component, event, helper) {
        helper.doInitHelper(component,helper);
    },
    showSpinner : function (component, event, helper) {
        component.set("v.spinner", true);   
    },
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    passSection : function(component, event, helper){
        helper.passSectionHelper(component, event);
    },
    firePicklistEvent : function(component, event, helper){
        //Clearing out logic for Outstanding fields --START--
        if(component.get('v.newAmdOpportunity.Outstanding_A_R_WF__c')){
            component.set('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c');   
            component.set('v.newAmdOpportunity.Effective_Date_of_OS_A_R_WF__c');   
            component.set('v.newAmdOpportunity.Responsible_for_Outstanding_A_R_WF__c');   
            component.set('v.newAmdOpportunity.Payment_Details_WF__c');
            
        }else{
            component.set('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c','');      
            component.set('v.newAmdOpportunity.Effective_Date_of_OS_A_R_WF__c',null);
            component.set('v.newAmdOpportunity.Responsible_for_Outstanding_A_R_WF__c',null);
            component.set('v.newAmdOpportunity.Payment_Details_WF__c','');
            
        }
        //--END--
        var fetchPickList = $A.get("e.c:fetchPicklist");
        fetchPickList.fire(); 
    },
    saveAmendments : function(component, event, helper){
        helper.getSecurityDepositDetails(component, false);
        if(!helper.validateCovenantTextField(component, event, helper))
        {
            component.set('v.BoolSaveDisable',true);
            component.set('v.DealValidated', false);
            helper.saveHelper(component, event, helper);
        }
        else
            return;
    },
    saveAndValidateAmendments : function(component, event, helper){
        component.set('v.SaveAndValidateClicked', true);
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var noError =true;
        helper.getSecurityDepositDetails(component, true);
        if(helper.validateCovenantTextField(component, event, helper))
        {
            noError =false;
        }
        if(!helper.validateHelper(component, event, helper))
         {
           noError =false;
         }
        if(noError){
            component.set('v.BoolValidateDisable',true);
            component.set('v.DealValidated', true);
            helper.saveHelper(component, event, helper);
        }
        else
            return;
    },
    handleCancel : function(component, event, helper){
        helper.cancelHelper(component, event);
    },
    fireRefreshEvent : function(component, event, helper){
        if(event.getParam("fieldValue") === "LegalEntity"){
            if(event.getParam("billingAddress") !== undefined){
                component.set('v.billingAddress', event.getParam("billingAddress"));
            } else{
                component.set('v.billingAddress', {});
            }
            if(event.getParam("noticeAddress") !== undefined){
                component.set('v.noticeAddress', event.getParam("noticeAddress"));
            } else{
                component.set('v.noticeAddress', {});
            }
            var addressEvent = $A.get("e.c:RefreshLightningComponentEvent");
            addressEvent.fire();
        }
    },
    reInitializePicklist : function(component, event, helper){
        if(!$A.util.isUndefinedOrNull(component.find("OpportunityHold_Cash_Deposit_For_Amendment_WF__c"))){
            component.find("OpportunityHold_Cash_Deposit_For_Amendment_WF__c").reInit();
        }
        var securityType = component.get('v.newAmdOpportunity.SecurityType_WF__c');
        securityType = String(securityType);
        if(securityType == '--None--' || securityType == ''){
            component.set('v.IsCashDeposit', false);
            component.set('v.IsGuarantor', false);
            component.set('v.IsLetterOfCredit', false);
        }
        console.log('****ctrl',securityType);
        helper.setSecurityTypeHelper(component, event,"change",null);
    },
    changeSecurityDepositRequired : function(component,event,helper){
            component.set('v.newAmdOpportunity.SecurityType_WF__c','');
            if(!$A.util.isUndefinedOrNull(component.find('OpportunitySecurityType_WF__c'))){
                component.find('OpportunitySecurityType_WF__c').reInit();
            }
            helper.setSecurityTypeHelper(component, event,"change",null);
        },
    changeReleaseAssignor : function(component, event, helper){
        if(component.get('v.newAmdOpportunity.Release_Assignor_WF__c')){
            component.set('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c');   
        }else{
            component.set('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c','');      
        }
      
    },  //--END--
    //Clearing out logic for Assignor Security Deposit fields --START--
    changeAssignorSecDep : function(component, event, helper){
        if(component.get('v.newAmdOpportunity.Assignor_Security_Deposit_on_File_WF__c')){
            component.set('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c');
        }else{
            component.set('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c','');      
        }
      
    },//--END--
    
     //Clearing out logic for Financial Reviewed  fields --START--
    changeFinancialReviewed : function(component, event, helper){
        if(component.get('v.newAmdOpportunity.changeFinancialReviewed')){
            component.set('v.newAmdOpportunity.Narrative_on_Financials_WF__c');   
        }else{
            component.set('v.newAmdOpportunity.Narrative_on_Financials_WF__c','');      
        }
      
    },
    clearOtherComment : function(component, event, helper){
        if(component.get('v.newAmdOpportunity.Hold_Cash_Deposit_For_Amendment_WF__c') == "Other" )
        {
            if(!$A.util.isUndefinedOrNull(component.get('v.newAmdOpportunity.Hold_Cash_Deposit_Other_WF__c')))
             {
                 component.set('v.newAmdOpportunity.Hold_Cash_Deposit_Other_WF__c','');
             }
        }
    },
})