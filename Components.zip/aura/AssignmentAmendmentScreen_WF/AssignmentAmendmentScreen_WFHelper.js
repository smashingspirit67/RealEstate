({
    doInitHelper : function(component,helper) {
        var idLease = component.get('v.idLease');
        var idAmdOpp = component.get('v.idAmdOpp');
        
        if(idAmdOpp !== undefined && idAmdOpp !== null && idAmdOpp !== ''){
            component.set('v.newAmendment', false);
        }
        
        var action = component.get('c.getRelatedLeaseDetails');
        action.setParams({
            "strLeaseId":idLease,
            "strExistingAmendmentOppId" : idAmdOpp
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess){
                var result = response.getReturnValue();
                if(result != null){
                    console.log('result.././././',result);
                    component.set('v.result',result);
                    component.set('v.lease', result.lease);
                    component.set('v.newAmdOpportunity', result.existingAmendmentOpp);
                    component.set('v.noticeAddressRO', result.noticeAddressRO);
                    component.set('v.billingAddressRO', result.billingAddressRO);
                    if(!$A.util.isUndefinedOrNull(component.find('coDetailsComp'))){
                        component.find('coDetailsComp').reInit();
                    }
                    if(component.get('v.newAmendment')){
                        if(result.relatedOpportunity != null && result.relatedOpportunity.Dealmaker_WF__c != null){
                            component.set('v.dealMaker', result.relatedOpportunity.Dealmaker_WF__r);
                            if(!$A.util.isUndefinedOrNull(result.relatedOpportunity.Dealmaker_WF__r)){
                                component.set('v.dealMakerId', result.relatedOpportunity.Dealmaker_WF__r.Id);
                                component.set('v.newAmdOpportunity.LeasingDivision_WF__c', result.relatedOpportunity.Dealmaker_WF__r.Division);
                            } 
                        }else{
                            component.set('v.dealMaker', result.dealmakerFromLease);                                
                            component.set('v.dealMakerId', result.dealmakerFromLease.Id);
                        }
                        
                    } else{
                        component.set('v.dealMaker', result.existingAmendmentOpp.Dealmaker_WF__r);
                        if(!$A.util.isUndefinedOrNull(result.existingAmendmentOpp.Dealmaker_WF__r)){
                            component.set('v.dealMakerId', result.existingAmendmentOpp.Dealmaker_WF__r.Id);
                        }
                        component.set('v.LegalEntity', result.existingAmendmentOpp.LegalEntity_WF__r);
                        if(!$A.util.isUndefinedOrNull(result.existingAmendmentOpp.LegalEntity_WF__r)){
                            component.set('v.legalEntityId', result.existingAmendmentOpp.LegalEntity_WF__r.Id);
                        }
                        component.set('v.DBACustomer', result.existingAmendmentOpp.B2BCustomer_WF__r);
                        if(!$A.util.isUndefinedOrNull(result.existingAmendmentOpp.B2BCustomer_WF__r)){
                            component.set('v.dbaCustomerId', result.existingAmendmentOpp.B2BCustomer_WF__r.Id);
                        }
                        /* Joshna, 3 Jul '17, removed default value for GDM-4992
                         * if(result.existingAmendmentOpp.B2BCustomer_WF__r !== undefined){
                            component.set('v.useClause', result.existingAmendmentOpp.B2BCustomer_WF__r.UseClause_WF__c);
                        }*/
                        if(result.existingAmendmentOpp !== undefined){
                            component.set('v.useClause', result.existingAmendmentOpp.UseClause_WF__c);
                        }
                        component.set('v.Broker', result.existingAmendmentOpp.Broker_WF__r);
                        if(!$A.util.isUndefinedOrNull(result.existingAmendmentOpp.Broker_WF__r)){
                            component.set('v.brokerId', result.existingAmendmentOpp.Broker_WF__r.Id);
                        }
                        
                        if(result.billingAddress !== undefined){
                            component.set('v.billingAddress', result.billingAddress);
                        }
                        if(result.noticeAddress !== undefined){
                            component.set('v.noticeAddress', result.noticeAddress);
                        }
                    }
                    var securityType = component.get('v.newAmdOpportunity.SecurityType_WF__c');
                    securityType = String(securityType);
                    console.log('****init',securityType);
                    if(securityType.includes("Cash Deposit")){
                        component.set('v.IsCashDeposit', true); 
                        if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                            component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                        }
                    }else {
                        component.set('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c',0);
                        component.set('v.newAmdOpportunity.Hold_Cash_Deposit_For_Amendment_WF__c','');
                        console.log('sss',component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'));
                        if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                            component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                        }
                        component.set('v.newAmdOpportunity.Cash_Deposit_Comments_WF__c','');
                        component.set('v.newAmdOpportunity.Hold_Cash_Deposit_Other_WF__c', '');
                        component.set('v.IsCashDeposit', false);
                    } 
                    if(securityType.includes("Letter of Credit")){  
                        if(result.existingAmendmentOpp !== undefined && result.existingAmendmentOpp != null){
                            console.log("TEST doInit IsLetterOfCredit "+component.get('v.IsLetterOfCredit'));
                            var lstLOC = component.get('v.lstLOC');
                            var count = 1;
                            for(var i = 1 ; i <= 5 ; i++){                         
                                var objLOC = {};
                                var cdAmt = 'Credit_Letter_Amount_'+i+'_WF__c';  
                                var bankAddress  = 'BankAddress_'+i+'_WF__c';                
                                var hoc          = 'Hold_LOC_For_'+i+'_Amendment_WF__c';
                                var identifyBank = 'IdentifyBank_'+i+'_WF__c';
                                var locComments = 'LOCComments_'+ i+'_WF__c';
                                var otherComments = 'Other_'+ i + '_WF__c';
                                
                                if(typeof result.existingAmendmentOpp[hoc] !== "undefined" && typeof result.existingAmendmentOpp[cdAmt] !== "undefined" && 
                                   result.existingAmendmentOpp[hoc] !== '' && result.existingAmendmentOpp[cdAmt] !== '' && result.existingAmendmentOpp[cdAmt] > 0){
                                    objLOC.CreditLetterAmount = result.existingAmendmentOpp[cdAmt];
                                    objLOC.BankAddress = result.existingAmendmentOpp[bankAddress];
                                    objLOC.holdLOCFor = result.existingAmendmentOpp[hoc];
                                    objLOC.IdentifyBank = result.existingAmendmentOpp[identifyBank];
                                    objLOC.LOCComments = result.existingAmendmentOpp[locComments];
                                    objLOC.otherComments = result.existingAmendmentOpp[otherComments];
                                    objLOC.count = count;
                                    lstLOC.push(objLOC);
                                    count = count + 1;
                                }
                            }
                            component.set('v.IsLetterOfCredit', true);
                            component.set('v.lstLOC', lstLOC);
                            component.set('v.noOfletterOfCredit' , lstLOC.length);
                        }
                    } else {
                        console.log("TEST doInit IsLetterOfCredit "+component.get('v.IsLetterOfCredit'));
                        component.set('v.IsLetterOfCredit', false);
                    }
                    if(securityType.includes("Guarantor")){  
                        if(result.lstGuarantors !== undefined && result.lstGuarantors !== null){
                            console.log("TEST doInit IsGuarantor "+component.get('v.IsGuarantor'));
                            var guarantors = result.lstGuarantors;
                            var updatedGuarantors = [];
                            for(var each in guarantors){
                                var eachG = {};
                                eachG = JSON.parse(JSON.stringify(guarantors[each]));
                                eachG.stateOfIncorp = guarantors[each].RelatedAccount_WF__r.StateOfIncorporation_WF__c;
                                //Need to convert this string as the "set" for ui:inputseectOption doesn't work if it's not of the same data type
                                if(guarantors[each].Years_WF__c !== undefined && guarantors[each].Years_WF__c !== null && guarantors[each].Years_WF__c !== '')
                                    eachG.Years_WF__c = String(guarantors[each].Years_WF__c);
                                if(guarantors[each].Months_WF__c !== undefined && guarantors[each].Months_WF__c !== null && guarantors[each].Months_WF__c !== '')
                                    eachG.Months_WF__c = String(guarantors[each].Months_WF__c);
                                updatedGuarantors.push(eachG);
                            }
                            component.set('v.IsGuarantor', true);  
                            component.set('v.guarantor', updatedGuarantors);
                            component.set('v.noOfGuarantors', result.lstGuarantors.length);
                        } } else {
                            console.log("TEST doInit IsGuarantor "+component.get('v.IsGuarantor'));
                            component.set('v.IsGuarantor', false);  
                        }
                    helper.setPicklistValues(component, result);
                    var fetchPickList = $A.get("e.c:fetchPicklist");
                    fetchPickList.fire();
                    var addressEvent = $A.get("e.c:RefreshLightningComponentEvent");
                    addressEvent.fire();
                }
            }
            console.log('******issue', component.get('v.Broker'));
        });
        $A.enqueueAction(action);
    }, 
    passSectionHelper : function(component, event){
        var sectionName = event.getParam("section");
        if(component.get('v.'+sectionName)){
            component.set('v.'+sectionName,false); 
            $A.util.addClass(component.find(sectionName), 'slds-hide'); 
        }else{
            component.set('v.'+sectionName,true);   
            $A.util.removeClass(component.find(sectionName), 'slds-hide'); 
        }
    },
    cancelHelper : function(component, event){
        if(component.get('v.idAmdOpp') != null){
            if((typeof sforce != 'undefined') && (sforce != null)) {
                sforce.one.navigateToSObject(component.get('v.idAmdOpp')); 
            } else{
                var urlOppDetailPage = "/one/one.app#/sObject/"+component.get('v.idAmdOpp')+"/view";
                window.open(urlOppDetailPage,"_self");
            }
        } else{
            if((typeof sforce != 'undefined') && (sforce != null)) {
                sforce.one.navigateToSObject(component.get('v.idLease')); 
            } else{
                var urlLeaseDetailPage = "/one/one.app#/sObject/"+component.get('v.idLease')+"/view";
                window.open(urlLeaseDetailPage,"_self");
            }
        }
    },
    saveHelper : function(component, event, helper){
        var action = component.get('c.saveAssignmentAmendment');
        var inputInst = {};
        inputInst.newAmdOpp = component.get('v.newAmdOpportunity');
        inputInst.newAmdOpp.Effective_Date_of_OS_A_R_WF__c = component.get('v.newAmdOpportunity.Effective_Date_of_OS_A_R_WF__c');
        inputInst.lease = component.get('v.lease');
        inputInst.nAddress = component.get('v.noticeAddress');
        inputInst.bAddress = component.get('v.billingAddress');
        inputInst.dbaCustomerAcc = component.get('v.dbaCustomerId') == null ? {} : component.get('v.DBACustomer');
        inputInst.legalEntityAcc = component.get('v.legalEntityId') == null ? {} : component.get('v.LegalEntity');
        inputInst.brokerAcc = component.get('v.brokerId') == null ? {} : component.get('v.Broker');
        inputInst.dealMaker = component.get('v.dealMakerId') == null ? {} : component.get('v.dealMaker');
        inputInst.useClause = component.get('v.useClause');
        if(component.get('v.newAmendment')){
            inputInst.newAmdOpp.Unit_WF__c = component.get('v.lease.Unit_WF__c');
        }
        if(component.get('v.DealValidated') == true)
        {
            inputInst.newAmdOpp.DealValidated_WF__c = true;
        }
        if(inputInst.StageName == $A.get("$Label.c.OpportunityProposalStage_WF") && component.get('v.DealValidated') == false)
        {
            inputInst.newAmdOpp.DealValidated_WF__c = false;
        } 
        var securityType = component.get('v.newAmdOpportunity.SecurityType_WF__c');
        inputInst.newGuarantors = component.get('v.addGuarantor');
        inputInst.delGuarantors = component.get('v.guarantorsToDelete');
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var saveAndValidate = component.get('v.SaveAndValidateClicked');
        console.log('*** saveAndValidate', saveAndValidate);
		action.setParams({
            "inputWrapperString": JSON.stringify(inputInst),
            "SaveAndValidateClicked" : saveAndValidate
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.idAmdOpp', result);
                    helper.cancelHelper(component, event);
                } else{
                    alert('insert failed');
                }
            }
        });
        $A.enqueueAction(action);
    },
    validateHelper : function(component, event, helper,noValidationCmntsErr){
        var noErrors = true;
        var GI_whoSectionError = false;
        var CO_sendDocSectionError = false;
        var LI_whoSectionError = false;
        var result =component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        console.log('covenantTextFieldMap',covenantTextFieldMap);
         component.set('v.LI_whoSectionError', false);
        component.set('v.GI_whoSectionError', false);
        var errorCmp = component.find("mailingAddressId");
        if(component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c') === undefined || component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c') === null || component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c') === ''){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            CO_sendDocSectionError = true;
        } else{
            var mAddr = component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c');
            mAddr = mAddr.replace(/;/g, '');
            if(mAddr == ''){
                $A.util.removeClass(errorCmp, 'slds-hide');
                noErrors = false;
            } else{
                $A.util.addClass(errorCmp, 'slds-hide');
            }
        }
        
        errorCmp = component.find("phoneErrorId");
        if(component.get('v.newAmdOpportunity.Send_Docs_To_Phone_WF__c') === undefined || component.get('v.newAmdOpportunity.Send_Docs_To_Phone_WF__c') === null || component.get('v.newAmdOpportunity.Send_Docs_To_Phone_WF__c') === ''){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            CO_sendDocSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("emailAddressErrorId");
        if(component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c') === undefined || component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c') === null || component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c') === ''){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            CO_sendDocSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }

        if(!$A.util.isUndefinedOrNull(component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c')) && component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c').length > covenantTextFieldMap['Send_Docs_To_Email_WF__c']){
            $A.util.removeClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
            CO_sendDocSectionError=true;
        }else{
            $A.util.addClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
        }
        
        errorCmp = component.find("nameErrorId");
        if(component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c') === undefined || component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c') === null || component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c') === ''){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            CO_sendDocSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }

        if(!$A.util.isUndefinedOrNull(component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c')) && component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c').length > covenantTextFieldMap['Send_Docs_To_Name_WF__c']){
            $A.util.removeClass(component.find("nameLengthErrorId"), 'slds-hide');
            CO_sendDocSectionError=true;
        }else{
            $A.util.addClass(component.find("nameLengthErrorId"), 'slds-hide');
        }
        
        errorCmp = component.find("guarantorError");
        if(component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Guarantor' && component.get('v.noOfGuarantors') === 0){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("locError");
        if(component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Letter of Credit' && component.get('v.noOfletterOfCredit') === 0){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("cashDepError");
        if(component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Cash Deposit' && (component.get('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c') === undefined || component.get('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c') === null || component.get('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c') === '' || component.get('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c') <= 0)){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("holdCashDepError");
        if(component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Cash Deposit' && ($A.util.isUndefinedOrNull(component.get('v.newAmdOpportunity.Hold_Cash_Deposit_For_Amendment_WF__c')) || 
                                        component.get('v.newAmdOpportunity.Hold_Cash_Deposit_For_Amendment_WF__c') === '')){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("securityTypeErrorId");
        if(component.get('v.newAmdOpportunity.SecurityDepositRequired_WF__c') && ($A.util.isUndefinedOrNull(component.get('v.newAmdOpportunity.SecurityType_WF__c')) || component.get('v.newAmdOpportunity.SecurityType_WF__c') === '' || component.get('v.newAmdOpportunity.SecurityType_WF__c') === '--None--')){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
                
        errorCmp = component.find("billingErrorId");
        if(component.get('v.billingAddress') === undefined || 
                ((component.get('v.billingAddress.StreetLine1_WF__c') === undefined || component.get('v.billingAddress.StreetLine1_WF__c') === null || component.get('v.billingAddress.StreetLine1_WF__c') === '') &&
                (component.get('v.billingAddress.State_WF__c') === undefined || component.get('v.billingAddress.State_WF__c') === null || component.get('v.billingAddress.State_WF__c') === '') && 
                (component.get('v.billingAddress.PostalCode_WF__c') === undefined || component.get('v.billingAddress.PostalCode_WF__c') === null || component.get('v.billingAddress.PostalCode_WF__c') === '') &&
                (component.get('v.billingAddress.Country_WF__c') === undefined || component.get('v.billingAddress.Country_WF__c') === null || component.get('v.billingAddress.Country_WF__c') === ''))){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("noticeErrorId");
        if(component.get('v.noticeAddress') === undefined || 
                ((component.get('v.noticeAddress.StreetLine1_WF__c') === undefined || component.get('v.noticeAddress.StreetLine1_WF__c') === null || component.get('v.noticeAddress.StreetLine1_WF__c') === '') &&
                (component.get('v.noticeAddress.State_WF__c') === undefined || component.get('v.noticeAddress.State_WF__c') === null || component.get('v.noticeAddress.State_WF__c') === '') && 
                (component.get('v.noticeAddress.PostalCode_WF__c') === undefined || component.get('v.noticeAddress.PostalCode_WF__c') === null || component.get('v.noticeAddress.PostalCode_WF__c') === '') && 
                (component.get('v.noticeAddress.Country_WF__c') === undefined || component.get('v.noticeAddress.Country_WF__c') === null || component.get('v.noticeAddress.Country_WF__c') === ''))){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("legalEntityErrorId");
        if(component.get('v.legalEntityId')==null){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        }else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("dbaCustomerErrorId");
        if(component.get('v.dbaCustomerId')==null){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            LI_whoSectionError = true;
        }else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("secDepositFileError");
        if(component.get('v.newAmdOpportunity.Assignor_Security_Deposit_on_File_WF__c') && (component.get('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c') === undefined || component.get('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c') === null || component.get('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c') === '' || component.get('v.newAmdOpportunity.Assignor_Security_Deposit_Amount_WF__c') <= 0)){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            GI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("osARAmtError");
        if(component.get('v.newAmdOpportunity.Outstanding_A_R_WF__c') && (component.get('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c') === undefined || component.get('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c') === null || component.get('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c') === '' || component.get('v.newAmdOpportunity.Outstanding_A_R_Amount_WF__c') <= 0)){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            GI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("dealmakerErrorId");
        if(component.get('v.dealMakerId')==null){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            GI_whoSectionError = true;
        }else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("assignmentFeeError");
        if(component.get('v.newAmdOpportunity.Assignment_Fee_WF__c') === undefined || component.get('v.newAmdOpportunity.Assignment_Fee_WF__c') === null || component.get('v.newAmdOpportunity.Assignment_Fee_WF__c') === '' || component.get('v.newAmdOpportunity.Assignment_Fee_WF__c') < 0){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            GI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        errorCmp = component.find("releaseAssignorExpl");
        if(component.get('v.newAmdOpportunity.Release_Assignor_WF__c') && (component.get('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c') === undefined || component.get('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c') === null || component.get('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c') === '')){
            $A.util.removeClass(errorCmp, 'slds-hide');
            noErrors = false;
            GI_whoSectionError = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        
        if(component.get('v.showLOCError') || component.get('v.showGuarantorError')){
            LI_whoSectionError = true;
            noErrors = false;
        }

	 if(component.get('v.GI_whoSectionTempError')|| GI_whoSectionError)
        {
            component.set('v.GI_whoSectionError', true);
        }
	
 	if(component.get('v.LI_whoSectionTempError') ||LI_whoSectionError)
        {
			component.set('v.LI_whoSectionError', true);
        }
        component.set('v.CO_sendDocSectionError', CO_sendDocSectionError);
        return noErrors;
        /*  if(noErrors && noValidationCmntsErr){
            component.set('v.BoolValidateDisable',true);
            component.set('v.DealValidated', true);
            helper.saveHelper(component, event, helper);
        }*/
    },
    getSecurityDepositDetails : function(component, validateData){
        if(component.get('v.newAmdOpportunity.SecurityDepositRequired_WF__c')){
            if(component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Guarantor'){
                var guarantorEvent = $A.get("e.c:GuarantorDetailsEvent");
                guarantorEvent.setParams({
                    "showErrors": validateData
                });
                guarantorEvent.fire();
            }else{
                component.set('v.showGuarantorError',false);
            }
            if (component.get('v.newAmdOpportunity.SecurityType_WF__c') === 'Letter of Credit'){
                // Event to fetch the letter of credit details.             
                var letterOfCreditEvent = $A.get("e.c:LOCDetailsEvent");
                letterOfCreditEvent.setParams({
                    "showErrors": validateData
                });
                letterOfCreditEvent.fire();
            }else{
                 component.set('v.showLOCError',false);
            }
        }else{
            component.set('v.showLOCError',false);
            component.set('v.showGuarantorError',false);
            
        }
    },
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = result.objectList;
        var fieldNames = result.FieldList;
        for(var each in objNames){
            for(var eachField in fieldNames){
                if(!$A.util.isUndefinedOrNull(component.find(objNames[each] + fieldNames[eachField]))){
                    var optionVals = picklistMap[objNames[each] + fieldNames[eachField]];
                    if(!$A.util.isUndefinedOrNull(optionVals)){
                        component.find(objNames[each] + fieldNames[eachField]).setLocalValues(optionVals);
                    }
                }
            }
        }
    },
    setSecurityTypeHelper : function(component,event,type,result){ 
        if(type=='change'){
            var securityType = component.get('v.newAmdOpportunity.SecurityType_WF__c');
            securityType = String(securityType);
            console.log('****setSecurityTypeHelper',securityType);
            if(securityType.includes("Cash Deposit")){
                component.set('v.IsCashDeposit', true); 
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
            }else {
                component.set('v.newAmdOpportunity.Cash_Deposit_Amount_WF__c',0);
                component.set('v.newAmdOpportunity.Hold_Cash_Deposit_For_Amendment_WF__c','');
                console.log('sss',component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'));
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
                component.set('v.newAmdOpportunity.Cash_Deposit_Comments_WF__c','');
                component.set('v.newAmdOpportunity.Hold_Cash_Deposit_Other_WF__c', '');
                component.set('v.IsCashDeposit', false);
            }
            
            if(securityType.includes("Letter of Credit")){
                component.set('v.IsLetterOfCredit', true); 
                console.log("TEST setSecurityTypeHelper IsLetterOfCredit "+component.get('v.IsLetterOfCredit'));
            }
            else {
                component.set('v.IsLetterOfCredit', false);
                console.log('*****Letter TEST Delete********');
                var noOfletterOfCredit = component.get('v.noOfletterOfCredit');
                
                var lstLOC = component.get("v.lstLOC");
                for(var i=0 ;i<noOfletterOfCredit; i++){
                    lstLOC.pop();
                } 
            component.set('v.newAmdOpportunity.BankAddress_1_WF__c','');
            component.set('v.newAmdOpportunity.BankAddress_2_WF__c','');
            component.set('v.newAmdOpportunity.BankAddress_3_WF__c','');
            component.set('v.newAmdOpportunity.BankAddress_4_WF__c','');
            component.set('v.newAmdOpportunity.BankAddress_5_WF__c','');
            component.set('v.newAmdOpportunity.IdentifyBank_1_WF__c','');
            component.set('v.newAmdOpportunity.IdentifyBank_2_WF__c','');
            component.set('v.newAmdOpportunity.IdentifyBank_3_WF__c','');
            component.set('v.newAmdOpportunity.IdentifyBank_4_WF__c','');
            component.set('v.newAmdOpportunity.IdentifyBank_5_WF__c','');
            component.set('v.newAmdOpportunity.LetterofCredit_1_WF__c ','');
            component.set('v.newAmdOpportunity.LetterofCredit_2_WF__c ','');
            component.set('v.newAmdOpportunity.LetterofCredit_3_WF__c ','');
            component.set('v.newAmdOpportunity.LetterofCredit_4_WF__c ','');
            component.set('v.newAmdOpportunity.LetterofCredit_5_WF__c ','');
            component.set('v.newAmdOpportunity.HoldLOCFor_1_WF__c',0);
            component.set('v.newAmdOpportunity.HoldLOCFor_2_WF__c',0);
            component.set('v.newAmdOpportunity.HoldLOCFor_3_WF__c',0);
            component.set('v.newAmdOpportunity.HoldLOCFor_4_WF__c',0);
            component.set('v.newAmdOpportunity.HoldLOCFor_5_WF__c',0);
            component.set('v.newAmdOpportunity.LOCComments_1_WF__c','');
            component.set('v.newAmdOpportunity.LOCComments_2_WF__c','');
            component.set('v.newAmdOpportunity.LOCComments_3_WF__c','');
            component.set('v.newAmdOpportunity.LOCComments_4_WF__c','');
            component.set('v.newAmdOpportunity.LOCComments_5_WF__c','');
            component.set('v.newAmdOpportunity.Credit_Letter_Amount_1_WF__c',0);
            component.set('v.newAmdOpportunity.Credit_Letter_Amount_2_WF__c',0);
            component.set('v.newAmdOpportunity.Credit_Letter_Amount_3_WF__c',0);
            component.set('v.newAmdOpportunity.Credit_Letter_Amount_4_WF__c',0);
            component.set('v.newAmdOpportunity.Credit_Letter_Amount_5_WF__c',0);
            component.set('v.newAmdOpportunity.Hold_LOC_For_1_Amendment_WF__c','');
            component.set('v.newAmdOpportunity.Hold_LOC_For_2_Amendment_WF__c','');
            component.set('v.newAmdOpportunity.Hold_LOC_For_3_Amendment_WF__c','');
            component.set('v.newAmdOpportunity.Hold_LOC_For_4_Amendment_WF__c','');
            component.set('v.newAmdOpportunity.Hold_LOC_For_5_Amendment_WF__c','');
            component.set('v.newAmdOpportunity.Other_1_WF__c','');
            component.set('v.newAmdOpportunity.Other_2_WF__c','');
            component.set('v.newAmdOpportunity.Other_3_WF__c','');
            component.set('v.newAmdOpportunity.Other_4_WF__c','');
            component.set('v.newAmdOpportunity.Other_5_WF__c','');
            component.set('v.lstLOC',lstLOC);
            component.set('v.noOfletterOfCredit',0);
            component.set('v.showLOCError',false);
            //component.set('v.GI_securitySectionError',false);
            
                /*var action = component.get('c.deleteLoc');
                action.setParams({
                    "OppId" : component.get('v.newAmdOpportunity.Id')
                });
                action.setCallback(this, function(response){
                    var result = response.getReturnValue();  
                    console.log('******Letter*******',result);
                    if(result && response.getState() == 'SUCCESS' && component.isValid()){
                        component.set('v.lstLOC',lstLOC);
                        component.set('v.noOfletterOfCredit',0);
                    }
                });
                $A.enqueueAction(action);*/
            }
            if(securityType.includes("Guarantor")){
                component.set('v.IsGuarantor', true);  
                console.log("TEST setSecurityTypeHelper IsGuarantor "+component.get('v.IsGuarantor'));
            }
            else {
                component.set('v.IsGuarantor', false);
                component.set('v.showGuarantorError',false);
                //component.set('v.GI_securitySectionError',false);
                var numberOfGuarantor = component.get('v.noOfGuarantors');
                var guarantor = component.get('v.guarantor');
                console.log("TEST guarantor "+guarantor);
                var lstToDelete = []
                for(var i=0 ;i<numberOfGuarantor; i++){
                    var deletedGuarantors = guarantor.pop();
                    if(deletedGuarantors.Id !== undefined && deletedGuarantors.Id !== null && deletedGuarantors.Id !== ''){
                        lstToDelete.push(deletedGuarantors.Id);
                    }                        
                }     
                var action = component.get('c.deleteGuarantor');
                action.setParams({
                    "lstToDelete" : JSON.stringify(lstToDelete)
                });
                action.setCallback(this, function(response){
                    console.log('gua delete call back');
                    var result = response.getReturnValue();  
                    if(result && response.getState() == 'SUCCESS' && component.isValid()){
                        component.set('v.guarantor',guarantor);
                        component.set('v.noOfGuarantors',0);
                    }
                });
                $A.enqueueAction(action);
            }
        }
    },
    validateCovenantTextField : function(component,event,helper){
        var whoNewSectionError = false;
        var whoSectionError = false;
        var commentssectionError = false;
        var sendDocsError = false;
        var result =component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        console.log('covenantTextFieldMap',covenantTextFieldMap);
	 component.set('v.LI_whoSectionTempError',false); 
        var boolIsError=false;
        
        var releaseAssign = component.get('v.newAmdOpportunity.Release_Assignor_Explanation_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Release_Assignor_Explanation_WF__c'])&&!$A.util.isUndefinedOrNull(releaseAssign)&& releaseAssign.length > covenantTextFieldMap['Release_Assignor_Explanation_WF__c'])
        {
            $A.util.removeClass(component.find("RAExplanationErrorId"),'slds-hide');
            boolIsError=true;
            whoSectionError = true;
        }
        else{
            $A.util.addClass(component.find("RAExplanationErrorId"),'slds-hide');
        }
        
        var pyDetails = component.get('v.newAmdOpportunity.Payment_Details_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Payment_Details_WF__c'])&&!$A.util.isUndefinedOrNull(pyDetails)&& pyDetails.length > covenantTextFieldMap['Payment_Details_WF__c'])
        {
            $A.util.removeClass(component.find("pyDetailsError"),'slds-hide');
            boolIsError=true;
            whoSectionError = true;
        }
        else{
            $A.util.addClass(component.find("pyDetailsError"),'slds-hide');
        }

        var useCDet = component.get('v.useClause');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['UseClause_WF__c'])&&!$A.util.isUndefinedOrNull(useCDet)&& useCDet.length > covenantTextFieldMap['UseClause_WF__c'])
        {
            $A.util.removeClass(component.find("useClauseError"),'slds-hide');
            boolIsError=true;
            whoNewSectionError = true;
        }
        else{
            $A.util.addClass(component.find("useClauseError"),'slds-hide');
        }
        
        var hdepErr = component.get('v.newAmdOpportunity.Hold_Cash_Deposit_Other_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Hold_Cash_Deposit_Other_WF__c'])&&!$A.util.isUndefinedOrNull(hdepErr)&& hdepErr.length > covenantTextFieldMap['Hold_Cash_Deposit_Other_WF__c'])
        {
            $A.util.removeClass(component.find("otherCDId"),'slds-hide');
            boolIsError=true;
            whoNewSectionError = true;
        }
        else{
            $A.util.addClass(component.find("otherCDId"),'slds-hide');
        }
        
        var cdErr = component.get('v.newAmdOpportunity.Cash_Deposit_Comments_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Cash_Deposit_Comments_WF__c'])&&!$A.util.isUndefinedOrNull(cdErr)&& cdErr.length > covenantTextFieldMap['Cash_Deposit_Comments_WF__c'])
        {
            $A.util.removeClass(component.find("cashDepositErrorId"),'slds-hide');
            boolIsError=true;
            whoNewSectionError = true;
        }
        else{
            $A.util.addClass(component.find("cashDepositErrorId"),'slds-hide');
        }
        
        var narrErr = component.get('v.newAmdOpportunity.Narrative_on_Financials_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Narrative_on_Financials_WF__c'])&&!$A.util.isUndefinedOrNull(narrErr)&& narrErr.length > covenantTextFieldMap['Narrative_on_Financials_WF__c'])
        {
            $A.util.removeClass(component.find("finNarrativeErrorId"),'slds-hide');
            whoNewSectionError = true;
            boolIsError=true;
        }
        else{
            $A.util.addClass(component.find("finNarrativeErrorId"),'slds-hide');
        }
        
        var commErr = component.get('v.newAmdOpportunity.Comments_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Comments_WF__c'])&&!$A.util.isUndefinedOrNull(commErr)&& commErr.length > covenantTextFieldMap['Comments_WF__c'])
        {
            component.set('v.CommentsError', true);
            boolIsError=true;
            commentssectionError = true;
        }
        else{
            component.set('v.CommentsError', false);
        }
        
        var holdcommErr = component.get('v.newAmdOpportunity.HoldOtherReasonComment_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['HoldOtherReasonComment_WF__c'])&&!$A.util.isUndefinedOrNull(holdcommErr)&& holdcommErr.length > covenantTextFieldMap['HoldOtherReasonComment_WF__c'])
        {
            component.set('v.holdCommsError', true);
            boolIsError=true;
            commentssectionError = true;
        }
        else{
            component.set('v.holdCommsError', false);
        }
        
        var deadcommErr = component.get('v.newAmdOpportunity.OtherReasonOpportunityDead_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])&&!$A.util.isUndefinedOrNull(deadcommErr)&& deadcommErr.length > covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        {
            component.set('v.oppDeadCommsLenError', true);
            boolIsError=true;
            commentssectionError = true;
        }
        else{
            component.set('v.oppDeadCommsLenError', false);
        }
        
        var sendDocErr = component.get('v.newAmdOpportunity.Send_Docs_To_Name_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Name_WF__c'])&&!$A.util.isUndefinedOrNull(sendDocErr)&& sendDocErr.length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {
            $A.util.removeClass(component.find("nameLengthErrorId"), 'slds-hide');
            boolIsError = true;
            sendDocsError = true;
        }else{
            $A.util.addClass(component.find("nameLengthErrorId"), 'slds-hide');
        }
        
        var sendDocEmailErr = component.get('v.newAmdOpportunity.Send_Docs_To_Email_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Email_WF__c'])&&!$A.util.isUndefinedOrNull(sendDocEmailErr)&& sendDocEmailErr.length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            $A.util.removeClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
            boolIsError = true;
            sendDocsError = true;
        }else{
            $A.util.addClass(component.find("emailAddressLengthErrorId"), 'slds-hide');
        }

        var sendDocPhErr = component.get('v.newAmdOpportunity.Send_Docs_To_Phone_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])&&!$A.util.isUndefinedOrNull(sendDocPhErr)&& sendDocPhErr.length > covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])
        {
            $A.util.removeClass(component.find("phoneLenErrorId"), 'slds-hide');
            boolIsError = true;
            sendDocsError = true;
        }else{
            $A.util.addClass(component.find("phoneLenErrorId"), 'slds-hide');
        }
        
        var billAddErr = component.get('v.billingAddress');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['BillingAddress'])&&!$A.util.isUndefinedOrNull(billAddErr)&& JSON.stringify(billAddErr).length > covenantTextFieldMap['BillingAddress'])
        {
            $A.util.removeClass(component.find("billingLenErrorId"), 'slds-hide');
            boolIsError = true;
            whoNewSectionError = true;
        }else{
            $A.util.addClass(component.find("billingLenErrorId"), 'slds-hide');
        }
        
        var notAddErr = component.get('v.noticeAddress');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['NoticeAddress'])&&!$A.util.isUndefinedOrNull(notAddErr)&& JSON.stringify(notAddErr).length > covenantTextFieldMap['NoticeAddress'])
        {
            $A.util.removeClass(component.find("noticeLenErrorId"), 'slds-hide');
            boolIsError = true;
            whoNewSectionError = true;
        }else{
            $A.util.addClass(component.find("noticeLenErrorId"), 'slds-hide');
        }
        
        var sendDocMailErr = component.get('v.newAmdOpportunity.Send_Docs_To_Mailing_Address_WF__c');
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])&&!$A.util.isUndefinedOrNull(sendDocMailErr)&& sendDocMailErr.length > covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])
        {
            $A.util.removeClass(component.find("MailingAddressErrorId"), 'slds-hide');
            boolIsError = true;
            sendDocsError = true;
        }else{
            $A.util.addClass(component.find("MailingAddressErrorId"), 'slds-hide');
        }
		//Validation for onhold Reason and Description
        var onHoldCheck = component.get('v.newAmdOpportunity.On_Hold_WF__c');
        var onHoldReason = component.get('v.newAmdOpportunity.HoldReason_WF__c');
        
        if( onHoldCheck && onHoldReason == ''){
            component.set('v.oppOnHoldValidation',true);
            component.set('v.CO_detailsError',true);
            commentssectionError = true;
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.oppOnHoldValidation',false);
            component.set('v.CO_detailsError',false);
        }
 		console.log('++onHoldCheck+++',onHoldCheck ,'++OnholdReason++',onHoldReason,'++Oppty Error++',component.get('v.oppOnHoldValidation'));
		
    	component.set('v.GI_whoSectionTempError',whoSectionError);
        component.set('v.LI_whoSectionTempError',whoNewSectionError);
        component.set('v.CO_detailsError',commentssectionError);
        component.set('v.CO_sendDocSectionError',sendDocsError);        

        //console.log('Inside Helper error flag val ',boolIsError);*/
        return boolIsError;
    }
})