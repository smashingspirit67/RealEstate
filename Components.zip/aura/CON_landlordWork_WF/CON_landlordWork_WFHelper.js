({
    helperChangeTemporaryPower : function(component,event){
        component.set('v.Construction.TemporaryPowerVal_WF__c',0);
    },
    helperChangeTemporaryTrashRemoval : function(component,event){
        component.set('v.Construction.TemporaryTrashRemovalVal_WF__c',0);       
    },
    helperChangeTemporaryToilets : function(component,event){
        component.set('v.Construction.TemporaryToiletsVal_WF__c',0);
    },
    helperChangeMallTile : function(component,event){
        component.set('v.Construction.MallTileVal_WF__c',0);   
    },
    helperChangeConstructionBarricade : function(component,event){
        component.set('v.Construction.ConstructionBarricadeVal_WF__c',0);
    },
    helperChangeBarricadeGraphicPackage : function(component,event){
        component.set('v.Construction.BarricadeGraphicPackageVal_WF__c',0);
    },
    helperChangeSprinklerDrainDown : function(component,event){
        component.set('v.Construction.SprinklerDrainDownVal_WF__c',0);
    },
    helperChangeSprinklerGrid : function(component,event){
        component.set('v.Construction.SprinklerGridVal_WF__c',0);
    },
    helperChangeElectricalBreakersOrFuseSocket : function(component,event){
        component.set('v.Construction.ElectricalBreakersFuseSocketVal_WF__c',0);
    },
    helperChangeFireAlarmProgramming : function(component,event){
        component.set('v.Construction.FireAlarmProgrammingVal_WF__c',0);
    },
    helperChangeGreaseInterceptor : function(component,event){
        component.set('v.Construction.GreaseInterceptorVal_WF__c',0);
    },
    helperChangeExhaustDucts : function(component,event){
        component.set('v.Construction.ExhaustDuctsVal_WF__c',0);
    },
    helperChangeMakeUpAirDucts : function(component,event){
        component.set('v.Construction.MakeUpAirDuctsVal_WF__c',0);
    },
    helperChangeShafts : function(component,event){
        component.set('v.Construction.ShaftsVal_WF__c',0);
    },
    helperChangeRefrigerantLines : function(component,event){
        component.set('v.Construction.RefrigerantLinesVal_WF__c',0);
    },
    helperChangePermitManagementFees : function(component,event){
        component.set('v.Construction.PermitManagementFeesVal_WF__c',0);
    },
    helperChangeCommissioningFee : function(component,event){
        component.set('v.Construction.CommissioningFeeVal_WF__c',0);
    },
    helperChangeOther : function(component,event){
        component.set('v.OtherTextValueErr',false);
        component.set('v.Construction.OtherLandlordWorkVal_WF__c',0);
        component.set('v.Construction.OtherLandlordWorkTxt_WF__c','');
    },
    resetPicklist : function (component,event){
        component.set('v.Construction.TemporaryPower_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cTemporaryPower_WF__c'))){ 
            component.find('Construction_WF__cTemporaryPower_WF__c').reInit();
        }
        component.set('v.Construction.TemporaryTrashRemoval_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cTemporaryTrashRemoval_WF__c'))){   
            component.find('Construction_WF__cTemporaryTrashRemoval_WF__c').reInit();
        }
        component.set('v.Construction.TemporaryToilets_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cTemporaryToilets_WF__c'))){    
            component.find('Construction_WF__cTemporaryToilets_WF__c').reInit();
        }
        component.set('v.Construction.MallTile_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMallTile_WF__c'))){   
            component.find('Construction_WF__cMallTile_WF__c').reInit();
        }
        component.set('v.Construction.ConstructionBarricade_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cConstructionBarricade_WF__c'))){   
            component.find('Construction_WF__cConstructionBarricade_WF__c').reInit();
        }
        component.set('v.Construction.BarricadeGraphicPackage_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cBarricadeGraphicPackage_WF__c'))){   
            component.find('Construction_WF__cBarricadeGraphicPackage_WF__c').reInit();
        }
        component.set('v.Construction.SprinklerDrainDown_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSprinklerDrainDown_WF__c'))){  
            component.find('Construction_WF__cSprinklerDrainDown_WF__c').reInit();
        }
        component.set('v.Construction.SprinklerGrid_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSprinklerGrid_WF__c'))){  
            component.find('Construction_WF__cSprinklerGrid_WF__c').reInit();
        }
        component.set('v.Construction.ElectricalBreakersFuseSocket_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cTemporaryToilets_WF__c'))){   
            component.find('Construction_WF__cTemporaryToilets_WF__c').reInit();
        }
        component.set('v.Construction.FireAlarmProgramming_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cFireAlarmProgramming_WF__c'))){   
            component.find('Construction_WF__cFireAlarmProgramming_WF__c').reInit();
        }
        component.set('v.Construction.GreaseInterceptor_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cGreaseInterceptor_WF__c'))){    
            component.find('Construction_WF__cGreaseInterceptor_WF__c').reInit();
        }
        component.set('v.Construction.ExhaustDucts_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cExhaustDucts_WF__c'))){     
            component.find('Construction_WF__cExhaustDucts_WF__c').reInit();
        }
        component.set('v.Construction.MakeUpAirDucts_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMakeUpAirDucts_WF__c'))){    
            component.find('Construction_WF__cMakeUpAirDucts_WF__c').reInit();
        }
        component.set('v.Construction.Shafts_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cShafts_WF__c'))){      
            component.find('Construction_WF__cShafts_WF__c').reInit();
        }
        component.set('v.Construction.RefrigerantLines_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cRefrigerantLines_WF__c'))){   
            component.find('Construction_WF__cRefrigerantLines_WF__c').reInit();
        }
        component.set('v.Construction.PermitManagementFees_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPermitManagementFees_WF__c'))){       
            component.find('Construction_WF__cPermitManagementFees_WF__c').reInit();
        }
        component.set('v.Construction.CommissioningFee_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cCommissioningFee_WF__c'))){  
            component.find('Construction_WF__cCommissioningFee_WF__c').reInit();
        }
        component.set('v.Construction.OtherLandlordWork_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cOtherLandlordWork_WF__c'))){   
            component.find('Construction_WF__cOtherLandlordWork_WF__c').reInit();
        }      
    },
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    },
    helperChangeStructuralModification : function(component,event) {
        component.set('v.StructuralModificationOtherError',false);
        component.set('v.Construction.StructuralModification_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('StructuralModification'))){  
            component.find('Construction_WF__cStructuralModification_WF__c').reInit();
        }
        component.set('v.Construction.StructuralModificationOther_WF__c','');
    },
    helperChangeDemisingWall : function(component,event) {
        component.set('v.Construction.DemisingWall_WF__c','');
        component.set('v.DemisingWallOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDemisingWall_WF__c'))){  
            component.find('Construction_WF__cDemisingWall_WF__c').reInit();
        }
        component.set('v.Construction.DemisingWallOther_WF__c','');
    },
    helperChangeStoreFrontage : function(component,event) {
        console.log('ddd',component.get('v.Construction.StoreFrontage_WF__c'));
        component.set('v.Construction.StoreFrontage_WF__c','');
        component.set('v.storeFrontageOtherError',false);
        console.log('eee',component.get('v.Construction.StoreFrontage_WF__c'));
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cStoreFrontage_WF__c'))){  
            component.find('Construction_WF__cStoreFrontage_WF__c').reInit();
        }
        component.set('v.Construction.StoreFrontageOther_WF__c','');
    },
    helperChangeElectrical : function(component,event) {
        component.set('v.Construction.Electrical_WF__c','');
         component.set('v.ElectricalsOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cElectrical_WF__c'))){  
            component.find('Construction_WF__cElectrical_WF__c').reInit();
        }
        component.set('v.Construction.ElectricalVoltage_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cElectricalVoltage_WF__c'))){  
            component.find('Construction_WF__cElectricalVoltage_WF__c').reInit();
        }
        component.set('v.Construction.ElectricalAmps_WF__c',0);
        component.set('v.Construction.ElectricalOther_WF__c','');
    },
    helperChangeData : function(component,event) {
        component.set('v.Construction.Data_WF__c','');
         component.set('v.DataOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cData_WF__c'))){  
            component.find('Construction_WF__cData_WF__c').reInit();
        }
        component.set('v.Construction.DataConduitSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDataConduitSize_WF__c'))){  
            component.find('Construction_WF__cDataConduitSize_WF__c').reInit();
        }
        component.set('v.Construction.DataQuantity_WF__c',0);
        component.set('v.Construction.DataOther_WF__c','');
    },
    helperChangeDomesticWater : function(component,event) {
        component.set('v.Construction.DomesticWater_WF__c','');
         component.set('v.DomesticWaterOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDomesticWater_WF__c'))){  
            component.find('Construction_WF__cDomesticWater_WF__c').reInit();
        }
        component.set('v.Construction.DomesticWaterPipeSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDomesticWaterPipeSize_WF__c'))){  
            component.find('Construction_WF__cDomesticWaterPipeSize_WF__c').reInit();
        }
        component.set('v.Construction.DomesticWaterOther_WF__c','');
    },
    helperChangeSewer : function(component,event) {
        component.set('v.Construction.Sewer_WF__c','');
         component.set('v.SewerOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewer_WF__c'))){  
            component.find('Construction_WF__cSewer_WF__c').reInit();
        }
        component.set('v.Construction.SewerSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerSize_WF__c'))){  
            component.find('Construction_WF__cSewerSize_WF__c').reInit();
        }
        component.set('v.Construction.SewerOther_WF__c','');
    },
    helperChangeSewerVent : function(component,event) {
        component.set('v.Construction.SewerVentSize_WF__c','');
         component.set('v.SewerVentOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerVentSize_WF__c'))){  
            component.find('Construction_WF__cSewerVentSize_WF__c').reInit();
        }
        component.set('v.Construction.SewerVent_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerVent_WF__c'))){  
            component.find('Construction_WF__cSewerVent_WF__c').reInit();
        }
        component.set('v.Construction.SewerVentOther_WF__c','');
    },
    helperChangeGreaseWaste : function(component,event) {
        component.set('v.Construction.GreaseInterceptorSize_WF__c','');
         component.set('v.GreaseWasteOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cGreaseInterceptorSize_WF__c'))){  
            component.find('Construction_WF__cGreaseInterceptorSize_WF__c').reInit();
        }
        component.set('v.Construction.GreaseWaste_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cGreaseWaste_WF__c'))){  
            component.find('Construction_WF__cGreaseWaste_WF__c').reInit();
        }
        component.set('v.Construction.GreaseWasteOther_WF__c','');
    },
    helperChangeSlabCondition : function(component,event) {
        component.set('v.Construction.SlabCondition_WF__c','');
         component.set('v.SlabConditionOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSlabCondition_WF__c'))){  
            component.find('Construction_WF__cSlabCondition_WF__c').reInit();
        }
        component.set('v.Construction.SlabConditionOther_WF__c','');
    },
    helperChangeMechanical : function(component,event) {
        component.set('v.Construction.Mechanical_WF__c','');
         component.set('v.MechanicalOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMechanical_WF__c'))){  
            component.find('Construction_WF__cMechanical_WF__c').reInit();
        }
        component.set('v.Construction.Mechanicals_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMechanicals_WF__c'))){  
            component.find('Construction_WF__cMechanicals_WF__c').reInit();
        }
        component.set('v.Construction.MechanicalOther_WF__c','');
    },
    helperChangeFireSprinkler : function(component,event) {
        component.set('v.Construction.FireSprinkler_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cFireSprinkler_WF__c'))){  
            component.find('Construction_WF__cFireSprinkler_WF__c').reInit();
        }
        component.set('v.Construction.FireSprinklerOther_WF__c','');
    },
    helperChangeFireLifeSafety : function(component,event) {
        component.set('v.Construction.FireLifeSafety_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cFireLifeSafety_WF__c'))){  
            component.find('Construction_WF__cFireLifeSafety_WF__c').reInit();
        }
        component.set('v.Construction.SmokeEvacuation_WF__c',false);
    },
    helperChangeMiscellaneous : function(component,event) {
        component.set('v.Construction.MiscellaneousOther_WF__c','');
         component.set('v.MiscellaneousOtherError',false);
    },
    helperChangeWorkRequiredRCD : function(component,event) {
		if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')=='Full'){
            component.set('v.Construction.StoreFront_WF__c','New');
            component.set('v.Construction.Signage_WF__c','New Sign');
            component.set('v.Construction.Floors_WF__c','New');
            component.set('v.Construction.Fixtures_WF__c','New');
            component.set('v.Construction.Ceiling_WF__c','New');
            component.set('v.Construction.Lighting_WF__c','New');
            component.set('v.Construction.HVAC_WF__c','New');
            component.find("Construction_WF__cStoreFront_WF__c").reInit();
            component.find("Construction_WF__cSignage_WF__c").reInit();
            component.find("Construction_WF__cFloors_WF__c").reInit();
            component.find("Construction_WF__cFixtures_WF__c").reInit();
            component.find("Construction_WF__cCeiling_WF__c").reInit();
            component.find("Construction_WF__cLighting_WF__c").reInit();
            component.find("Construction_WF__cHVAC_WF__c").reInit();
        }
        console.log('b');
        if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')=='Partial'|| component.get('v.Construction.PriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.StoreFront_WF__c','');
            component.set('v.Construction.Signage_WF__c','');
            component.set('v.Construction.Floors_WF__c','');
            component.set('v.Construction.Fixtures_WF__c','');
            component.set('v.Construction.Ceiling_WF__c','');
            component.set('v.Construction.Lighting_WF__c','');
            component.set('v.Construction.HVAC_WF__c','');
            component.find("Construction_WF__cStoreFront_WF__c").reInit();
            component.find("Construction_WF__cSignage_WF__c").reInit();
            component.find("Construction_WF__cFloors_WF__c").reInit();
            component.find("Construction_WF__cFixtures_WF__c").reInit();
            component.find("Construction_WF__cCeiling_WF__c").reInit();
            component.find("Construction_WF__cLighting_WF__c").reInit();
            component.find("Construction_WF__cHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.PriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.TTWorkComments_WF__c','');
            component.set('v.Construction.IndemnityRequired_WF__c',false);
            //component.set('v.Construction.IndemnityAmt_WF__c',0);
        }
	},
    helperChangeWorkRequiredMidTerm : function(component,event) {
		if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='Full'){
            component.set('v.Construction.MidTermStoreFront_WF__c','New');
            component.set('v.Construction.MidTermSignage_WF__c','New Sign');
            component.set('v.Construction.MidTermFloors_WF__c','New');
            component.set('v.Construction.MidTermFixtures_WF__c','New');
            component.set('v.Construction.MidTermCeiling_WF__c','New');
            component.set('v.Construction.MidTermLighting_WF__c','New');
            component.set('v.Construction.MidTermHVAC_WF__c','New');
            component.set('v.TTWorkCommentsError',false);
            component.find("Construction_WF__cMidTermStoreFront_WF__c").reInit();
            component.find("Construction_WF__cMidTermSignage_WF__c").reInit();
            component.find("Construction_WF__cMidTermFloors_WF__c").reInit();
            component.find("Construction_WF__cMidTermFixtures_WF__c").reInit();
            component.find("Construction_WF__cMidTermCeiling_WF__c").reInit();
            component.find("Construction_WF__cMidTermLighting_WF__c").reInit();
            component.find("Construction_WF__cMidTermHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='Partial' || component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.MidTermStoreFront_WF__c','');
            component.set('v.Construction.MidTermSignage_WF__c','');
            component.set('v.Construction.MidTermFloors_WF__c','');
            component.set('v.Construction.MidTermFixtures_WF__c','');
            component.set('v.Construction.MidTermCeiling_WF__c','');
            component.set('v.Construction.MidTermLighting_WF__c','');
            component.set('v.Construction.MidTermHVAC_WF__c','');
            component.set('v.TTWorkCommentsError',false);
            component.find("Construction_WF__cMidTermStoreFront_WF__c").reInit();
            component.find("Construction_WF__cMidTermSignage_WF__c").reInit();
            component.find("Construction_WF__cMidTermFloors_WF__c").reInit();
            component.find("Construction_WF__cMidTermFixtures_WF__c").reInit();
            component.find("Construction_WF__cMidTermCeiling_WF__c").reInit();
            component.find("Construction_WF__cMidTermLighting_WF__c").reInit();
            component.find("Construction_WF__cMidTermHVAC_WF__c").reInit();
        }
        if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')==''){
            component.set('v.Construction.MidTermTTWorkComments_WF__c','');
            component.set('v.Construction.RemodelDueDate_WF__c',null);
        }
	},
    helperChangeMinimumSpendReq : function(component,event){
        component.set('v.Construction.MinimumSpendAmount_WF__c',0);
    },
    helperChangeIndemnityNeeded : function(component,event){
        component.set('v.Construction.IndemnityAmt_WF__c',0);
    }
})