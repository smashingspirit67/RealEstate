({
    setPicklistValues : function(component){
        var result = component.get('v.result');
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    },
    changeTypeOfCharges : function(component,event,helper){
        component.set('v.OtherTextValueErr',false);
        component.set('v.Construction.TotalTenantChargebacks_WF__c',0);
        helper.resetPicklist(component,event);
        helper.helperChangeTemporaryPower(component,event);
        helper.helperChangeTemporaryTrashRemoval(component,event);
        helper.helperChangeTemporaryToilets(component,event);
        helper.helperChangeMallTile(component,event);
        helper.helperChangeConstructionBarricade(component,event);
        helper.helperChangeBarricadeGraphicPackage(component,event);
        helper.helperChangeSprinklerDrainDown(component,event);
        helper.helperChangeSprinklerGrid(component,event);
        helper.helperChangeElectricalBreakersOrFuseSocket(component,event);
        helper.helperChangeFireAlarmProgramming(component,event);
        helper.helperChangeGreaseInterceptor(component,event);
        helper.helperChangeExhaustDucts(component,event);
        helper.helperChangeMakeUpAirDucts(component,event);
        helper.helperChangeShafts(component,event);
        helper.helperChangeRefrigerantLines(component,event);
        helper.helperChangePermitManagementFees(component,event);
        helper.helperChangeCommissioningFee(component,event);
        helper.helperChangeOther(component,event);
        var constructionEvent = $A.get("e.c:changeConstructionEvent");
        if(!$A.util.isUndefinedOrNull(constructionEvent)){   
            constructionEvent.fire();
        }
    },
    changeTemporaryPower : function(component,event,helper){
        helper.helperChangeTemporaryPower(component,event);
    },
    changeTemporaryTrashRemoval : function(component,event,helper){
        helper.helperChangeTemporaryTrashRemoval(component,event);
    },
    changeTemporaryToilets : function(component,event,helper){
        helper.helperChangeTemporaryToilets(component,event);
    },
    changeMallTile : function(component,event,helper){
        helper.helperChangeMallTile(component,event);
    },
    changeConstructionBarricade : function(component,event,helper){
        helper.helperChangeConstructionBarricade(component,event);
    },
    changeBarricadeGraphicPackage : function(component,event,helper){
        helper.helperChangeBarricadeGraphicPackage(component,event);
    },
    changeSprinklerDrainDown : function(component,event,helper){
        helper.helperChangeSprinklerDrainDown(component,event);
    },
    changeSprinklerGrid : function(component,event,helper){
        helper.helperChangeSprinklerGrid(component,event);
    },
    changeElectricalBreakersOrFuseSocket : function(component,event,helper){
        helper.helperChangeElectricalBreakersOrFuseSocket(component,event);
    },
    changeFireAlarmProgramming : function(component,event,helper){
        helper.helperChangeFireAlarmProgramming(component,event);
    },
    changeGreaseInterceptor : function(component,event,helper){
        helper.helperChangeGreaseInterceptor(component,event);
    },
    changeExhaustDucts : function(component,event,helper){
        helper.helperChangeExhaustDucts(component,event);
    },
    changeMakeUpAirDucts : function(component,event,helper){
        helper.helperChangeMakeUpAirDucts(component,event);
    },
    changeShafts : function(component,event,helper){
        helper.helperChangeShafts(component,event);
    },
    changeRefrigerantLines : function(component,event,helper){
        helper.helperChangeRefrigerantLines(component,event);
    },
    changePermitManagementFees : function(component,event,helper){
        helper.helperChangePermitManagementFees(component,event);
    },
    changeCommissioningFee : function(component,event,helper){
        helper.helperChangeCommissioningFee(component,event);
    },
    changeOther : function(component,event,helper){
        helper.helperChangeOther(component,event);
    },
    doInit : function(component,event){
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StructuralModification_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.StructuralModification_WF__c'))){
            var strModif = component.get('v.Construction.StructuralModification_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.structuralOthersDesc',true);
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StoreFrontage_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.StoreFrontage_WF__c'))){
            var strModif = component.get('v.Construction.StoreFrontage_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.storageFrontageOthers',true);
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DomesticWater_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.DomesticWater_WF__c'))){
            var strModif = component.get('v.Construction.DomesticWater_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.domesticWaterOthers',true);
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.Sewer_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.Sewer_WF__c'))){
            var strModif = component.get('v.Construction.Sewer_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.sewerOthers',true);
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SewerVent_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.SewerVent_WF__c'))){
            var strModif = component.get('v.Construction.SewerVent_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.sewerVentOthers',true);
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.Mechanicals_WF__c')) && !$A.util.isEmpty(component.get('v.Construction.Mechanicals_WF__c'))){
            var strModif = component.get('v.Construction.Mechanicals_WF__c').split(';');
            for(var key in strModif){
               if(strModif[key] == 'Other')
                    component.set('v.mechanicalOthers',true);
            }
        }
    },
    multiPicklistChange : function(component,event){
        var items = event.getParam("values");
        var name = event.getParam("name");
        if(items.includes('Other')){
            $A.util.removeClass(component.find(name+'Other'), 'slds-hide'); 
        }else{
            $A.util.addClass(component.find(name+'Other'), 'slds-hide');
            component.find(name+'Other').set('v.value','');
            component.set('v.'+name+'OtherError',false);
        }
        console.log(items,name);
    },
    hideOther : function(component,event){
        if(!event.getSource().get("v.value")){
            var name = event.getSource().get("v.name");   
            name = name.split('Available')[0];
            console.log(name);
            $A.util.addClass(component.find(name+'Other'), 'slds-hide'); 
        }else{
            
        }
    },
    updateStartDate : function(component,event,helper){
        helper.setPicklistValues(component,component.get('v.result'));       
        if(!$A.util.isUndefinedOrNull(component.get('v.spaceDeliveryDate'))){
            var spaceDeliveryDate = Date.parse(new Date(component.get('v.spaceDeliveryDate')));
            if(!isNaN(spaceDeliveryDate)){
                var daysLLDrawing;
                if(typeof component.get('v.Construction.DaysCompleteLLWDrawingsPermits_WF__c') !== "undefined")
                    daysLLDrawing = component.get('v.Construction.DaysCompleteLLWDrawingsPermits_WF__c')*84600000;
                else
                    daysLLDrawing = 0;
                var daysLLConstruction;
                if(typeof component.get('v.Construction.DaysCompleteLLWConstruction_WF__c') !== "undefined")
                    daysLLConstruction = component.get('v.Construction.DaysCompleteLLWConstruction_WF__c')*84600000;
                else
                    daysLLConstruction = 0;
                var requiredStartDate1 = new Date(spaceDeliveryDate-daysLLDrawing-daysLLConstruction).toISOString().substring(0,10);
                var requiredStartDate2 = new Date(spaceDeliveryDate-daysLLConstruction).toISOString().substring(0,10);
                console.log(requiredStartDate1,component.find('requiredStartDate1'));
                if(!$A.util.isUndefinedOrNull(requiredStartDate1)){
                    component.set('v.showReqDate1',true);
                }else{
                    component.set('v.showReqDate1',false);
                }
                if(!$A.util.isUndefinedOrNull(component.find('requiredStartDate1'))){  
                    component.find('requiredStartDate1').set('v.value',requiredStartDate1);                      
                }
                
                if(!$A.util.isUndefinedOrNull(requiredStartDate2)){
                    component.set('v.showReqDate2',true);
                }else{
                    component.set('v.showReqDate2',false);
                }   
                if(!$A.util.isUndefinedOrNull(component.find('requiredStartDate2'))){  
                    component.find('requiredStartDate2').set('v.value',requiredStartDate2); 
                }
                          
                var appConEvent = $A.get("e.c:ConstructionDateEvent_WF");
                if(!$A.util.isUndefinedOrNull(appConEvent)){
                    appConEvent.fire(); 
                }
            }
        }
    },
    setScopeOfWork : function(component,event,helper){
		if(component.get('v.Construction.LandlordWorkEst_WF__c')>0){
            component.set('v.Construction.ScopeOfWork_WF__c','Other');
        }else{
            component.set('v.Construction.ScopeOfWork_WF__c','As-Is');
        }
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cScopeOfWork_WF__c'))){  
            component.find('Construction_WF__cScopeOfWork_WF__c').reInit();
        }        
    },
    changeScopeOfWork : function(component,event,helper){
        component.set('v.Construction.StructuralModificationRequired_WF__c',false);
        component.set('v.Construction.DemisingWallRequired_WF__c',false);
        component.set('v.Construction.StoreFrontageRequired_WF__c',false);
        component.set('v.Construction.ElectricalRequired_WF__c',false);
        component.set('v.Construction.DataRequired_WF__c',false);
        component.set('v.Construction.DomesticWaterRequired_WF__c',false);
        component.set('v.Construction.SewerRequired_WF__c',false);
        component.set('v.Construction.SewerVentRequired_WF__c',false);
        component.set('v.Construction.GreaseWasteRequired_WF__c',false);
        component.set('v.Construction.SlabConditionRequired_WF__c',false);
        component.set('v.Construction.MechanicalRequired_WF__c',false);
        component.set('v.Construction.FireSprinklerRequired_WF__c',false);
        component.set('v.Construction.FireLifeSafetyRequired_WF__c',false);
        component.set('v.Construction.MiscellaneousRequired_WF__c',false);
        component.set('v.Construction.LLWorkDescription_WF__c','');
        component.set('v.Construction.ConstructionDeposit_WF__c',false);
        component.set('v.Construction.ConstructionDeposit_WF__c',0);
        component.set('v.Construction.DaysCompleteLLWDrawingsPermits_WF__c',0);
        component.set('v.Construction.DaysCompleteLLWConstruction_WF__c',0);
        
        component.set('v.StructuralModificationOtherError',false);
        component.set('v.DemisingWallOtherError',false);
        component.set('v.storeFrontageOtherError',false);
        component.set('v.ElectricalsOtherError',false);
        component.set('v.DataOtherError',false);
        component.set('v.DomesticWaterOtherError',false);
        component.set('v.SewerOtherError',false);
        component.set('v.SewerVentOtherError',false);
        component.set('v.GreaseWasteOtherError',false);
        component.set('v.SlabConditionOtherError',false);
        component.set('v.MechanicalOtherError',false);
        component.set('v.LLworkDescriptionError',false);
        
        helper.helperChangeStructuralModification(component,event);
        helper.helperChangeDemisingWall(component,event);
        helper.helperChangeStoreFrontage(component,event);
        helper.helperChangeElectrical(component,event);
        helper.helperChangeData(component,event);
        helper.helperChangeDomesticWater(component,event);
        helper.helperChangeSewer(component,event);        
        helper.helperChangeSewerVent(component,event);
        helper.helperChangeGreaseWaste(component,event);
        helper.helperChangeSlabCondition(component,event);
        helper.helperChangeMechanical(component,event);
        helper.helperChangeFireSprinkler(component,event);
        helper.helperChangeFireLifeSafety(component,event);
        helper.helperChangeMiscellaneous(component,event);       
        var constructionEvent = $A.get("e.c:changeConstructionEvent");
        if(!$A.util.isUndefinedOrNull(constructionEvent)){   
            constructionEvent.fire();
        }
    },
    changeStructuralModification : function(component,event,helper){
        helper.helperChangeStructuralModification(component,event);
    },
    changeDemisingWall : function(component,event,helper){
        helper.helperChangeDemisingWall(component,event);
    },
    changeStoreFrontage : function(component,event,helper){
        helper.helperChangeStoreFrontage(component,event);
    },
    changeElectrical : function(component,event,helper){
        helper.helperChangeElectrical(component,event);    
    },
    changeData : function(component,event,helper){
        helper.helperChangeData(component,event);  
    },
    changeDomesticWater : function(component,event,helper){
        helper.helperChangeDomesticWater(component,event); 
    },
    changeSewer : function(component,event,helper){
        helper.helperChangeSewer(component,event);        
    },
    changeSewerVent : function(component,event,helper){
        helper.helperChangeSewerVent(component,event);
    },
    changeGreaseWaste : function(component,event,helper){
        helper.helperChangeGreaseWaste(component,event);
    },
    changeSlabCondition : function(component,event,helper){
        helper.helperChangeSlabCondition(component,event);
    },
    changeMechanical : function(component,event,helper){
        helper.helperChangeMechanical(component,event);
    },
    changeFireSprinkler : function(component,event,helper){
        helper.helperChangeFireSprinkler(component,event);
    },
    changeFireLifeSafety : function(component,event,helper){
        helper.helperChangeFireLifeSafety(component,event);
    },
    changeMiscellaneous : function(component,event,helper){
        helper.helperChangeMiscellaneous(component,event); 
    },
    setPicklistValues : function(component){
        var result = component.get('v.result');
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    },
    changeBuildOut : function(component,event,helper){
        component.set('v.Construction.BuildOut_WF__c','');
        component.set('v.TTPriorWorkCommentsError',false);
        component.set('v.TTWorkCommentsError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cBuildOut_WF__c'))){            
            component.find('Construction_WF__cBuildOut_WF__c').reInit();
        }       
        component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
            component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
        }  
        component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
            component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
        }  
        component.set('v.Construction.MinimumSpendRequired_WF__c',false);
        helper.helperChangeMinimumSpendReq(component,event);
        helper.helperChangeWorkRequiredRCD(component,event);
        helper.helperChangeWorkRequiredMidTerm(component,event);
        var constructionEvent = $A.get("e.c:changeConstructionEvent");
        if(!$A.util.isUndefinedOrNull(constructionEvent)){            
            constructionEvent.fire();
        } 
    },
    changeBuildOutPick : function(component,event,helper){
        if(component.get('v.Construction.BuildOut_WF__c')=='No Work Required' || component.get('v.Construction.BuildOut_WF__c')==''){
            component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
            
            component.set('v.TTPriorWorkCommentsError',false);
        	component.set('v.TTWorkCommentsError',false);
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
            }  
            component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
            }  
            component.set('v.Construction.MinimumSpendRequired_WF__c',false);
            helper.helperChangeMinimumSpendReq(component,event);
            helper.helperChangeWorkRequiredRCD(component,event);
            helper.helperChangeWorkRequiredMidTerm(component,event);
        }
        if(component.get('v.Construction.BuildOut_WF__c')=='Prior To RCD'){
            
			component.set('v.TTWorkCommentsError',false);
            component.set('v.Construction.MidTermPriorToRCDWorkRequired_WF__c','');
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cMidTermPriorToRCDWorkRequired_WF__c').reInit();
            }  
            helper.helperChangeWorkRequiredMidTerm(component,event);
        }
		if(component.get('v.Construction.BuildOut_WF__c')=='Mid-Term Remodel'){
            component.set('v.Construction.PriorToRCDWorkRequired_WF__c','');
            component.set('v.TTPriorWorkCommentsError',false);
            if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c'))){            
                component.find('Construction_WF__cPriorToRCDWorkRequired_WF__c').reInit();
            }  
            helper.helperChangeWorkRequiredRCD(component,event);
        }
    },
    changeWorkRequiredRCD : function(component,event,helper){
        helper.helperChangeWorkRequiredRCD(component,event);
    },
    changeWorkRequiredMidTerm : function(component,event,helper){
        helper.helperChangeWorkRequiredMidTerm(component,event);
    },
    changeMinimumSpendReq : function(component,event,helper){
        helper.helperChangeMinimumSpendReq(component,event);
    },
    changeIndemnityNeeded : function(component,event,helper){
        helper.helperChangeIndemnityNeeded(component,event);
    }
})