({
    /*
    * Modification Log
    * -------------------------------------------------------------------------------------------------------
    * Name              Date            Comments
    * --------------    ------------    ---------------------------------------------------------------------
    * Arut              08/21/2018      Changes for GDM-8354: Clearing out milestone dates on opportunity
    * 
    * */ 

    updateStandardChargesHelper : function(component){
        var documentType = component.get('v.sObj.New_Document_Type_WF__c');
        var rcdDate;
        if(!$A.util.isEmpty(component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c')) && !$A.util.isEmpty(component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c'))){
            var dateString1 = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
            var date1 = new Date(dateString1);
            var dateString2 = component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c');
            var date2 = new Date(dateString2);
            if(date1<date2){
                rcdDate = date1;
            }else{
                rcdDate = date2;
            }
        }else if($A.util.isEmpty(component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c')) && !$A.util.isEmpty(component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c'))){
            rcdDate = component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c');
        }else if(!$A.util.isEmpty(component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c')) && $A.util.isEmpty(component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c'))){
            rcdDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
        }else{
            rcdDate = component.get('v.sObj.RCDEarlierOfOpeningOf_WF__c');
        }
        
        var charges = component.get('v.Charges');
        var GLA=1;
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.AmendmentGLAUsed_WF__c')) && component.get('v.sObj.AmendmentGLAUsed_WF__c')!=0){
            GLA = component.get('v.sObj.AmendmentGLAUsed_WF__c');
        }else{
            GLA = component.get('v.sObj.GLAUsed_WF__c');
        }
        var productId ='';
        console.log('GLAGLAGLAGLAGLA',GLA);
        if(!$A.util.isUndefinedOrNull(component.get('v.newProduct'))){
            productId = component.get('v.newProduct').Id; 
        }else{
            productId = component.get('v.sObj.Unit_WF__c');
        }
        console.log('Unit ID',component.get('v.sObj.Unit_WF__c'));
        console.log('productId',productId,rcdDate);
        var action = component.get('c.getStandardChargesFly');
        action.setParams({
            "RCDDate" : rcdDate,
            "UnitId" : productId,
            "GLA" : GLA,
            "charges" : JSON.stringify(charges),
            "DocumentType" : documentType
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            console.log('isSuccess',isSuccess);
            if(isSuccess){
                var result = response.getReturnValue();
                console.log(result);
                if(result != null){
                    $A.createComponent(
                        "c:CHoperatingExpense",
                        {
                            "aura:id": "CH_operatingExpenseComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": GLA,
                            "error": component.getReference("v.CH_operatingExpenseError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(opChargesCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var opChCmp = [];
                                opChCmp.push(opChargesCmp);
                                component.set('v.opChargeComponent', opChCmp);
                                opChargesCmp.reInit();
                                opChargesCmp.changeUnit();
                                opChargesCmp.calculateVariance();
                            }
                        }
                    );
                    console.log(component.getReference("v.Charges"));
                    $A.createComponent(
                        "c:CHinsurance",
                        {
                            "aura:id": "CH_insuranceComp",
                            "disabled": component.getReference("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "error": component.getReference("v.CH_insuranceError")
                        },
                        function(insuranceCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var insCmp = [];
                                insCmp.push(insuranceCmp);
                                component.set('v.insuranceComponent', insCmp);
                                insuranceCmp.reInit();
                                insuranceCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHfoodCourtExpense",
                        {
                            "aura:id": "CH_foodCourtExpenseComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": GLA,
                            "error": component.getReference("v.CH_foodCourtExpenseError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(fcCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var fdCrtCmp = [];
                                fdCrtCmp.push(fcCmp);
                                component.set('v.fcComponent', fdCrtCmp);
                                fcCmp.reInit();
                                fcCmp.changeUnit();
                                fcCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHpromotionalCharges",
                        {
                            "aura:id": "CH_promotionalChargesComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": GLA,
                            "error": component.getReference("v.CH_promotionalChargesError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(pCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var promoCmp = [];
                                promoCmp.push(pCmp);
                                component.set('v.promoComponent', promoCmp);
                                pCmp.reInit();
                                pCmp.changeUnit();
                                pCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHrealEstateTax",
                        {
                            "aura:id": "CH_realEstateTaxComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "realEstateTax":component.getReference("v.realEstateTax"),
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "taxDescLengthErr":component.getReference("v.taxDescLengthErr"),
                            "GLAUsed": GLA,
                            "error": component.getReference("v.CH_realEstateTaxError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(reCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var rEstateCmp = [];
                                rEstateCmp.push(reCmp);
                                component.set('v.realEstComponent', rEstateCmp);
                                reCmp.reInit();
                                reCmp.changeUnit();
                                reCmp.calculateVariance();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHmallCharges",
                        {
                            "aura:id": "CH_mallChargesComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "StandardCharges": component.getReference("v.StandardCharges"),
                            "GLAUsed": component.getReference("v.opportunity.GLAUsed_WF__c"),
                            "error": component.getReference("v.CH_mallChargesError"),
                            "result": component.getReference("v.relatedRecord"),
                            "WaterError": component.getReference("v.WaterError"),
                            "FDSError": component.getReference("v.FDSError"),
                            "ElectricityError": component.getReference("v.ElectricityError"),
                            "TrashError": component.getReference("v.TrashError"),
                            "EncldMallError": component.getReference("v.EncldMallError"),
                            "HVACError": component.getReference("v.HVACError"),
                            "ParkingError": component.getReference("v.ParkingError"),
                            "Other1Error": component.getReference("v.Other1Error"),
                            "Other2Error": component.getReference("v.Other2Error"),
                            "Other3Error": component.getReference("v.Other3Error"),
                            "OtherDes1Error": component.getReference("v.OtherDes1Error"),
                            "OtherDes2Error": component.getReference("v.OtherDes2Error"),
                            "OtherDes3Error": component.getReference("v.OtherDes3Error")
                        },
                        function(mallCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var mCmp = [];
                                mCmp.push(mallCmp);
                                component.set('v.mallComponent', mCmp);
                                mallCmp.reInit();
                            }
                        }
                    );
                    $A.createComponent(
                        "c:CHother",
                        {
                            "aura:id": "CH_otherComp",
                            "disabled": component.get("v.disabled"),
                            "Charges": result,
                            "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                            "error": component.getReference("v.CH_otherError"),
                            "result": component.getReference("v.relatedRecord")
                        },
                        function(otherCmp, status, errorMessage){
                            if(status === "SUCCESS"){
                                var oCmp = [];
                                oCmp.push(otherCmp);
                                component.set('v.otherChargeComponent', oCmp);
                                otherCmp.reInit();
                            }
                        }
                    );
                    component.set('v.Charges',result);
                }
            }
        });
        if(!$A.util.isUndefinedOrNull(productId) && !$A.util.isEmpty(charges)){
            $A.enqueueAction(action);
        }
    },
    checkRequiredFieldsHelper : function(component, event ) {
        /*changes to make fields required : start*/
        
        var docTypeError = component.find("docTypeErrorId");    
        var containgencyError = component.find("containgencyErrorId");  
        var legalEntityTypeError = component.find("legalEntityTypeErrorId");
        var useClauseError = component.find("useClauseErrorId");
        var securityTypeError = component.find("securityTypeErrorId");
        var brokerError = component.find("brokerErrorId");
        var dbaCustomerError = component.find("dbaCustomerErrorId");
        var legalEntityError = component.find("legalEntityErrorId");
        var dealmakerLeaseError = component.find("dealmakerErrorLeaseId");
        var dealmakerLeaseBlankError = component.find("dealmakerErrorLeaseBlankId");
        var dealmakerOppError = component.find("dealmakerErrorOppId");
        var centerNameError = component.find("centerNameErrorId");
        var useTypeError = component.find("useTypeErrorId");
        var productFamilyError = component.find("productFamilyErrorId");
        var unitError = component.find("unitErrorId");  
        var restrictionTypeError = component.find("restrictionTypeErrorId");
        var areaRestUnitOfMeasureError = component.find("areaRestUnitOfMeasureErrorId");
        var relocRightsDescriptionError = component.find("relocRightsDescriptionErrorId");
        var boolIsreqFiledEmpty = false;
        var strDeadReasonComms = component.get("v.sObj.OtherReasonOpportunityDead_WF__c");
        var strDeadReason = component.get("v.sObj.LossReason_WF__c");
        component.set("v.CO_sendDocsToTempError", false);
        component.set('v.COV_commonAreaRestrictionTempError',false);
        component.set("v.GI_securitySectionTempError", false);      
        component.set('v.COV_llRelocationRightsTempError',false);
        component.set('v.COV_llTerminationRightsTempError',false);
        component.set('v.COV_noBuildZoneTempError',false);
        component.set('v.COV_exclusiveRightTempError',false);
        var result= component.get('v.relatedRecord');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        
        component.set("v.GI_whereSectionTempError",false);
        component.set("v.GI_whenSectionTempError",false);
        component.set('v.OP_detailsTempError', false);
        component.set('v.CON_capitalTempError',false);
        component.set("v.CH_mallChargesTempError", false);
        component.set('v.CON_tenantConstructionReqTempError',false);
        component.set("v.COV_radiusRestrictionTempError", false);
        component.set("v.commonAreaRestrictionTempError", false);
        component.set('v.CO_detailsTempError',false);
        component.set("v.COV_kickoutsTempError", false);
        /*** What Section ***/
        
        var whatEmpty = false;
        var agreementTypeError = component.find("agreementTypeError");
        var agreementTypeErrorInvalid = component.find("agreementTypeErrorInvalid");
        var dealExpiryDate = component.get('v.sObj.NewExpiration_WF__c');
        var dealRCDDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
        var isReconfig = component.get('v.sObj.AmendmentReconfiguration_WF__c');
        var unitConfig = component.get('v.selectedUnits');
        var reservation = component.get('v.selectedProducts');
        var invalidUnitChoosen = false;
        var noRCDError = true;
        var noExpirationError = true;
        
        if(isReconfig == true){
            if(!$A.util.isUndefinedOrNull(unitConfig)){
                for(var i = 0; i < unitConfig.length; i++){
                    if(unitConfig[i].unitStatus == 'Active'){
                        if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(unitConfig[i].activationEndDate)){
                            if(dealExpiryDate > unitConfig[i].activationEndDate){
                                invalidUnitChoosen = true;
                                boolIsreqFiledEmpty = true;
                                noExpirationError = false;                                
                            }                                                       
                        }
                        if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(unitConfig[i].activationStartDate)){
                            if(dealRCDDate < unitConfig[i].activationStartDate){
                                invalidUnitChoosen = true;
                                boolIsreqFiledEmpty = true;
                                noRCDError = false;                              
                            }                                                        
                        }
                    }
                }       
            }
        }else if(!isReconfig){
            var unitToAdd = component.get('v.addProduct');
            if(!$A.util.isUndefinedOrNull(reservation)){
                if(reservation.length > 0){
                    for(var i = 0; i < reservation.length; i++){ 
                        if( reservation[i].idProduct == unitToAdd ){
                            if(reservation[i].unitStatus == 'Active'){
                                if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(reservation[i].activationEndDate)){
                                    if(dealExpiryDate > reservation[i].activationEndDate){
                                        invalidUnitChoosen = true;
                                        boolIsreqFiledEmpty = true;
                                        noExpirationError = false;
                                    }                                       
                                }
                                if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(reservation[i].activationStartDate)){
                                    if(dealRCDDate < reservation[i].activationStartDate){
                                        invalidUnitChoosen = true;
                                        boolIsreqFiledEmpty = true;
                                        noRCDError = false;
                                    }                                       
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(noRCDError){
            $A.util.addClass(component.find("unitRCDErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitRCDErrorId"),'slds-hide');
        }
        if(noExpirationError){
            $A.util.addClass(component.find("unitExpirationErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitExpirationErrorId"),'slds-hide');
        }
        
        
        console.log('Hold  ',component.get("v.sObj.On_Hold_WF__c") , ' Reason' ,component.get("v.sObj.HoldReason_WF__c") );
        //Comments Validation
        var commentError = false;
        if(strDeadReason =='Other' && (strDeadReasonComms ==null || strDeadReasonComms ==''))
        {
            component.set('v.oppDeadCommsError', true);
            commentError = true;
        }
        else
        {           
            component.set('v.oppDeadCommsError', false);
        }
        //Modified by Vikram - 23-OCT-2017 : Bug -6995 and GDM-7756
        
        if(component.get('v.sObj.On_Hold_WF__c') && $A.util.isEmpty(component.get('v.sObj.HoldReason_WF__c'))){
            component.set('v.oppOnHoldValidation', true);
            component.set('v.CO_detailsTempError', true);
            component.set('v.CO_details', true);
            commentError = true;
            boolIsCmntError = true;
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.CO_details', false);
            component.set('v.CO_detailsTempError', false);
            component.set('v.oppOnHoldValidation', false);
            commentError = false;
            boolIsCmntError =  false;
        }
		if((component.get("v.sObj.REC_Approval_Status_WF__c")=='Reject'||component.get("v.sObj.REC_Approval_Status_WF__c")=='On Hold') && $A.util.isEmpty(component.get("v.sObj.REC_Comments_WF__c"))){
            component.set('v.recCommentsRejectError', true);
            component.set('v.CO_detailsTempError', true);
            component.set('v.CO_details', true);
            commentError = true;
			boolIsreqFiledEmpty = true;
            boolIsCmntError = true
        }else{
            component.set('v.recCommentsRejectError', false);
			commentError = false;
		}
        if(commentError){
            component.set('v.CO_detailsTempError', true);
            boolIsreqFiledEmpty=true;       
        }else{
            component.set('v.CO_detailsTempError', false);  
        }
        
        //Check and set the error flags for each section - END
        console.log('v.oppOnHoldValidation-->',component.get("v.oppOnHoldValidation"));
        if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c')) || component.get('v.sObj.New_Agreement_Type_WF__c') === ''){
            $A.util.removeClass(agreementTypeError, 'slds-hide');
            $A.util.addClass(agreementTypeErrorInvalid, 'slds-hide');
            whatEmpty = true;
        } else{
            $A.util.addClass(agreementTypeError, 'slds-hide');
            $A.util.addClass(agreementTypeErrorInvalid, 'slds-hide');
            if(component.get('v.sObj.New_Agreement_Type_WF__c').includes('Rent Relief') ||
               component.get('v.sObj.New_Agreement_Type_WF__c').includes('Termination') ||
               component.get('v.sObj.New_Agreement_Type_WF__c').includes('Assignment') ||
               component.get('v.sObj.New_Agreement_Type_WF__c').includes('New')){
                whatEmpty = true;
                $A.util.removeClass(agreementTypeErrorInvalid, 'slds-hide');
            }
        }
        
        //Check and set the error flags for each section - START
        if(whatEmpty){
            boolIsreqFiledEmpty = true;
            component.set("v.GI_whatSectionError", true);
        }else{
            component.set("v.GI_whatSectionError", false);
        }
        
        /*** Who Section ***/
        var whoIsreqFiledEmpty = false;
        
        // check for DBA is not empty
        if(component.get('v.sObj.B2BCustomer_WF__c')=='' || component.get('v.sObj.B2BCustomer_WF__c')==null){
            $A.util.removeClass(dbaCustomerError, 'slds-hide');
            whoIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(dbaCustomerError, 'slds-hide');
        }
        
        // check for Deal maker is not empty
        if(component.get('v.relatedRecord.sObjName')=='Lease_WF__c' && !$A.util.isUndefinedOrNull(component.get('v.sObj.Opportunity__c'))){
            if(component.get('v.sObj.Opportunity__r.Dealmaker_WF__c')=='' || component.get('v.sObj.Opportunity__r.Dealmaker_WF__c')==null){
                $A.util.removeClass(dealmakerLeaseError, 'slds-hide');
                whoIsreqFiledEmpty = true;
            }else{          
                $A.util.addClass(dealmakerLeaseError, 'slds-hide');
            }
        }
        if(component.get('v.relatedRecord.sObjName')=='Lease_WF__c' && $A.util.isEmpty(component.get('v.sObj.Opportunity__c'))){
            if(component.get('v.relatedRecord.dealMaker.Id')=='' || component.get('v.relatedRecord.dealMaker.Id')==null){
                $A.util.removeClass(dealmakerLeaseBlankError, 'slds-hide');
                whoIsreqFiledEmpty = true;
        }else{
                $A.util.addClass(dealmakerLeaseBlankError, 'slds-hide');
            }
        }
        if(component.get('v.relatedRecord.sObjName')=='Opportunity'){
            if(component.get('v.sObj.Dealmaker_WF__c')=='' || component.get('v.sObj.Dealmaker_WF__c')==null){
                $A.util.removeClass(dealmakerOppError, 'slds-hide');
                whoIsreqFiledEmpty = true;
            }else{          
                $A.util.addClass(dealmakerOppError, 'slds-hide');
            }
        }
        
        // check for Use Clause is not empty
        if(component.get('v.sObj.UseClause_WF__c')== undefined || component.get('v.sObj.UseClause_WF__c')=='' || component.get('v.sObj.UseClause_WF__c')==null){
            $A.util.removeClass(useClauseError, 'slds-hide');
            whoIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(useClauseError, 'slds-hide');
        }
        
        var BrokerCost = isNaN(parseFloat(component.get('v.Construction.BrokerCommissions_WF__c'))) ? 0 : parseFloat(component.get('v.Construction.BrokerCommissions_WF__c'));
        if(component.get('v.sObj.Broker_WF__c')==null && BrokerCost>0){
            $A.util.removeClass(brokerError, 'slds-hide');
            whoIsreqFiledEmpty = true;
        }else{
            $A.util.addClass(brokerError, 'slds-hide');
        }
        
        //Check and set the error flags for each section - START
        if(whoIsreqFiledEmpty){ //|| helper.commonValidations(component)){
            boolIsreqFiledEmpty = true;
            component.set("v.GI_whoSectionError", true);
        }else{
            component.set("v.GI_whoSectionError", false);
        }
        
        /*** Security Section ***/
        var securityMissing = false;
        if(component.get('v.sObj.SecurityDepositRequired_WF__c') == true && (component.get('v.sObj.SecurityType_WF__c')=='' || component.get('v.sObj.SecurityType_WF__c')==null || component.get('v.sObj.SecurityType_WF__c')=='--None--')){
            $A.util.removeClass(securityTypeError, 'slds-hide');
            securityMissing = true;
        }else{          
            $A.util.addClass(securityTypeError, 'slds-hide');
        }   
        
        if(component.get('v.sObj.SecurityDepositRequired_WF__c')){
            var securityType = component.get('v.sObj.SecurityType_WF__c');
            if(securityType !== undefined && securityType !== null && securityType !== ''){
                var errorMsgDiv = component.find("cashDepError");
                //If ‘Cash Deposit’ is selected, user can save the sObj without entering in ‘Cash Deposit’ amount
                if(securityType.includes('Cash Deposit') && (component.get('v.sObj.Cash_Deposit_Amount_WF__c') === undefined || component.get('v.sObj.Cash_Deposit_Amount_WF__c') === null || 
                                                             component.get('v.sObj.Cash_Deposit_Amount_WF__c') === '' || component.get('v.sObj.Cash_Deposit_Amount_WF__c') <= 0)){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    securityMissing = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                
                errorMsgDiv = component.find("holdCashDepError");
                if(securityType.includes('Cash Deposit') && (component.get('v.sObj.Hold_Cash_Deposit_For_Amendment_WF__c') === undefined || component.get('v.sObj.Hold_Cash_Deposit_For_Amendment_WF__c') === null || 
                                                             component.get('v.sObj.Hold_Cash_Deposit_For_Amendment_WF__c') === '')){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    securityMissing = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                
                errorMsgDiv = component.find("locError");
                //adding at least one LOC should be required IF ‘Letter of Credit’ is selected/included in the ‘Security Type’
                if(securityType.includes('Letter of Credit') && component.get('v.noOfletterOfCredit') === 0){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    securityMissing = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
                
                errorMsgDiv = component.find("guarantorError");
                //adding at least one Guarantor should be required IF ‘Guarantor’ is selected/included in the ‘Security Type’
                if(securityType.includes('Guarantor') && component.get('v.noOfGuarantor') === 0){
                    $A.util.removeClass(errorMsgDiv, 'slds-hide');
                    securityMissing = true;
                } else{
                    $A.util.addClass(errorMsgDiv, 'slds-hide');
                }
            }
        }
        
        if(securityMissing || component.get('v.showErrors') || component.get('v.showGuarantorErrors')){
            component.set("v.GI_securitySectionTempError", true);
            boolIsreqFiledEmpty = true;
        }else{
            component.set("v.GI_securitySectionTempError", false);
        }
        
        /*** Where Section ***/
        
        // check for Use Type is not empty
        if(component.get('v.sObj.UseType_WF__c')=='' || component.get('v.sObj.UseType_WF__c')==null || component.get('v.sObj.UseType_WF__c')=='--None--'){
            $A.util.removeClass(useTypeError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{          
            $A.util.addClass(useTypeError, 'slds-hide');
        }
        
        // check for Product Family is not empty
        if(component.get('v.sObj.ProductFamily_WF__c')=='' || component.get('v.sObj.ProductFamily_WF__c')==null || component.get('v.sObj.ProductFamily_WF__c')=='--None--' || invalidUnitChoosen){
            $A.util.removeClass(productFamilyError, 'slds-hide');
            boolIsreqFiledEmpty = true;
        }else{			
            $A.util.addClass(productFamilyError, 'slds-hide');
        }
        
        if(component.get('v.sObj.UseType_WF__c')=='' || component.get('v.sObj.UseType_WF__c')==null || component.get('v.sObj.UseType_WF__c')=='--None--' || component.get('v.sObj.ProductFamily_WF__c')=='' || component.get('v.sObj.ProductFamily_WF__c')==null || component.get('v.sObj.ProductFamily_WF__c')=='--None--'){
            component.set("v.GI_whereSectionTempError", true);
        }else{
            component.set("v.GI_whereSectionTempError",false);
        }
        

        
        /*** When Section ***/
        var whenSectionError = false;
        if(component.get('v.containgencyContainOther') && (component.get('v.sObj.ContingencyComments_WF__c')==null || component.get('v.sObj.ContingencyComments_WF__c')=='')){
            $A.util.removeClass(containgencyError, 'slds-hide');
            whenSectionError = true;            
        }else{
            $A.util.addClass(containgencyError, 'slds-hide');
        }
        
        if(new Date(component.get('v.sObj.NewExpiration_WF__c')) < new Date(component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c'))){
            $A.util.removeClass(component.find('NewExpiryErrorId'), 'slds-hide');
            whenSectionError = true;            
        }else{
            $A.util.addClass(component.find('NewExpiryErrorId'), 'slds-hide');
        }
        
        if(whenSectionError){
            boolIsreqFiledEmpty = true;
            component.set("v.GI_whenSectionTempError", true);
        }else{
            component.set("v.GI_whenSectionTempError", false);
        }        
        
        if(component.get('v.sObj.OptionToExtend_WF__c')){
            if(component.get('v.sObj.OptionsMeasuringPeriod_WF__c') ==='Other' && ($A.util.isUndefinedOrNull(component.get('v.sObj.OptionsMeasuringPeriodComments_WF__c')) || component.get('v.sObj.OptionsMeasuringPeriodComments_WF__c') === '')){
                component.set('v.optionsErrors', true);
                component.set('v.OP_detailsTempError', true);
            } else{
                component.set('v.optionsErrors', false);
                component.set('v.OP_detailsTempError', false);
            }
        }
        
        /****Charges Util Validation ****/
        
        var chargesValidationBool = false;
        var mallCharges = {} ;
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Utilities']){
                mallCharges = charges[item];
            }
        }
        if(mallCharges.WaterProposed_WF__c!='' && mallCharges.WaterProposed_WF__c!=null && mallCharges.WaterProposed_WF__c!=0 && mallCharges.WaterProposed_WF__c!='0'  && ( mallCharges.WaterUnitofMeasure_WF__c == '--Select a value--' || mallCharges.WaterUnitofMeasure_WF__c == '') ){
            component.set('v.WaterError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.WaterError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.FDSProposed_WF__c!='' && mallCharges.FDSProposed_WF__c!=null && mallCharges.FDSProposed_WF__c!=0 && mallCharges.FDSProposed_WF__c!='0' && (mallCharges.FDSUnitofMeasure_WF__c == '--Select a value--' || mallCharges.FDSUnitofMeasure_WF__c == '') ){
            component.set('v.FDSError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.FDSError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.ElectricityProposed_WF__c!='' && mallCharges.ElectricityProposed_WF__c!=null && mallCharges.ElectricityProposed_WF__c!=0 && mallCharges.ElectricityProposed_WF__c!='0' && (mallCharges.ElectricityUnitofMeasure_WF__c == '--Select a value--' || mallCharges.ElectricityUnitofMeasure_WF__c == '') ){
            component.set('v.ElectricityError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.ElectricityError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.EncldMallHVACProposed_WF__c!='' && mallCharges.EncldMallHVACProposed_WF__c!=null && mallCharges.EncldMallHVACProposed_WF__c!=0 && mallCharges.EncldMallHVACProposed_WF__c!='0' && (mallCharges.EncldMallHVACUnitofMeasure_WF__c == '--Select a value--' || mallCharges.EncldMallHVACUnitofMeasure_WF__c == '') ){
            component.set('v.EncldMallError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.EncldMallError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.TTHVACCPLChilledWaterProposed_WF__c!='' && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!=null && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!=0 && mallCharges.TTHVACCPLChilledWaterProposed_WF__c!='0' && (mallCharges.TTHVACCPLChilledWaterUnitofMeasure_WF__c == '--Select a value--' || mallCharges.TTHVACCPLChilledWaterUnitofMeasure_WF__c == '') ){
            component.set('v.HVACError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.HVACError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.TrashProposed_WF__c!='' && mallCharges.TrashProposed_WF__c!=null && mallCharges.TrashProposed_WF__c!=0 && mallCharges.TrashProposed_WF__c!='0' && (mallCharges.TrashUnitofMeasure_WF__c == '--Select a value--' || mallCharges.TrashUnitofMeasure_WF__c == '') ){
            component.set('v.TrashError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.TrashError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.ParkingProposed_WF__c !='' && mallCharges.ParkingProposed_WF__c!=null && mallCharges.ParkingProposed_WF__c!=0 && mallCharges.ParkingProposed_WF__c!='0' && (mallCharges.ParkingUnitofMeasure_WF__c == '--Select a Value--' || mallCharges.ParkingUnitofMeasure_WF__c == '') ){
            component.set('v.ParkingError',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.ParkingError',false);
        }
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge1Proposed_WF__c!='' && mallCharges.OtherCharge1Proposed_WF__c!=null && mallCharges.OtherCharge1Proposed_WF__c!=0 && mallCharges.OtherCharge1Proposed_WF__c!='0' && (mallCharges.OtherCharge1UnitofMeasure_WF__c == '--Select a Value--' || mallCharges.OtherCharge1UnitofMeasure_WF__c == '') ){
            component.set('v.Other1Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other1Error',false);
        }
        
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge2Proposed_WF__c!='' && mallCharges.OtherCharge2Proposed_WF__c!=null  && mallCharges.OtherCharge2Proposed_WF__c!=0 && mallCharges.OtherCharge2Proposed_WF__c!='0'  && (mallCharges.OtherCharge2UnitofMeasure_WF__c == '--Select a value--' || mallCharges.OtherCharge2UnitofMeasure_WF__c == '') ){
            component.set('v.Other2Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other2Error',false);
        }
        
        console.log(chargesValidationBool);
        if(mallCharges.OtherCharge3Proposed_WF__c !='' && mallCharges.OtherCharge3Proposed_WF__c !=null  && mallCharges.OtherCharge3Proposed_WF__c !=0 && mallCharges.OtherCharge3Proposed_WF__c !='0'  && (mallCharges.OtherCharge3UnitofMeasure_WF__c == '--Select a value--' || mallCharges.OtherCharge3UnitofMeasure_WF__c == '') ){
            component.set('v.Other3Error',true);
            chargesValidationBool = true;
        }else{          
            component.set('v.Other3Error',false);
        }
        
        console.log(chargesValidationBool);
        if(chargesValidationBool){
            component.set("v.CH_mallChargesTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.CH_mallChargesTempError", false);
        }
        
        /*** Capital Construction ***/
        
        //Capital Error Section
        var capitalError = false;     
        
        // Check for Tenant Allowance Amount for Others
        var currTotalTA = component.get('v.Construction.TenantAllowance_WF__c');
        var calcTotalTA = component.get('v.Construction.TAPaymentAmount1_WF__c')+
            component.get('v.Construction.TAPaymentAmount2_WF__c')+
            component.get('v.Construction.TAPaymentAmount3_WF__c')+
            component.get('v.Construction.TAPaymentAmount4_WF__c')+
            component.get('v.Construction.TAPaymentAmount5_WF__c');
        var calcPerTA = component.get('v.Construction.TAPaymentPercent1_WF__c')+
            component.get('v.Construction.TAPaymentPercent2_WF__c')+
            component.get('v.Construction.TAPaymentPercent3_WF__c')+
            component.get('v.Construction.TAPaymentPercent4_WF__c')+
            component.get('v.Construction.TAPaymentPercent5_WF__c');
        console.log('calcPerTA',calcPerTA);
        if(component.get('v.Construction.TAPaymentSchedule_WF__c') == 'Other'){
            if(component.get('v.Construction.TAProgressPaymentOtherType_WF__c')=='$'){
                if(currTotalTA != calcTotalTA){
                    console.log('Termination Rights Desc empty-->');
                    component.set('v.TAPaymentAmountError',true);
                    boolIsreqFiledEmpty = true;
                    capitalError = true;
                }else{
                    component.set('v.TAPaymentAmountError',false);
                }
            }
            if(component.get('v.Construction.TAProgressPaymentOtherType_WF__c')=='%'){
                if(calcPerTA != 1){
                    console.log('Termination Rights Desc empty-->');
                    component.set('v.TAPaymentAmountError',true);
                    boolIsreqFiledEmpty = true;
                    capitalError = true;
                }else{
                    component.set('v.TAPaymentAmountError',false);
                }
            }
        }else{
            component.set('v.TAPaymentAmountError',false);
        }
        
        //Capital Other Landlord Cost
        if(component.get('v.Construction.OtherLandlordCosts_WF__c')>0 && (component.get('v.Construction.OtherCostsDescription_WF__c')=='' || component.get('v.Construction.OtherCostsDescription_WF__c')==null)){
            component.set('v.CapitalOtherCostDescriptionError',true);
            capitalError = true;
        }else{
            component.set('v.CapitalOtherCostDescriptionError',false);
        }
        
        if(capitalError){
            boolIsreqFiledEmpty = true;
            component.set('v.CON_capitalTempError',true);
        }else{
            component.set('v.CON_capitalTempError',false);
        }
        
        /*** Construction Tenant Construction ***/
        
        // check for Remodel Date is not empty
        if(component.get('v.Construction.BuildOutRequired_WF__c') && (component.get('v.Construction.BuildOut_WF__c')=='Mid-Term Remodel' || component.get('v.Construction.BuildOut_WF__c')=='Both')){
            if($A.util.isUndefinedOrNull(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')) || component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c')=='' ){
                component.set('v.workRequiredError',true);
                component.set('v.CON_tenantConstructionReqTempError',true);
                boolIsreqFiledEmpty = true;
            } else{
                component.set('v.workRequiredError',false);
                component.set('v.CON_tenantConstructionReqTempError',false);
            }
            if(component.get('v.Construction.MidTermPriorToRCDWorkRequired_WF__c') !='No Work Required' && (component.get('v.Construction.RemodelDueDate_WF__c')==null || component.get('v.Construction.RemodelDueDate_WF__c')=='' )){ //GDM-7370 : updated condition
                component.set('v.RemodelDueDateError',true);
                component.set('v.CON_tenantConstructionReqTempError',true);
                boolIsreqFiledEmpty = true;
            }else{
                component.set('v.RemodelDueDateError',false);
                component.set('v.CON_tenantConstructionReqTempError',false);
            }
        }
        
        /*** Covenant Common Area Restriction ***/
        
        var commonAreaRestrictionValidationBool = false;
        var commonAreaRestriction = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Common Area Restrictions']){
                commonAreaRestriction = covenant[item];
            }
        }
        
        // check for Restriction Type is not empty       
        if(commonAreaRestriction.CommonAreaRestrictions_WF__c==true && (commonAreaRestriction.RestrictionType_WF__c =='' || commonAreaRestriction.RestrictionType_WF__c ==null || commonAreaRestriction.RestrictionType_WF__c=='--None--')){
            component.set('v.restrictionTypeError',true);
            commonAreaRestrictionValidationBool = true;
        }else{          
            component.set('v.restrictionTypeError',false);
        }
        
        // check for Area Restriction Unit of Measure is not empty
        if(commonAreaRestriction.CommonAreaRestrictions_WF__c==true && (commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c =='' || commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c==null || commonAreaRestriction.AreaRestrictionUnitofMeasure_WF__c=='--None--')){
            component.set('v.areaRestUnitOfMeasureError',true);
            commonAreaRestrictionValidationBool = true;
        }else{          
            component.set('v.areaRestUnitOfMeasureError',false);
        }
        
        if(commonAreaRestrictionValidationBool){
            component.set("v.COV_commonAreaRestrictionTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_commonAreaRestrictionTempError", false);
        }
        
        
        /*** Covenant Radius Restriction ***/
        console.log('i am in wrong');
        var RadiusRestrictionValidationBool = false;
        var radiusRestriction = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Radius Restriction']){
                radiusRestriction = covenant[item];
            }
        }
        if(radiusRestriction.RadiusRestriction_WF__c){   
            // check for # of is not empty
            if(radiusRestriction.of_WF__c =='' || radiusRestriction.of_WF__c == null || radiusRestriction.of_WF__c =='--None--'){
                component.set('v.noOfError',true);
                RadiusRestrictionValidationBool = true;
            }else{
                component.set('v.noOfError',false);
            }
            // check for Duration is not empty
            if(radiusRestriction.Duration_WF__c =='' || radiusRestriction.Duration_WF__c ==null || radiusRestriction.Duration_WF__c =='--None--'){
                component.set('v.durationError',true);
                RadiusRestrictionValidationBool = true;
            }else{
                component.set('v.durationError',false);
            }
            // check for If Duration is Other is not empty
            if(radiusRestriction.Duration_WF__c =='Other' && ((radiusRestriction.Duration_Months__c =='' && radiusRestriction.DurationYears_WF__c =='') ||
                                                              (radiusRestriction.Duration_Months__c ==null && radiusRestriction.DurationYears_WF__c ==null))){
                component.set('v.yearMonthError',true);
                RadiusRestrictionValidationBool = true;
            }else{          
                component.set('v.yearMonthError',false);
            }
            
            if(RadiusRestrictionValidationBool){
                component.set("v.COV_radiusRestrictionTempError", true);
                boolIsreqFiledEmpty=true;
            }else{
                component.set("v.COV_radiusRestrictionTempError", false);
            }
        }else{
            component.set("v.COV_radiusRestrictionTempError", false);
        }
        /*** Covenant llRelocationRight ***/
        
        var llRelocationRightValidationBool = false;
        var llRelocationRight = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Relocation Rights']){
                llRelocationRight = covenant[item];
            }
        }
        
        // check for Relocation Rights Description is not empty
        if(llRelocationRight.StandardRelocationRights_WF__c==false && (llRelocationRight.IfNoRelocationRightsDescription_WF__c =='' || llRelocationRight.IfNoRelocationRightsDescription_WF__c ==null)){
            component.set('v.relocRightsDescriptionError',true);
            llRelocationRightValidationBool = true;
        }else{          
            component.set('v.relocRightsDescriptionError',false);
        }
        
        if(llRelocationRightValidationBool){
            component.set("v.COV_llRelocationRightsTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_llRelocationRightsTempError", false);
        }
        
        
        /*** Covenant landlordTerminationtionRight ***/
        
        var landlordTerminationtionRightValidationBool = false;
        var landlordTerminationtionRight = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Termination Rights']){
                landlordTerminationtionRight = covenant[item];
            }
        }
        
        // check for Termination Rights Description is not empty
        if(landlordTerminationtionRight.StandardTerminationRights_WF__c==false && (landlordTerminationtionRight.TerminationRightsDescription_WF__c ==='' || landlordTerminationtionRight.TerminationRightsDescription_WF__c ===null)){
            component.set('v.terminationRightsDescError',true);
            landlordTerminationtionRightValidationBool = true;
        }else{          
            component.set('v.terminationRightsDescError',false);
        }
        if(landlordTerminationtionRightValidationBool){
            component.set("v.COV_llTerminationRightsTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_llTerminationRightsTempError", false);
        }
        
        /*** Covenant SLR ***/
        
        var SLRValidationBool = false;
        var SLR = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['SLR']){
                SLR = covenant[item];
            }
        }
        
        // check for Relocation Rights Description is not empty
        if(SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c ==true && SLR.Zone_WF__c ==true && ( SLR.DescriptionZone_WF__c =='' || SLR.DescriptionZone_WF__c ==null)){
            component.set('v.descNoBuildError',true);
            SLRValidationBool = true;
        }else{          
            component.set('v.descNoBuildError',false);
        }
        if(SLRValidationBool){
            component.set("v.COV_noBuildZoneTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_noBuildZoneTempError", false);
        }
        
        /*** Covenant exclusiveRights ***/
        var exclusiveRightsValidationBool = false;
        var exclusiveRights = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Exclusive Right']){
                exclusiveRights = covenant[item];
            }
        }
        // check for Excl Right Description is not empty
        if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclRightDescription_WF__c =='' ||  exclusiveRights.ExclRightDescription_WF__c ==null)){
            component.set('v.exclRightDescError',true);
            exclusiveRightsValidationBool = true;
        }else{
            component.set('v.exclRightDescError',false);
        }
        // check for Excl Duration is not empty
        if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclDuration_WF__c =='' ||  exclusiveRights.ExclDuration_WF__c ==null)){
            component.set('v.exclDurationError',true);
            exclusiveRightsValidationBool = true;
        }else{
            component.set('v.exclDurationError',false);
        }
        // check for Excl Remedy Description is not empty
        if( exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && ( exclusiveRights.ExclRemedyDescription_WF__c =='' ||  exclusiveRights.ExclRemedyDescription_WF__c ==null)){
            component.set('v.exclRemedyDescError',true);
            exclusiveRightsValidationBool = true;
        }else{
            component.set('v.exclRemedyDescError',false);
        }
        if(exclusiveRightsValidationBool){
            component.set("v.COV_exclusiveRightTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_exclusiveRightTempError", false);
        }
        
        /*** Covenant Kickouts ***/
        var kickoutEvent = $A.get("e.c:KickoutDetailsEvent");
        if(!$A.util.isUndefinedOrNull(kickoutEvent)){ 
            kickoutEvent.fire();
        }
        if(component.get('v.kickoutError')){
            component.set("v.COV_kickoutsTempError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_kickoutsTempError", false);
        }
        
        
        /*** Covenant Co-Tenancy ***/
        var CoTenancyEvent = $A.get("e.c:CoTenancyDetailsEvent");
        if(!$A.util.isUndefinedOrNull(CoTenancyEvent)){ 
            CoTenancyEvent.fire();
        }
        if(component.get('v.CoTenancyError')){
            component.set("v.COV_coTenancyError", true);
            boolIsreqFiledEmpty=true;
        }else{
            component.set("v.COV_coTenancyError", false);
        }
        
        /*** Send Document Section***/
        
        var sendDocumentToValidationBool = false;
        
        // check for Send Documents to Name is not empty
        component.get('v.sObj.UseType_WF__c')
        if(component.get('v.sObj.Send_Docs_To_Name_WF__c')==undefined || component.get('v.sObj.Send_Docs_To_Name_WF__c')=='' || component.get('v.sObj.Send_Docs_To_Name_WF__c')==null){
            component.set('v.SendDocumentToNameError',true);
            sendDocumentToValidationBool = true;
        }else{
            component.set('v.SendDocumentToNameError',false);
        }
        // check for Send Documents to Email Address is not empty
        if(component.get('v.sObj.Send_Docs_To_Email_WF__c')==undefined || component.get('v.sObj.Send_Docs_To_Email_WF__c')=='' || component.get('v.sObj.Send_Docs_To_Email_WF__c')==null){
            component.set('v.SendDocumentToEmailAddressError',true);
            sendDocumentToValidationBool = true;
        }else{
            component.set('v.SendDocumentToEmailAddressError',false);
        }   
        // check for Send Documents to Phone is not empty
        if(component.get('v.sObj.Send_Docs_To_Phone_WF__c')==undefined || component.get('v.sObj.Send_Docs_To_Phone_WF__c')=='' || component.get('v.sObj.Send_Docs_To_Phone_WF__c')==null){
            component.set('v.SendDocumentToPhoneNoError',true);
            sendDocumentToValidationBool = true;
        }else{
            component.set('v.SendDocumentToPhoneNoError',false);
        }
        // check for Send Documents to Mailing Address is not empty
        if(component.get('v.sObj.Send_Docs_To_Mailing_Address_WF__c')==undefined || component.get('v.sObj.Send_Docs_To_Mailing_Address_WF__c')=='' || component.get('v.sObj.Send_Docs_To_Mailing_Address_WF__c')==null){
            component.set('v.SendDocumentToMailingAddressError',true);
            sendDocumentToValidationBool = true;
        }else{
            component.set('v.SendDocumentToMailingAddressError',false);
        }
        
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Name_WF__c')) && component.get('v.sObj.Send_Docs_To_Name_WF__c').length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {
            sendDocumentToValidationBool = true;
            component.set('v.SendDocumentToNameLengthError',true);
        }else{
            component.set('v.SendDocumentToNameLengthError',false);
        }
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Email_WF__c')) && component.get('v.sObj.Send_Docs_To_Email_WF__c').length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            sendDocumentToValidationBool = true;
            component.set('v.SendDocumentToEmailAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToEmailAddressLengthError',false);
        }
        
        if(sendDocumentToValidationBool){
            component.set("v.CO_sendDocsToTempError", true);
            boolIsreqFiledEmpty = true;
        }else{
            component.set("v.CO_sendDocsToTempError", false);
        }
        
        console.log('Hold  ',component.get("v.sObj.On_Hold_WF__c") , ' Reason' ,component.get("v.sObj.HoldReason_WF__c") );
        //Comments Validation
        var commentError = false;
        if(strDeadReason =='Other' && (strDeadReasonComms ==null || strDeadReasonComms ==''))
        {
            component.set('v.oppDeadCommsError', true);
            commentError = true;
        }
        else
        {           
            component.set('v.oppDeadCommsError', false);
            //boolIsreqFiledEmpty=false;
        }
        
        if(component.get('v.sObj.On_Hold_WF__c') && $A.util.isEmpty(component.get('v.sObj.HoldReason_WF__c'))){
            component.set('v.oppOnHoldValidation', true);
            component.set('v.CO_detailsTempError', true);
            component.set('v.CO_detailsError', true);
            component.set('v.CO_details', true);
            commentError = true;
            boolIsCmntError = true;
            boolIsreqFiledEmpty = true;
        }else{
            component.set('v.CO_details', false);
            component.set('v.CO_detailsTempError', false);
            component.set('v.CO_detailsError', false);
            component.set('v.oppOnHoldValidation', false);
            commentError = false;
            boolIsCmntError =  false;
        }
        if(commentError){
            component.set('v.CO_detailsTempError', true);
            boolIsreqFiledEmpty=true;       
        }else{
            component.set('v.CO_detailsTempError', false);  
        }
        
        
        //Check and set the error flags for each section - END
        return boolIsreqFiledEmpty;
    },
    setSecurityTypeHelper : function(component,event,type,result){ 
        var securityType = component.get('v.sObj.SecurityType_WF__c');
        if(securityType == '--None--' || $A.util.isEmpty(securityType)){
            component.set('v.IsCashDeposit', false);
            component.set('v.IsGuarantor', false);
            component.set('v.IsLetterOfCredit', false);
        }else {                          
            if(securityType.includes("Cash Deposit")){
                var sObj = component.get('v.sObj');
                
                component.set('v.IsCashDeposit', true);    
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
                if(!$A.util.isUndefinedOrNull(sObj.Hold_Cash_Deposit_For_WF__c)){
                    var years = String(Math.floor(sObj.Hold_Cash_Deposit_For_WF__c/12));
                    var months = String(Math.floor(sObj.Hold_Cash_Deposit_For_WF__c%12));
                    if( sObj.Hold_Cash_Deposit_For_Amendment_WF__c == 'Other'){
                        if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears'))){
                            component.find('cashHoldYears').set('v.value', years);
                        }
                        if(!$A.util.isUndefinedOrNull(component.find('cashHoldMonths'))){
                            component.find('cashHoldMonths').set('v.value', months);     
                        }   
                    }                                                                                
                }
            }else {
                component.set('v.IsCashDeposit', false);
                component.set('v.sObj.Cash_Deposit_Amount_WF__c',0);
                component.set('v.sObj.Hold_Cash_Deposit_For_Amendment_WF__c','');
                if(!$A.util.isUndefinedOrNull(component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c'))){
                    component.find('OpportunityHold_Cash_Deposit_For_Amendment_WF__c').reInit();
                }
                component.set('v.sObj.Cash_Deposit_Comments_WF__c','');
            }
            if(type=='init'){
                if(securityType.includes("Letter of Credit")){            
                    var lstLOC = component.get('v.lstLOC');
                    var count = 1;
                    for(var i = 1 ; i <= 5 ; i++){                         
                        var objLOC = {};
                        var letterCredit = 'LetterofCredit_'+i+'_WF__c';  
                        var bankAddress  = 'BankAddress_'+i+'_WF__c';                
                        var hoc          = 'HoldLOCFor_'+i+'_WF__c';
                        var identifyBank = 'IdentifyBank_'+i+'_WF__c';
                        var locComments = 'LOCComments_'+ i+'_WF__c';
                        var hocAmd       = 'Hold_LOC_For_'+i+'_Amendment_WF__c';
                        
                        if(typeof result.sObj[hoc] !== "undefined" && typeof result.sObj[letterCredit] !== "undefined" && 
                           result.sObj[hoc] !== '' && result.sObj[letterCredit] !== '' && result.sObj[letterCredit] > 0){
                            objLOC.LetterofCredit = result.sObj[letterCredit];
                            objLOC.BankAddress =  result.sObj[bankAddress];
                            if(typeof result.sObj[hoc] !== "undefined" && result.sObj[hoc] !== null && result.sObj[hoc] !== ''){
                                objLOC.years = String(Math.floor(result.sObj[hoc]/12));
                                objLOC.months = String(result.sObj[hoc]%12);
                            }
                            objLOC.IdentifyBank = result.sObj[identifyBank];
                            objLOC.LOCComments = result.sObj[locComments];
                            objLOC.holdLOCFor = result.sObj[hocAmd];
                            objLOC.count = count;
                            lstLOC.push(objLOC);
                            count = count + 1;
                        }
                    }
                    component.set('v.lstLOC', lstLOC);
                    component.set('v.LetterOfCreditBool', true);
                    component.set('v.noOfletterOfCredit' , lstLOC.length);                              
                    component.set('v.IsLetterOfCredit', true);
                }
                else{
                    component.set('v.IsLetterOfCredit', false);
                }
                if(securityType.includes("Guarantor")){   
                    console.log('GuasecurityType',securityType);
                    console.log('Guatype',type);
                    var guarantors = '{}';
                    if (typeof result.guarantors !== "undefined") {
                        guarantors = result.guarantors;
                        var updatedGuarantors = [];
                        for(var each in guarantors){
                            var eachG = {};
                            eachG = JSON.parse(JSON.stringify(guarantors[each]));
                            //Joshna, 18/10/2017 - INC0038047
                            eachG.stateOfIncorp = $A.util.isUndefinedOrNull(guarantors[each].RelatedAccount_WF__r) ? '' : guarantors[each].RelatedAccount_WF__r.StateOfIncorporation_WF__c;
                            //Need to convert this string as the "set" for ui:inputseectOption doesn't work if it's not of the same data type
                            if(guarantors[each].Years_WF__c !== undefined && guarantors[each].Years_WF__c !== null && guarantors[each].Years_WF__c !== '')
                                eachG.Years_WF__c = String(guarantors[each].Years_WF__c);
                            if(guarantors[each].Months_WF__c !== undefined && guarantors[each].Months_WF__c !== null && guarantors[each].Months_WF__c !== '')
                                eachG.Months_WF__c = String(guarantors[each].Months_WF__c);
                            updatedGuarantors.push(eachG);
                        }
                        component.set('v.guarantor', updatedGuarantors);
                        component.set('v.GuarantorBool', true);
                        component.set('v.noOfGuarantor',guarantors.length);         
                    }                    
                    component.set('v.IsGuarantor', true);   
                }
                else{
                    component.set('v.IsGuarantor', false);            
                }
            }
            else{
                if(securityType.includes("Letter of Credit")){
                    component.set('v.IsLetterOfCredit', true);            
                }
                else {
                    component.set('v.IsLetterOfCredit', false);
                    component.set('v.GI_securitySectionTempError',false);
                    var noOfletterOfCredit = component.get('v.noOfletterOfCredit');
                    var lstLOC = component.get('v.lstLOC');
                    var lstToDelete = []
                    for(var i=0 ;i<noOfletterOfCredit; i++){
                        lstLOC.pop();                      
                    }   
                    var action = component.get('c.deleteLoc');
                    action.setParams({
                        "OppId" : component.get('v.recordId')
                    });
                    action.setCallback(this, function(response){
                        var result = response.getReturnValue();  
                        if(result && response.getState() == 'SUCCESS' && component.isValid()){
                            component.set('v.lstLOC',lstLOC);
                            component.set('v.noOfletterOfCredit',0);
                        }
                    });
                    $A.enqueueAction(action);
                }
                if(securityType.includes("Guarantor")){
                    component.set('v.IsGuarantor', true);            
                }
                else {
                    component.set('v.IsGuarantor', false);
                    component.set('v.GI_securitySectionTempError',false);
                    var numberOfGuarantor = component.get('v.noOfGuarantor');
                    var guarantor = component.get('v.guarantor');
                    var lstToDelete = []
                    for(var i=0 ;i<numberOfGuarantor; i++){
                        var deletedGuarantors = guarantor.pop();
                        if(deletedGuarantors.Id !== undefined && deletedGuarantors.Id !== null && deletedGuarantors.Id !== ''){
                            lstToDelete.push(deletedGuarantors.Id);
                        }                        
                    }            
                    var action = component.get('c.deleteGuarantor');
                    action.setParams({
                        "lstToDelete" : JSON.stringify(lstToDelete)
                    });
                    action.setCallback(this, function(response){
                        var result = response.getReturnValue();  
                        if(result && response.getState() == 'SUCCESS' && component.isValid()){
                            component.set('v.guarantor',guarantor);
                            component.set('v.noOfGuarantor',0);
                        }
                    });
                    $A.enqueueAction(action);
                }
            }
        }
    },
    saveOpportunity  : function(component, event){
        
        $A.util.toggleClass(component.find("spinner"), "slds-hide");
        //this.agreementTypeMethod(component, true); GDM-8706
        var sObj = component.get('v.sObj');
        var leaseAmount=0;
        var finalStr = '';
        var allAgreementTypesSet = [];
        /*GDM-8706*/
       if(component.get('v.sObj.AmendmentReconfiguration_WF__c') && $A.util.isEmpty(component.get('v.sObj.AmendmentProposedUnitNumber_WF__c')))
        {
              component.set('v.sObj.AmendmentReconfiguration_WF__c',false);
        }
        this.agreementTypeMethod(component, true);
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
            allAgreementTypesSet = component.get('v.sObj.New_Agreement_Type_WF__c').split(';');
        }
        if(component.get('v.DealValidated') == true)
        {
            sObj.DealValidated_WF__c = true;
        }
        if(sObj.StageName == $A.get("$Label.c.OpportunityProposalStage_WF") && component.get('v.DealValidated') == false)
        {
            sObj.DealValidated_WF__c = false;
        } 
        for(var each in allAgreementTypesSet){
            console.log('name ', allAgreementTypesSet[each]);
            if(!finalStr.includes(allAgreementTypesSet[each])){
                var i = (allAgreementTypesSet.length - 1) + "";
                if(each === i){
                    finalStr += allAgreementTypesSet[each];
                } else{
                    finalStr += allAgreementTypesSet[each] + '/';
                }
            }
        }
        var unitName = component.get('v.sObj.AmendmentProposedUnitNumber_WF__c');
        if($A.util.isEmpty(unitName)){
            unitName = component.get('v.sObj.ProposedUnitNumber_WF__c');
        }
        if($A.util.isEmpty(unitName)){
            unitName='';
        }
        if(component.get('v.relatedRecord.sObjName')=='Lease_WF__c'){
            sObj.Id=null;
            if(sObj.Opportunity__r!=null)
                sObj.Dealmaker_WF__c=sObj.Opportunity__r.Dealmaker_WF__c;
            if(sObj.B2BCustomer_WF__c!=null && sObj.CenterName_WF__c!=null){
                sObj.Name = sObj.B2BCustomer_WF__r.Name +' '+ sObj.CenterName_WF__r.Name +' '+unitName+' '+ finalStr;
            }
            if(sObj.Amount_WF__c!=null){
                leaseAmount = sObj.Amount_WF__c;
            }
            sObj.Source_Opportunity_Amd_WF__c = sObj.Opportunity__c;
            if(sObj.Opportunity__r!=null)
                sObj.LeasingDivision_WF__c = component.get('v.sObj.Opportunity__r.Dealmaker_WF__r.Division');
        }else{
            sObj.Id = component.get('v.recordId');
            if(sObj.B2BCustomer_WF__c!=null && sObj.CenterName_WF__c!=null){
                   sObj.Name = sObj.B2BCustomer_WF__r.Name +' '+ sObj.CenterName_WF__r.Name +' '+unitName+' '+ finalStr;
            }
            if($A.util.isUndefinedOrNull(component.get('v.sObj.Dealmaker_WF__r.Division'))){
                sObj.LeasingDivision_WF__c = component.get('v.sObj.Dealmaker_WF__r.Division');
            }
        }
        //GDM-6514
        if(sObj.SpaceDeliveryDate__c === ''){
            sObj.SpaceDeliveryDate__c = null;
        }
        if(sObj.NewRCDEarlierofOpeningor_WF__c === ''){
            sObj.NewRCDEarlierofOpeningor_WF__c = null;
        }
        if(sObj.RelocationSpaceDeliveryDate_WF__c === ''){
            sObj.RelocationSpaceDeliveryDate_WF__c = null;
        }
        if(sObj.RelocationRCDEarlierofOpening_WF__c === ''){
            sObj.RelocationRCDEarlierofOpening_WF__c = null;
        }
        if(sObj.NewExpiration_WF__c === ''){
            sObj.NewExpiration_WF__c = null;
        }
        if(sObj.ProposalGeneratedDate_WF__c === ''){
            sObj.ProposalGeneratedDate_WF__c = null;
        }
        if(sObj.ProposalSignedDate_WF__c === ''){
            sObj.ProposalSignedDate_WF__c = null;
        }
        if(sObj.ApprovalSubmissionDate_WF__c === ''){
            sObj.ApprovalSubmissionDate_WF__c = null;
        }
        //end of GDM-6514
        var construction = component.get('v.Construction');

        // JIRA ticket GDM-8354 Fix - Arut, 08202018 - Start
        // Root Cause Analysis: Clearing out milestone dates on the existing opportunities sets the date 
        //      fields with '' (empty string) in the aura:attribute 'Construction' instead of null values
        //      and this causes JSON deserialization issues in APEX code. 
        // Fix: Following code checks for empty string for milestone date fields and if found, replaces 
        //      them with null values in the JSON before the APEX method is called.
        var tmpCons = JSON.parse(JSON.stringify(construction));
        tmpCons.CommencementOfTenantWorkDate_WF__c === ''? 
            tmpCons.CommencementOfTenantWorkDate_WF__c = null: 
            tmpCons.CommencementOfTenantWorkDate_WF__c = construction.CommencementOfTenantWorkDate_WF__c;
        tmpCons.TenantBuildingPermitSubmissionDate_WF__c === ''? 
            tmpCons.TenantBuildingPermitSubmissionDate_WF__c = null: 
            tmpCons.TenantBuildingPermitSubmissionDate_WF__c = construction.TenantBuildingPermitSubmissionDate_WF__c;
        tmpCons.TenantFinalPlansSubmissionDate_WF__c === ''? 
            tmpCons.TenantFinalPlansSubmissionDate_WF__c = null: 
            tmpCons.TenantFinalPlansSubmissionDate_WF__c = construction.TenantFinalPlansSubmissionDate_WF__c;
        tmpCons.TenantLicenseSubmissionDate_WF__c === ''? 
            tmpCons.TenantLicenseSubmissionDate_WF__c = null: 
            tmpCons.TenantLicenseSubmissionDate_WF__c = construction.TenantLicenseSubmissionDate_WF__c;
        tmpCons.TenantsPreliminaryDesignDate_WF__c === ''? 
            tmpCons.TenantsPreliminaryDesignDate_WF__c = null: 
            tmpCons.TenantsPreliminaryDesignDate_WF__c = construction.TenantsPreliminaryDesignDate_WF__c;
        construction = tmpCons;
        // JIRA ticket GDM-8354 Fix - Arut, 08202018 - End

        var covenants = component.get('v.Covenants');
        //console.log('ss',covenants)
        var charges = component.get('v.Charges');
        var account = component.get('v.account');
        var budgets = component.get('v.budgets');
        var lease = component.get('v.Lease');
        var securityType = component.get('v.sObj.SecurityType_WF__c');
        var guarantor = component.get('v.addGuarantor');
        var loc = component.get('v.letterOfCredit');
        var strCreateTasksA3 = component.get('v.strCreateTaskA3');
        //var strCreateTasksA = false;
        var strCreateTasksA = component.get('v.strCreateTasks');
        console.log('Save time value for strcreatetask A2 :',strCreateTasksA);
        //if(compA2val == 'true') 
        //  strCreateTasksA = true;
        //console.log('task a2 val'+strCreateTasksA);
        console.log('covenants',covenants);
        var strPercentRate;
        
        if(component.get('v.lstGrowthRateTable').length > 0){
            strPercentRate = JSON.stringify(component.get('v.lstGrowthRateTable'));
        }
        var strOptionsPercentRate;
        
        if(component.get('v.lstOptionsTable').length > 0){
            strOptionsPercentRate = JSON.stringify(component.get('v.lstOptionsTable'));
        }      
        
        var strRenewalOptions;
        
        if(component.get('v.renewalOptions')){
            strRenewalOptions = JSON.stringify(component.get('v.renewalOptions'));
        }
        
        var action = component.get('c.saveOpportunityMethod');
        
        if(component.get('v.reconfigBool')){
            sObj.Reconfiguration_WF__c='Y';
        }else{
            sObj.Reconfiguration_WF__c='N';
        }        
        sObj.StorageUnitNo_WF__c = component.get('v.StorageUnit.Id');                
        sObj.Unit_WF__c = component.get('v.Unit.Id');
        sObj.Covenant__r = null;   
        sObj.B2BCustomer_WF__r= null;
        sObj.Unit_WF__r=null;
        sObj.CenterName_WF__r=null;
        sObj.Opportunity__r=null;
        sObj.Dealmaker_WF__r=null;
        sObj.LegalEntity_WF__r = null;
        sObj.ParentAccount_WF__r = null;
       // sObj.SuperParent_WF__r = null;
        sObj.AmdementTermMonths_WF__c = parseInt(sObj.AmdementTermMonths_WF__c);
        sObj.AmdementTermYears_WF__c = parseInt(sObj.AmdementTermYears_WF__c);
        
        var addProductArray = [];
        var strProductIds = '';
        
        var addStorageProductArray = [];
        var strStorageProductIds = '';
        
        if(component.get('v.strProductIds') != null && component.get('v.strProductIds') != ''){
            strProductIds = String(component.get('v.strProductIds'));
        }else{
            if(component.get('v.reconfigBool') != true){
                if(component.get('v.addProduct') != null){
                    addProductArray.push(component.get('v.addProduct'));                
                    strProductIds = JSON.stringify(addProductArray);
                }else
                    strProductIds = null;
            }else{
                if(component.get('v.addProducts') != undefined && component.get('v.addProducts') != null)
                    strProductIds = JSON.stringify(component.get('v.addProducts'));
                else
                    strProductIds = null;
            }
        }   
        
    //   if(($A.util.isUndefinedOrNull(component.get('v.strProductIds')) || component.get('v.strProductIds') === '') && component.get('v.relatedRecord.sObjName')=='Lease_WF__c' && (!component.get('v.isUnitInvoked') || (component.get('v.isUnitInvoked') && component.get('v.strProducts') !== ""))){
       if($A.util.isUndefinedOrNull(strProductIds) && ($A.util.isUndefinedOrNull(component.get('v.strProductIds')) || component.get('v.strProductIds') == '') && component.get('v.relatedRecord.sObjName')=='Lease_WF__c' && (!component.get('v.isUnitInvoked') || (component.get('v.isUnitInvoked') && component.get('v.strProducts') !== ""))){

            var productIds = [];
            if(!$A.util.isUndefinedOrNull(component.get('v.Product')) && !$A.util.isUndefinedOrNull(component.get('v.Product.Id'))){
                productIds.push(component.get('v.Product.Id'));
                strProductIds = JSON.stringify(productIds);
                component.set('v.isUnitInvoked', true);
            }
        }
        
        var unitConfigs = component.get('v.unitConfig');        
        var strUnitConfig;        
        if(unitConfigs !== undefined && unitConfigs !== null){
            if(unitConfigs.length >0 )
                strUnitConfig = JSON.stringify(unitConfigs);
            else
                strUnitConfig = null;
        }else
            strUnitConfig = null;
        
        /* Storage Unit Configs */
        if(component.get('v.strStorageProductIds') != null && component.get('v.strStorageProductIds') != ''){
            strStorageProductIds = String(component.get('v.strStorageProductIds'));
        }else{
            
            if(component.get('v.addProductStorage') != null)
            {
                addStorageProductArray.push(component.get('v.addProductStorage'));
            }
            
            strStorageProductIds = JSON.stringify(addStorageProductArray); console.log('ReservationIds', strStorageProductIds);
        }
        
        var cotenants = component.get('v.lstCoTenants');
        sObj.CoTenancyRights_WF__c = false;
        if(!$A.util.isUndefinedOrNull(cotenants)){
            for(var item in cotenants){
                if((cotenants[item].OperatingCoTenancy_WF__c && cotenants[item].CoTenancyType_WF__c=='Operating')
                   || (cotenants[item].OpeningCoTenancy_WF__c && cotenants[item].CoTenancyType_WF__c=='Opening')
                   || (cotenants[item].PosessionCoTenancy_WF__c && cotenants[item].CoTenancyType_WF__c=='Posession')
                   || (cotenants[item].ConstructionCoTenancy_WF__c && cotenants[item].CoTenancyType_WF__c=='Construction')){
                    sObj.CoTenancyRights_WF__c = true;
                } 
            }
        }
        
        var kickouts = component.get('v.lstKickouts');
        sObj.KickOuts_WF__c = false;
        if(!$A.util.isUndefinedOrNull(kickouts) && kickouts.length > 0){
            sObj.KickOuts_WF__c = true;
        }
        
        /*var covenants = [];
        covenants = JSON.parse(JSON.stringify(component.get('v.lstKickouts')));
        var radiusRest = component.get('v.radiusRestriction');          
        if(component.get('v.boolRadiusRestriction') == true){
            covenants.push(radiusRest);
        }
        var cotenants = component.get('v.lstCoTenants');
        
        for(var i=0;i<cotenants.length;i++){
            covenants.push(cotenants[i]);
        }
        console.log('----exclusiveRights----->'+JSON.stringify(component.get('v.exclusiveRights')));
        if(component.get('v.exclusiveRights').DoesTnthaveanExclusiveRight_WF__c){
            covenants.push(component.get('v.exclusiveRights'));
        }
        if(component.get('v.SLR').NoBdZneSiteLnRestrnLsngRestrn_WF__c){
            covenants.push(component.get('v.SLR'));
        }
        covenants.push(component.get('v.otherCovenant'));
        covenants.push(component.get('v.landlordTerminationtionRight'));
        covenants.push(component.get('v.commonArRestriction'));
        covenants.push(component.get('v.llRelocationRight'));*/
        
        var strReservations = [];
        var strTempRes;            
        
        var strStorageReservations = [];
        var strStorageTempRes;            
        
        if(component.get('v.reconfigBool')){
            var reservations  = component.get('v.selectedUnits');
            if(reservations !== undefined && reservations !== null){
                if(reservations.length > 0)
                    strReservations = JSON.stringify(reservations);
                else
                    strReservations = null;
            }else
                strReservations = null;             
        }
        else{
            strTempRes = component.get('v.selectedProducts');
            console.log('212', strTempRes);
            if(strTempRes.length != undefined && strTempRes != null){
                if(strTempRes.length > 0){
                    for(var i=0; i<strTempRes.length; i++)
                    {
                        strReservations.push(strTempRes[i]);
                    }                               
                    strReservations = JSON.stringify(strReservations);console.log('213', strReservations);
                }else
                    strReservations = null;                    
            }else
                strReservations = null;                
        }
        /* Storage */
        /*Added as part of GDM-8477 Issue #3 */
        if(sObj.StorageReconfiguration_WF__c && component.get('v.sObj.ProposedStorageUnitNumber_WF__c') == ''){
            var storageUC  = component.get('v.storageSelectedUnits');
            if($A.util.isUndefinedOrNull(storageUC) || $A.util.isEmpty(storageUC)){
                sObj.StorageReconfiguration_WF__c = false;
                sObj.ProposedStorageUnitNumber_WF__c = component.get('v.strStorageProducts');
            }
        }
        
        if(sObj.StorageReconfiguration_WF__c){
            var storageReservations  = component.get('v.storageSelectedUnits');
            if(storageReservations !== undefined && storageReservations !== null){
                if(storageReservations.length > 0)
                    strStorageReservations = JSON.stringify(storageReservations);
                else
                    strStorageReservations = null;
            }else
                strStorageReservations = null;              
        }
        else{
            strStorageTempRes = component.get('v.storageSelectedProducts');             
            if(strStorageTempRes.length != undefined && strStorageTempRes != null){
                if(strStorageTempRes.length > 0){
                    for(var i=0; i<strStorageTempRes.length; i++)
                    {
                        strStorageReservations.push(strStorageTempRes[i]);
                    }               
                    strStorageReservations = JSON.stringify(strStorageReservations);console.log('213', strStorageReservations);    
                }else
                    strStorageReservations = null;                    
            }else
                strStorageReservations = null;                                       
        }
        
        var isCashDeposit = component.get('v.IsCashDeposit');
        if(isCashDeposit){
            if( sObj.Hold_Cash_Deposit_For_Amendment_WF__c == 'Other'){
                var years = 0;
                if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears')))
                    years = component.find('cashHoldYears').get('v.value');
                var months = 0;
                if(!$A.util.isUndefinedOrNull(component.find('cashHoldYears')))
                    months =  component.find('cashHoldMonths').get('v.value'); 
                
                if(!($A.util.isUndefinedOrNull(years) && $A.util.isUndefinedOrNull(months)))
                    sObj.Hold_Cash_Deposit_For_WF__c = Number(years  * 12) + Number(months);   
            }            
        }
        if($A.util.isUndefinedOrNull(sObj.Dealmaker_WF__c) && !$A.util.isUndefinedOrNull(component.get('v.relatedRecord.dealMaker')) && component.get('v.relatedRecord.sObjName')=='Lease_WF__c' && sObj.Opportunity__r==null){
            sObj.Dealmaker_WF__c = component.get('v.relatedRecord.dealMaker.Id');
            console.log('Dealmaker',component.get('v.relatedRecord.dealMaker.Id'));
            console.log('Dealmaker',component.get('v.relatedRecord.dealMaker').Id);
        }
        console.log('sObjsObjsObj',sObj);
        console.log(JSON.stringify(component.get('v.lstKickouts')));
        console.log('v.commonArRestriction save oppty-->',JSON.stringify(component.get('v.commonArRestriction')));
        console.log('v.llRelocationRight save oppty-->',JSON.stringify(component.get('v.llRelocationRight')));
        console.log('popup', component.get('v.boolUnitConfig'));
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        var saveAndValidate = component.get('v.SaveAndValidateClicked');
        console.log('*** saveAndValidate', saveAndValidate);
        action.setParams({"recordString" : component.get('v.recordId'),
                          "strOpportunity" : JSON.stringify(sObj),
                          "strAccount" : JSON.stringify(account),
                          "strLease" : JSON.stringify(lease),
                          "strConstruction" : JSON.stringify(construction),
                          "strCharges":JSON.stringify(charges),
                          "strCovenants":JSON.stringify(covenants),
                          "strBudget":JSON.stringify(budgets),
                          "strProductIds" : strProductIds,           
                          "strUnitConfig": strUnitConfig,
                          "proposedUnitNumber" : String(component.get('v.strProducts')),
                          "strComments" : String(component.get('v.strComments')),
                          "strGuarantor" : JSON.stringify(guarantor),  
                          "strDelGuarantor" : JSON.stringify(component.get('v.guarantorsToDelete')),
                          "strPercentRate" : strPercentRate,
                          "strShowProdPopup" : component.get('v.boolUnitConfig'),
                          "strOptionsPercentRate": strOptionsPercentRate,
                          "strRenewalOptions" : strRenewalOptions,
                          "strReservations" : strReservations,
                          "strStorageProductIds" : strStorageProductIds, 
                          "strStorageUnitConfig" : JSON.stringify(component.get('v.storageUnitConfig')), 
                          "storageProposedUnitNumber" : String(component.get('v.strStorageProducts')), 
                          "strStorageReservations" :strStorageReservations,
                          "isUnitInvoked" : component.get('v.isUnitInvoked'),
                          "isStorageInvoked" : component.get('v.isStorageInvoked'),
                          "kickoutToDelete" : JSON.stringify(component.get("v.kickoutToDelete")),
                          "strCreateTasksA3" : strCreateTasksA3,
                          "strCreateTasksA" : strCreateTasksA,
                          "leaseAmount" : parseInt(leaseAmount),
                          "SaveAndValidateClicked" : saveAndValidate,
                          "bolStrReconfigChange":component.get('v.bolStrReconfigChange')
                         });
        action.setCallback(this, function(response){
            var result = response.getReturnValue();                 
            
            // JIRA ticket GDM-8354: Added 'result' null check in the line below
            if(response.getState() == 'SUCCESS' && result !== undefined && result !== null){
                component.set('v.boolUnitConfig', false);
                if( (typeof sforce != 'undefined') && (sforce != null) ) {                          
                    
                    sforce.one.navigateToSObject(result); 
                }
                /* back up if - sforce.one.navigateToSObject(recordId) code fails */
                else{                           
                    var urlOpptyDetailPage = "/one/one.app#/sObject/"+result+"/view";
                    window.open(urlOpptyDetailPage,"_self");
                }
            }
            else if(response.getState() == 'SUCCESS' && result == false){
                alert($A.get("$Label.c.DealSheetExceptionErrorMessage_WF"));
            }
            
        });
        $A.enqueueAction(action);
    },
    getSecurityDepositDetails : function(component, validateData){
        if(component.get('v.sObj.SecurityDepositRequired_WF__c')){
            var securityType = component.get('v.sObj.SecurityType_WF__c');
            if(securityType.includes('Guarantor')){
                //  Event to fetch the guarantor details          
                var guarantorEvent = $A.get("e.c:GuarantorDetailsEvent");
                guarantorEvent.setParams({
                    "showErrors": validateData
                });
                if(!$A.util.isUndefinedOrNull(guarantorEvent)){ 
                    guarantorEvent.fire();
                }
            }
            else{                
                component.set('v.showGuarantorErrors',false);
            }
            if (securityType.includes('Letter of Credit')){
                // Event to fetch the letter of credit details.             
                var letterOfCreditEvent = $A.get("e.c:LOCDetailsEvent");
                letterOfCreditEvent.setParams({
                    "showErrors": validateData
                });
                if(!$A.util.isUndefinedOrNull(letterOfCreditEvent)){ 
                    letterOfCreditEvent.fire();
                }
            }
            else
            {
                component.set('v.showErrors',false);
            }
        }else{
            component.set('v.showErrors',false);
            component.set('v.showGuarantorErrors',false);
            
        }
    },
    agreementTypeMethod : function(component, isConsUpdate){
        var buildout = component.get('v.Construction.BuildOutRequired_WF__c');
        var typeOfCharge = component.get('v.Construction.TypesofCharges_WF__c');
        var scopeOfWork = component.get('v.Construction.ScopeOfWork_WF__c');
        var reconfig = component.get('v.sObj.AmendmentReconfiguration_WF__c');
        var oldProposedUnit = component.get('v.sObj.ProposedUnitNumber_WF__c');
        var proposedUnit = component.get('v.sObj.AmendmentProposedUnitNumber_WF__c');
        var expiration = component.get('v.sObj.NewExpiration_WF__c'); 
        var expirationOld = component.get('v.sObj.ExpirationDate_WF__c');
        
        if(isConsUpdate){
            if(buildout || (typeOfCharge!='' && !$A.util.isUndefinedOrNull(typeOfCharge)) || scopeOfWork=='Other'){
                if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                    component.set('v.sObj.New_Agreement_Type_WF__c','Remodel');
                } else if(!component.get('v.sObj.New_Agreement_Type_WF__c').includes('Remodel')){
                    component.set('v.sObj.New_Agreement_Type_WF__c',component.get('v.sObj.New_Agreement_Type_WF__c')+';Remodel');
                }
            }else{
                if(!$A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                    var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                    newAgrementType = newAgrementType.replace('Remodel','');
                    newAgrementType = newAgrementType.replace(';;',';');
                    console.log('newAgrementType',newAgrementType);
                    component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
                }
            }
        }
        if(!$A.util.isEmpty(proposedUnit) && !$A.util.isUndefined(proposedUnit) && oldProposedUnit != proposedUnit){   
            if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                component.set('v.sObj.New_Agreement_Type_WF__c', 'Relocation');
            } else if(!component.get('v.sObj.New_Agreement_Type_WF__c').includes('Relocation')){
                component.set('v.sObj.New_Agreement_Type_WF__c',component.get('v.sObj.New_Agreement_Type_WF__c')+';Relocation');
            }
        }else{
            if(!$A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                newAgrementType = newAgrementType.replace('Relocation','');
                newAgrementType = newAgrementType.replace(';;',';');
                console.log('newAgrementType',newAgrementType);
                component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
            }
        }
        if(reconfig){
            if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                component.set('v.sObj.New_Agreement_Type_WF__c', 'Reconfiguration');
            } else if(!component.get('v.sObj.New_Agreement_Type_WF__c').includes('Reconfiguration')){
                component.set('v.sObj.New_Agreement_Type_WF__c',component.get('v.sObj.New_Agreement_Type_WF__c')+';Reconfiguration');
            }
        }else{
            if(!$A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                newAgrementType = newAgrementType.replace('Reconfiguration','');
                newAgrementType = newAgrementType.replace(';;',';');
                console.log('newAgrementType',newAgrementType);
                component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
            }
        }
        if($A.util.isUndefined(component.get('v.sObj.New_Agreement_Overridden_WF__c')) || !component.get('v.sObj.New_Agreement_Overridden_WF__c')){
            if(!$A.util.isEmpty(expiration) && !$A.util.isUndefined(expiration)){            
                var _MS_PER_DAY = 1000 * 60 * 60 * 24;
                var utc1 = new Date(expiration);
                var utc2 = new Date(expirationOld);
                var diff = Math.floor((utc1 -  utc2) / _MS_PER_DAY);
                if(diff<=1096 && diff>0){
                    if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                        component.set('v.sObj.New_Agreement_Type_WF__c', 'Extension');
                    } else if(!component.get('v.sObj.New_Agreement_Type_WF__c').includes('Extension')){
                        var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c')+';Extension';
                        console.log('newAgrementType',newAgrementType);
                        newAgrementType = newAgrementType.replace('Renewal','');
                        newAgrementType = newAgrementType.replace(';;','');
                        console.log('newAgrementType',newAgrementType);
                        component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
                    }
                } else if(diff > 0){
                    if($A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                        component.set('v.sObj.New_Agreement_Type_WF__c', 'Renewal');
                    } else{
                        var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                        if(!component.get('v.sObj.New_Agreement_Type_WF__c').includes('Renewal')){
                            newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c')+';Renewal';
                        }
                        console.log('newAgrementType',newAgrementType);
                        newAgrementType = newAgrementType.replace('Extension','');
                        newAgrementType = newAgrementType.replace(';;',';');
                        console.log('newAgrementType',newAgrementType);
                        component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
                    }
                } else if(diff === 0){
                    var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                    newAgrementType = newAgrementType.replace('Extension','');
                    newAgrementType = newAgrementType.replace(';;',';');
                    newAgrementType = newAgrementType.replace('Renewal','');
                    newAgrementType = newAgrementType.replace(';;','');
                    component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
                }
            } else{
                if(!$A.util.isUndefinedOrNull(component.get('v.sObj.New_Agreement_Type_WF__c'))){
                    var newAgrementType = component.get('v.sObj.New_Agreement_Type_WF__c');
                    newAgrementType = newAgrementType.replace('Extension','');
                    newAgrementType = newAgrementType.replace(';;',';');
                    newAgrementType = newAgrementType.replace('Renewal','');
                    newAgrementType = newAgrementType.replace(';;','');
                    component.set('v.sObj.New_Agreement_Type_WF__c',newAgrementType);
                }
            }
        }
        component.set('v.agreementTypeBackUp', component.get('v.sObj.New_Agreement_Type_WF__c'));
        if(!$A.util.isUndefinedOrNull(component.find('OpportunityNew_Agreement_Type_WF__c'))){            
            component.find('OpportunityNew_Agreement_Type_WF__c').reInit();
        }
    },
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = result.objectList;
        var fieldNames = result.FieldList;
        for(var each in objNames){
            for(var eachField in fieldNames){
                if(!$A.util.isUndefinedOrNull(component.find(objNames[each] + fieldNames[eachField]))){
                    var optionVals = picklistMap[objNames[each] + fieldNames[eachField]];
                    if(!$A.util.isUndefinedOrNull(optionVals)){
                        component.find(objNames[each] + fieldNames[eachField]).setLocalValues(optionVals);
                    }
                }
            }
        }
        
        var fetchPickList = $A.get("e.c:fetchPicklist");
        if(!$A.util.isUndefinedOrNull(fetchPickList)){ 
            fetchPickList.fire(); 
        }
        
        var fetchPickTableList = $A.get("e.c:fetchPicklistTable");
        if(!$A.util.isUndefinedOrNull(fetchPickTableList)){
            fetchPickTableList.fire();   
        }
    },
    
    lazyLoadComponents : function(component, helper, result){
        helper.secondCallout(component, helper, result);
    }, 
    
    secondCallout : function(component, helper, result) {  
        
        var action = component.get('c.getRelatedRecordDetails');
        
        var relatedRecord = component.get('v.relatedRecord');
        
        action.setParams({
            "sObj" : JSON.stringify(relatedRecord.sObj), 
            "sObjName":relatedRecord.sObjName,
            "Disabled" : component.get('v.disabled')
        });
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess && component.isValid()){
                var result = response.getReturnValue();
                if(result != null){
                    
                    if(result.lstRentTableWrapper != undefined ){                            
                        component.set('v.lstGrowthRateTable', result.lstRentTableWrapper);  
                        component.set('v.showTable', true);
                    }
                    if(result.lstOptionsRentTableWrapper != undefined ){                            
                        component.set('v.lstOptionsTable', result.lstOptionsRentTableWrapper);   
                        component.set('v.showOptionsTable', true);
                    }
                    if(result.lstLeaseRenewalOptionsWrapper != undefined){
                        component.set('v.renewalOptions', result.lstLeaseRenewalOptionsWrapper);
                    }
                    var lstLeaseRenewalOptionsWrapper =  $A.util.isUndefinedOrNull(result.lstLeaseRenewalOptionsWrapper) ? [] : result.lstLeaseRenewalOptionsWrapper;
                    if(relatedRecord.sObjName =='Lease_WF__c'){
                        if( lstLeaseRenewalOptionsWrapper.length > 0 ){
                            component.set('v.sObj.LeaseOptionsStartDate_WF__c',lstLeaseRenewalOptionsWrapper[0].datStartDate);
                            component.set('v.sObj.LeaseOptionsEndDate_WF__c',lstLeaseRenewalOptionsWrapper[0].datEndDate);    
                        }
                    
                    }
                    if(relatedRecord.sObjName =='Opportunity'){
                        component.set('v.sObj', result.sObj);
                        component.set('v.strStorageProducts', result.sObj.ProposedStorageUnitNumber_WF__c);
                    }
                    if(result.chargesRecordTypeMap != undefined ){
                        component.set('v.ChargesRecordType',result.chargesRecordTypeMap);
                    }
                    if(result.charges != undefined ){
                        component.set('v.Charges',result.charges);
                    }
                    
                    if(result.standardCharges !== undefined){
                        component.set('v.StandardCharges',result.standardCharges);
                    }
                    if(result.construction != undefined ){
                        component.set('v.Construction',result.construction);
                    }                                       
                    helper.createComponents(component, helper, result);
                }
            }
        });
        $A.enqueueAction(action);
    },        
    
    createComponents : function(component, helper, result){
        //Initialize minimum rent
        window.setTimeout(
            $A.getCallback(function() {
                
                $A.createComponent(
                    "c:MinimumRent_WF",
                    {
                        "opportunity": component.getReference("v.sObj"),
                        "yearsVal": component.getReference("v.sObj.AmdementTermYears_WF__c"),
                        "monthsVal": component.getReference("v.sObj.AmdementTermMonths_WF__c"),
                        "WeaAmdType_2_WF__c": component.getReference("v.sObj.WeaAmdType_2_WF__c"),
                        "isRenewals" : true,
                        "startDateRenewals" : component.getReference("v.startDateRenewals"),
                        "error" : component.get('v.FI_minimumRentError'),
                        "rentStabCmntErr":component.getReference('v.rentStabCmntErr'),
                        "nstCommentsErr":component.getReference('v.nstCommentsErr'),
                        "lstMinRentTable": component.getReference('v.lstGrowthRateTable'),
                        "IsMinimumRent": component.getReference("v.IsMinimumRent"),
                        "IsOptions": component.getReference("v.IsOptions"),
                        "hasErrors": component.getReference("v.FI_minimumRentError"),
                        "MinRentDesc": "Minimum Rent?",
                        "IsNegativeValue": component.getReference("v.IsNegativeValue"),
                        "disabled": component.getReference("v.disabled"),
                        "rentStabCommentError":component.getReference("v.rentStabCommentError"),
                        "unitOfMeasure": component.getReference("v.unitOfMeasure"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newMinRentComp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var minRentCmp = component.get('v.minRentComponent');
                            minRentCmp.push(newMinRentComp);
                            component.set('v.minRentComponent', minRentCmp);
                        }
                    }
                );
                
                $A.createComponent(
                    "c:PercentRentComponent_WF",
                    {
                        "IsNegativeValue": component.getReference("v.IsPercentNegativeValue"),
                        "startDate": component.getReference("v.sObj.RelocationRCDEarlierofOpening_WF__c"),
                        "endDate": component.getReference("v.sObj.NewExpiration_WF__c"),
                        "showTable": component.getReference("v.showTable"),
                        "opportunity": component.getReference("v.sObj"),
                        "IsOptions": false,
                        "defaultDate": component.getReference("v.defaultDate"),
                        "IsMinimumRent": component.getReference("v.IsMinimumRent"),
                        "lstGrowthRateTable": component.getReference("v.lstGrowthRateTable"),
                        "lstMinRentTable": component.getReference("v.lstMinPercentRentTable"),
                        "lstOtherTable": component.getReference("v.lstOtherPercentRentTable"),
                        "hasErrors": component.getReference("v.FI_overageRentError"),
                        "percentCommentsErr":component.getReference('v.percentCommentsErr'),
                        "error" : component.getReference("v.FI_overageRentError"),
                        "PercentRentDescription": "Percentage Rent Information",
                        "disabled": component.getReference("v.disabled"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newPercRentComp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var percRentCmp = component.get('v.percRentComponent');
                            percRentCmp.push(newPercRentComp);
                            component.set('v.percRentComponent', percRentCmp);
                        }
                    }
                );
                
                $A.createComponent(
                    "c:OptionsComponent_WF",
                    {
                        "aura:id": "idOptions",
                        "isRenewals"  : true,                        
                        "IsOptionsMiniNegativeValue": component.getReference("v.IsOptionsMiniNegativeValue"),
                        "IsOptionsPerNegativeValue": component.getReference("v.IsOptionsPerNegativeValue"),
                        "hasErrors": component.getReference("v.optionsErrors"), 
                        "measuringPeriodCmntErrorId":component.getReference("v.measuringPeriodCmntErrorId"),
                        "error"  : component.getReference("v.optionsErrors"),                        
                        "optionsCommentsErrors": component.getReference("v.optionsCommentsErrors"),
                        "rentStabOptnCmntErr":component.getReference("v.rentStabOptnCmntErr"),
                        "OptionNotifyOtherCmntErr":component.getReference("v.OptionNotifyOtherCmntErr"),
                        "IsOptionsMinimumRent": component.getReference("v.IsOptionsMinimumRent"),
                        "opportunity": component.getReference("v.sObj"),
                        "lstOptionsTable": component.getReference("v.lstOptionsTable"),                        
                        "showOptionsTable": component.getReference("v.showOptionsTable"),                        
                        "disabled": component.get("v.disabled"),                        
                        "unitOfMeasure": component.getReference("v.optionsUnitOfMeasure"),
                       "renewalOptions": component.getReference("v.renewalOptions"),
                        "tenantPerfReqDescError":component.getReference("v.tenantPerfReqDescError"),
                        "IsTenantPerformanceRequirement" : component.get('v.sObj.TenantPerformanceRequirement_WF__c'),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(newOptComp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var renOptCmp = component.get('v.optionsComponent');
                            renOptCmp.push(newOptComp);
                            component.set('v.optionsComponent', renOptCmp);
                            newOptComp.reInit();
                        }
                    }
                );              
                $A.createComponent(
                    "c:CHoperatingExpense",
                    {
                        "aura:id": "CH_operatingExpenseComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.glaUsed"),                        
                        "result": component.getReference("v.relatedRecord")                         
                    },
                    function(opChargesCmp, status, errorMessage){
                        console.log('I am coming here with status' +status );
                        console.log('I am coming here with errorMessage' +errorMessage );
                        console.log('I am coming here with opChargesCmp' +opChargesCmp );
                        if(status === "SUCCESS"){
                            
                            var opChCmp = component.get('v.opChargeComponent');
                            console.log('opChCmp' + opChCmp);
                            console.log('opChargesCmp' + opChargesCmp);
                            opChCmp.push(opChargesCmp);
                            console.log('opChargesCmp' + opChargesCmp);
                            component.set('v.opChargeComponent', opChCmp);
                            opChargesCmp.reInit();
                            if(!component.get('v.disabled'))
                                opChargesCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHinsurance",
                    {
                        "aura:id": "CH_insuranceComp",
                        "disabled": component.getReference("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges")                        
                    },
                    function(insuranceCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var insCmp = component.get('v.insuranceComponent');
                            insCmp.push(insuranceCmp);
                            component.set('v.insuranceComponent', insCmp);
                            insuranceCmp.reInit();
                            if(!component.get('v.disabled'))
                                insuranceCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHfoodCourtExpense",
                    {
                        "aura:id": "CH_foodCourtExpenseComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.glaUsed"),
                        
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(fcCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var fdCrtCmp = component.get('v.fcComponent');
                            fdCrtCmp.push(fcCmp);
                            component.set('v.fcComponent', fdCrtCmp);
                            fcCmp.reInit();
                            if(!component.get('v.disabled'))
                                fcCmp.calculateVariance();
                        }
                    }
                );
            }), 100
        );
        
        
        //Initialize food court
        window.setTimeout(
            $A.getCallback(function() {
                $A.createComponent(
                    "c:CHpromotionalCharges",
                    {
                        "aura:id": "CH_promotionalChargesComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.glaUsed"),                        
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(pCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var promoCmp = component.get('v.promoComponent');
                            promoCmp.push(pCmp);
                            component.set('v.promoComponent', promoCmp);
                            pCmp.reInit();
                            if(!component.get('v.disabled'))
                                pCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHrealEstateTax",
                    {
                        "aura:id": "CH_realEstateTaxComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "realEstateTax":component.getReference("v.realEstateTax"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),
                        "GLAUsed": component.getReference("v.glaUsed"),
                        "taxDescLengthErr":component.getReference("v.taxDescLengthErr"),                        
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(reCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var rEstateCmp = component.get('v.realEstComponent');
                            rEstateCmp.push(reCmp);
                            component.set('v.realEstComponent', rEstateCmp);
                            reCmp.reInit();
                            if(!component.get('v.disabled'))
                                reCmp.calculateVariance();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHmallCharges",
                    {
                        "aura:id": "CH_mallChargesComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "result": component.getReference("v.relatedRecord"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),
                        "StandardCharges": component.getReference("v.StandardCharges"),                       
                        "WaterError": component.getReference("v.WaterError"),
                        "FDSError": component.getReference("v.FDSError"),
                        "ElectricityError": component.getReference("v.ElectricityError"),
                        "TrashError": component.getReference("v.TrashError"),
                        "EncldMallError": component.getReference("v.EncldMallError"),
                        "HVACError": component.getReference("v.HVACError"),
                        "ParkingError": component.getReference("v.ParkingError"),
                        "Other1Error": component.getReference("v.Other1Error"),
                        "Other2Error": component.getReference("v.Other2Error"),
                        "Other3Error": component.getReference("v.Other3Error"),
                        "OtherDes1Error": component.getReference("v.OtherDes1Error"),
                        "OtherDes2Error": component.getReference("v.OtherDes2Error"),
                        "OtherDes3Error": component.getReference("v.OtherDes3Error")
                    },
                    function(mallCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var mCmp = component.get('v.mallComponent');
                            mCmp.push(mallCmp);
                            component.set('v.mallComponent', mCmp);
                            mallCmp.reInit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CHother",
                    {
                        "aura:id": "CH_otherComp",
                        "disabled": component.get("v.disabled"),
                        "Charges": component.getReference("v.Charges"),
                        "ChargesRecordType": component.getReference("v.ChargesRecordType"),                        
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(otherCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var oCmp = component.get('v.otherChargeComponent');
                            oCmp.push(otherCmp);
                            component.set('v.otherChargeComponent', oCmp);
                            otherCmp.reInit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_capital_WF",
                    {
                        "aura:id": "CON_capitalComp",
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "GLA": component.getReference("v.glaUsed"),
                        "TAPaymentAmountError": component.getReference("v.TAPaymentAmountError"),
                        "CapitalOtherCostDescriptionError": component.getReference("v.CapitalOtherCostDescriptionError"),
                        "CapitalOtherCostDescriptionLengthError": component.getReference("v.CapitalOtherCostDescriptionLengthError"),
                        "TACommentsLenError":component.getReference("v.TACommentsLenError"),
                        "TAPaymentOptions1OtherError":component.getReference("v.TAPaymentOptions1OtherError"),
                        "TAPaymentOptions2OtherError":component.getReference("v.TAPaymentOptions2OtherError"),
                        "TAPaymentOptions3OtherError":component.getReference("v.TAPaymentOptions3OtherError"),
                        "TAPaymentOptions4OtherError":component.getReference("v.TAPaymentOptions4OtherError"),
                        "TAPaymentOptions5OtherError":component.getReference("v.TAPaymentOptions5OtherError"),
                        "error": component.getReference("v.CON_capitalError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(capCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var cpCmp = component.get('v.capitalComponent');
                            cpCmp.push(capCmp);
                            component.set('v.capitalComponent', cpCmp);
                            capCmp.init();
                            capCmp.changeUnit();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_landlordWork_WF",
                    {
                        "Construction": component.getReference('v.Construction'),
                        "disabled": component.get("v.disabled"),
                        "error": component.getReference('v.CON_landlordWorkError'),
                        "result": component.getReference("v.relatedRecord"),
                        "OtherTextValueErr":component.getReference("v.OtherTextValueErr"),
                        "aura:id" : "CON_landlordWorkComp"
                    },
                    function(llwCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var llWrkCmp = component.get('v.llWorkComponent');
                            llWrkCmp.push(llwCmp);
                            component.set('v.llWorkComponent', llWrkCmp);
                            llwCmp.init();
                        }
                    }
                );
            }), 200
        );
        
        //Initialize landlord construction
        window.setTimeout(
            $A.getCallback(function() {
                $A.createComponent(
                    "c:CON_landlordConstructionReq_WF",
                    {
                        "aura:id": "CON_landlordConstructionReqComp",
                        "disabled": component.get('v.disabled'), 
                        "Construction": component.getReference('v.Construction'),
                        "spaceDeliveryDate": component.getReference('v.spaceDeliveryDate'),
                        "StructuralModificationOtherError":component.getReference('v.StructuralModificationOtherError'),
                        "DemisingWallOtherError":component.getReference('v.DemisingWallOtherError'),
                        "storeFrontageOtherError":component.getReference('v.storeFrontageOtherError'),
                        "ElectricalsOtherError":component.getReference('v.ElectricalsOtherError'),
                        "DataOtherError":component.getReference('v.DataOtherError'),
                        "DomesticWaterOtherError":component.getReference('v.DomesticWaterOtherError'),
                        "SewerOtherError":component.getReference('v.SewerOtherError'),
                        "SewerVentOtherError":component.getReference('v.SewerVentOtherError'),
                        "GreaseWasteOtherError":component.getReference('v.GreaseWasteOtherError'),
                        "SlabConditionOtherError":component.getReference('v.SlabConditionOtherError'),
                        "MechanicalOtherError":component.getReference('v.MechanicalOtherError'),
                        "MiscellaneousOtherError":component.getReference('v.MiscellaneousOtherError'),
                        "LLworkDescriptionError":component.getReference('v.LLworkDescriptionError'),
                        "error": component.getReference('v.CON_landlordConstructionReqError'),
                        "result": component.getReference('v.relatedRecord')
                    },
                    function(llCCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var llConCmp = component.get('v.llConsComponent');
                            llConCmp.push(llCCmp);
                            component.set('v.llConsComponent', llConCmp);
                            llCCmp.updateStartDate();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_tenantConstructionReq_WF",
                    {
                        "aura:id": "CON_tenantConstructionReqComp",
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "workRequiredError": component.getReference("v.workRequiredError"),
                        "RemodelDueDateError": component.getReference("v.RemodelDueDateError"),
                        "TTWorkCommentsError":component.getReference("v.TTWorkCommentsError"),
                        "TTPriorWorkCommentsError":component.getReference("v.TTPriorWorkCommentsError"),
                        "error": component.getReference("v.CON_tenantConstructionReqError"),
                        "result": component.getReference("v.relatedRecord")
                    },
                    function(tcCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var tConCmp = component.get('v.tenConsComponent');
                            tConCmp.push(tcCmp);
                            component.set('v.tenConsComponent', tConCmp);
                            tcCmp.init();
                        }
                    }
                );
                
                $A.createComponent(
                    "c:CON_milestones_WF",
                    {
                        "disabled": component.get("v.disabled"),
                        "Construction": component.getReference("v.Construction"),
                        "error": component.getReference("v.CON_milestonesError")
                    },
                    function(milestoneCmp, status, errorMessage){
                        if(status === "SUCCESS"){
                            var mCmp = component.get('v.msComponent');
                            mCmp.push(milestoneCmp);
                            component.set('v.msComponent', mCmp);
                        }
                    }
                );
                
                if(component.find('GI_CurrentTenant_WF') !== undefined){
                    component.find('GI_CurrentTenant_WF').reInit();  
                }
                
                helper.setPicklistValues(component, result);
                if(component.get('v.disabled') !== true){
                    component.set('v.BoolSaveDisable', false);    
                    component.set('v.BoolValidateDisable', false);
                }
            }), 300
        );
    },
    
    validateCovenantTextField:function(component,result)
    {
        console.log("inside validateCovenantTextField");
        var boolIsError =false;
        var sendDocumentToValidationBool =false;
        var landlordTerminationtionRightValidationBool = false;
        var llRelocationRightValidationBool= false; 
        var boolIsCmnResError=false;
        var descriptionZoneValidationBool=false;
        var boolIsLandlordConsError=false;
        var OptionRentStabCmntErr=false;
        var rentStabCmntErr=false;
        var boolIsRadiusResErr=false;
        var zonedDetailsValidationBool=false; 
        var exclDurationValidationBool=false;
        var exclRemedyDurationValidationBool=false;
        var exclRightDescValidationBool=false;
        var boolIsUseClauseErr=false;
        var boolIsCmntError=false;
        var boolIsPatioCommentErr=false;
        var boolIsContigencyCommentErr=false;
        var restrictionTimePeriodError =false;
        var covCommentsValidationBool=false;
        var boolIsCaptialDescError=false;
        var boolIsRentStabError=false;
        var boolIstenatConsCmntErr=false;
        var optionNotifyOtherCmntErr=false;
        var boolIschargesErr=false;
        var boolIsTenantPerfReqError=false;
        var noZoneValidationBool=false;
        var exclRightsValidationBool=false;
        var minimumCmpNonStdCmntError=false;
        var percentRentNonStdCmntError=false;
        var boolIsPercentRentNonStdErr=false;
        var boolIsOptionCommentError=false;
        var boolIsKickoutErr=false;
        var boolIsCashDepErr=false;
        var result= component.get('v.relatedRecord');
        var covenantTextFieldMap =result.covenantTextFieldMap;
        
        var useClauseLengthError =component.find('useClauseLengthError');
        var patioCommentError=component.find('patioCommentLengthErrorId');
        var conCommsLengthError= component.find('conCommsLengthErrorId');
        var cashDepLengthError=component.find('cashDepLengthError');
        
        component.set('v.GI_currentTenantError',false);
        
        
        console.log('Begin validation');
        
        //validate Relocation Rights
        var llRelocationRight = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Relocation Rights']){
                llRelocationRight = covenant[item];
            }
        }
        
        if(llRelocationRight.StandardRelocationRights_WF__c==false && !$A.util.isUndefinedOrNull(covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c']) && !$A.util.isUndefinedOrNull(llRelocationRight.IfNoRelocationRightsDescription_WF__c.length)
           && llRelocationRight.IfNoRelocationRightsDescription_WF__c.length > covenantTextFieldMap['IfNoRelocationRightsDescription_WF__c']) 
        {
            
            component.set('v.relocRightsDescriptionLengthError',true);
            llRelocationRightValidationBool = true;
            boolIsError=true;
        }else{          
            component.set('v.relocRightsDescriptionLengthError',false);
        }
        if(llRelocationRightValidationBool || component.get('v.COV_llRelocationRightsTempError')){
            component.set("v.COV_llRelocationRightsError", true);
        }else{
            component.set("v.COV_llRelocationRightsError", false);
        }
        
        //Validate Landlord Termination
        var landlordTerminationtionRight = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Termination Rights']){
                landlordTerminationtionRight = covenant[item];
            }
        }
        
        if(landlordTerminationtionRight.StandardTerminationRights_WF__c==false && !$A.util.isUndefinedOrNull(covenantTextFieldMap['TerminationRightsDescription_WF__c']) && !$A.util.isUndefinedOrNull(landlordTerminationtionRight.TerminationRightsDescription_WF__c.length) 
           && landlordTerminationtionRight.TerminationRightsDescription_WF__c.length > covenantTextFieldMap['TerminationRightsDescription_WF__c'])
        {
            component.set("v.terminationRightsLengthError", true);
            landlordTerminationtionRightValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.terminationRightsLengthError',false);
        }
        if(landlordTerminationtionRightValidationBool || component.get('v.COV_llTerminationRightsTempError')){
            component.set("v.COV_llTerminationRightsError", true);
        }else{
            component.set("v.COV_llTerminationRightsError", false);
        }
        
        //Validate common Area restriction
        var commonArRestriction = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Common Area Restrictions']){
                commonArRestriction = covenant[item];
            }
        }
        if(commonArRestriction.CommonAreaRestrictions_WF__c==true &&
           !$A.util.isUndefinedOrNull(covenantTextFieldMap['Description_Restriction_Type_WF__c']) && !$A.util.isUndefinedOrNull(commonArRestriction.Description_Restriction_Type_WF__c.length)
           && commonArRestriction.Description_Restriction_Type_WF__c.length > covenantTextFieldMap['Description_Restriction_Type_WF__c']) 
        {
            boolIsError=true;
            component.set("v.descriptionRestrictionLengthErrorId", true);
            boolIsCmnResError=true;
        }
        else{           
            component.set('v.descriptionRestrictionLengthErrorId',false);
        }
        
        console.log('commonArRestriction',commonArRestriction);
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['IfCompetingUseDescription_WF__c'])&&!$A.util.isUndefinedOrNull(commonArRestriction.IfCompetingUseDescription_WF__c)&& commonArRestriction.IfCompetingUseDescription_WF__c.length > covenantTextFieldMap['IfCompetingUseDescription_WF__c']) 
        {
            component.set("v.commonArRestrictionError", true);
            boolIsCmnResError=true;
            boolIsError=true;
        }
        else
        {
            component.set("v.commonArRestrictionError",false);
        }
        
        if(boolIsCmnResError || component.get("v.commonAreaRestrictionTempError"))
        {
            component.set("v.COV_commonAreaRestrictionError", true);   
        }else
        {
            component.set("v.COV_commonAreaRestrictionError", false);
        }
        console.log('Before SLR'); 
        //Validate No Build Zone
        var SLR = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['SLR']){
                SLR = covenant[item];
            }
        }
        console.log('SLR',SLR);
        if(SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c ==true && SLR.Zone_WF__c ==true && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DescriptionZone_WF__c']) && !$A.util.isUndefinedOrNull(SLR.DescriptionZone_WF__c.length) && SLR.DescriptionZone_WF__c.length > covenantTextFieldMap['DescriptionZone_WF__c']) 
        {
            component.set("v.descNoBuildLengthError", true);
            noZoneValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.descNoBuildLengthError',false);
        }
        /*if(descriptionZoneValidationBool || component){
            component.set("v.COV_noBuildZoneError", true);
        }else{
            component.set("v.COV_noBuildZoneError", false);
        }*/
        
        if(SLR.NoBdZneSiteLnRestrnLsngRestrn_WF__c ==true && SLR.Zone_WF__c ==true && 
           !$A.util.isUndefinedOrNull(covenantTextFieldMap['ZoneDetails_WF__c']) && 
           !$A.util.isUndefinedOrNull( SLR.ZoneDetails_WF__c.length) && 
           SLR.ZoneDetails_WF__c.length > covenantTextFieldMap['ZoneDetails_WF__c']) 
        {
            component.set("v.zoneDetailsLengthError", true);
            noZoneValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.zoneDetailsLengthError',false);
        }
        if(noZoneValidationBool || component.get('v.COV_noBuildZoneTempError')){
            component.set("v.COV_noBuildZoneError", true);
        }else{
            component.set("v.COV_noBuildZoneError", false);
        }
        
        //validate Exclusive Right
        var exclusiveRights = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Exclusive Right']){
                exclusiveRights = covenant[item];
            }
        }
        
        console.log('excluside',exclusiveRights);
        if(exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclDuration_WF__c'])
           &&(!$A.util.isUndefinedOrNull(exclusiveRights.ExclDuration_WF__c)) && !$A.util.isUndefinedOrNull(exclusiveRights.ExclDuration_WF__c.length)
           && exclusiveRights.ExclDuration_WF__c.length > covenantTextFieldMap['ExclDuration_WF__c']) 
        {
            console.log('inside exclusive');
            component.set("v.exclDurationLengthCharError", true);
            exclRightsValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.exclDurationLengthCharError',false);
        }
        /*if(exclDurationValidationBool){
            component.set("v.COV_exclusiveRightError", true);
        }else{
            component.set("v.COV_exclusiveRightError", false);
        }*/
        if(exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRemedyDescription_WF__c'])&&(!$A.util.isUndefinedOrNull(exclusiveRights.ExclRemedyDescription_WF__c))
           && !$A.util.isUndefinedOrNull(exclusiveRights.ExclRemedyDescription_WF__c.length) && exclusiveRights.ExclRemedyDescription_WF__c.length > covenantTextFieldMap['ExclRemedyDescription_WF__c']) 
        {
            component.set("v.exclRemedyDescLengthError", true);
            exclRightsValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.exclRemedyDescLengthError',false);
        }
        /*if(exclRemedyDurationValidationBool){
            component.set("v.COV_exclusiveRightError", true);
        }else{
            component.set("v.COV_exclusiveRightError", false);
        }*/
        
        if(exclusiveRights.DoesTnthaveanExclusiveRight_WF__c ==true && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ExclRightDescription_WF__c']) && (!$A.util.isUndefinedOrNull(exclusiveRights.ExclRightDescription_WF__c))
           && !$A.util.isUndefinedOrNull(exclusiveRights.ExclRightDescription_WF__c.length)
           && exclusiveRights.ExclRightDescription_WF__c.length > covenantTextFieldMap['ExclRightDescription_WF__c']) 
        {
            component.set("v.exclRightDescLengthError", true);
            exclRightsValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.exclRightDescLengthError',false);
        }
        if(exclRightsValidationBool || component.get('v.COV_exclusiveRightTempError')){
            component.set("v.COV_exclusiveRightError", true);
        }else{
            component.set("v.COV_exclusiveRightError", false);
        }
        
        //Validate other covenants
        var otherCovenant = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Other']){
                otherCovenant = covenant[item];
            }
        }
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['CovenantComments_WF__c']) && !$A.util.isUndefinedOrNull(otherCovenant.CovenantComments_WF__c)
           && !$A.util.isUndefinedOrNull(covenantTextFieldMap['CovenantComments_WF__c']) && 
           otherCovenant.CovenantComments_WF__c.length > covenantTextFieldMap['CovenantComments_WF__c'])
        {
            component.set("v.covCommentLengthError", true);
            covCommentsValidationBool=true;
            boolIsError=true;
        }
        else{           
            component.set('v.covCommentLengthError',false);
        }
        if(covCommentsValidationBool){
            component.set("v.COV_otherError", true);
        }else{
            component.set("v.COV_otherError", false);
        }
        
        //validate Send Documents to
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Name_WF__c')) && component.get('v.sObj.Send_Docs_To_Name_WF__c').length > covenantTextFieldMap['Send_Docs_To_Name_WF__c'])
        {
            sendDocumentToValidationBool = true;
            boolIsError=true;
            component.set('v.SendDocumentToNameLengthError',true);
        }else{
            component.set('v.SendDocumentToNameLengthError',false);
        }
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Email_WF__c')) && component.get('v.sObj.Send_Docs_To_Email_WF__c').length > covenantTextFieldMap['Send_Docs_To_Email_WF__c'])
        {
            sendDocumentToValidationBool = true;
            boolIsError=true;
            component.set('v.SendDocumentToEmailAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToEmailAddressLengthError',false);
        }
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Mailing_Address_WF__c')) && component.get('v.sObj.Send_Docs_To_Mailing_Address_WF__c').length > covenantTextFieldMap['Send_Docs_To_Mailing_Address_WF__c'])
        {
            sendDocumentToValidationBool = true;
            boolIsError=true;
            component.set('v.SendDocumentToMailingAddressLengthError',true);
        }else{
            component.set('v.SendDocumentToMailingAddressLengthError',false);
        }
        
        if(!$A.util.isEmpty(component.get('v.sObj.Send_Docs_To_Phone_WF__c')) && component.get('v.sObj.Send_Docs_To_Phone_WF__c').length > covenantTextFieldMap['Send_Docs_To_Phone_WF__c'])
        {
            sendDocumentToValidationBool = true;
            boolIsError=true;
            component.set('v.SendDocumentToPhoneLengthError',true);
        }else{
            component.set('v.SendDocumentToPhoneLengthError',false);
        }
        
        if(sendDocumentToValidationBool || component.get('v.CO_sendDocsToTempError')){
            component.set("v.CO_sendDocsToError", true);
        }else{
            component.set("v.CO_sendDocsToError", false);
        }
        
        //validate Useclause
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.UseClause_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['UseClause_WF__c'])
           && component.get('v.sObj.UseClause_WF__c').length > covenantTextFieldMap['UseClause_WF__c']){
            $A.util.removeClass(useClauseLengthError, 'slds-hide');
            boolIsUseClauseErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(useClauseLengthError, 'slds-hide');
        }
        if(boolIsUseClauseErr)
        {
            component.set("v.GI_whoSectionError", true);
        }
        
        //validate Patio comments
        if((component.get('v.sObj.Patio_WF__c')==true) && !$A.util.isUndefinedOrNull(component.get('v.sObj.PatioComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['PatioComments_WF__c'])
           && component.get('v.sObj.PatioComments_WF__c').length > covenantTextFieldMap['PatioComments_WF__c']){
            $A.util.removeClass(patioCommentError, 'slds-hide');
            boolIsPatioCommentErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(patioCommentError, 'slds-hide');
        }
        if(boolIsPatioCommentErr || component.get('v.GI_whereSectionTempError'))
        {
            component.set("v.GI_whereSectionError", true);
        }else{
            component.set("v.GI_whereSectionError", false);
        }
        
        
        //validate Restriction Time Period
        var restrictionTimePeriodEvent = $A.get("e.c:CurrentTenantEvent");
        if(restrictionTimePeriodEvent!=null)
        {
            restrictionTimePeriodEvent.setParams({
                "restrictionTimePeriodError": false
            });
            restrictionTimePeriodEvent.fire();
        }
        restrictionTimePeriodError=  component.get('v.restrictionTimePeriodError');
        if(restrictionTimePeriodError)
        {
            component.set('v.GI_currentTenantError',true);
            boolIsError=true;
        }
        
        // validate contigency comments
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.ContingencyComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ContingencyComments_WF__c'])
           && component.get('v.sObj.ContingencyComments_WF__c').length > covenantTextFieldMap['ContingencyComments_WF__c']){
            $A.util.removeClass(conCommsLengthError, 'slds-hide');
            boolIsContigencyCommentErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(conCommsLengthError, 'slds-hide');
        }
        if(boolIsContigencyCommentErr || component.get('v.GI_whenSectionTempError'))
        {
            component.set("v.GI_whenSectionError", true);
        }else{
            component.set("v.GI_whenSectionError", false);
        }
        
        //validate minimum rent non std comments
        var minimumRentCmpEvent = $A.get("e.c:MinimumRentCmpEvent");
        if(minimumRentCmpEvent!=null)
        {
           minimumRentCmpEvent.setParams({
                "nstCommentsErr": false
            });
            minimumRentCmpEvent.fire();
        }
        minimumCmpNonStdCmntError=  component.get('v.nstCommentsErr');
        console.log("hdhdasdshdsa hd.mmfmfmf/////",minimumCmpNonStdCmntError);
        if(minimumCmpNonStdCmntError)
        {
          boolIsError=true;
        }
        
        //validate Rent Stabilization Comments
        /*if(!$A.util.isUndefinedOrNull(component.get('v.sObj.Rent_Stabilization_Comments_WF__c')) 
           && component.get('v.sObj.Rent_Stabilization_Comments_WF__c').length > covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
        {
            
            component.set('v.rentStabCommentError',true);
            boolIsRentStabError = true;
            boolIsError=true;
        }else{
            component.set('v.rentStabCommentError',false);
        }*/

        var OptionRentStabCmntEvent = $A.get("e.c:OptionRentStabCmntEvent");
        if(OptionRentStabCmntEvent!=null)
        {
          
            OptionRentStabCmntEvent.fire();
        }
       OptionRentStabCmntErr=  component.get('v.rentStabOptnCmntErr');
        rentStabCmntErr=  component.get('v.rentStabCmntErr');
        if(OptionRentStabCmntErr || rentStabCmntErr)
        {
         // boolIsOptionCommentError =true;
          boolIsError=true;
        }      
        
        if(boolIsRentStabError || rentStabCmntErr || minimumCmpNonStdCmntError|| component.get('v.FI_minimumRentTempError'))
        {
            component.set("v.FI_minimumRentError",true);
        }else{
            component.set("v.FI_minimumRentError",false);
        }
        
        
        //validate Percentage Rent Non Standard Comments
        var percentageRentCmpEvent = $A.get("e.c:PercentageRentCmpEvent");
        if(percentageRentCmpEvent!=null)
        {
           percentageRentCmpEvent.setParams({
                "percentCommentsErr": false
            });
            percentageRentCmpEvent.fire();
        }
    
        percentRentNonStdCmntError=  component.get('v.percentCommentsErr');
        if(percentRentNonStdCmntError)
        {
          boolIsPercentRentNonStdErr =true;
          boolIsError=true;
        }
        if(boolIsPercentRentNonStdErr || component.get('v.IsPercentNegativeValue'))
        {
            component.set('v.FI_overageRentError',true);
            boolIsError=true;
        }else{
            component.set('v.FI_overageRentError',false);  
        }
        
        //validate Tenant Performance Requirement Description
        if(!$A.util.isUndefinedOrNull(component.get("v.sObj.TenantPerformanceRequirement_WF__c")) && component.get("v.sObj.TenantPerformanceRequirement_WF__c"))
        {
            if(!$A.util.isUndefinedOrNull(component.get("v.sObj.TenantPerformanceRequirementDesc_WF__c"))&& !$A.util.isUndefinedOrNull(covenantTextFieldMap['TenantPerformanceRequirementDesc_WF__c'])
               && component.get("v.sObj.TenantPerformanceRequirementDesc_WF__c").length > covenantTextFieldMap['TenantPerformanceRequirementDesc_WF__c'] )
            {
                component.set('v.tenantPerfReqDescError',true);  
                boolIsTenantPerfReqError = true;
                boolIsError=true;
            }
            else{
                component.set('v.tenantPerfReqDescError',false);
            }
        }
         
         //validate Measuring Period Comments
        if(component.get('v.sObj.OptionsMeasuringPeriod_WF__c') =='Other'){
            if(!$A.util.isUndefinedOrNull(component.get('v.sObj.OptionsMeasuringPeriodComments_WF__c')) 
               && component.get('v.sObj.OptionsMeasuringPeriodComments_WF__c').length > covenantTextFieldMap['OptionsMeasuringPeriodComments_WF__c'] )
            {
                component.set("v.measuringPeriodCmntErrorId",true);
                boolIsError=true;
                boolIsTenantPerfReqError = true;;
            }else{
                component.set('v.measuringPeriodCmntErrorId',false);
            }
        }
        
        var optionNotifyOtherCmntsEvent = $A.get("e.c:OptionNotifyOtherCmntError");
        if(optionNotifyOtherCmntsEvent!=null)
        {
          
            optionNotifyOtherCmntsEvent.fire();
        }
       optionNotifyOtherCmntErr=  component.get('v.OptionNotifyOtherCmntErr');
        if(optionNotifyOtherCmntErr)
        {
          boolIsOptionCommentError =true;
          boolIsError=true;
        }
    
        if(boolIsTenantPerfReqError||OptionRentStabCmntErr || boolIsOptionCommentError || component.get("v.OP_detailsTempError"))
        {
            component.set("v.OP_detailsError",true);
        }else{
            component.set("v.OP_detailsError",false);
        }
        // validate Real Estate Tax
        console.log("realstate",component.get('v.realEstateTax.Charge_Type_Oth_WF__c'));
        if(component.get('v.realEstateTax.Charge_Type_Oth_WF__c') == true && ! $A.util.isUndefinedOrNull(component.get('v.realEstateTax.TaxDescription_WF__c'))
           && ! $A.util.isUndefinedOrNull(covenantTextFieldMap['TaxDescription_WF__c']) && component.get('v.realEstateTax.TaxDescription_WF__c').length > covenantTextFieldMap['TaxDescription_WF__c'])
        {
            component.set('v.taxDescLengthErr',true);
            component.set('v.CH_realEstateTaxError',true);
            boolIsError=true;
        }else{
            component.set('v.taxDescLengthErr',false);
            component.set('v.CH_realEstateTaxError',false);
        }
        
        //validate charges Description
        var mallCharges = {} ;
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Utilities']){
                mallCharges = charges[item];
            }
        }
        console.log("malCharges",mallCharges);
        //7699
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription1Proposed_WF__c'])&&!$A.util.isUndefinedOrNull(mallCharges.OtherDescription1Proposed_WF__c)&&mallCharges.OtherDescription1Proposed_WF__c.length >covenantTextFieldMap['OtherDescription1Proposed_WF__c'])
        {
            console.log('inside des1 error');
            component.set('v.OtherDes1Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes1Error',false);
        }
        //7699
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription2Proposed_WF__c'])&&!$A.util.isUndefinedOrNull(mallCharges.OtherDescription1Proposed_WF__c)&&mallCharges.OtherDescription2Proposed_WF__c.length >covenantTextFieldMap['OtherDescription2Proposed_WF__c'])
        {
            component.set('v.OtherDes2Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes2Error',false);
        }
        //7699
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription3Proposed_WF__c'])&&!$A.util.isUndefinedOrNull(mallCharges.OtherDescription1Proposed_WF__c)&&mallCharges.OtherDescription3Proposed_WF__c.length >covenantTextFieldMap['OtherDescription3Proposed_WF__c'])
        {
            component.set('v.OtherDes3Error',true);
            boolIsError=true;
            boolIschargesErr = true;
        }else{          
            component.set('v.OtherDes3Error',false);
        }
        
        if(boolIschargesErr||component.get("v.CH_mallChargesTempError"))
        {
            component.set("v.CH_mallChargesError",true);
        }else{
            component.set("v.CH_mallChargesError",false);
        }
        
        //validate Capital other Cost Desc and tenant comments
        if(component.get('v.Construction.OtherLandlordCosts_WF__c')>0 &&!$A.util.isUndefinedOrNull(component.get('v.Construction.OtherCostsDescription_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherCostsDescription_WF__c'])&& component.get('v.Construction.OtherCostsDescription_WF__c').length > covenantTextFieldMap['OtherCostsDescription_WF__c']){
            component.set('v.CapitalOtherCostDescriptionLengthError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.CapitalOtherCostDescriptionLengthError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAComments_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAComments_WF__c'))
           && component.get('v.Construction.TAComments_WF__c').length > covenantTextFieldMap['TAComments_WF__c']){
            component.set('v.TACommentsLenError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TACommentsLenError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions1Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions1Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions1Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions1Other_WF__c']){
            console.log("inside ta paymrnt other error");
            component.set('v.TAPaymentOptions1OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions1OtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions2Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions2Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions2Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions2Other_WF__c']){
            component.set('v.TAPaymentOptions2OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions2OtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions3Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions3Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions3Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions3Other_WF__c']){
            component.set('v.TAPaymentOptions3OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions3OtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions4Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions4Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions4Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions4Other_WF__c']){
            component.set('v.TAPaymentOptions4OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions4OtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(covenantTextFieldMap['TAPaymentOptions5Other_WF__c'])&& !$A.util.isUndefinedOrNull(component.get('v.Construction.TAPaymentOptions5Other_WF__c'))
           && component.get('v.Construction.TAPaymentOptions5Other_WF__c').length > covenantTextFieldMap['TAPaymentOptions5Other_WF__c']){
            component.set('v.TAPaymentOptions5OtherError',true);
            boolIsError= true;
            boolIsCaptialDescError = true;
        }else{
            component.set('v.TAPaymentOptions5OtherError',false);
        }
        
        if(boolIsCaptialDescError||component.get('v.CON_capitalTempError'))
        {
            component.set('v.CON_capitalError',true);   
        }else{
            component.set('v.CON_capitalError',false);   
        }
        
        //validate landlord work at Tenat
        if(component.get('v.Construction.TypesofCharges_WF__c')=='Individual Charges' && component.get('v.Construction.OtherLandlordWork_WF__c') != 'N/A'
           && component.get('v.Construction.OtherLandlordWork_WF__c') != '' && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherLandlordWorkTxt_WF__c'])
           &&  component.get('v.Construction.OtherLandlordWorkTxt_WF__c').length > covenantTextFieldMap['OtherLandlordWorkTxt_WF__c'])    
        {
            component.set('v.OtherTextValueErr',true);
            component.set('v.CON_landlordWorkError',true);
            boolIsError=true;
        }else{
            component.set('v.OtherTextValueErr',false);
            component.set('v.CON_landlordWorkError',false);
        }
        
        //validate Landlord Const requirement
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StructuralModificationOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['StructuralModificationOther_WF__c'])
           && component.get('v.Construction.StructuralModificationOther_WF__c').length > covenantTextFieldMap['StructuralModificationOther_WF__c'])
        {
            component.set('v.StructuralModificationOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.StructuralModificationOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DemisingWallOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DemisingWallOther_WF__c'])
           && component.get('v.Construction.DemisingWallOther_WF__c').length > covenantTextFieldMap['DemisingWallOther_WF__c'])
        {
            component.set('v.DemisingWallOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.DemisingWallOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.StoreFrontageOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['StoreFrontageOther_WF__c'])
           && component.get('v.Construction.StoreFrontageOther_WF__c').length > covenantTextFieldMap['StoreFrontageOther_WF__c'])
        {
            component.set('v.storeFrontageOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.storeFrontageOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.ElectricalOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['ElectricalOther_WF__c'])
           && component.get('v.Construction.ElectricalOther_WF__c').length > covenantTextFieldMap['ElectricalOther_WF__c'])
        {
            component.set('v.ElectricalsOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.ElectricalsOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DataOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DataOther_WF__c'])
           && component.get('v.Construction.DataOther_WF__c').length > covenantTextFieldMap['DataOther_WF__c'])
        {
            component.set('v.DataOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.DataOtherError',false);
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.DomesticWaterOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['DomesticWaterOther_WF__c'])
           && component.get('v.Construction.DomesticWaterOther_WF__c').length > covenantTextFieldMap['DomesticWaterOther_WF__c'])
        {
            component.set('v.DomesticWaterOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.DomesticWaterOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SewerOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SewerOther_WF__c'])
           && component.get('v.Construction.SewerOther_WF__c').length > covenantTextFieldMap['SewerOther_WF__c'])
        {
            component.set('v.SewerOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SewerOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SewerVentOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SewerVentOther_WF__c'])
           && component.get('v.Construction.SewerVentOther_WF__c').length > covenantTextFieldMap['SewerVentOther_WF__c'])
        {
            component.set('v.SewerVentOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SewerVentOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.GreaseWasteOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['GreaseWasteOther_WF__c'])
           && component.get('v.Construction.GreaseWasteOther_WF__c').length > covenantTextFieldMap['GreaseWasteOther_WF__c'])
        {
            component.set('v.GreaseWasteOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.GreaseWasteOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.SlabConditionOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['SlabConditionOther_WF__c'])
           && component.get('v.Construction.SlabConditionOther_WF__c').length > covenantTextFieldMap['SlabConditionOther_WF__c'])
        {
            component.set('v.SlabConditionOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.SlabConditionOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MechanicalOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MechanicalOther_WF__c'])
           && component.get('v.Construction.MechanicalOther_WF__c').length > covenantTextFieldMap['MechanicalOther_WF__c'])
        {
            component.set('v.MechanicalOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.MechanicalOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MiscellaneousOther_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MiscellaneousOther_WF__c'])
           && component.get('v.Construction.MiscellaneousOther_WF__c').length > covenantTextFieldMap['MiscellaneousOther_WF__c'])
        {
            component.set('v.MiscellaneousOtherError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.MiscellaneousOtherError',false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.LLWorkDescription_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['LLWorkDescription_WF__c'])
           && component.get('v.Construction.LLWorkDescription_WF__c').length > covenantTextFieldMap['LLWorkDescription_WF__c'])
        {
            component.set('v.LLworkDescriptionError',true);
            boolIsError=true;
            boolIsLandlordConsError=true;
        }else{
            component.set('v.LLworkDescriptionError',false);
        }
        console.log("boolIsLandlordConsError",boolIsLandlordConsError);
        if(boolIsLandlordConsError)
        {
            component.set('v.CON_landlordConstructionReqError',true);
        }
        else{
            component.set('v.CON_landlordConstructionReqError',false);
        }
        
        //validate TTWorkComments 
        console.log("mid term",component.get('v.Construction.MidTermTTWorkComments_WF__c').length);
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.MidTermTTWorkComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['MidTermTTWorkComments_WF__c'])
           && component.get('v.Construction.MidTermTTWorkComments_WF__c').length > covenantTextFieldMap['MidTermTTWorkComments_WF__c'])
        {
            component.set('v.TTWorkCommentsError',true);
            boolIsError=true; 
            boolIstenatConsCmntErr =true;
        }else{
            component.set('v.TTWorkCommentsError',false);
        }
        console.log("Prior term",component.get('v.Construction.TTWorkComments_WF__c').length);
        if(!$A.util.isUndefinedOrNull(component.get('v.Construction.TTWorkComments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['TTWorkComments_WF__c'])
           && component.get('v.Construction.TTWorkComments_WF__c').length > covenantTextFieldMap['TTWorkComments_WF__c'])
        {
            component.set('v.TTPriorWorkCommentsError',true);
            boolIsError=true; 
            boolIstenatConsCmntErr =true;
        }else{
            component.set('v.TTPriorWorkCommentsError',false);
        }
        
        if(boolIstenatConsCmntErr || component.get('v.CON_tenantConstructionReqTempError'))
        {
            component.set('v.CON_tenantConstructionReqError',true);
        }else{
            component.set('v.CON_tenantConstructionReqError',false);
        }
         //Validate Kickouts
       var kickouts = component.get('v.lstKickouts');
        console.log("id of kickoutjsncl s................",component.get('v.boolKickout'));
        if(kickouts.length >0 && component.get('v.boolKickout')==true){
            for(var i=0; i<kickouts.length; i++){
                
                 if(!$A.util.isUndefinedOrNull(kickouts[i].OtherDescription_WF__c) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherDescription_WF__c'])
                    && kickouts[i].OtherDescription_WF__c.length > covenantTextFieldMap['OtherDescription_WF__c'])
                 {
                      console.log("inside if of kicko");
                      $A.util.removeClass(document.getElementById('kickoutOtherErrorId'+i),'slds-hide');
                      boolIsKickoutErr = true;
                      boolIsError=true;
                  }else{
                       $A.util.addClass(document.getElementById('kickoutOtherErrorId'+i),'slds-hide');
                  }
    
                }
            }
        if(boolIsKickoutErr || component.get('v.COV_kickoutsTempError'))
         {
            component.set('v.COV_kickoutsError',true);
         }
        else{
            component.set('v.COV_kickoutsError',false);
        }
        
        //Validate Cash Deposit Comments
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.Cash_Deposit_Comments_WF__c')) &&!$A.util.isUndefinedOrNull(covenantTextFieldMap['Cash_Deposit_Comments_WF__c'])
           && component.get('v.sObj.Cash_Deposit_Comments_WF__c').length > covenantTextFieldMap['Cash_Deposit_Comments_WF__c']){
            $A.util.removeClass(cashDepLengthError, 'slds-hide');
            boolIsCashDepErr = true;
            boolIsError=true;
        }else{          
            $A.util.addClass(cashDepLengthError, 'slds-hide');
        }
        
        if(boolIsCashDepErr || component.get('v.GI_securitySectionTempError'))
        {
            component.set("v.GI_securitySectionError", true);
        }else{
            component.set("v.GI_securitySectionError", false);
        }
        
        
        
        //Validate Radius Restriction
        var radiusRestriction = {} ;
        var covenant = component.get('v.Covenants');
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Radius Restriction']){
                radiusRestriction = covenant[item];
            }
        }
        
        if( radiusRestriction.RadiusRestriction_WF__c== true && radiusRestriction.of_WF__c == 'Other'
           && !$A.util.isUndefinedOrNull(radiusRestriction.RR_Other_WF__c) && radiusRestriction.RR_Other_WF__c.length> covenantTextFieldMap['RR_Other_WF__c'])
        {
            component.set("v.RR_OtherError", true);
            boolIsRadiusResErr = true;
            boolIsError=true;
        }else{
            component.set("v.RR_OtherError", false);
        }
        
        if(boolIsRadiusResErr || component.get('v.COV_radiusRestrictionTempError'))
        {
            component.set('v.COV_radiusRestrictionError',true);
        }
        else{
            component.set('v.COV_radiusRestrictionError',false);
        }
        
        
        //validate Comments
        
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Comments_WF__c'])
           && component.get('v.sObj.Comments_WF__c').length > covenantTextFieldMap['Comments_WF__c'])
        {
            component.set("v.CommentsError", true);
            boolIsCmntError = true;
            boolIsError=true;
        }else{
            component.set("v.CommentsError", false);
        } 
        
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.OtherReasonOpportunityDead_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
           && component.get('v.sObj.OtherReasonOpportunityDead_WF__c').length > covenantTextFieldMap['OtherReasonOpportunityDead_WF__c'])
        {
            component.set("v.oppDeadCommsLenError", true);
            boolIsCmntError = true;
            boolIsError=true;
        }else{
            component.set("v.oppDeadCommsLenError", false);
        }
        
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.REC_Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['REC_Comments_WF__c'])
           && component.get('v.sObj.REC_Comments_WF__c').length > covenantTextFieldMap['REC_Comments_WF__c'])
        {
            component.set("v.recCommentsLenError", true);
            boolIsCmntError = true;
            boolIsError=true;
        }else{
            component.set("v.recCommentsLenError", false);
        } 
        
        if(boolIsCmntError || component.get('v.CO_detailsTempError'))
        {
            component.set('v.CO_detailsError',true);
        }
        else{
            component.set('v.CO_detailsError',false);
        }
	//GDM-7705 Changes
	        if((component.get("v.sObj.REC_Approval_Status_WF__c")=='Reject'||component.get("v.sObj.REC_Approval_Status_WF__c")=='On Hold') && $A.util.isEmpty(component.get("v.sObj.REC_Comments_WF__c"))){
            component.set('v.recCommentsRejectError', true);
            boolIsCmntError = true;
            boolIsError=true;
        }else{
            component.set('v.recCommentsRejectError', false);
		}
        
        console.log('END');
        return boolIsError;
    },
    validateSubComponentTextField:function(component){
        var boolIsCoTenancyError =false;
        var CoTenancyEvent = $A.get("e.c:CoTenancyDetailsEvent");
        if(!$A.util.isUndefinedOrNull(CoTenancyEvent)){ 
            CoTenancyEvent.fire();
        }
        if(component.get('v.CoTenancyError')){
            component.set("v.COV_coTenancyError", true);
            boolIsCoTenancyError=true;
        }else{
            component.set("v.COV_coTenancyError", false);
        }
        return boolIsCoTenancyError;
   },
     
  updateBudgetData : function (component, event, invokedFromLeaseTerm){
        /*Author - Sachin : Updated the method as part of GDM-8728. This method will now be invoked from two methods
          in the controller (updateUnitDetails, updateLeaseTerm). updateUnitDetails will be invoked on change of the checkbox Reconfiguration on the UI.
          Whenever the Relocation/Reconfiguration text box is blank, the budget details of the Original unit should be displayed and this is the new fix made as part of this ticket in the else part below.*/
        if(invokedFromLeaseTerm){
            var action = component.get('c.updateBudgetDataBasedOnRCD');
            /*Getting Reservation or UnitConfig data if any */
            var isReconfig = component.get('v.sObj.AmendmentReconfiguration_WF__c');
            if($A.util.isUndefinedOrNull(isReconfig)){
                isReconfig = false;
            }
            var strTempRes;
            var strUnitConfig;
            var strReservations = [];
            var reservations;
            if(isReconfig){
                var unitConfigs = component.get('v.unitConfig');        
                var strUnitConfig;        
                if(unitConfigs !== undefined && unitConfigs !== null){
                    if(unitConfigs.length >0 )
                        strUnitConfig = JSON.stringify(unitConfigs);
                    else
                        strUnitConfig = null;
                }else
                    strUnitConfig = null;
            }else{
                strTempRes = component.get('v.selectedProducts');
                if(strTempRes.length != undefined && strTempRes != null){
                    if(strTempRes.length > 0){
                        for(var i=0; i<strTempRes.length; i++)
                        {
                            strReservations.push(strTempRes[i]);
                        }                           
                        strReservations = JSON.stringify(strReservations);console.log('213', strReservations);    
                    }else
                        strReservations = null;                    
                }else
                    strReservations = null;                
            }
            if(!$A.util.isUndefinedOrNull(strReservations) && strReservations.length > 0)
                reservations = JSON.stringify(JSON.parse(strReservations));
            var sObj = component.get('v.sObj');
            var relatedRecord = component.get('v.relatedRecord');
            var strReservation ={};
            var sObjOppBU ;
            var sObjOppRefBU ;
            if($A.util.isUndefinedOrNull(strReservations) && sObj.AmendmentProposedUnitNumber_WF__c === ''){
                strReservations = [];
                if(relatedRecord.sObjName == 'Lease_WF__c'){
                    strReservation.idProduct = sObj.Unit_WF__c;   
                    strReservation.unitNo = sObj.ProposedUnitNumber_WF__c;
                    strReservations.push(strReservation);
                    reservations = JSON.stringify(strReservations);
                }                       
            }
            //Joshna, 1/18 - added this if block to fix deserialize issue. Replaced 
            if(!$A.util.isUndefinedOrNull(sObj.Opportunity__c)){
                sObjOppBU = sObj.Opportunity__c;
                sObjOppRefBU = sObj.Opportunity__r;
                sObj.Opportunity__c = '';
                sObj.Opportunity__r = null;
            }        
            action.setParams({
                "oppty" : JSON.stringify(sObj),
                "strOpportunityBudgets" :JSON.stringify(component.get('v.budgets')),
                "isReconfig" : JSON.stringify(isReconfig),
                "selectedUnits" : isReconfig ? ($A.util.isUndefinedOrNull(strUnitConfig) ? null : JSON.stringify(JSON.parse(strUnitConfig))) : ($A.util.isUndefinedOrNull(reservations) ? null : reservations)
            });
            action.setCallback(this, function(response){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.budgets', result);
                }
            });
            $A.enqueueAction(action);
            sObj.Opportunity__c = sObjOppBU;
            sObj.Opportunity__r = sObjOppRefBU;
        }
      	else{
            var action = component.get('c.updateBudgetDataBasedOnRCD');
            
            var strReservations = null;
            var reservations;
            
            var sObj = component.get('v.sObj');
            var originalProduct = component.get('v.Product');
            var relatedRecord = component.get('v.relatedRecord');
            var strReservation ={};
            var sObjOppBU ;
            var sObjOppRefBU ;
            if($A.util.isUndefinedOrNull(strReservations) && sObj.AmendmentProposedUnitNumber_WF__c === ''){
                strReservations = [];
                strReservation.idProduct = originalProduct.Id;   
                strReservation.unitNo = sObj.ProposedUnitNumber_WF__c;
                strReservations.push(strReservation);
                reservations = JSON.stringify(strReservations);   
            }
            
            if(!$A.util.isUndefinedOrNull(sObj.Opportunity__c)){
                sObjOppBU = sObj.Opportunity__c;
                sObjOppRefBU = sObj.Opportunity__r;
                sObj.Opportunity__c = '';
                sObj.Opportunity__r = null;
            }        
            action.setParams({
                "oppty" : JSON.stringify(sObj),
                "strOpportunityBudgets" :JSON.stringify(component.get('v.budgets')),
                "isReconfig" : JSON.stringify(false),
                "selectedUnits" : $A.util.isUndefinedOrNull(reservations) ? null : reservations
            });
            action.setCallback(this, function(response){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.budgets', result);
                }
            });
            $A.enqueueAction(action);
            sObj.Opportunity__c = sObjOppBU;
            sObj.Opportunity__r = sObjOppRefBU;
        }  
    },
       
})