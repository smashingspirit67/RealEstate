({
    /*** Start Clearing logic for Data ***/
    changeLeaseDeposit : function(component,event){
        if(!component.get('v.sObj.LeaseDeposit_WF__c')){
            component.set('v.sObj.LeaseDepositAmount_WF__c',0);
        }
    },
    changeSecurityDepositRequired : function(component,event,helper){
        component.set('v.sObj.SecurityType_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('OpportunitySecurityType_WF__c'))){
            component.find('OpportunitySecurityType_WF__c').reInit();
        }
        helper.setSecurityTypeHelper(component, event,"change",null);
    },
    changeStorageRequired : function(component,event,helper){
        component.set('v.sObj.ProposedStorageUnitNumber_WF__c','');
        if(!component.get('v.sObj.Storage_WF__c')){
            component.set('v.sObj.StorageRentAmount_WF__c',0);
            component.set('v.sObj.StorageTerm_WF__c','');
            component.set('v.sObj.StorageElectricityCharge_WF__c',0);
            component.set('v.sObj.StorageType_WF__c','');
            component.set('v.sObj.StorageGLA_WF__c',0);
            component.set('v.sObj.StorageAnnualIncrease_WF__c',0);
            component.set('v.sObj.strStorageProducts','');
            component.set('v.sObj.StorageReconfiguration_WF__c',false);
       		component.set('v.bolStrReconfigChange', 'true');
         
         
        }else{
            if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageTerm_WF__c'))){
                component.find('OpportunityStorageTerm_WF__c').reInit();
            }
            if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageType_WF__c'))){
                component.find('OpportunityStorageType_WF__c').reInit();
            }
        }
    },
    changePatioRequired : function(component,event){
        if(!component.get('v.sObj.Patio_WF__c')){
            component.set('v.sObj.PatioComments_WF__c','');
            component.set('v.sObj.PatioMR_WF__c',false);
            component.set('v.sObj.MRAmount_WF__c',0);
            component.set('v.sObj.PatioCAM_WF__c',false);
            component.set('v.sObj.CAMAmount_WF__c',0);
            component.set('v.sObj.PatioPromo_WF__c',false);
            component.set('v.sObj.PromoAmount_WF__c',0);
            component.set('v.sObj.PatioTaxes_WF__c',false);
            component.set('v.sObj.TaxesAmount_WF__c',0);            
        }
    },
    changePatioMRRequired : function(component,event){
        if(!component.get('v.sObj.PatioMR_WF__c')){
            component.set('v.sObj.MRAmount_WF__c',0);
        }
    },
    changePatioCAMRequired : function(component,event){
        if(!component.get('v.sObj.PatioCAM_WF__c')){
            component.set('v.sObj.CAMAmount_WF__c',0);
        }
    },
    changePatioPromoRequired : function(component,event){
        if(!component.get('v.sObj.PatioPromo_WF__c')){
            component.set('v.sObj.PromoAmount_WF__c',0);
        }
    },
    changePatioTaxRequired : function(component,event){
        if(!component.get('v.sObj.PatioTaxes_WF__c')){
            component.set('v.sObj.TaxesAmount_WF__c',0);            
        }
    },
    
    /*** End Clearing logic for Data ***/
    docTypeManualOverride:function(component, eve, helper){
        var boolDocTypeManualOverride = true; 
        component.set('v.sObj.DocTypeManualOverride_WF__c', boolDocTypeManualOverride);  
        helper.updateStandardChargesHelper(component);
    },
    initStoragePicklist : function(component,event){
        if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageTerm_WF__c'))){
            component.find('OpportunityStorageTerm_WF__c').reInit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('OpportunityStorageType_WF__c'))){
            component.find('OpportunityStorageType_WF__c').reInit();
        }
    },
    updateAgreementType: function(component,event,helper){
        if(!component.get('v.disabled')){
            helper.agreementTypeMethod(component, true);
        }
    },
    amedmentManuallyChanged : function(component,event){
        component.set('v.sObj.FlagOnCoverMemo_WF__c',component.get('v.flagOnCoverMemo'));
        var newAgreementType = component.get('v.sObj.New_Agreement_Type_WF__c');
        var oldAgreementType = component.get('v.agreementTypeBackUp');
        var oldExt = (!$A.util.isUndefinedOrNull(oldAgreementType)) && oldAgreementType.includes('Extension');
        var oldRen = (!$A.util.isUndefinedOrNull(oldAgreementType)) && oldAgreementType.includes('Renewal');
        var newExt = (!$A.util.isUndefinedOrNull(newAgreementType)) && newAgreementType.includes('Extension');
        var newRen = (!$A.util.isUndefinedOrNull(newAgreementType)) && newAgreementType.includes('Renewal');
        var overridden = false;
        if((oldExt && !newExt) || (oldRen && !newRen) || (!oldExt && newExt) || (!oldRen && newRen) || ($A.util.isUndefinedOrNull(oldAgreementType) && (newExt || newRen)) || ($A.util.isUndefinedOrNull(newAgreementType) && (oldExt || oldRen))){
            overridden = true;
        }
        if(overridden){
            component.set('v.sObj.New_Agreement_Overridden_WF__c', true);
        }
    },
    addFlag : function(component,event){
        var msg='Agreement Type defaulted to '+ event.getParam("oldValue") +' , but was overridden';
        component.set('v.flagOnCoverMemo',msg);
    },
    updateUnitDetails : function(component,event,helper){
        component.set('v.sObj.AmendmentProposedUnitNumber_WF__c', '');        
        component.set('v.sObj.AmendmentGLAUsed_WF__c', 0);
        component.set('v.strProductIds', []);
        component.set('v.sObj.AmendmentProposedUnitNumber_WF__c','');
        if(component.get('v.sObj.AmendmentReconfiguration_WF__c') == 'N')
			{
				component.set('v.bolReconfigChange', 'true');
			}
        if(!component.get('v.disabled')){
            helper.agreementTypeMethod(component, false);
            helper.updateStandardChargesHelper(component);
	    /*Author - Sachin: Added as part of defect GDM-8728. On change of the Reconfiguration checkbox 
	                       we are calling the method to recalculate the Opportunity Budget values for the Orginal Unit.*/
            helper.updateBudgetData(component, event, false);
        }  
    },
    updateStorageDetails : function(component,event,helper){
        component.set('v.strStorageProductIds', []);
         component.set('v.sObj.ProposedStorageUnitNumber_WF__c','');
         if(!component.get('v.sObj.StorageReconfiguration_WF__c'))
			{
				component.set('v.bolStrReconfigChange', 'true');
			}
        if(!component.get('v.disabled')){
            helper.agreementTypeMethod(component, false);
            helper.updateStandardChargesHelper(component);
        }  
    },
    changeAmendmentType : function(component,event,helper){
        if(!component.get('v.disabled')){
            helper.agreementTypeMethod(component, false);
            helper.updateStandardChargesHelper(component);
        }     
    },
    passSection : function(component,event){
        var sectionName = event.getParam("section");
        if(component.get('v.'+sectionName)){
            component.set('v.'+sectionName,false); 
            $A.util.addClass(component.find(sectionName), 'slds-hide'); 
        }else{
            component.set('v.'+sectionName,true);   
            $A.util.removeClass(component.find(sectionName), 'slds-hide'); 
        }
    },
    updateConstruction : function(component,event){
        if(!$A.util.isEmpty(component.get('v.sObj.RelocationSpaceDeliveryDate_WF__c'))){
            component.set('v.spaceDeliveryDate', component.get('v.sObj.RelocationSpaceDeliveryDate_WF__c'));
        } else{
            component.set('v.spaceDeliveryDate', component.get('v.sObj.SpaceDeliveryDate__c'));
        }
        if(!$A.util.isUndefinedOrNull(component.find('CON_landlordConstructionReqComp'))){ 
            component.find('CON_landlordConstructionReqComp').updateStartDate();
        }
    },
    passAccount : function(component,event){
        var record = event.getParam("record");
        var fieldValue = event.getParam("fieldValue");
        if(!fieldValue.includes('Guarantor')){
            component.set('v.'+ fieldValue , record);
        }
    },
    setSecurityType:function(component, event, helper) {
        helper.setSecurityTypeHelper(component, event,"change",null);
    },
    calculateYear : function(component,event){
        var years = parseInt(component.find('cashHoldYears'));
        var months = parseInt(component.find('cashHoldMonths'));
        var totaltime= years*12+months;
        component.set('v.totalTime',totaltime);
    },
    changeLeaseTerm : function(component, event, helper){
        var rcdDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
        var newRCDDate = component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c');
        var origRCDDate = component.get('v.sObj.RCDEarlierOfOpeningOf_WF__c');
        if(!$A.util.isUndefinedOrNull(newRCDDate) && newRCDDate !== ''){
            if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
                if(new Date(newRCDDate + ' 00:00:00') < new Date(rcdDate + ' 00:00:00')){
                    rcdDate = newRCDDate;
                }
            } else{
                rcdDate = newRCDDate;
            }
        } else{
            if($A.util.isUndefinedOrNull(rcdDate) || rcdDate === ''){
                rcdDate = origRCDDate;
            }
        }
        component.set('v.startDateRenewals', rcdDate);
        if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate!=''){
            var drcdDare = new Date(rcdDate + ' 00:00:00');
            var noofDaysinRCDDate = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
            var years = parseInt(component.get('v.sObj.AmdementTermYears_WF__c'));
            var zeroTerm = false;
            if(years<0 || isNaN(years)){
                years =0;
            }
            var months= parseInt(component.get('v.sObj.AmdementTermMonths_WF__c'));
            if(months<0 || isNaN(months)){
                months=0;
            }
            if(years ==0 && months ==0){
                zeroTerm = true;
            }
            var monthsToAdd = years*12+months-1;
            if(monthsToAdd<0)
                monthsToAdd=0;
            if(zeroTerm){
                var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
                var dexpDateZero = new Date(drcdDare-tzoffset);
                component.set('v.sObj.ExpirationDate_WF__c',dexpDateZero.toISOString().slice(0,10));
            }
            else{
                if(noofDaysinRCDDate == drcdDare.getDate()){
                    monthsToAdd = monthsToAdd +1;
                    if(monthsToAdd%2==1){
                        var dexpDate = new Date();
                        dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                    }else{
                        var dexpDate = new Date();
                        dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                    }
                }
                else{
                    var dexpDate = new Date();
                    dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                }
                var noofDaysinExpDate = new Date(dexpDate.getFullYear(), dexpDate.getMonth()+1, 0).getDate();
                dexpDate.setDate(noofDaysinExpDate);
                var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
                dexpDate = new Date(dexpDate-tzoffset);
                component.set('v.sObj.NewExpiration_WF__c',dexpDate.toISOString().slice(0,10));
            }
        }
        if(!$A.util.isUndefinedOrNull(component.get('v.optionsComponent'))){
            var optionComponent = component.get('v.optionsComponent');
            if(optionComponent.length > 0 && optionComponent[0]){
                component.get('v.optionsComponent')[0].updateRenewalStartDate();     
            }
        }   
    },
    updateLeaseTerm : function(component, event, helper){
        var rcdDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
        var newRCDDate = component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c');
        var origRCDDate = component.get('v.sObj.RCDEarlierOfOpeningOf_WF__c');
        if(!$A.util.isUndefinedOrNull(newRCDDate) && newRCDDate !== ''){
            if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
                if(new Date(newRCDDate + ' 00:00:00') < new Date(rcdDate + ' 00:00:00')){
                    rcdDate = newRCDDate;
                }
            } else{
                rcdDate = newRCDDate;
            }
        } else{
            if($A.util.isUndefinedOrNull(rcdDate) || rcdDate === ''){
                rcdDate = origRCDDate;
            }
        }
        component.set('v.startDateRenewals', rcdDate);
        if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
            rcdDate = rcdDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var expDate = component.get('v.sObj.NewExpiration_WF__c');       
        if(!$A.util.isUndefinedOrNull(expDate) && expDate !== ''){
            expDate = expDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var drcdDare = new Date(rcdDate);
        var dexpDate = new Date(expDate);
        var noOdDaysinRCDMonth = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
        var diff = (dexpDate.getFullYear()*12 + dexpDate.getMonth()) - (drcdDare.getFullYear()*12 + drcdDare.getMonth());
        if(drcdDare.getDate()!=noOdDaysinRCDMonth){
            diff=diff+1;
        }
        var months = diff%12;
        var years = Math.floor(diff/12);
        if((dexpDate-drcdDare)<86400000){
            component.set('v.sObj.AmdementTermYears_WF__c',String(0));
            component.set('v.sObj.AmdementTermMonths_WF__c',String(0));
        }else{
            component.set('v.sObj.AmdementTermYears_WF__c',String(years));
            component.set('v.sObj.AmdementTermMonths_WF__c',String(months));
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermYears'))){            
            component.find('leaseTermYears').reInit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermMonths'))){            
            component.find('leaseTermMonths').reInit();
        }
        helper.updateStandardChargesHelper(component);
        if(!$A.util.isUndefinedOrNull(component.get('v.optionsComponent'))){
            var optionComponent = component.get('v.optionsComponent');
            if(optionComponent.length > 0 && optionComponent[0]){
                component.get('v.optionsComponent')[0].updateRenewalStartDate();     
            }
        }                     
        var relocRCDDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
        if(relocRCDDate === '' || $A.util.isUndefinedOrNull(relocRCDDate)){
            component.set('v.sObj.RelocationRCDEarlierofOpening_WF__c', null);
        }
        if( newRCDDate === '' || $A.util.isUndefinedOrNull(newRCDDate)){
            component.set('v.sObj.NewRCDEarlierofOpeningor_WF__c', null);   
        }
        if  ( origRCDDate === '' || $A.util.isUndefinedOrNull(origRCDDate)){
            component.set('v.sObj.RCDEarlierOfOpeningOf_WF__c', null);
        }
        //Author - Sachin: Modified the below method call by adding a new parameter true as part of ticket GDM-8728.              
        var amendmentProposedUnit = component.get('v.sObj.AmendmentProposedUnitNumber_WF__c');
        if(amendmentProposedUnit != undefined && amendmentProposedUnit != null && amendmentProposedUnit != ''){
            
            helper.updateBudgetData(component,event, true);
        }else{
            helper.updateBudgetData(component,event, false);
        }
    },
    showHideOthercontaingency : function(component, event, helper){
        var containgencyOther = component.get('v.sObj.ContingenciesIfAny_WF__c');
        if(containgencyOther.includes('Other')){
            component.set('v.containgencyContainOther',true);
        }else{
            component.set('v.containgencyContainOther',false);
        }        
    },
    doInit: function(component,event,helper) {
        console.log('start ----->',Date.now());
        var action = component.get('c.getRelatedRecordDetail');
        if(component.get('v.disabled') !== true){
                component.set('v.BoolSaveDisable', true);    
                component.set('v.BoolValidateDisable', true);
            }
        var recordId = component.get('v.recordId');
        action.setParams({"recordId" : recordId});
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
            if(isSuccess && component.isValid()){
                var result = response.getReturnValue();
                if(result != null){
                    component.set('v.relatedRecord',result);
                    
                    if(!$A.util.isUndefinedOrNull(result.sObj) &&  !$A.util.isUndefinedOrNull(result.sObj.LegalEntity_WF__r)){
                        if(result.sObj.LegalEntity_WF__r.StateOfIncorporation_WF__c==null || result.sObj.LegalEntity_WF__r.StateOfIncorporation_WF__c   ==''){
                            result.sObj.LegalEntity_WF__r.StateOfIncorporation_WF__c = 'None';
                        }
                        if(result.sObj.LegalEntity_WF__r.CompanyLegalType_WF__c ==null || result.sObj.LegalEntity_WF__r.CompanyLegalType_WF__c ==''){
                            result.sObj.LegalEntity_WF__r.CompanyLegalType_WF__c = 'None';
                        }
                    }
                    if(!$A.util.isUndefinedOrNull(result.sObj) &&  !$A.util.isUndefinedOrNull(result.sObj.AmendmentLegalEntity_WF__r)){
                        if(result.sObj.AmendmentLegalEntity_WF__r.StateOfIncorporation_WF__c==null || result.sObj.AmendmentLegalEntity_WF__r.StateOfIncorporation_WF__c ==''){
                            result.sObj.AmendmentLegalEntity_WF__r.StateOfIncorporation_WF__c = 'None';
                        }
                        if(result.sObj.AmendmentLegalEntity_WF__r.CompanyLegalType_WF__c ==null || result.sObj.AmendmentLegalEntity_WF__r.CompanyLegalType_WF__c ==''){
                            result.sObj.AmendmentLegalEntity_WF__r.CompanyLegalType_WF__c = 'None';
                        }
                    }
                    component.set('v.IsMinimumRent', result.sObj.IsMinimumRent_WF__c);
                    
                    if(result.sObj.IsMinimumRent_WF__c ){
                        var unitOfMeasure = result.sObj.AnnualGrowthSteptype_WF__c.includes("$") ? "$" : "%"
                        component.set('v.unitOfMeasure',unitOfMeasure );
                    }
                    
                    component.set('v.IsOptionsMinimumRent', result.sObj.IsOptionsMinimumRent_WF__c);
                     
                    if(result.sObj.IsOptionsMinimumRent_WF__c){
                        var optionsUnitOfMeasure = result.sObj.OptionsAnnualGrowthSteptype_WF__c.includes("$") ? "$" : "%"
                        component.set('v.optionsUnitOfMeasure',optionsUnitOfMeasure );
                    }
                                        
                    component.set('v.sObj',result.sObj);
                    component.set('v.strStorageProducts', result.sObj.ProposedStorageUnitNumber_WF__c);
                    console.log('v.sObj.New_Agreement_Type_WF__c',component.get('v.sObj.New_Agreement_Type_WF__c'));
                    component.set('v.parentAccountPrepopulated', result.sObj.ParentAccount_WF__c != null ? true : false);
                    component.set('v.superParentPrepopulated', result.sObj.SuperParent_WF__c != null ? true : false);
                    
                    component.set('v.centerForPopup', result.sObj.CenterName_WF__c != null ? result.sObj.CenterName_WF__r : null);
                    if(result.sObjName=='Lease_WF__c'){
                        component.set('v.sObj.New_Document_Type_WF__c',result.sObj.Document_Type_WF__c);
                        component.set('v.agreementTypeBackUp', '');
                        component.set('v.sObj.Howmanyoptions_WF__c', '1');
                        component.set('v.sObj.AmendmentProposedUnitNumber_WF__c', '');
                        component.set('v.glaUsed', component.get('v.sObj.GLAUsed_WF__c'));
                        component.set('v.spaceDeliveryDate', component.get('v.sObj.SpaceDeliveryDate__c'));
                        component.set('v.RCD', component.get('v.sObj.RCDEarlierOfOpeningOf_WF__c'));
                    } else{
                        component.set('v.idOpportunity', component.get('v.sObj.Id'));
                        component.set('v.isRecApprover', result.isRecApprover);
                        if(result.sObj.AmendmentReconfiguration_WF__c){
                            if(!$A.util.isUndefinedOrNull(result.unitConfigurations)){
                                component.set('v.allUnitConfigs', result.unitConfigurations);
                                if(result.unitConfigurations.length > 0){                                    
                                    component.set('v.boolMerge', true);    
                                }                                
                            }
                        }else{
                            if(!$A.util.isUndefinedOrNull(result.reservationsForReconfigNo)){
                                component.set('v.selectedProducts', result.reservationsForReconfigNo);
                            }
                        }
                        
                        if(result.sObj.StorageReconfiguration_WF__c){
                            if(!$A.util.isUndefinedOrNull(result.storageUnitConfigurations)){
                                component.set('v.allStorageUnitConfigs', result.storageUnitConfigurations);
                                if(result.storageUnitConfigurations.length > 0){                                    
                                    component.set('v.boolStorageMerge', true);    
                                }                                
                            }
                        }else{
                            if(!$A.util.isUndefinedOrNull(result.reservationsForStorageReconfigNo)){
                                component.set('v.storageSelectedProducts', result.reservationsForStorageReconfigNo);
                            }
                        }
                        
                        
                        component.set('v.agreementTypeBackUp', component.get('v.sObj.New_Agreement_Type_WF__c'));
                        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.AmendmentGLAUsed_WF__c')) && component.get('v.sObj.AmendmentGLAUsed_WF__c') !== 0){
                            component.set('v.glaUsed', component.get('v.sObj.AmendmentGLAUsed_WF__c'));
                        } else{
                            component.set('v.glaUsed', component.get('v.sObj.GLAUsed_WF__c'));
                        }
                        if(!$A.util.isEmpty(component.get('v.sObj.RelocationSpaceDeliveryDate_WF__c'))){
                            component.set('v.spaceDeliveryDate', component.get('v.sObj.RelocationSpaceDeliveryDate_WF__c'));
                        } else{
                            component.set('v.spaceDeliveryDate', component.get('v.sObj.SpaceDeliveryDate__c'));
                        }
                        var rcdDate = component.get('v.sObj.RelocationRCDEarlierofOpening_WF__c');
                        var newRCDDate = component.get('v.sObj.NewRCDEarlierofOpeningor_WF__c');
                        var origRCDDate = component.get('v.sObj.RCDEarlierOfOpeningOf_WF__c');
                        if(!$A.util.isUndefinedOrNull(newRCDDate) && newRCDDate !== ''){
                            if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
                                if(new Date(newRCDDate + ' 00:00:00') < new Date(rcdDate + ' 00:00:00')){
                                    rcdDate = newRCDDate;
                                }
                            } else{
                                rcdDate = newRCDDate;
                            }
                        } else{
                            if($A.util.isUndefinedOrNull(rcdDate) || rcdDate === ''){
                                rcdDate = origRCDDate;
                            }
                        }
                        component.set('v.startDateRenewals', rcdDate);
                        component.set('v.RCD', rcdDate);
                    }
                    if(!$A.util.isUndefinedOrNull(component.get('v.sObj.LeaseTerm_WF__c'))){
                        var year = Math.floor(component.get('v.sObj.LeaseTerm_WF__c')/12);
                        var month = Math.floor(component.get('v.sObj.LeaseTerm_WF__c')%12);
                        component.set('v.sObj.leaseYears',year);
                        component.set('v.sObj.leaseMonth',month);
                    }
                    
                 /*   if(result.construction != undefined ){
                        component.set('v.Construction',result.construction);
                    } */
                    if(result.covenantsRecordTypeMap != undefined ){
                        component.set('v.CovenantRecordType',result.covenantsRecordTypeMap);
                    }
                    if(result.covenants != undefined ){
                        component.set('v.Covenants',result.covenants);
                    }
                   /* if(result.chargesRecordTypeMap != undefined ){
                        component.set('v.ChargesRecordType',result.chargesRecordTypeMap);
                    }
                    if(result.charges != undefined ){
                        component.set('v.Charges',result.charges);
                    }*/
                    if(result.budgets != undefined ){
                        component.set('v.budgets',result.budgets);
                    }
                    if(result.product !== undefined){
                        component.set('v.Product', result.product);
                    }
                    //Author-Sachin: Commented below code as part of GDM-8728 as it's not needed anymore.
                   /* if(result.storageProduct !== undefined){
                        component.set('v.Product', result.storageProduct);
                    }*/
                    if(result.lease !== undefined){
                        component.set('v.Lease',result.lease);
                    }
                    /*if(result.standardCharges !== undefined){
                        component.set('v.StandardCharges',result.standardCharges);
                    } */
                    if(result.sObj.ContingenciesIfAny_WF__c !== undefined){
                        if(result.sObj.ContingenciesIfAny_WF__c.includes('Other')){
                            component.set('v.containgencyContainOther',true);
                        }else{
                            component.set('v.containgencyContainOther',false);
                        }
                    }
                   /* if(result.lstRentTableWrapper != undefined ){                            
                        component.set('v.lstGrowthRateTable', result.lstRentTableWrapper);  
                        component.set('v.showTable', true);
                    }
                    if(result.lstOptionsRentTableWrapper != undefined ){                            
                        component.set('v.lstOptionsTable', result.lstOptionsRentTableWrapper);   
                        component.set('v.showOptionsTable', true);
                    }
                    if(result.lstLeaseRenewalOptionsWrapper != undefined){
                        component.set('v.renewalOptions', result.lstLeaseRenewalOptionsWrapper);
                    } */
                    if(result.sObj.Reconfiguration_WF__c=='Y'){
                        component.set('v.reconfigBool',true);
                    }else{
                        component.set('v.reconfigBool',false);
                    }
                    helper.setSecurityTypeHelper(component, event,"init",result);
                  
                    if(!$A.util.isUndefinedOrNull(component.find('COV_kickoutsComp'))){ 
                        component.find('COV_kickoutsComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_radiusRestrictionComp'))){ 
                        component.find('COV_radiusRestrictionComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_coTenancyComp'))){ 
                        component.find('COV_coTenancyComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_commonAreaRestrictionComp'))){ 
                        component.find('COV_commonAreaRestrictionComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_llRelocationRightsComp'))){ 
                        component.find('COV_llRelocationRightsComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_llTerminationRightsComp'))){ 
                        component.find('COV_llTerminationRightsComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_noBuildZoneComp'))){ 
                        component.find('COV_noBuildZoneComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_exclusiveRightComp'))){ 
                        component.find('COV_exclusiveRightComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('COV_otherComp'))){ 
                        component.find('COV_otherComp').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('CO_detailsComp'))){ 
                        component.find('CO_detailsComp').reInit();
                    }
                    if(!component.get('v.disabled')){
                        helper.setPicklistValues(component, result);
                    }
                    
                    
                                 
                    helper.lazyLoadComponents(component, helper, result);
                    /*var fetchPickList = $A.get("e.c:fetchPicklist");
                    if(!$A.util.isUndefinedOrNull(fetchPickList)){ 
                        fetchPickList.fire(); 
                    }
                    var fetchPickTableList = $A.get("e.c:fetchPicklistTable");
                    if(!$A.util.isUndefinedOrNull(fetchPickTableList)){
                        fetchPickTableList.fire();   
                    }*/
                    var addressEvent = $A.get("e.c:RefreshLightningComponentEvent");
                    addressEvent.fire();
                    $A.util.toggleClass(component.find("spinner"), "slds-hide");
                }   
            }
            console.log('End ----->',Date.now());
        });
        $A.enqueueAction(action);
        var arrLeaseTermYearsOptions = [];
        var arrLeaseTermMonthsOptions = [];
        var action;
        var yearPickValue = [];
        var monthPickValue = [];
        for(var i=0;i<=25;i++){
            yearPickValue.push({ value: String(i), label: String(i) });
        }
        for(var i=0;i<12;i++){
            monthPickValue.push({ value: String(i), label: String(i) });
        }
        component.set('v.yearPickValue',yearPickValue);
        component.set('v.monthPickValue',monthPickValue);
    },
    oppoValidate  : function(component, event,helper){
        component.set('v.SaveAndValidateClicked', true);
        console.log('*** v.SaveAndValidateClicked', component.get('v.SaveAndValidateClicked'));
        /*check if all the required fields are filled*/
        console.log('broker',component.get('v.sObj.Broker_WF__c'));
        helper.getSecurityDepositDetails(component, true);
        if(helper.checkRequiredFieldsHelper(component, event)){
            console.log('saveOpportunities - if-->');
            if(helper.validateCovenantTextField(component,component.get('v.relatedRecord'))){
                return; 
            }else{
                return;
            }
        }
        if(helper.validateCovenantTextField(component,component.get('v.relatedRecord')))
        {
            return;
        }
        else{
            console.log("OPPO VALIDTAED");
           component.set('v.BoolValidateDisable',true);
           component.set('v.DealValidated', true);
           helper.saveOpportunity(component,event);
        }
    },
    saveOpportunities  : function(component, event,helper){
            
        var validationError=false;
        component.set('v.BoolSaveDisable',true);
        helper.getSecurityDepositDetails(component, false);
        //validating GDM-7254 fields
        if(helper.validateCovenantTextField(component,component.get('v.relatedRecord')))
        {
            validationError=true;
        }
        if(helper.validateSubComponentTextField(component))
        {
            validationError=true;
        }
        if((component.get("v.sObj.REC_Approval_Status_WF__c")=='Reject'||component.get("v.sObj.REC_Approval_Status_WF__c")=='On Hold') && $A.util.isEmpty(component.get("v.sObj.REC_Comments_WF__c"))){
            component.set('v.recCommentsRejectError', true);
            component.set('v.CO_details', true);
            validationError=true;
        }else{
            component.set('v.recCommentsRejectError', false);
            component.set('v.CO_details', false);
        }
        console.log('Validated text fields for save as Draft');
        component.set('v.DealValidated', false);
        if(component.get('v.showErrors') ||component.get('v.showGuarantorErrors')||validationError)
        {
            component.set('v.BoolSaveDisable',false);
            
            console.log('loc',component.get('v.showErrors'));
            console.log('guaranot',component.get('v.showGuarantorErrors'));
            if(component.get('v.showErrors') ||component.get('v.showGuarantorErrors'))
            {
                component.set('v.GI_securitySectionError',true);
            }else{
                component.set('v.GI_securitySectionError',false);
            } 
            return;
        }
        helper.saveOpportunity(component, event);
        //}
    },
    handleCancel : function(component, event,helper){
        if( (typeof sforce != 'undefined') && (sforce != null) ) {                                                  
            sforce.one.navigateToSObject(component.get('v.recordId')); 
        }
        /*back up if - sforce.one.navigateToSObject(recordId) code fails */
        else{                           
            var urlOpptyDetailPage = "/one/one.app#/sObject/"+component.get('v.recordId')+"/view";
            window.open(urlOpptyDetailPage,"_self");
        }
    },
    showProducts : function(component, event, helper){
        component.set('v.showProductsPopup', 'true'); 
        component.set('v.boolUnitConfig', 'true');          
    },
    showStorageProducts : function (component, event, helper){
        component.set('v.showStorageProductsPopup', 'true'); 
        component.set('v.boolUnitConfig', 'true');    
    },
    onUnitChange:function(component, eve, helper){
        component.set('v.lease', '{}');
        if(!component.get('v.disabled')){
            helper.updateStandardChargesHelper(component);
        }
    },
    onStorageChange : function(component,event,helper){
        var oldValue = event.getParam("oldValue");
        var newValue = event.getParam("value");
        //console.log('New Center' + newCenter.Name);
        if(newValue != '' && newValue != null && newValue != undefined){
            component.set('v.strStorageProducts', newValue);
        }
        //8371
       /* if(component.get('v.sObj.Storage_WF__c')){
            component.set('v.sObj.StorageAnnualIncrease_WF__c',0.05);
        }*/
    },
    validateForNegativeValues:function(component, eve, helper){
        
        var storagePercent = component.get('v.sObj.StorageAnnualIncrease_WF__c');
        if(storagePercent >= 0 ){
            $A.util.addClass(component.find("StorageAnnualIncreaseErrorId"),'slds-hide');
        }
        else{
            $A.util.removeClass(component.find("StorageAnnualIncreaseErrorId"),'slds-hide');
        }
    },
    changeGLA: function(component){
        if(!$A.util.isUndefinedOrNull(component.get('v.sObj.AmendmentGLAUsed_WF__c')) && component.get('v.sObj.AmendmentGLAUsed_WF__c') !== 0){
            component.set('v.glaUsed', component.get('v.sObj.AmendmentGLAUsed_WF__c'));
        } else{
            component.set('v.glaUsed', component.get('v.sObj.GLAUsed_WF__c'));
        }
        /*if(!$A.util.isUndefinedOrNull(component.find('CH_operatingExpenseComp'))){            
            component.find('CH_operatingExpenseComp').changeUnit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('CH_foodCourtExpenseComp'))){ 
            component.find('CH_foodCourtExpenseComp').changeUnit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('CH_promotionalChargesComp'))){ 
            component.find('CH_promotionalChargesComp').changeUnit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('CH_realEstateTaxComp'))){ 
            component.find('CH_realEstateTaxComp').changeUnit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('CON_capitalComp'))){ 
            component.find('CON_capitalComp').changeUnit();
        }*/
    }
})