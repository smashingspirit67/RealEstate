({
    passSection : function(component,event){
        var sectionName = event.getParam("section");
        if(component.get('v.'+sectionName)){
            component.set('v.'+sectionName,false); 
            $A.util.addClass(component.find(sectionName), 'slds-hide'); 
        }else{
            component.set('v.'+sectionName,true);   
            $A.util.removeClass(component.find(sectionName), 'slds-hide'); 
        }
    },
    changeMutliUnitDeal : function(component,event,helper){  
        helper.changeMutliUnitDealHelper(component,event,helper);
    },
    onOperatorChange : function(component,event,helper){ 
        console.log("old value: " , event.getParam("oldValue"));
        console.log("current value: " , event.getParam("value"));
        var idAccount = event.getParam("value");
        if($A.util.isUndefinedOrNull(event.getParam("value"))){
            component.set('v.operatorId',null);
        }else{          
            var action = component.get('c.getProspectDetails');
            action.setParams({"idAccount":idAccount});
            action.setCallback(this, function(response){
                var OperatorNew  = response.getReturnValue();
                component.set('v.operator',response.getReturnValue());
                component.set('v.operatorId',OperatorNew.Id);
            });
            $A.enqueueAction(action);
        }
        component.set('v.tempOpty.IsMultiUnitDeal_WF__c',false);
        helper.changeMutliUnitDealHelper(component,event,helper);
    },
    onDealMakerIdChange : function(component,event,helper){ 
        component.set('v.tempOpty.IsMultiUnitDeal_WF__c',false);
        helper.changeMutliUnitDealHelper(component,event,helper);
    }, 
    printpoc : function(component,event){        
        window.print();
    },
    /** Update Lease Logic **/
    changeLeaseTerm : function(component, event, helper){
        var rcdDate = component.get('v.datRcd');
        console.log(rcdDate);
        if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate!=''){
            var drcdDare = new Date(rcdDate + ' 00:00:00');
            var noofDaysinRCDDate = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
            console.log('noofDaysinRCDDate',noofDaysinRCDDate);
            var years = parseInt(component.get('v.strLeaseYears'));
            var zeroTerm = false;
            if(years<0 || isNaN(years)){
                years =0;
            }
            var months= parseInt(component.get('v.strLeaseMonths'));
            if(months<0 || isNaN(months)){
                months=0;
            }
            if(years ==0 && months ==0){
                zeroTerm = true;
            }
            var monthsToAdd = years*12+months-1;
            if(monthsToAdd<0)
                monthsToAdd=0;
            if(zeroTerm){
                 var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
                 var dexpDateZero = new Date(drcdDare-tzoffset);
                 component.set('v.datExpiryDate',dexpDateZero.toISOString().slice(0,10));
            }
            else{
                if(noofDaysinRCDDate == drcdDare.getDate()){
                    monthsToAdd = monthsToAdd +1;   
                    console.log('monthsToAdd',monthsToAdd);
                    if(monthsToAdd%2==1){
                        console.log('in if');
                        var dexpDate = new Date();
                        dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                        //dexpDate.setMonth(drcdDare.getMonth()+monthsToAdd);
                        //console.log('ddd',dexpDate);
                    }else{
                        console.log('in else');
                        var dexpDate = new Date();
                        dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                        //dexpDate.setMonth(drcdDare.getMonth()+monthsToAdd);
                        //dexpDate.setDate(dexpDate.getDate()-1);
                    }
                }
                else{
                    console.log('in out most else');
                    var dexpDate = new Date();
                    console.log('curr',dexpDate);
                    dexpDate.setFullYear(drcdDare.getFullYear(),drcdDare.getMonth()+monthsToAdd, 1);
                    console.log('afterMonth',dexpDate);
                }
                var noofDaysinExpDate = new Date(dexpDate.getFullYear(), dexpDate.getMonth()+1, 0).getDate();
                dexpDate.setDate(noofDaysinExpDate);
                var tzoffset = (new Date()).getTimezoneOffset() * 60000; 
                dexpDate = new Date(dexpDate-tzoffset);
                console.log('afterDayafterTimeZone',dexpDate.toISOString().slice(0,10));
                component.set('v.datExpiryDate',dexpDate.toISOString().slice(0,10));
            }
        }
    },
    updateLeaseTerm : function(component, event, helper){
        var rcdDate = component.get('v.datRcd');
        if(!$A.util.isUndefinedOrNull(rcdDate) && rcdDate !== ''){
            rcdDate = rcdDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var expDate = component.get('v.datExpiryDate');       
        if(!$A.util.isUndefinedOrNull(expDate) && expDate !== ''){
            expDate = expDate + ' 00:00:00'; //@Joshna - added this if block on 8/8 to ensure time zone is ignored
        }
        var drcdDare = new Date(rcdDate);
        var dexpDate = new Date(expDate);
        var noOdDaysinRCDMonth = new Date(drcdDare.getFullYear(), drcdDare.getMonth()+1, 0).getDate();
        var diff = (dexpDate.getFullYear()*12 + dexpDate.getMonth()) - (drcdDare.getFullYear()*12 + drcdDare.getMonth());
        if(drcdDare.getDate()!=noOdDaysinRCDMonth){
            diff=diff+1;
        }
        console.log('diff',diff);
        var years = Math.floor(diff/12);        
        var months = diff%12;  
        if((dexpDate-drcdDare)<86400000){
            component.set('v.strLeaseYears',String(0));
            component.set('v.strLeaseMonths',String(0));
        }else{
            component.set('v.strLeaseYears',String(years));
            component.set('v.strLeaseMonths',String(months));
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermYears'))){            
            component.find('leaseTermYears').reInit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermMonths'))){            
            component.find('leaseTermMonths').reInit();
        }
    },
    /* This method is called when the page is loaded. */
    doInit : function(component, event, helper) {
        /* console.log('in doInit');
        console.log('Unit empty? '+component.get('v.bolIsUnitEmpty'));
        if(component.get('v.bolIsUnitEmpty')){
            component.set('v.strProducts.value'," ");
        } */
        helper.doInitHelper(component, event, helper);     
    },
    displayGLAFields : function(component, event, helper) {
        helper.displayGLAFieldsHelper(component, event, helper);
    },
    
    updateUnitDetails : function(component, event, helper) {
        component.set('v.strProducts', '');
        component.set('v.addProduct', '');
        component.set('v.addProducts', '');
        component.set('v.intGLAUsed', 0);

        component.set('v.strProductIds', []);
        if(component.get('v.reconfigBool') == false)
        {
        	component.set('v.bolReconfigChange', 'true');
        }
    },
    onCenterIdChange : function(component, event, helper) {
        console.log('*********onCenterIdChange');
    	var oldCenterId = event.getParam("oldValue");
        var newCenterId = event.getParam("value");
        if(oldCenterId !== null && newCenterId === null){
            component.set('v.strProducts',"");
            component.set('v.boolCenterChange',true);
            component.set('v.centerForPopup', {});
            if(!(component.get('v.bolIsUnitEmpty'))){
                helper.onCenterChangeHelper(component, event, helper);
            }
        }
        component.set('v.tempOpty.IsMultiUnitDeal_WF__c',false);
        helper.changeMutliUnitDealHelper(component,event,helper);
    },
    //Invoked on Center change
    onCenterChange : function(component, event, helper) {
        console.log('*********onCenterChange');
        var oldCenter = event.getParam("oldValue");
        //console.log('Old Center : '+ oldCenter.Name);
        var newCenter = event.getParam("value");
        
        //console.log('New Center' + newCenter.Name);
        if(oldCenter != null ){
            if(!(oldCenter.Name == undefined) && (oldCenter != newCenter))
            {
	                    
                component.set('v.strProducts',"");
                component.set('v.intGLAUsed', 0);
                var isReconfig = component.get('v.reconfigBool');
                if(isReconfig){
                component.set('v.boolCenterChange',true);
                    component.set('v.selectedUnits', []);            
                    component.set('v.addProduct', []);
                    component.set('v.unitConfig', null);
                    component.set('v.allUnitConfigs', []);
                    component.set('v.remainingGLAProducts', []);
                    component.set('v.addProducts', []);
                    component.set('v.boolMerge', false);
        }else{
                    component.set('v.selectedProducts', []);            
                }
			}
        }
    },
    /*On change of any two lease term fields the third field should get updated*/
    /*onChangeLeaseTermFields : function(component, event, helper) {
        var strFlag = 'leasterm';
        helper.onChangeLeaseTermFieldsHelper(component, event, helper,strFlag);
    },
    /*On change of any two lease term fields the third field should get updated*
    onSelectLeaseTermFields : function(component, event, helper) {
        var strFlag = 'expirydate';
        helper.onChangeLeaseTermFieldsHelper(component, event, helper,strFlag);
    },
    
    displayExpiryDate : function(component, event, helper) {
        helper.displayExpiryDateHelper(component, event, helper) ;
    },*/
    /* click on "cancel" button calls this method : mallik */
    cancelOpportunity : function(component, event, helper) {
        helper.cancelOpportunityHelper(component, event, helper);     
    },
    saveOpportunity : function(component, event, helper) {
        
        /*check if all the required fields are filled*/
        if(helper.checkRequiredFieldsHelper(component, event, helper)){         
            return;	          
        }
        /*else take details and save Opportunity*/
        else{
            component.set('v.boolOppoCreated',true);
            console.log('save action', action);        
            var action = helper.saveOpportunityHelper(component, event, helper);        	 
            
            action.setCallback(this, function(response){
                var idOppty = response.getReturnValue();                 
                console.log('save response', idOppty);
                if(response.getState() == 'SUCCESS' && idOppty!=null){
                    if( (typeof sforce != 'undefined') && (sforce != null) ) {                    		
                        var idOpptyRecord = idOppty;
                        sforce.one.navigateToSObject(idOpptyRecord); 
                    }
                    /* back up if - sforce.one.navigateToSObject(recordId) code fails */
                    else{                    		
                        var urlOpptyDetailPage = "/one/one.app#/sObject/"+idOppty+"/view";
                        window.open(urlOpptyDetailPage,"_self");
                    }
                }else if (response.getState() === "ERROR") {
                    alert($A.get("$Label.c.DealSheetExceptionErrorMessage_WF"));
                    var lstErrors = response.getError();
                    if (lstErrors) {
                        if (lstErrors[0] && lstErrors[0].message) {                        	
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }                
            });
            
            $A.enqueueAction(action);
        }
    },
    saveAndNewOpportunity : function(component, event, helper){
        /*check if all the required fields are filled*/
        if(helper.checkRequiredFieldsHelper(component, event, helper)){
            return;																						  
        }
        /*else take details and save Opportunity*/								   
        else{
            var action = helper.saveOpportunityHelper(component, event, helper);  
            console.log('saveAndNewOpportunity action :'+action);
            action.setCallback(this, function(response){
                var idOppty = response.getReturnValue();                                 	
                
                if(response.getState() === 'SUCCESS'&& idOppty!=null){                         
                    $A.get('e.force:refreshView').fire();
                }
                else if (response.getState() === "ERROR") {
                    alert($A.get("$Label.c.DealSheetExceptionErrorMessage_WF"));
                    var lstErrors = response.getError();
                    if (lstErrors) {
                        if (lstErrors[0] && lstErrors[0].message) {
                            console.log("Disply error: " +
                                        lstErrors[0].message);
                        }
                    } else {
                        console.log("Unknown error");
                    }
                }
                
            });
            $A.enqueueAction(action);
            //component.set("v.opptyId",opptyId);
            //navigateToRecord(component, event, helper); //mallik changes 
        }
    },
    showProducts : function(cmp, eve, helper){
        var reconfig = cmp.get('v.strReconfig');                    
        cmp.set('v.showProductsPopup', 'true');            
        
    },
    /*Shows Prior Tenant Information on click of Url*/
    showPriorTenantsInfo : function(cmp, eve, helper){
        cmp.set('v.showPriorTenantInfoPopup', 'true');
    },
    clearAccount : function(component,event){
        var fieldValue = event.getParam("fieldValue");
        if(fieldValue == 'dealMaker'){
            component.set('v.strLeasingDivision','');
        }
        if(fieldValue == 'B2BCustomer'){
            component.set('v.B2BCustomerParent',{});
            component.set('v.B2BCustomerSuperParent',{});
            component.set('v.legalEntity',{});
            component.set('v.dealMaker',{});
            component.set('v.strLeasingDivision','');
            component.set('v.datExpiryDate','');
            component.set('v.datRcd','');
            component.set('v.strLeaseYears','0');
            component.set('v.strLeaseMonths','0');
        }
        component.set('v.'+ fieldValue , null);
        console.log(component.get('v.'+ fieldValue));
    },
    passAccount : function(component,event){
        var record = event.getParam("record");
        var fieldValue = event.getParam("fieldValue");
        component.set('v.'+ fieldValue , record);
    }
})