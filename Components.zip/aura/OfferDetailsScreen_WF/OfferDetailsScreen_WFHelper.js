({
    saveOpportunityHelper : function(component, event, operation) {
        console.log("Record New");        
        var action = component.get("c.saveOpportunityDB");
        var addProductArray = [];
        var strProductIds = '';
        console.log(String(component.get('v.strProductIds')));
        console.log(JSON.stringify(addProductArray));
        if(component.get('v.strProductIds') != null && component.get('v.strProductIds') != ''){
            strProductIds = String(component.get('v.strProductIds'));
        }else{
            if(component.get('v.reconfigBool') == false){
                if(component.get('v.addProduct') != null){
                    addProductArray.push(component.get('v.addProduct'));                               
                    strProductIds = JSON.stringify(addProductArray);
                }else
                    strProductIds = null
                    }else if(component.get('v.reconfigBool') == true){
                        if(component.get('v.addProducts') != null){
                            strProductIds = JSON.stringify(component.get('v.addProducts'));
                        }else
                            strProductIds = null
                            }
        }
        var intLeaseterm=0;
        /*if(component.get('v.strLeaseYears') != null){
            component.set('v.intLeaseTerm', intLeaseterm);
        	intLeaseterm = intLeaseterm + Number(component.get('v.strLeaseYears'))*12;
            component.set('v.intLeaseTerm', intLeaseterm);
        }
        if(component.get('v.strLeaseMonths') != null){
            component.set('v.intLeaseTerm', intLeaseterm);
        	intLeaseterm = intLeaseterm + Number(component.get('v.strLeaseMonths'));
            component.set('v.intLeaseTerm', intLeaseterm);
        }*/
        
        var unitConfigs = component.get('v.unitConfig');
        var reservations ;
        var strUnitConfig;
        var strReservations;
        
        if(unitConfigs !== undefined && unitConfigs !== null){
            if(unitConfigs.length >0 )
                strUnitConfig = JSON.stringify(unitConfigs);
            else
                strUnitConfig = null;
        }else
            strUnitConfig = null;
        
        if(component.get('v.reconfigBool')){
            reservations = component.get('v.selectedUnits');
        }else{
            reservations = component.get('v.selectedProducts');
        }
        if(reservations !== undefined && reservations !== null){
            if(reservations.length > 0)
                strReservations = JSON.stringify(reservations);
            else
                strReservations = null;
        }else
            strReservations = null;
        
        if(component.get('v.reconfigBool') == false){
            component.set('v.strReconfig','N');
        }else{
            component.set('v.strReconfig','Y');
        }
        var tempOpty = component.get("v.tempOpty");
        if(!$A.util.isUndefinedOrNull(tempOpty)){
            tempOpty.BundleOpportunity_WF__r = null;
            tempOpty.Reservations__r = null;
            tempOpty.Product__r = null;
            tempOpty.B2BCustomer_WF__r = null;
            tempOpty.LegalEntity_WF__r = null;
            tempOpty.CenterName_WF__r = null;
            tempOpty.Dealmaker_WF__r = null;
            tempOpty.Operator_WF__r = null;
        }
        tempOpty.Operator_WF__c = component.get('v.operatorId');
        
        console.log("Unit Configs ===> ", JSON.stringify(component.get('v.unitConfig')));
        console.log('----strLeaseMonths---->'+Number(component.get('v.strLeaseYears')));
        console.log('----strLeaseMonths---->'+Number(component.get('v.strLeaseMonths')));
        console.log('----intLeaseterm---->'+intLeaseterm);
        console.log('---SetTask'+String(component.get("v.strCreateTasks")));  
        console.log('---SetComments--->'+String(component.get('v.strComments'))); 
        console.log('--Dil--> strRevLine'+String(component.get('v.strRevenueLine')));
        console.log('tempOpty'+ JSON.stringify(tempOpty));
        action.setParams({"idAccount" : component.get("v.idAccount"),
                          "idOpportunity" : component.get("v.idOpportunity"),
                          "idB2BCustomer" : component.get("v.B2BCustomerId"),
                          "idB2BCustomerParent" : component.get("v.B2BCustomerParentId"),
                          "idB2BCustomerSuperParent" : component.get("v.B2BCustomerSuperParentId"),
                          "idLegalEntity" : component.get("v.legalEntityId"),
                          "idCenterName" : (component.get("v.centerName") != null) ? component.get("v.centerName").Id : null,
                          "strUseType" : component.get("v.strUseType"),
                          "strCreateTasks" : String(component.get("v.strCreateTasks")),
                          "idDealMaker" : component.get("v.dealMakerId"),
                          "idUnit" : component.get("v.idUnit"),
                          "idRcd" : component.get("v.datRcd"),
                          "intLeaseTerm" : intLeaseterm,
                          "strLeaseYears" :  parseInt(component.get("v.strLeaseYears")),
                          "strLeaseMonths" : parseInt(component.get("v.strLeaseMonths")),
                          "strExpiryDate" : component.get("v.datExpiryDate"),
                          "strProductFamily" : component.get("v.strProductFamily"),
                          "strFoodUseType" : component.get("v.strFoodUseType"),
                          "strLeasingDivision" : component.get("v.strLeasingDivision"),
                          "strReconfig" : component.get("v.strReconfig"),
                          "intTotalGLA" : component.get("v.intTotalGLA"),
                          "intGLAUsed" : component.get("v.intGLAUsed"),
                          "strCurrTenant" : component.get("v.strCurrTenant"),
                        /* airports
						  "strSpaceDelivDate" : component.get("v.datSpaceDelivDate"),
                          "decLeaseRevenue" : component.get("v.currLeaseRevenue"),
                          "decSpaceCost" : component.get("v.currSpaceCost"), */
                          "tempOpty" : JSON.stringify(tempOpty), //airports
                          "strProductIds" : strProductIds,           
                          "strUnitConfig": strUnitConfig,
                          "proposedUnitNumber" : String(component.get('v.strProducts')),
                          "strComments" : String(component.get('v.strComments')),
                          "strReservations" : strReservations,
                          "strRevenueLine" : component.get('v.strRevenueLine')
                         });
        
        return action;
        
    },
    onCenterChangeHelper : function(component,event,helper) {
        console.log('Center helper called');
        component.set('v.intGLAUsed', null);
        var OppoId = component.get('v.idOpportunity');
        console.log("Opportunity id is :" +OppoId);
        if(OppoId != null){
            var action = component.get("c.removeUnitConfigurations");
            action.setParams({
                "Idopportunity" : OppoId
            });
            action.setCallback(this, function(response){
                component.set("v.bolIsUnitEmpty",response.status);
                console.log('Is unit Empty? ' + response.status);
            });
            $A.enqueueAction(action);}
    },
    checkRequiredFieldsHelper : function(component, event, operation) {
        /*changes to make fields required : Mallik : start*/
        var objCenterNameField = component.find("idCenterName");
        var objUnitNameField = component.find("unitName");
        var objRCDDateField = component.find("rcd");
        var objExpirationDateField = component.find("expirationdate");     
        var objLeaseTermField = component.find("leaseTerm");
        //var strFoodUseTypeField = component.find("foodUseType");
        var objSpaceDelivDateField = component.find("spacedelivdate");
        var objUseTypeField = component.find("useType");
        var strUseType = component.get("v.strUseType");
        var strProductFamily = component.get("v.strProductFamily");
        var bolIsreqFiledEmpty = false;
        // check for Center Name is not empty
        var centerName = component.get('v.centerNameId');
        var dealMaker = component.get('v.dealMakerId');
        var dbaCustomer = component.get('v.B2BCustomerId');
        var Operator = component.get('v.operatorId');
        var OperatorRecord = component.get('v.operator');
        var multiUnitDeal = component.get('v.tempOpty.BundleOpportunity_WF__c');
        var  isMultiUnitDeal = component.get('v.tempOpty.IsMultiUnitDeal_WF__c');
        console.log('**',centerName);
        var whereSectionError = false;
        var whoSectionError = false;
        
        var dealExpiryDate = component.get('v.datExpiryDate');
        var dealRCDDate = component.get('v.datRcd');
        var isReconfig = component.get('v.reconfigBool');
        var unitConfig = component.get('v.unitConfig');
        var selectedProducts = component.get('v.selectedProducts');
        var noRCDError = true;
        var noExpirationError = true;
        
        if(isReconfig == true){
            if(!$A.util.isUndefinedOrNull(selectedProducts)){
                for(var i = 0; i < selectedProducts.length; i++){
                    if(selectedProducts[i].unitStatus == 'Active'){
                        if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(selectedProducts[i].activationEndDate)){
                            if(dealExpiryDate > selectedProducts[i].activationEndDate){
                                whereSectionError = true;
                                bolIsreqFiledEmpty = true;
                                noExpirationError = false;                                
                            }                                                        
                        }
                        if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(selectedProducts[i].activationStartDate)){
                            if(dealRCDDate < selectedProducts[i].activationStartDate){
                                whereSectionError = true;
                                bolIsreqFiledEmpty = true;
                                noRCDError = false;                              
                            }                                                        
                        }
                    }
                }       
            }
        }else if(!isReconfig){
            var unitToAdd = component.get('v.addProduct');
            if(!$A.util.isUndefinedOrNull(selectedProducts)){
                if(selectedProducts.length > 0){
                    for(var i = 0; i < selectedProducts.length; i++){ 
                        if( selectedProducts[i].idProduct == unitToAdd ){
                            if(selectedProducts[i].unitStatus == 'Active'){
                                if(!$A.util.isUndefinedOrNull(dealExpiryDate) && !$A.util.isUndefinedOrNull(selectedProducts[i].activationEndDate)){
                                    if(dealExpiryDate > selectedProducts[i].activationEndDate){
                                        whereSectionError = true;
                                        bolIsreqFiledEmpty = true;
                                        noExpirationError = false;
                                    }                                        
                                }
                                if(!$A.util.isUndefinedOrNull(dealRCDDate) && !$A.util.isUndefinedOrNull(selectedProducts[i].activationStartDate)){
                                    if(dealRCDDate < selectedProducts[i].activationStartDate){
                                        whereSectionError = true;
                                        bolIsreqFiledEmpty = true;
                                        noRCDError = false;
                                    }                                        
                                }
                            }
                        }
                    }
                }
            }
        }

        if(noRCDError){
            $A.util.addClass(component.find("unitRCDErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitRCDErrorId"),'slds-hide');
        }
        if(noExpirationError){
            $A.util.addClass(component.find("unitExpirationErrorId"),'slds-hide');
        }else{
            $A.util.removeClass(component.find("unitExpirationErrorId"),'slds-hide');
        }
        
        
        //Center validation
        if($A.util.isUndefinedOrNull(centerName)){
            $A.util.removeClass(component.find('centerErrorId'), 'slds-hide');
            whereSectionError = true;
        }
        else{
            $A.util.addClass(component.find('centerErrorId'), 'slds-hide');
        }
        //Center validation for Airport
        if(component.get('v.strRevenueLine') == $A.get("$Label.c.AirportLeasing_WF") && !$A.util.isUndefinedOrNull(centerName)){
            if(component.get('v.centerName').Operating_Center_Type__c!='Airport'){
                $A.util.removeClass(component.find('centerAirportErrorId'), 'slds-hide');
                whereSectionError = true;
            }else{
            	$A.util.addClass(component.find('centerAirportErrorId'), 'slds-hide');
            }
        }
        if(component.get('v.strRevenueLine') != $A.get("$Label.c.AirportLeasing_WF") && !$A.util.isUndefinedOrNull(centerName)){
            if(component.get('v.centerName').Operating_Center_Type__c=='Airport'){
                $A.util.removeClass(component.find('centerAirportErrorId'), 'slds-hide');
                whereSectionError = true;
            }else{
            	$A.util.addClass(component.find('centerAirportErrorId'), 'slds-hide');
            }
        }
        if(component.get('v.strRevenueLine') == $A.get("$Label.c.AirportLeasing_WF") && isMultiUnitDeal && $A.util.isUndefinedOrNull(multiUnitDeal)){
            $A.util.removeClass(component.find('multiUnitDeal'), 'slds-hide');
            whereSectionError = true;
        }
        else{
            $A.util.addClass(component.find('multiUnitDeal'), 'slds-hide');
        }
        
        if(component.get('v.strRevenueLine') == $A.get("$Label.c.AirportLeasing_WF") && isMultiUnitDeal && !$A.util.isUndefinedOrNull(multiUnitDeal)){
            console.log('Operator_WF__c' + component.get('v.tempOpty.BundleOpportunity_WF__r').Operator_WF__c);
            console.log('Operator'+Operator);
            console.log('CenterName_WF__c'+component.get('v.tempOpty.BundleOpportunity_WF__r').CenterName_WF__c);
            console.log('centerName'+centerName);
            console.log('Dealmaker_WF__c'+component.get('v.tempOpty.BundleOpportunity_WF__r').Dealmaker_WF__c);
            console.log('dealMaker'+dealMaker);
            console.log('!!!!!',component.get('v.tempOpty'));
            if(component.get('v.tempOpty.BundleOpportunity_WF__r').Operator_WF__c != Operator || component.get('v.tempOpty.BundleOpportunity_WF__r').CenterName_WF__c != centerName || component.get('v.tempOpty.BundleOpportunity_WF__r').Dealmaker_WF__c != dealMaker){
                $A.util.removeClass(component.find('multiUnitDealError'), 'slds-hide');
                whereSectionError = true;
            }else{
                $A.util.addClass(component.find('multiUnitDealError'), 'slds-hide');
            }
        }
        
        // B2BCustomer validations
        if($A.util.isUndefinedOrNull(dbaCustomer)){
            $A.util.removeClass(component.find('dbaErrorId'), 'slds-hide');
            whoSectionError = true;
        }
        else{
            $A.util.addClass(component.find('dbaErrorId'), 'slds-hide');
        }
        
        //Dealmaker Validation
        if($A.util.isUndefinedOrNull (dealMaker)){
            $A.util.removeClass(component.find('dealmakerErrorId'), 'slds-hide');
            whoSectionError = true;
        }else{
            $A.util.addClass(component.find('dealmakerErrorId'), 'slds-hide');
        }
        
        //Operator Validation
        if(component.get('v.strRevenueLine') == $A.get("$Label.c.AirportLeasing_WF") && !$A.util.isUndefinedOrNull(Operator) && OperatorRecord.RecordType.Name!='Prospect'){
            $A.util.removeClass(component.find('operWrongErrorId'), 'slds-hide');
            whoSectionError = true;
        }else{
            $A.util.addClass(component.find('operWrongErrorId'), 'slds-hide');
        }
        
        /*if(!$A.util.isUndefinedOrNull(component.get("v.B2BCustomerSuperParentId")) && !component.get('v.superParentNonDBA')){
			$A.util.removeClass(component.find("superParentErrorId"), 'slds-hide');
			whoSectionError = true;
		} else{
			$A.util.addClass(component.find("superParentErrorId"), 'slds-hide');
		}
        if(!$A.util.isUndefinedOrNull(component.get("v.B2BCustomerParentId")) && !component.get('v.parentNonDBA')){
			$A.util.removeClass(component.find("parentErrorId"), 'slds-hide');
			whoSectionError = true;
		} else{
			$A.util.addClass(component.find("parentErrorId"), 'slds-hide');
		}*/
        // check for Unit/New Unit(Product) is not empty
        if((component.get('v.strProducts')==null) || (component.get('v.strProducts')=="")){
            $A.util.removeClass(component.find('unitNumberErrorId'), 'slds-hide');
            whereSectionError = true;
        }
        else{
            $A.util.addClass(component.find('unitNumberErrorId'), 'slds-hide');
        }
        
        // check for Use Type is not empty
        if((component.get('v.strUseType')==='--None--')){
            $A.util.removeClass(component.find('useTypeErrorId'), 'slds-hide');
            whereSectionError = true;
        }else{
            $A.util.addClass(component.find('useTypeErrorId'), 'slds-hide');
        }
		// check for Product Family is not empty
        if((component.get('v.strProductFamily')==='none')){
            $A.util.removeClass(component.find('productFamilyErrorId'), 'slds-hide');
            whereSectionError = true;
        }else{
            $A.util.addClass(component.find('productFamilyErrorId'), 'slds-hide');
        }
        
        if(whereSectionError){
            bolIsreqFiledEmpty = true;
            component.set('v.whereSectionError',true);
        }else{
            component.set('v.whereSectionError',false);
        }
        
        if(whoSectionError){
            bolIsreqFiledEmpty = true;
            component.set('v.whoSectionError',true);
        }else{
            component.set('v.whoSectionError',false);
        }
        
        var whenSectionError=false;
        // check for Space Delivery is not empty Airports: change from datSpaceDelivDate to tempOpty.datSpaceDelivDate
        if(component.get('v.tempOpty.SpaceDeliveryDate__c')=='' || component.get('v.tempOpty.SpaceDeliveryDate__c')==null){
            $A.util.removeClass(component.find('spaceDeliveryErrorId'), 'slds-hide');
            whenSectionError = true;
        }else{
            $A.util.addClass(component.find('spaceDeliveryErrorId'), 'slds-hide');
        }
        // check for RCD Earlier Of is not empty
        if(component.get('v.datRcd')=='' || component.get('v.datRcd')==null){
            $A.util.removeClass(component.find('rcdEarlierOfErrorId'), 'slds-hide');
            whenSectionError = true;
        }else{
            $A.util.addClass(component.find('rcdEarlierOfErrorId'), 'slds-hide');
        }
        // check for Expiration is not empty
        if(component.get('v.datExpiryDate')=='' || component.get('v.datExpiryDate')==null){
            $A.util.removeClass(component.find('expirationErrorId'), 'slds-hide');
            $A.util.addClass(component.find('expirationPastErrorId'), 'slds-hide');
            whenSectionError = true;
        }else{
            if(new Date(component.get('v.datExpiryDate')) < new Date(component.get('v.datRcd'))){
                $A.util.removeClass(component.find('expirationPastErrorId'), 'slds-hide');
                whenSectionError = true;
            }else{
                $A.util.addClass(component.find('expirationPastErrorId'), 'slds-hide');
            }
            $A.util.addClass(component.find('expirationErrorId'), 'slds-hide');
        }
        if(whenSectionError){
            bolIsreqFiledEmpty = true;
            component.set('v.whenSectionError',true);
        }else{
            component.set('v.whenSectionError',false);
        }
        
        return bolIsreqFiledEmpty;
    },
    doInitHelper: function(component, event, helper){
        console.log('in doInitHelper');
        var idAccount= component.get('v.idAccount');
        var idOpportunity= component.get('v.idOpportunity');
        var lstDealRevenueLine = component.get('v.lstDealRevenueLine');
        /*var arrLeaseTermYearsOptions = [];
        var arrLeaseTermMonthsOptions = [];
        var action;
        for(var i=0;i<=25;i++){
        	arrLeaseTermYearsOptions.push({ value: String(i), label: String(i) });
        }
        for(var i=0;i<=12;i++){
        	arrLeaseTermMonthsOptions.push({ value: String(i), label: String(i) });
        }
        component.set('v.arrLeaseTermYearsOptions',arrLeaseTermYearsOptions);
        component.set('v.arrLeaseTermMonthsOptions',arrLeaseTermMonthsOptions);*/
        /*Set Product Family based when cross sell is 'No'*/
        this.setProductFamilyOnCrossSell(component);
        component.set('v.selectedUnits',[]);
        component.set('v.remainingGLAProducts',[]);
        /*Revenue Line check in screen2 based on selection on screen1*/
        var strRevenueLine = component.get('v.strRevenueLine');
        if(strRevenueLine!=null && strRevenueLine == 'Permanent Leasing'){
            component.set('v.bolHasLeaseRevenue',true);
        }
        else if(strRevenueLine!=null && strRevenueLine == 'Events'){
            component.set('v.bolHasSpaceCost',true);
        }
            else{
                component.set('v.bolHasLeaseRevenue',true);
                component.set('v.bolHasSpaceCost',true);
            }
        var yearPickValue = [];
        var monthPickValue = [];
        for(var i=0;i<=25;i++){
            yearPickValue.push({ value: String(i), label: String(i) });
        }
        for(var i=0;i<12;i++){
            monthPickValue.push({ value: String(i), label: String(i) });
        }
        component.set('v.yearPickValue',yearPickValue);
        component.set('v.monthPickValue',monthPickValue);
        
        /*Revenue Line check in screen2 based on selection on screen1*/
        if(idOpportunity != null){
            var action;
            component.set('v.boolIsEditScreen',true);
            action= component.get('c.getRelatedOpportunityDetails');
            action.setParams({"strOpportunityId":String(idOpportunity)});
            action.setCallback(this, function(response){
                //var opportunityDetails = response.getReturnValue();
                var relatedOpportunities = response.getReturnValue();
                var opportunityDetails = relatedOpportunities.opportunity;
                var products = relatedOpportunities.products;
                var reservations = relatedOpportunities.reservations;
                
                if(opportunityDetails != null){
                    if(opportunityDetails.RevenueLine_WF__c!='Permanent Leasing')
                        component.set("v.strRevenueLine",opportunityDetails.RevenueLine_WF__c);
                    else
                        component.set("v.strRevenueLine",'Permanent Leasing Opportunity');
                    component.set("v.idAccount",opportunityDetails.AccountId);
                    component.set("v.B2BCustomer",opportunityDetails.B2BCustomer_WF__c != null ? opportunityDetails.B2BCustomer_WF__r : '{}');
                    component.set("v.B2BCustomerId",opportunityDetails.B2BCustomer_WF__c);
                    component.set("v.B2BCustomerParent",opportunityDetails.ParentAccount_WF__c != null ? opportunityDetails.ParentAccount_WF__r : '{}');
                    component.set("v.B2BCustomerParentId",opportunityDetails.ParentAccount_WF__c);
                    component.set("v.B2BCustomerSuperParent",opportunityDetails.SuperParent_WF__c != null ? opportunityDetails.SuperParent_WF__r : '{}');
                    component.set("v.B2BCustomerSuperParentId",opportunityDetails.SuperParent_WF__c);
                    
                    component.set('v.boolParentPopulated', opportunityDetails.ParentAccount_WF__c != null ? true : false);
                    component.set('v.boolSuperParentPopulated', opportunityDetails.SuperParent_WF__c != null ? true : false);
                        
                    component.set("v.legalEntity",opportunityDetails.LegalEntity_WF__c != null ? opportunityDetails.LegalEntity_WF__r : '{}');
                    component.set("v.legalEntityId",opportunityDetails.LegalEntity_WF__c);
                    component.set("v.centerName",opportunityDetails.CenterName_WF__c != null ? opportunityDetails.CenterName_WF__r : '{}');
                    component.set("v.centerNameId",opportunityDetails.CenterName_WF__c);
                    component.set("v.centerForPopup",opportunityDetails.CenterName_WF__c != null ? opportunityDetails.CenterName_WF__r : '{}');
                    
                    component.set("v.strUseType",opportunityDetails.UseType_WF__c);
                    component.set("v.dealMaker",opportunityDetails.Dealmaker_WF__c != null ? opportunityDetails.Dealmaker_WF__r : '{}');
                    component.set("v.dealMakerId",opportunityDetails.Dealmaker_WF__c);
                    component.set("v.strLeasingDivision",opportunityDetails.LeasingDivision_WF__c);
                    component.set("v.operator",opportunityDetails.Operator_WF__c != null ? opportunityDetails.Operator_WF__r : '{}');
                    component.set("v.operatorId",opportunityDetails.Operator_WF__c);
                    component.set("v.idUnit",opportunityDetails.Unit_WF__c);
                    component.set("v.datRcd",opportunityDetails.RCDEarlierOfOpeningOf_WF__c);
                    component.set("v.isMultiDeal",opportunityDetails.IsMultiUnitDeal_WF__c);
                    component.set("v.parentOpty",opportunityDetails.BundleOpportunity_WF__c != null ? opportunityDetails.BundleOpportunity_WF__r : '{}');
                    component.set("v.parentOptyId",opportunityDetails.BundleOpportunity_WF__c);
                   
                    component.set('v.tempOpty',opportunityDetails);
                    console.log('*********',component.get('v.tempOpty'));
                    //console.log(opportunityDetails.LeaseTerm_WF__c);
                    //console.log(component.get("v.strLeaseYears"));
                    //console.log(opportunityDetails.LeaseTerm_WF__c/12);
                    /*if(opportunityDetails.LeaseTerm_WF__c != null){
                    	component.set("v.strLeaseYears",String(Math.floor(opportunityDetails.LeaseTerm_WF__c/12)));
                    	component.set("v.strLeaseMonths",String(opportunityDetails.LeaseTerm_WF__c%12));
                    }
                    else{
                        component.set("v.strLeaseYears","0");
                    	component.set("v.strLeaseMonths","0");
                    }*/
                    
                    
                    
                    
                    component.set("v.strLeaseYears",opportunityDetails.TermYears_WF__c);
                    component.set("v.strLeaseMonths",opportunityDetails.TermMonths_WF__c);
                    
                    component.set("v.datExpiryDate",opportunityDetails.ExpirationDate_WF__c);
                    component.set("v.strProductFamily",opportunityDetails.ProductFamily_WF__c);
                    //component.set("v.strFoodUseType",opportunityDetails.FoodUseType_WF__c);
                    component.set("v.strReconfig",opportunityDetails.Reconfiguration_WF__c);
                    component.set("v.intTotalGLA",opportunityDetails.Total_GLA__c);
                    component.set("v.intGLAUsed",opportunityDetails.GLAUsed_WF__c);
                    console.log('i am here');
                    component.set("v.strCurrTenant",opportunityDetails.CurrentTenantInUnit_WF__c);
                    component.set("v.datTenantLeaseExpDate",opportunityDetails.CurrentTenantLeaseExpirationDate_WF__c);
                    /*component.set("v.tempOpty.SpaceDeliveryDate__c", opportunityDetails.SpaceDeliveryDate__c); //Airports: change from datSpaceDelivDate
                    component.set("v.tempOpty.EstimatedValueOfTheDeal_WF__c", opportunityDetails.EstimatedValueOfTheDeal_WF__c); //Airports: change from currLeaseRevenue 
                    component.set("v.tempOpty.SpaceCost_WF__c", opportunityDetails.SpaceCost_WF__c);  //Airports: change from currSpaceCost
                    */
                    component.set("v.boolIsChanged",false);
                    component.set('v.strProducts', opportunityDetails.ProposedUnitNumber_WF__c);
                    console.log('i am here');
                    component.set('v.strCurrTenant',relatedOpportunities.currentTenant);
                    component.set('v.datTenantLeaseExpDate',relatedOpportunities.tenantExpiryDate);
                    component.set('v.strComments',opportunityDetails.Comments_WF__c !== undefined ? opportunityDetails.Comments_WF__c : '');
                    if(component.get('v.strReconfig') == 'Y'){
                        component.set('v.reconfigBool',true);
                    }else{
                        component.set('v.reconfigBool',false);
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('leaseTermYears'))){     
                        console.log('run years');
                        component.find('leaseTermYears').reInit();
                    }
                    if(!$A.util.isUndefinedOrNull(component.find('leaseTermMonths'))){    
                        console.log('run Months');
                        component.find('leaseTermMonths').reInit();
                    }
                    if(component.get('v.reconfigBool') == false){
                        if(reservations != undefined){
                            if(reservations.length !== undefined){
                                component.set("v.addProduct", reservations[0].Product__c);
                            }
                        }
                        var selectedProducts = relatedOpportunities.reservationsForReconfigNo;
                        if(!$A.util.isUndefinedOrNull(selectedProducts)){
                            if(selectedProducts.length > 0)
                                component.set('v.selectedProducts', selectedProducts);
                    }
                    }else if(component.get('v.reconfigBool')){
                        var selectedUnits = relatedOpportunities.unitConfigurations;
                        if(!$A.util.isUndefinedOrNull(selectedUnits)){
                            component.set('v.allUnitConfigs', selectedUnits);
                            if(selectedUnits.length > 0){
                                component.set('v.boolMerge', true);
                    }
                        }
                    }
                    console.log('i am here');
                    if(component.get("v.strProductFamily") == 'GLA'){
                        console.log('i am here inside if');
                        if(component.get('v.reconfigBool') == false){                            
                            component.set("v.boolDisplayTotalGLA", true);            
                            component.set("v.boolDisplayGLAFields", false);
                        }
                        else if(component.get('v.reconfigBool')== true){
                            component.set("v.boolDisplayGLAFields", true);
                            component.set("v.boolDisplayTotalGLA", true);  
                        }
                    }
                    console.log('i am here');
                }
            });
        }
        else{
            action = component.get('c.getRelatedAccountDetails');
            action.setParams({"idAccount":idAccount, "strRevenueLine" : strRevenueLine});
            action.setCallback(this, function(response){
                var AccountDetails = response.getReturnValue();
                if(AccountDetails != null){                
                    //B2B customer making read-only
                    component.set("v.B2BCustomer", AccountDetails.B2BCustomer);
                    component.set("v.B2BCustomerId", AccountDetails.B2BCustomer.Id);
                    component.set("v.B2BCustomerParent", AccountDetails.accountParent);
                    
                    if(!$A.util.isUndefinedOrNull(AccountDetails.accountParent))
                    component.set("v.B2BCustomerParentId", AccountDetails.accountParent.Id);
                    
                    if(AccountDetails.accountParent != null){
                        component.set("v.boolParentPopulated",true);
                    }
                    else
                    component.set("v.boolParentPopulated",false);
                    
                    component.set("v.B2BCustomerSuperParent", AccountDetails.accountSuperParent);
                    if(!$A.util.isUndefinedOrNull(AccountDetails.accountSuperParent))
                    component.set("v.B2BCustomerSuperParentId",AccountDetails.accountSuperParent.Id);
                    if(AccountDetails.accountSuperParent != null){
                    	component.set("v.boolSuperParentPopulated",true);
                    }
                    else
                    	component.set("v.boolSuperParentPopulated",false);
                    component.set("v.legalEntity", AccountDetails.legalEntity);
                    if(!$A.util.isUndefinedOrNull(AccountDetails.legalEntity)){
                    	component.set("v.legalEntityId",AccountDetails.legalEntity.Id);
                    }
                    component.set("v.dealMaker", AccountDetails.dealMaker);
                    if(!$A.util.isUndefinedOrNull(AccountDetails.dealMaker)){
                    	component.set("v.dealMakerId",AccountDetails.dealMaker.Id);
                    }
                    component.set("v.strLeasingDivision", AccountDetails.strLeasingDivision);
                    this.displayGLAFieldsHelper(component,event,helper);
                }
            }); 
            console.log('out of doInit helper');
        }        
        $A.enqueueAction(action);
    },
    displayGLAFieldsHelper: function(component, event, helper) {
        component.set('v.strComments',""); //Defect GDM-4341
        var productFamily= component.get('v.strProductFamily');      
        if(productFamily == 'GLA'){
            var reconfig = component.get('v.strReconfig');    
            var opportunityId = component.get('v.idOpportunity');
            if(reconfig == 'Split/Merge'){
                var unitConfig = [];
                component.set("v.boolDisplayTotalGLA", true);            
                component.set("v.boolDisplayGLAFields", false);
                component.set('v.strCurrTenant','');
                component.set('v.intTotalGLA',0);
                component.set('v.datTenantLeaseExpDate','');
                component.set('v.unitConfig',unitConfig);
                component.set('v.remainingGLAProducts', unitConfig);
                //component.set('v.selectedUnits',unitConfig);
                component.set('v.boolMerge',false);
                
            }else if(reconfig == 'none'){
                var unitConfig = [];
                component.set("v.boolDisplayTotalGLA", true);            
                component.set("v.boolDisplayGLAFields", false);
                component.set('v.unitConfig',unitConfig);
                component.set('v.remainingGLAProducts', unitConfig);
               // component.set('v.selectedUnits',unitConfig);
            }
        }else{
            component.set("v.boolDisplayGLAFields", false);
            component.set('v.boolDisplayTotalGLA', false);
        }
    },
    changeMutliUnitDealHelper : function(component, event, helper){
    	component.set('v.tempOpty.CEPDeal_WF__c',false);
        if(!$A.util.isUndefinedOrNull(component.find('bundleOpportunity'))){
            component.find('bundleOpportunity').clear();
        }
        if(!$A.util.isUndefinedOrNull(component.find('bundleOpportunityNoValue'))){
            component.find('bundleOpportunityNoValue').clear();
        }
    },
    /*displayExpiryDateHelper : function(component, event, helper) {
        if(component.get('v.datRcd') != null && component.get('v.intLeaseTerm') != null){
            var action = component.get('c.getExpiryDate');
            var dateField = component.find("rcd");
            action.setParams({
                'strRcd' : dateField.get("v.value"),
                'intLeaseTerm' : component.get('v.intLeaseTerm')
            });
            action.setCallback(this, function(response){
                if(response.getReturnValue() != null){
                    component.set("v.datExpiryDate", response.getReturnValue());
                }
            });
            $A.enqueueAction(action);
        }
    },*/
    
    cancelOpportunityHelper : function(component, event, helper) {
        if(component.get("v.idOpportunity") != null){
            sforce.one.navigateToSObject(component.get("v.idOpportunity"),'detail');    
        }
        else{
            sforce.one.navigateToSObject(component.get("v.idAccount"),'related');            
        }     
    },
    /*On change of any two lease term fields the third field should get updated
    onChangeLeaseTermFieldsHelper : function(component, event, helper,strFlag) {
        var action = component.get('c.getLeaseTermDetails');
        var datRcd = component.find("rcd");
        var datExp = component.find("expirationdate");
        console.log('inside onChangeLeaseTermFieldsHelper-->');
        var intLeaseterm=0;
        if(component.get('v.strLeaseYears') != null){
            component.set('v.intLeaseTerm', intLeaseterm);
        	intLeaseterm = intLeaseterm + Number(component.get('v.strLeaseYears'))*12;
            component.set('v.intLeaseTerm', intLeaseterm);
        }
        if(component.get('v.strLeaseMonths') != null){
            component.set('v.intLeaseTerm', intLeaseterm);
        	intLeaseterm = intLeaseterm + Number(component.get('v.strLeaseMonths'));
            component.set('v.intLeaseTerm', intLeaseterm);
        }
        console.log('----Ye----->'+component.get('v.strLeaseYears'));
        console.log('----Mo----->'+component.get('v.strLeaseMonths'));
        console.log('----intLeaseTerm----->'+intLeaseterm);
        component.set('v.intLeaseTerm', intLeaseterm);
        if(datRcd.get("v.value")== null || datExp.get("v.value") ==null || intLeaseterm==null){
            var sss;
            action.setParams({
                'strRcd' : datRcd.get("v.value"),
                'strExpirationDate' : datExp.get("v.value"),
                'intLeaseTerm' : intLeaseterm,
                'strFlag' : sss
            });
            action.setCallback(this, function(response){
                if(response.getReturnValue() != null){
                    var objLeaseDetails = response.getReturnValue();
                    component.set("v.datExpiryDate", objLeaseDetails.datExpiryDate);
                    component.set("v.datRcd", objLeaseDetails.datRcd);
                    component.set("v.strLeaseYears", String(Math.floor(objLeaseDetails.intLeaseTerm/12)));
                    component.set("v.strLeaseMonths", String(objLeaseDetails.intLeaseTerm%12));
                }
            });
            $A.enqueueAction(action);
        }
        else if (datRcd.get("v.value")!= null && datExp.get("v.value") !=null && intLeaseterm!=null && strFlag!=null){
            action.setParams({
                'strRcd' : datRcd.get("v.value"),
                'strExpirationDate' : datExp.get("v.value"),
                'intLeaseTerm' : intLeaseterm,
                'strFlag' : strFlag
            });
            action.setCallback(this, function(response){
                if(response.getReturnValue() != null){
                    var objLeaseDetails = response.getReturnValue();
                    component.set("v.datExpiryDate", objLeaseDetails.datExpiryDate);
                    component.set("v.datRcd", objLeaseDetails.datRcd);
                    component.set("v.strLeaseYears", String(Math.floor(objLeaseDetails.intLeaseTerm/12)));
                    component.set("v.strLeaseMonths", String(objLeaseDetails.intLeaseTerm%12));
                }
            });
            $A.enqueueAction(action);
            
        }
    },*/
    /*Sets the  Product family in Screen 2 when Cross sell is 'No'*/
    setProductFamilyOnCrossSell : function(component){
        var strSell = component.get('v.strSell');
        var strRevenueLine = component.get('v.strRevenueLine');
        if((strSell!== null && strSell=='No')&&(strRevenueLine!==null&&strRevenueLine!=='none'&&(strRevenueLine=='Permanent Leasing')||strRevenueLine=='Airport')){
            component.set('v.strProductFamily','GLA');
        }
    },
})