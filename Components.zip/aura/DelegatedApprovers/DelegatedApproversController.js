({
	doInit : function(component, event, helper) {
       // Current User ID
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        //var userId = component.get('v.CurrentUserId');
        var action = component.get('c.fetchRecords');
        action.setParams({"currUser":userId});
        action.setCallback(this, function(response){
            var isSuccess = response.getState();
             if(isSuccess){
                 var result = response.getReturnValue();
                 if((!$A.util.isUndefinedOrNull(result)) && (result.length != 0)){  
                     //Set the retrieved records to the iteration variable
                     component.set('v.optyRecords',result);
                 }
             }
        });
		$A.enqueueAction(action);
	}
})