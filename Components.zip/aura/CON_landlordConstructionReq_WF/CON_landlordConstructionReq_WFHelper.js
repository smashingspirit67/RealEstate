({
    setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = 'Construction_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    },
    helperChangeStructuralModification : function(component,event) {
        component.set('v.StructuralModificationOtherError',false);
        component.set('v.Construction.StructuralModification_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('StructuralModification'))){  
            component.find('Construction_WF__cStructuralModification_WF__c').reInit();
        }
        component.set('v.Construction.StructuralModificationOther_WF__c','');
    },
    helperChangeDemisingWall : function(component,event) {
        component.set('v.Construction.DemisingWall_WF__c','');
        component.set('v.DemisingWallOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDemisingWall_WF__c'))){  
            component.find('Construction_WF__cDemisingWall_WF__c').reInit();
        }
        component.set('v.Construction.DemisingWallOther_WF__c','');
    },
    helperChangeStoreFrontage : function(component,event) {
        console.log('ddd',component.get('v.Construction.StoreFrontage_WF__c'));
        component.set('v.Construction.StoreFrontage_WF__c','');
        component.set('v.storeFrontageOtherError',false);
        console.log('eee',component.get('v.Construction.StoreFrontage_WF__c'));
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cStoreFrontage_WF__c'))){  
            component.find('Construction_WF__cStoreFrontage_WF__c').reInit();
        }
        component.set('v.Construction.StoreFrontageOther_WF__c','');
    },
    helperChangeElectrical : function(component,event) {
        component.set('v.Construction.Electrical_WF__c','');
         component.set('v.ElectricalsOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cElectrical_WF__c'))){  
            component.find('Construction_WF__cElectrical_WF__c').reInit();
        }
        component.set('v.Construction.ElectricalVoltage_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cElectricalVoltage_WF__c'))){  
            component.find('Construction_WF__cElectricalVoltage_WF__c').reInit();
        }
        component.set('v.Construction.ElectricalAmps_WF__c',0);
        component.set('v.Construction.ElectricalOther_WF__c','');
    },
    helperChangeData : function(component,event) {
        component.set('v.Construction.Data_WF__c','');
         component.set('v.DataOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cData_WF__c'))){  
            component.find('Construction_WF__cData_WF__c').reInit();
        }
        component.set('v.Construction.DataConduitSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDataConduitSize_WF__c'))){  
            component.find('Construction_WF__cDataConduitSize_WF__c').reInit();
        }
        component.set('v.Construction.DataQuantity_WF__c',0);
        component.set('v.Construction.DataOther_WF__c','');
    },
    helperChangeDomesticWater : function(component,event) {
        component.set('v.Construction.DomesticWater_WF__c','');
         component.set('v.DomesticWaterOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDomesticWater_WF__c'))){  
            component.find('Construction_WF__cDomesticWater_WF__c').reInit();
        }
        component.set('v.Construction.DomesticWaterPipeSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cDomesticWaterPipeSize_WF__c'))){  
            component.find('Construction_WF__cDomesticWaterPipeSize_WF__c').reInit();
        }
        component.set('v.Construction.DomesticWaterOther_WF__c','');
    },
    helperChangeSewer : function(component,event) {
        component.set('v.Construction.Sewer_WF__c','');
         component.set('v.SewerOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewer_WF__c'))){  
            component.find('Construction_WF__cSewer_WF__c').reInit();
        }
        component.set('v.Construction.SewerSize_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerSize_WF__c'))){  
            component.find('Construction_WF__cSewerSize_WF__c').reInit();
        }
        component.set('v.Construction.SewerOther_WF__c','');
    },
    helperChangeSewerVent : function(component,event) {
        component.set('v.Construction.SewerVentSize_WF__c','');
         component.set('v.SewerVentOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerVentSize_WF__c'))){  
            component.find('Construction_WF__cSewerVentSize_WF__c').reInit();
        }
        component.set('v.Construction.SewerVent_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSewerVent_WF__c'))){  
            component.find('Construction_WF__cSewerVent_WF__c').reInit();
        }
        component.set('v.Construction.SewerVentOther_WF__c','');
    },
    helperChangeGreaseWaste : function(component,event) {
        component.set('v.Construction.GreaseInterceptorSize_WF__c','');
         component.set('v.GreaseWasteOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cGreaseInterceptorSize_WF__c'))){  
            component.find('Construction_WF__cGreaseInterceptorSize_WF__c').reInit();
        }
        component.set('v.Construction.GreaseWaste_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cGreaseWaste_WF__c'))){  
            component.find('Construction_WF__cGreaseWaste_WF__c').reInit();
        }
        component.set('v.Construction.GreaseWasteOther_WF__c','');
    },
    helperChangeSlabCondition : function(component,event) {
        component.set('v.Construction.SlabCondition_WF__c','');
         component.set('v.SlabConditionOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cSlabCondition_WF__c'))){  
            component.find('Construction_WF__cSlabCondition_WF__c').reInit();
        }
        component.set('v.Construction.SlabConditionOther_WF__c','');
    },
    helperChangeMechanical : function(component,event) {
        component.set('v.Construction.Mechanical_WF__c','');
         component.set('v.MechanicalOtherError',false);
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMechanical_WF__c'))){  
            component.find('Construction_WF__cMechanical_WF__c').reInit();
        }
        component.set('v.Construction.Mechanicals_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cMechanicals_WF__c'))){  
            component.find('Construction_WF__cMechanicals_WF__c').reInit();
        }
        component.set('v.Construction.MechanicalOther_WF__c','');
    },
    helperChangeFireSprinkler : function(component,event) {
        component.set('v.Construction.FireSprinkler_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cFireSprinkler_WF__c'))){  
            component.find('Construction_WF__cFireSprinkler_WF__c').reInit();
        }
        component.set('v.Construction.FireSprinklerOther_WF__c','');
    },
    helperChangeFireLifeSafety : function(component,event) {
        component.set('v.Construction.FireLifeSafety_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('Construction_WF__cFireLifeSafety_WF__c'))){  
            component.find('Construction_WF__cFireLifeSafety_WF__c').reInit();
        }
        component.set('v.Construction.SmokeEvacuation_WF__c',false);
    },
    helperChangeMiscellaneous : function(component,event) {
        component.set('v.Construction.MiscellaneousOther_WF__c','');
         component.set('v.MiscellaneousOtherError',false);
    },
})