({
	submitForApproval: function(component) {
        var recordId=component.get("v.recordId");
        var comments=component.get("v.comments");
        var action=component.get("c.submitForApproval");

        var submitButton = component.find("submit");
        submitButton.set('v.disabled', true);
        action.setParams({
            "opportunityId":recordId,
            "comments":comments 
        });
        
        action.setCallback(this,function(response){
            var approvalMessage=response.getReturnValue();
            
            if(approvalMessage.message != $A.get("$Label.c.ApprovalSuccess"))
            {   
            	component.set("v.messageSeverity", approvalMessage.severity);
		        component.set("v.message", approvalMessage.message.split("~~"));
		        submitButton.set('v.disabled', false);
            }
            else
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message": "Opportunity was submitted for approval.",
                    "type": "success"
                });
                toastEvent.fire();
            	$A.get("e.force:closeQuickAction").fire();
            }
        });
        
        $A.enqueueAction(action);
	
	}
})