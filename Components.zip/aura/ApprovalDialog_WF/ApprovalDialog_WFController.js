({
	doSubmit: function(component, event, helper) {
		helper.submitForApproval(component);
	}
})