({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Other']){
                component.set('v.otherCovenant',covenant[item]);
                isPresent=true;
            }
        }
        if(!isPresent){
            var otherCovenant = {};
            otherCovenant.RecordTypeId =component.get('v.CovenantRecordType')['Other'];
            component.set('v.otherCovenant',otherCovenant);
            covenant.push(component.get('v.otherCovenant'));
            component.set('v.Covenant',covenant);
        }
	},
})