({
     
    handleIsMinimumRentChange : function(component, event, helper) {
       component.set("v.rentStabCmntErr",false);
       var newValue = component.get('v.isMinimumRent');      
        console.log(event);
        if (!$A.util.isUndefinedOrNull(newValue) && typeof newValue === "boolean") {
            helper.setDefaults(component, newValue);
        }
        console.log('**new issue', component.get("v.opportunity.FirstyrAnnualizedAmount_WF__c"));
        console.log('**new issue', component.get("v.opportunity.FirstYrRatePSF_WF__c"));
    },

    handleIncreaseIntervalChange : function(component, event, helper) {
        var options = helper.getOptions(component);
        options.calcs = "dates";
        helper.getRentRows(component, options, false);  
    },
    
    handleGrowthTypeChange : function(component, event, helper) {
        var options = helper.getOptions(component);
        options.calcs = "steps";
        helper.getRentRows(component, options, false);  
    },

    handleDateChange : function(component, event, helper) {
        var options = helper.getOptions(component);
        console.log('****', options);
        options.calcs = "";
        helper.getRentRows(component, options, false);  
        console.log('****got rent rows');
    },
    
    handleSTRSChange : function(component, event, helper){
        component.set("v.rentStabCmntErr",false);
        if(!component.get('v.opportunity.SubjecttoRentStabilization_WF__c')){
            component.set('v.opportunity.Rent_Stabilization_Comments_WF__c', '');
        }
    },
    handleOptionsSTRSChange : function(component, event, helper){
        component.set("v.rentStabCmntErr",false);
        if(!component.get('v.opportunity.OptionsSubjecttoRentStabilization_WF__c')){
            component.set('v.opportunity.Options_Rent_Stabilization_Comments_WF__c', '');
        }
    },
    handleIncreaseChange : function(component, event, helper) {
        var lstMinRentTable = component.get('v.lstMinRentTable') ;
        var errorCmp = component.find('errorId');
        var isErrorInc = false;
        //console.log('Rent Step =---> ', lstMinRentTable);
        //console.log('Rent Step 0 =---> ', lstMinRentTable[1].decRentStep);
        //for(var iter=0; iter < lstMinRentTable.length ; iter++){
        for(var iter in lstMinRentTable){
            if(lstMinRentTable[iter].decRentStep < 0){
                isErrorInc = true;
                
            }
        }
        if(isErrorInc){
            $A.util.removeClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', true);
        }
        else{
            $A.util.addClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', false);
            var options = helper.getOptions(component);
            options.calcs = "";
            helper.getRentRows(component, options, false);    
        }
    },

    handlePsfChange : function(component, event, helper) {        
        
        var errorCmp = component.find('errorId');
        var lstMinRentTable = component.get('v.lstMinRentTable');
        var isErrorInc = false;
        for(var iter in lstMinRentTable){
        if(lstMinRentTable[iter].decAnnualizedRentPSF < 0){ 
             isErrorInc = true;
            }
        }
        for(var iter in lstMinRentTable){
            console.log('****',lstMinRentTable[iter].decRentStep);
            if(lstMinRentTable[iter].decRentStep < 0){ 
                isErrorInc = true;
            }
        }
        if(isErrorInc){
            $A.util.removeClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', true);
        }
        else{
            $A.util.addClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', false);
            var options = helper.getOptions(component);
            console.log(options);
            console.log(component.get("v.lstMinRentTable"));
            options.calcs = "psf";
            helper.getRentRows(component, options, true);   
        }
    },

    
    handleRentChange : function(component, event, helper) {        
        var options = helper.getOptions(component);
        var errorCmp = component.find('errorId');
        var lstMinRentTable = component.get('v.lstMinRentTable');
        var isErrorInc = false;
        options.calcs = "ann";
        options.annValue = helper.rentRow.formatRent(event.target.value);
        options.annIndex = event.target.getAttribute("data-id");
        helper.getRentRows(component, options, true);        
        for(var iter in lstMinRentTable){
            if(lstMinRentTable[iter].decAnnualizedRentPSF < 0){ 
                isErrorInc = true;
            }
        }
        for(var iter in lstMinRentTable){
            console.log('****',lstMinRentTable[iter].decRentStep);
            if(lstMinRentTable[iter].decRentStep < 0){ 
                isErrorInc = true;
            }
        }
        if(isErrorInc){
            $A.util.removeClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', true);
        }
        else{
            $A.util.addClass(errorCmp , 'slds-hide');
            component.set('v.IsNegativeValue', false);
        }
    },

    handleEstimated : function(component, event, helper) {
        helper.updateEstimated(component);
        var options = helper.getOptions(component);
        helper.getRentRows(component, options, false);
    },
    
    handleComments : function(component, event, helper) {
        var options = helper.getOptions(component);
        helper.getRentRows(component, options, false);
    },
    
    updateAllEstimated : function(component, event, helper) {
        var allEstimated = component.get("v.allEstimated");
        var table = component.get("v.lstMinRentTable");
        component.set("v.isEstimated", allEstimated);
        for (var i = 0; i < table.length; i++) {
            table[i].boolEstimated = allEstimated
        }
        component.set("v.lstMinRentTable", table);
    },
    
    handleGlaEffectRentChange : function(component, event, helper) {
        var newValue = event.getSource().get("v.value");
        component.set("v.glaEffectRent", newValue);
    },

    handleTermChange : function(component, event, helper) {
        var newValue = event.getParam("value");
        var oldValue = event.getParam("oldValue");
        if((component.get('v.oldStartDate') !== undefined && component.get('v.oldStartDate') !== null && component.get('v.oldStartDate') == oldValue && newValue != component.get('v.oldStartDate')) || 
           (component.get('v.oldEndDate') !== undefined && component.get('v.oldEndDate') !== null && component.get('v.oldEndDate') == oldValue && newValue != component.get('v.oldEndDate'))){
        var extended = false;
        if(!$A.util.isUndefinedOrNull(newValue) && !$A.util.isUndefinedOrNull(oldValue) && newValue !== '' && oldValue !== ''){
            var oldValueDate = new Date(oldValue);
            var newValueDate = new Date(newValue);
            if(newValueDate > oldValueDate){
                extended = true;
            }
        }
        var isMinimumRent = component.get("v.isMinimumRent");
        if (isMinimumRent) {
            if( typeof newValue === "string") {
                var options = helper.getOptions(component);
                options.calcs = "dates";
                options.extended = extended;
                helper.getRentRows(component, options, false);  
            }
            var appEvent = $A.get("e.c:UpdatePercentRentTableEvent");
            appEvent.fire();
        }
        }
        if(component.get('v.startDate') !== undefined && component.get('v.startDate') !== null){
        component.set('v.oldStartDate', component.get('v.startDate'));
        }
        if(component.get('v.endDate') !== undefined && component.get('v.endDate') !== null){
        component.set('v.oldEndDate', component.get('v.endDate'));
        }
    },

    handleGlaChange : function(component, event, helper) {
        var newValue = event.getParam("value");
        var oldValue = event.getParam("oldValue");
        var glaEffectRent = component.get("v.glaEffectRent");
        var isMinimumRent = component.get("v.isMinimumRent");
        if (isMinimumRent) {
                  if(component.get('v.oldGla') == oldValue && newValue != component.get('v.oldGla')){
                
            if (glaEffectRent === $A.get("$Label.c.GLA_Effect_Rent_PSF_WF")) {
                helper.calculateFirstYrAmt(component, event, helper, false);
            } else{
                helper.calculateFirstYrAmt(component, event, helper, true);
                }
            }
            component.set('v.oldGla', component.get('v.gla'));
        }
    },
    
    calculateAnnual : function(component, event, helper){
        helper.calculateFirstYrAmt(component, event, helper, true);
    },
    
    calculatePSF : function(component, event, helper){
        helper.calculateFirstYrAmt(component, event, helper, false);
    },
    validateNonStdCmnts:function(component,event,helper)
    {
        console.log("inside minimum cntrl ");
        helper.validateNonStdCmnts(component,event);
    },
    validateRentStabCmnts:function(component,event,helper)
    {
        helper.validateRentStabCmnts(component,event);
    }
})