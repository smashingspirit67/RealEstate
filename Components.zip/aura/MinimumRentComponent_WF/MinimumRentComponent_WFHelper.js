({ 
    setDefaults : function (component, isMinRent) {
        if (isMinRent) {
            /*Joshna - 26 Jun '17 - Bug 4550.. Setting to defaults only if it's undefined. This ensures that when
              editing an existing opportunity where min rent is already selected, the values saved on opportunity load*/
            if(component.get("v.increaseInterval") === undefined || component.get("v.increaseInterval") === null || component.get("v.increaseInterval") === '' || component.get("v.increaseInterval") === 'NA'){
                component.set("v.increaseInterval", $A.get("$Label.c.Rent_Increases_RCD_WF"));
            }
            if(component.get("v.growthType") === undefined || component.get("v.growthType") === null || component.get("v.growthType") === '' || component.get("v.growthType") === 'NA'){
                component.set("v.growthType", $A.get("$Label.c.Annual_Growth_Same_Perc_WF"));
            }
            if(component.get("v.glaEffectRent") === undefined || component.get("v.glaEffectRent") === null || component.get("v.glaEffectRent") === ''){
                component.set("v.glaEffectRent", $A.get("$Label.c.GLA_Effect_Rent_Annual_WF"));
            }
        } else {
            component.set("v.increaseInterval", "NA");
            component.set("v.growthType", "NA");
            component.set("v.glaEffectRent", "");
            //Joshna - 30 Jun '17 when min rent is unchecked, these defaults should be set
            component.set("v.firstYearAnnualizedAmount", 0);
            component.set("v.firstYearAnnualizedRentPSF", 0);
        }
        var options = this.getOptions(component);
        options.calcs = "dates;steps";
        this.getRentRows(component, options);
    },

    getOptions : function(component) {
        return {
                "lstMinRentTable"   : component.get("v.lstMinRentTable"),
                "isMinimumRent"     : component.get("v.isMinimumRent"),
                "startDate"         : component.get("v.startDate"),
                "endDate"           : component.get("v.endDate"),
                "gla"               : component.get("v.gla"),
                "increaseInterval"  : component.get("v.increaseInterval"),
                "growthType"        : component.get("v.growthType"),
                "glaEffectRent"     : component.get("v.glaEffectRent"),
                "isEstimated"       : component.get("v.isEstimated"),
                "allEstimated"      : component.get("v.allEstimated"),
                "unitOfMeasure"     : component.get("v.unitOfMeasure"),
                "opportunity"       : component.get('v.opportunity'),
                "IsOptions"         : component.get('v.IsOptions'),
                "calcs"             : "",
                "updatedTable"      : [],
                "index"             : 0,
                "firstRowRent"      : component.get('v.firstYearAnnualizedAmount'),
                "extended"          : false
            }
    },
    
    rentRow : {
        
        getNextRow : function(options) {
            var startDate = this.getStartDate(options);
            var endDate = this.getEndDate(startDate, options);
            var step = this.getStep(options);
            var rent = this.getRent(step, options);
            var psf = this.getPsf(rent, options);
            var estimated = this.getEstimated(options);
            var comments = this.getComments(options);
            if(!estimated){
                comments = '';
            }
            var minRent;
            var percentRent;
            var decBrkptCalcpercent; 
            var minRentRate;
            var decBrkptAmount;
            var boolEstimatedPercent = false;
            var percentComments;
            if(options.lstMinRentTable.length > 0 ){
                var objRentRow = options.lstMinRentTable[options.index];                  
                if( !$A.util.isUndefinedOrNull(objRentRow) && !$A.util.isUndefinedOrNull(objRentRow.objMinRent)){                                        
                    minRent = objRentRow.objMinRent ;                                        
               }
            }
            if(options.lstMinRentTable.length > 0){                
                 if( !$A.util.isUndefinedOrNull(objRentRow) && !$A.util.isUndefinedOrNull(objRentRow.objPercentRent)){                                                        
                    percentRent = objRentRow.objPercentRent ;                                        
                }                
                var minRentRow = options.lstMinRentTable[options.index];
                
                minRentRate = minRentRow != undefined ? minRentRow.decRentRate : null;
                
                if(options.opportunity != undefined){
                    if(options.IsOptions !== true){
                    if(!$A.util.isUndefinedOrNull(options.lstMinRentTable[options.index])){
                        boolEstimatedPercent = options.lstMinRentTable[options.index].boolEstimatedPercent;
                        percentComments = options.lstMinRentTable[options.index].percentComments;    
                    }                                        
                    if(options.opportunity.BreakpointType_WF__c == 'Natural' || (options.opportunity.BreakpointType_WF__c =='Unnatural' && options.opportunity.RentTypeBasis_WF__c == 'Minimum Rent') ){
                        decBrkptCalcpercent = minRentRow != undefined ? minRentRow.decBrkptCalcpercent : null;
                        if(decBrkptCalcpercent > 0){
                            decBrkptAmount = decBrkptCalcpercent != 0 ? (Number(rent) / decBrkptCalcpercent)*100 : 0;      
                        }       
                    }else if(options.opportunity.BreakpointType_WF__c == 'Unnatural' && options.opportunity.RentTypeBasis_WF__c ==='Other' ){ 
                        if(options.index > 0){
                            decBrkptCalcpercent = minRentRow != undefined ? minRentRow.decBrkptCalcpercent : 0;
                            if(decBrkptCalcpercent >0 ){
                                if(options.opportunity.BreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                    
                                    decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + (( Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) * decBrkptCalcpercent) / 100);
                                    decBrkptCalcpercent = decBrkptCalcpercent;
                                    
                                }else if(options.opportunity.BreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                            
                                    
                                    decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + (( Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) * decBrkptCalcpercent) / 100);
                                    decBrkptCalcpercent = decBrkptCalcpercent;                                                                                                            
                                    
                                }else if(options.opportunity.BreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                                    
                                    decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + Number(decBrkptCalcpercent);
                                    decBrkptCalcpercent = decBrkptCalcpercent;
                                    
                                }else if(options.opportunity.BreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                                    
                                    decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + Number(decBrkptCalcpercent);
                                    decBrkptCalcpercent = decBrkptCalcpercent;                                    
                                }
                            }
                        }else{
                            decBrkptCalcpercent = 0;
                            decBrkptAmount = minRentRow.decBreakpointAmount;
                        }
                    }else{
                        decBrkptAmount = null;
                        decBrkptCalcpercent = null;
                        minRentRate = null;
                        }
                    }else{
                        if(!$A.util.isUndefinedOrNull(options.lstMinRentTable[options.index])){
                            boolEstimatedPercent = options.lstMinRentTable[options.index].boolEstimatedPercent;
                            percentComments = options.lstMinRentTable[options.index].percentComments;    
                        }                                        
                        if(options.opportunity.OptionsBreakpointType_WF__c == 'Natural' || (options.opportunity.OptionsBreakpointType_WF__c =='Unnatural' && options.opportunity.OptionsRentTypeBasis_WF__c == 'Minimum Rent') ){
                            decBrkptCalcpercent = minRentRow != undefined ? minRentRow.decBrkptCalcpercent : null;
                            if(decBrkptCalcpercent > 0){
                                decBrkptAmount = decBrkptCalcpercent != 0 ? (Number(rent) / decBrkptCalcpercent)*100 : 0;      
                            }       
                        }else if(options.opportunity.OptionsBreakpointType_WF__c == 'Unnatural' && options.opportunity.OptionsRentTypeBasis_WF__c ==='Other' ){ 
                            if(options.index > 0){
                                decBrkptCalcpercent = minRentRow != undefined ? minRentRow.decBrkptCalcpercent : 0;
                                if(decBrkptCalcpercent >0 ){
                                    if(options.opportunity.OptionsBreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Same_Per_WF")){                    
                                        decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + (( Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) * decBrkptCalcpercent) / 100);
                                        decBrkptCalcpercent = decBrkptCalcpercent;
                                    }else if(options.opportunity.OptionsBreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Diff_Perc_WF")){                            
                                        decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + (( Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) * decBrkptCalcpercent) / 100);
                                        decBrkptCalcpercent = decBrkptCalcpercent;                                                                                                            
                                    }else if(options.opportunity.OptionsBreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Same_Dollar_WF")){
                                        decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + Number(decBrkptCalcpercent);
                                        decBrkptCalcpercent = decBrkptCalcpercent;
                                    }else if(options.opportunity.OptionsBreakpointStepType_WF__c === $A.get("$Label.c.Break_Point_Step_Diff_Dollar_WF")){
                                        decBrkptAmount = Number(options.lstMinRentTable[options.index-1].decBreakpointAmount) + Number(decBrkptCalcpercent);
                                        decBrkptCalcpercent = decBrkptCalcpercent;                                    
                                    }
                                }
                            }else{
                                decBrkptCalcpercent = 0;
                                decBrkptAmount = minRentRow.decBreakpointAmount;
                            }
                        }else{
                            decBrkptAmount = null;
                            decBrkptCalcpercent = null;
                            minRentRate = null;
                        }
                    }
                }                
            }           
            
            return {
                    "datStartDate"                          : startDate,
                    "datEndDate"                            : endDate,                              
                    "decAmount"                             : rent, 
                    "decAnnualizedRentPSF"                  : psf,
                    "boolEstimated"                         : estimated,
                    "decRentStep"                           : step,
                    "decBreakpointAmount"                   : decBrkptAmount,
                    "decBrkptCalcpercent"                   : decBrkptCalcpercent,
                    "decRentRate"                           : minRentRate,  
                    "nstComments"                           : comments,
                    "percentComments"                       : $A.util.isUndefinedOrNull(percentComments) ? '' : percentComments,
                    "boolEstimatedPercent"                  : boolEstimatedPercent,
                    "objMinRent" : 
                    {
                        
                        "AnnualizedRent_WF__c" : rent,      
                        "AnnualizedRentPSF_WF__c": psf,
                        "EndDate_WF__c" : endDate,
                        "StartDate_WF__c" : startDate,
                        "Estimated_WF__c" : estimated,
                        "Increase_WF__c": step,              
                        "Non_Standard_Comments_WF__c": comments,
                        "Id" : minRent !== undefined ? minRent.Id : null
                    },
                    "objPercentRent" : 
                    {                        
                        "AnnualizedRent_WF__c" : rent,
                        "BrkptCalcpercent_WF__c" : null,
                        "BreakpointAmount_WF__c" : null,
                        "EndDate_WF__c" : endDate,
                        "StartDate_WF__c" : startDate,
                        "RentRate_WF__c": null,                        
                        "Id" : percentRent !== undefined ? percentRent.Id : null,
                        "PercentNonStandardComments_WF__c" :'',
                        "PercentNonStandard_WF__c" : false
                        
                    }
                }
        },
        
        getStartDate : function(options) {
            if (options.calcs.includes("dates")) {
                return (options.index == 0) ? options.startDate : 
                    this.getNextDay(options.updatedTable[options.updatedTable.length-1].datEndDate);
            } else {
                if (options.increaseInterval == "Other") {
                    return (options.index == 0) ? options.startDate : 
                    this.getNextDay(options.lstMinRentTable[options.index-1].datEndDate);
                } else if (options.lstMinRentTable.length > options.index) {
                    return options.lstMinRentTable[options.index].datStartDate;
                } else {
                    return null;
                }
            }
        },
        
        getEndDate : function(startDate, options) {
            var newDate = new Date(startDate);
            var endDate = new Date(options.endDate);
            var optionsStd = "Other";
            if(options.increaseInterval === $A.get("$Label.c.Rent_Increases_RCD_WF")){
                optionsStd = "RCDYr";
            } else if(options.increaseInterval === $A.get("$Label.c.Rent_Increases_Partial_Year_WF")){
                optionsStd = "PartialYr";
            } else if(options.increaseInterval === $A.get("$Label.c.Rent_Increases_Lease_Year_WF")){
                optionsStd = "LeaseYr";
            }
            if (options.calcs.includes("dates")) {
                switch(optionsStd) {
                case "RCDYr":
                    newDate = new Date(newDate.getFullYear() + 1,
                            (newDate.getDate() == 1) ? newDate.getMonth() : (newDate.getMonth() + 1),
                            0);
                    break;
                case "LeaseYr":
                    newDate = new Date(newDate.getFullYear() + 1,
                            0,
                            31);
                    break;
                case "PartialYr":
                    newDate = options.index == 0 ? new Date(newDate.getFullYear() + 2, 0, 31) : new Date(newDate.getFullYear() + 1, 0, 31);
                    break;
                case "Other":
                    newDate = options.extended ? (options.index == (options.lstMinRentTable.length - 1) ? options.endDate : ((!$A.util.isUndefinedOrNull(options.lstMinRentTable[options.index].datEndDate) && options.lstMinRentTable[options.index].datEndDate !== '') ? new Date(options.lstMinRentTable[options.index].datEndDate) : null)) : null;
                }
                return (newDate > endDate) ? options.endDate : (newDate != null && (typeof newDate === "object")) ? this.getFormattedDate(newDate) : newDate;
            } else {
                if (options.lstMinRentTable.length > options.index) {
                    newDate = new Date(options.lstMinRentTable[options.index].datEndDate);
                    return (newDate > endDate) ? options.endDate : options.lstMinRentTable[options.index].datEndDate;
                } else {
                    return null;
                }
            }
            
        },
        
        getNextDay : function(prevDate) {
            var newDate = new Date(prevDate);
            newDate.setDate(newDate.getDate() + ((newDate.getTimezoneOffset() > 0) ? 2 : 1));
            newDate = this.getFormattedDate(newDate);
            return newDate;
        },
        
        getFormattedDate : function(date) {
            var year = date.getFullYear();
            var month = (1 + date.getMonth()).toString();
            month = month.length > 1 ? month : '0' + month;
            var day = date.getDate().toString();
            day = day.length > 1 ? day : '0' + day;
            return year + '-' + month + '-' + day;
        },
        
        getStep : function(options) {
            var step = 0;
            var uom = options.growthType.includes("$") ? "$" : "%";
            var oldUom = options.unitOfMeasure;
            
            if (options.calcs.includes("steps") && oldUom != uom) {
                if (options.index == 0) {
                    step = 0;
                } else {
                    if (options.growthType == $A.get("$Label.c.Annual_Growth_Same_Perc_WF")) {
                        if (options.lstMinRentTable.length > 1 && options.lstMinRentTable[1].decRentStep >= 0 && options.lstMinRentTable[0].decAmount > 0) {
                            step = options.lstMinRentTable[1].decRentStep/options.lstMinRentTable[0].decAmount;
                        } else {
                            step = .03;
                        }
                    } else if (options.growthType == $A.get("$Label.c.Annual_Growth_Same_Dollar_WF")) {
                        if (options.lstMinRentTable.length > 1 && options.lstMinRentTable[1].decRentStep > 0) {
                            step = options.lstMinRentTable[1].decAmount - options.lstMinRentTable[0].decAmount;
                        } else {
                            step = 0;
                        }
                    } else if (options.growthType == $A.get("$Label.c.Annual_Growth_Diff_Perc_WF")) {
                        if (options.lstMinRentTable.length > options.index &&
                                options.lstMinRentTable[options.index-1].decAmount > 0 &&
                                options.lstMinRentTable[options.index].decRentStep > 0) {
                            step = options.lstMinRentTable[options.index].decRentStep / options.lstMinRentTable[options.index-1].decAmount;
                        } else {
                            step = 0;
                        }
                    } else if (options.growthType == $A.get("$Label.c.Annual_Growth_Diff_Dollar_WF")) {
                        if (options.lstMinRentTable.length > options.index) {
                            step = options.lstMinRentTable[options.index].decAmount - options.lstMinRentTable[options.index-1].decAmount;
                        } else {
                            step = 0;
                        }
                    } else {
                        step = 0;
                    }
                }
                
            } else {
                if (options.growthType == $A.get("$Label.c.Annual_Growth_Same_Perc_WF") || options.growthType == $A.get("$Label.c.Annual_Growth_Same_Dollar_WF")) {
                    if (options.index > 0 &&
                            options.lstMinRentTable.length > 1 && 
                            options.lstMinRentTable[1].decRentStep >= 0) {
                        step = options.lstMinRentTable[1].decRentStep;
                    } else if (options.index == 1 &&
                            options.growthType == $A.get("$Label.c.Annual_Growth_Same_Perc_WF")) {
                        step = .03;
                    } else {
                        step = 0;
                    }
                } else if (options.index > 0 &&
                            options.lstMinRentTable.length > 1 &&
                            options.calcs.includes("ann") &&
                            options.annIndex == options.index &&
                            options.annValue >= 0) {
                    //only happens with diff $
                    step = options.annValue - options.lstMinRentTable[options.index-1].decAmount;
                } else if (options.lstMinRentTable.length > options.index) {
                    step = options.lstMinRentTable[options.index].decRentStep;
                } else {
                    step = 0;
                }
            }
            return step;
        },
        
        getPsf : function(rent, options) {
            var psf = 0;
            if (options.calcs.includes("psf") && options.index == 0) {
                if (options.lstMinRentTable.length >= 1) {
                    psf = options.lstMinRentTable[0].decAnnualizedRentPSF;
                } else {
                    psf = 0;
                }
            } else if (options.calcs.includes("gla")) {
                psf = options.lstMinRentTable[options.index].decAnnualizedRentPSF;
            } else {
                if (options.gla > 0) {
                    psf = rent / options.gla;
                } else {
                    psf = 0;
                }
            }
            
            return psf;
        },
        
        getRent : function(step, options) {
            var rent = 0;
            if (options.calcs.includes("psf") && options.index == 0) {
                if (options.lstMinRentTable.length >= 1) {
                    rent = this.formatRent(options.lstMinRentTable[0].decAnnualizedRentPSF * options.gla);
                } else {
                    rent = 0;
                }
            } else if (options.calcs.includes("gla")) {
                rent = this.formatRent(options.lstMinRentTable[options.index].decAnnualizedRentPSF * options.gla);
            } else if (options.calcs.includes("ann") && options.index <= options.annIndex) {
                if (options.index < options.annIndex || options.annValue < 0) {
                    rent = options.lstMinRentTable[options.index].decAmount;
                } else {
                    rent = options.annValue;
                }
            } else if (options.index == 0 &&
                        options.lstMinRentTable.length >= 1) {
                //rent = options.lstMinRentTable[0].decAmount;
                rent = options.firstRowRent;
            } else if (options.index > 0){
                var uom = options.growthType.includes("$") ? "$" : "%";
                
                if (uom == "$") {
                    rent = 
                        this.formatRent(parseFloat(options.updatedTable[options.index-1].decAmount) + 
                                step);
                } else {
                    rent = 
                        this.formatRent(parseFloat(options.updatedTable[options.index-1].decAmount) * 
                                (1+step));
                }
            }
            return rent;
        },

        formatRent : function(amt) {
            var annRent;
            if (!isNaN(parseFloat(amt)) && isFinite(amt)) {
                annRent = parseFloat(amt).toFixed(2); 
            }
            return annRent;
        },
        
        getEstimated : function(options) {
            var estimated = false;
            if (options.lstMinRentTable.length > options.index) {
                estimated = options.lstMinRentTable[options.index].boolEstimated;
            }
            return estimated;
        },
        
        getComments : function(options){
            var comments = '';
            if(options.lstMinRentTable.length > options.index) {
                comments = options.lstMinRentTable[options.index].nstComments;
            }
            return comments;
        }
    },
    
    getRentRows : function(component, options, updateValues) {
     
        if (options.increaseInterval != "NA" &&
                options.startDate &&
                options.endDate &&
                (options.startDate <= options.endDate)) {
            
            var endDate = options.endDate;
            do {
                var row = this.rentRow.getNextRow(options);
                var rowEndDate = row.datEndDate;
                var rowStartDate = row.datStartDate;
                var endDateIsValid = this.validateEndDate(rowStartDate, rowEndDate);
                options.updatedTable.push(row);
              //  options.lstMinRentTable.push(row);
                options.index++; 
            }
            while (rowEndDate != endDate && rowEndDate != null && endDateIsValid);           
        } 
        /*options.updatedTable = [];
        options.updatedTable.push(options.lstMinRentTable[0]);
        options.updatedTable.push(options.lstMinRentTable[0]);*/
        var errorCmp = component.find("errorSection");
        if(options.updatedTable.length > 30){
            $A.util.removeClass(errorCmp, 'slds-hide');
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        component.set("v.unitOfMeasure", options.growthType.includes("$") ? "$" : "%");
        component.set("v.lstMinRentTable", options.updatedTable);
        console.log('test exception');
        if(updateValues && options.updatedTable !== undefined && options.updatedTable.length > 0){
            component.set('v.firstYearAnnualizedRentPSF', options.updatedTable[0].decAnnualizedRentPSF);
            component.set('v.firstYearAnnualizedAmount', options.updatedTable[0].decAmount);
        }
        console.log('test exception 1');
    },

    updateEstimated : function(component) {
        var table = component.get("v.lstMinRentTable");
        var count = this.getEstimatedCount(table);
        component.set("v.isEstimated", count > 0);
        component.set("v.allEstimated", count > 0 && count == table.length);        
    },  
    
    getEstimatedCount : function(table) {
        var count = 0;
        for (var i = 0; i < table.length; i++) {
            if (table[i].boolEstimated) count++;
        }
        return count;
    },
    
    calculateFirstYrAmt : function(component, event, helper, isAnnualized) {
        var annualVal = component.get('v.firstYearAnnualizedAmount');
        var gla = component.get('v.gla');
        var psfVal = component.get('v.firstYearAnnualizedRentPSF');
        var errorCmp = component.find('errorId');
        
        if(annualVal === undefined || annualVal === null || annualVal === ''){
            annualVal = 0;
        } else if (!isNaN(annualVal) && annualVal < 0){
            annualVal = 0;
            component.set('v.firstYearAnnualizedAmount', annualVal);
        }
        if(gla === undefined || gla === null || gla === ''){
            gla = 0;
        }
        if(psfVal === undefined || psfVal === null || psfVal === ''){
            psfVal = 0;
        }
        var tableRows = component.get('v.lstMinRentTable');
        
        if(isAnnualized){
            if(gla === 0){
                component.set('v.firstYearAnnualizedRentPSF', 0);
            } else{
                component.set('v.firstYearAnnualizedRentPSF', annualVal/gla);
            }
            if(tableRows !== undefined && tableRows.length > 0){
                tableRows[0].decAmount = annualVal;
                component.set('v.lstMinRentTable', tableRows);
                var options = helper.getOptions(component);
                options.calcs = "ann";
                options.annValue = helper.rentRow.formatRent(annualVal);
                options.annIndex = 0;
                helper.getRentRows(component, options, false);  
            }
        } else{
            component.set('v.firstYearAnnualizedAmount', psfVal * gla);
            if(tableRows !== undefined && tableRows.length > 0){
                tableRows[0].decAnnualizedRentPSF = psfVal;
                component.set('v.lstMinRentTable', tableRows);
                var options = helper.getOptions(component);
                options.calcs = "psf";
                helper.getRentRows(component, options, false);  
            }
        }
    },

    validateEndDate: function(startDate, endDate) {
        var isValid = false;
        if (!$A.util.isUndefinedOrNull(endDate)) {
            var match = endDate.match(/([0-9]{4}[-](0[1-9]|1[0-2])[-]([0-2]{1}[0-9]{1}|3[0-1]{1})|([0-2]{1}[0-9]{1}|3[0-1]{1})[-](0[1-9]|1[0-2])[-][0-9]{4})/);
            if (!$A.util.isUndefinedOrNull(match)) {
                var d1 = new Date(startDate);
                var d2 = new Date(endDate);
                if (d2 > d1) {
                    isValid = true;
                }
            }
        }
        return isValid;     
    },
    validateNonStdCmnts:function(component,event)
    {

        var result = component.get('v.result');
        console.log('result.. of min rent comp',result);
        var covenantTextFieldMap =result.covenantTextFieldMap;
        var lstGrowthRateTable = component.get('v.lstMinRentTable');
        var isError=false;
        var isOptnError =false;
       /* console.log(" component.get(", component.get('v.isMinimumRent'));
        if(component.get('v.MinRentTableDesc')=="Minimum Rent Steps")
        {
          component.set('v.nstCommentsErr',false);   
        }*/
        for(var i=0;i<lstGrowthRateTable.length;i++)
        {
     
            //console.log("inside this method",lstGrowthRateTable[i].nstComments);
            if(!$A.util.isUndefinedOrNull(lstGrowthRateTable[i].nstComments) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Non_Standard_Comments_WF__c']) 
               & lstGrowthRateTable[i].nstComments.length > covenantTextFieldMap['Non_Standard_Comments_WF__c'])
            {
                if(component.get('v.IsOptions')==true)
                {
                    $A.util.removeClass(document.getElementById('nstCommentsOthrErrId'+i),'slds-hide'); 
                    isOptnError=true;
                }else{
                     $A.util.removeClass(document.getElementById('nstCommentsErrId'+i),'slds-hide');
                    isError=true;
                }
            
            }
            else 
            {
                 if(component.get('v.IsOptions')==true)
                {
                    $A.util.addClass(document.getElementById('nstCommentsOthrErrId'+i),'slds-hide');
                    component.set("v.nstCommentsOptnErr",false);   
                }else{
                     $A.util.addClass(document.getElementById('nstCommentsErrId'+i),'slds-hide');
                     component.set("v.nstCommentsErr",false);
                }
                
            }
         }
         if(isError)
        {
              component.set("v.nstCommentsErr",true);
        }
        if(isOptnError)
        {

            component.set("v.nstCommentsOptnErr",true);            
        }
    },
     validateRentStabCmnts:function(component,event)
    {

       var result = component.get('v.result');
        var covenantTextFieldMap =result.covenantTextFieldMap;
        var lstGrowthRateTable = component.get('v.lstMinRentTable');
        var isError=false;
        var isOptnError =false;
       console.log(" component.getoption value", component.get('v.IsOptions'));
     
        //console.log("inside this method",lstGrowthRateTable[i].nstComments);
        if(component.get('v.IsOptions')!=true && !$A.util.isUndefinedOrNull(component.get('v.opportunity.Rent_Stabilization_Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
           && component.get('v.opportunity.Rent_Stabilization_Comments_WF__c').length > covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
        {
                console.log("inside else of minrent");
                $A.util.removeClass(document.getElementById('rentStabError'),'slds-hide');
                component.set("v.rentStabCmntErr",true);
            } else{
                if(component.get('v.IsOptions')!=true)
                {
                $A.util.addClass(document.getElementById('rentStabError'),'slds-hide');
                component.set("v.rentStabCmntErr",false);
                }
            }
        if(component.get('v.IsOptions')==true && !$A.util.isUndefinedOrNull(component.get('v.opportunity.Options_Rent_Stabilization_Comments_WF__c')) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
           && component.get('v.opportunity.Options_Rent_Stabilization_Comments_WF__c').length > covenantTextFieldMap['Rent_Stabilization_Comments_WF__c'])
        {
           
                console.log("inside if op of minrent");
                $A.util.removeClass(document.getElementById('rentStabCommentOthrError'),'slds-hide');
                component.set("v.rentStabOptnCmntErr",true);
            }
        else
        {
            if(component.get('v.IsOptions')==true)
            {
                if(component.get('v.opportunity.OptionsSubjecttoRentStabilization_WF__c')==true){
                console.log("inside if op of minrent else part2");
                console.log("inside if op of minrent else part");
                $A.util.addClass(document.getElementById('rentStabCommentOthrError'),'slds-hide');
                component.set("v.rentStabOptnCmntErr",false);   
            }
            }
        } 
        
    }

})