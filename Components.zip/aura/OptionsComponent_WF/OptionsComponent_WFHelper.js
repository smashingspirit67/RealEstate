({
    getData : function(component) {
        var action = component.get("c.getOptions");
        action.setParams({
            "recordId": component.get("v.opportunity.Id")
        });
        action.setCallback(this, function(response) {
            if(component.isValid()){
                var responseVal = response.getReturnValue();
                component.set("v.renewalOptions", responseVal.options);                
            }
        });
        $A.enqueueAction(action);
    },
    updateRows : function(component, updateDate) {
        console.log('updateRows call count-->', component.get("v.opportunity.Howmanyoptions_WF__c"));
        console.log('updateRows call json-->', component.get("v.renewalOptions"));
        console.log('updateRows call dateOrTerm-->', updateDate);
        var action = component.get("c.getUpdatedOptions");
        action.setParams({
            "count": component.get("v.opportunity.Howmanyoptions_WF__c"),
            "jsonStr": JSON.stringify(component.get("v.renewalOptions")),
            "dateOrTerm": updateDate
        });
        action.setCallback(this, function(response) {
            if(component.isValid()){
                var objOptionsWrapper = response.getReturnValue();
                console.log('Renewal Options Response ---> ', objOptionsWrapper);
                if(objOptionsWrapper !== undefined){
                    component.set("v.renewalOptions", objOptionsWrapper.renewalOptions);
                    
                    component.set('v.opportunity.LeaseOptionsStartDate_WF__c', objOptionsWrapper.renewalStartDate);
                    component.set("v.opportunity.LeaseOptionsEndDate_WF__c" , objOptionsWrapper.renewalExpirationDate);
                    var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
                    fetchPickListTable.fire();
                }
            }
        });
        $A.enqueueAction(action);
    },
    getFormattedDate : function(date) {
            var year = date.getFullYear();
            var month = (1 + date.getMonth()).toString();
            month = month.length > 1 ? month : '0' + month;
            var day = date.getDate().toString();
            day = day.length > 1 ? day : '0' + day;
            return year + '-' + month + '-' + day;
        },
    validateNotifyotherCmnts:function(component,event)
    {
        var result=component.get('v.result');
        var covenantTextFieldMap =result.covenantTextFieldMap;
        //7699
        if(!$A.util.isUndefinedOrNull(component.get('v.renewalOptions'))){
        var renewalOptions=component.get('v.renewalOptions');
        console.log("covenantTextFieldMap.....in notify",covenantTextFieldMap);
        component.set('v.OptionNotifyOtherCmntErr',false);
        for(var i=0;i<renewalOptions.length;i++)
        {
            if(!$A.util.isUndefinedOrNull(renewalOptions[i].strNotifyLLByOtherComments) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['NotifyLLByOtherComment_WF__c'])
               && renewalOptions[i].strNotifyLLByOtherComments.length > covenantTextFieldMap['NotifyLLByOtherComment_WF__c'] )
            {
                component.set('v.OptionNotifyOtherCmntErr',true);
                 $A.util.removeClass(document.getElementById('notifyLLByOtherCommentId'+i),'slds-hide');
            }else{
                 $A.util.addClass(document.getElementById('notifyLLByOtherCommentId'+i),'slds-hide');
            }
        }
        }
    },
    updateRenewalStartDateHelper:function(cmp, eve, helper){
        console.log('in helper');
        var renewalOptions = JSON.parse(JSON.stringify(cmp.get("v.renewalOptions")));
        if(!$A.util.isUndefinedOrNull(renewalOptions) && renewalOptions.length > 0){
            var dealExpiryDate = cmp.get('v.opportunity.ExpirationDate_WF__c');
            if(cmp.get('v.isRenewals')){
                dealExpiryDate = cmp.get('v.opportunity.NewExpiration_WF__c');
            }
            if(!$A.util.isUndefinedOrNull(dealExpiryDate) && dealExpiryDate !== ''){
                var expiryDate = new Date(dealExpiryDate);
                expiryDate.setDate(expiryDate.getUTCDate() + 1);
                expiryDate = helper.getFormattedDate(expiryDate);                
                renewalOptions[0].datStartDate = expiryDate;
                cmp.set('v.renewalOptions', renewalOptions);
                helper.updateRows(cmp,true);    
            }            
        }
    }
})