({
    doInit : function(component, event, helper) {
        component.find('OpportunityOptionsMeasuringPeriod_WF__c').reInit();
    },
    updateTable : function(component, event, helper) {
        helper.updateRows(component, true);
    },
    updateDate : function(component, event, helper) {
        helper.updateRows(component, true);
    },
    updateTerm : function(component, event, helper) {
        helper.updateRows(component, false);
    },
    showSpinner : function (component, event, helper) {
        component.set("v.spinner", true);   
    },
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    updateRenewalStartDate : function (cmp, eve, helper){
        if(cmp.get('v.opportunity.OptionToExtend_WF__c')){
            helper.updateRenewalStartDateHelper(cmp, eve, helper);
        }
    },
    isOptionsCheck : function(cmp, eve, helper){
        console.log('Is Options Checked ----> ', eve);
       cmp.set('v.tenantPerfReqDescError',false);
        cmp.set('v.measuringPeriodCmntErrorId',false);
        var isOptions = cmp.get('v.opportunity.OptionToExtend_WF__c');
        if(!isOptions){
            cmp.set('v.IsOptionsMinimumRent', false);
            cmp.set('v.opportunity.IsOptionsMinimumRent_WF__c', false);
            cmp.set('v.opportunity.OptionsToPercentRent_WF__c', false);
            cmp.set('v.opportunity.OptionsBreakpointType_WF__c', 'Natural');
            cmp.set('v.opportunity.OptionsRentTypeBasis_WF__c', '--None--');
            cmp.set('v.opportunity.OptionsBreakpointStepType_WF__c', '--None--');
            cmp.set('v.opportunity.OptionsPercentRentRate_WF__c', '--None--');
            cmp.set('v.lstOptionsTable', []);
            cmp.set('v.opportunity.OptionsSalesThreshold_WF__c',0.00);
            var dealExpiryDate = cmp.get('v.opportunity.ExpirationDate_WF__c');
            if(!$A.util.isUndefinedOrNull(dealExpiryDate)){
                var renewalWrap ={};
                var renewalOptions = [];
                
                var startDate = new Date(dealExpiryDate);
                startDate.setDate(startDate.getUTCDate() + 1);
                startDate  = helper.getFormattedDate(startDate);
                
                var expiryDate = new Date(startDate);                                
                expiryDate.setFullYear(expiryDate.getFullYear()+1);
                expiryDate.setDate(expiryDate.getDate()-1);
                expiryDate = helper.getFormattedDate(expiryDate);                
                
                renewalWrap.datStartDate = startDate;                
                renewalWrap.datEndDate = expiryDate;
                renewalWrap.intTermInMonths = 12;
                renewalWrap.strNotifyLLBy = '6 Months';
                renewalWrap.strNotifyLLByOtherComments = '';
                renewalOptions.push(renewalWrap);
                cmp.set('v.renewalOptions', renewalOptions);                                
            }  
            cmp.set('v.opportunity.Howmanyoptions_WF__c','1');
            cmp.set('v.IsTenantPerformanceRequirement', false);
            cmp.set('v.opportunity.TenantPerformanceRequirement_WF__c', false);
            cmp.set('v.opportunity.TenantPerformanceRequirementDesc_WF__c', '');
            cmp.set('v.IsOptionsMeasuringPeriod', '12 Months Prior to Tenants Exercise');
            cmp.set('v.opportunity.OptionsMeasuringPeriod_WF__c ', '12 Months Prior to Tenants Exercise');
            cmp.set('v.opportunity.OptionsMeasuringPeriodComments_WF__c', '');            
        } else{
            helper.updateRenewalStartDateHelper(cmp, eve, helper);
        }
        
        /*Change made by sachin. Moved the below lines out of the if condition as the measuring period picklist is not working when the components are created dynamically */
        cmp.find('OpportunityOptionsMeasuringPeriod_WF__c').reInit();
        var fetchPickListTable = $A.get("e.c:fetchPicklistTable");
        fetchPickListTable.fire();
        
    },
    IsTenantPerformance : function(cmp, eve){
      
            cmp.set('v.tenantPerfReqDescError',false);
        if(cmp.get('v.IsTenantPerformanceRequirement') == false){
            cmp.set('v.opportunity.TenantPerformanceRequirement_WF__c', false);
            cmp.set('v.opportunity.TenantPerformanceRequirementDesc_WF__c', '');
        }else{
            cmp.set('v.opportunity.TenantPerformanceRequirement_WF__c', true);
        }
    },
    IsOptionsMeasuringPeriod : function(cmp,eve){
        cmp.set('v.opportunity.OptionsMeasuringPeriod_WF__c',  cmp.get('v.IsOptionsMeasuringPeriod'));
        if(cmp.get('v.IsOptionsMeasuringPeriod') !== 'Other'){            
            cmp.set('v.opportunity.OptionsMeasuringPeriodComments_WF__c', '');
        }        
    },
    clearComments : function(cmp, eve){
        var renewalOptions = cmp.get('v.renewalOptions');
        if(!$A.util.isUndefinedOrNull(renewalOptions)){
            if(renewalOptions.length > 0){
                for(var i = 0 ; i < renewalOptions.length; i++){
                    if(renewalOptions[i].strNotifyLLBy !== 'Other'){
                        renewalOptions[i].strNotifyLLByOtherComments = '';
                    }
                }
                cmp.set('v.renewalOptions', renewalOptions);
            }
        }
    },
    changeMeasuringPeriod : function(cmp,eve)
    {
        console.log('called change measuring period',cmp.get('v.opportunity.OptionsMeasuringPeriodComments_WF__c'));
       cmp.set('v.opportunity.OptionsMeasuringPeriodComments_WF__c','');
       cmp.set('v.measuringPeriodCmntErrorId',false);
    },
    validateNotifyotherCmnts:function(cmp,eve,helper)
    {
        helper.validateNotifyotherCmnts(cmp,eve);
    }
})