({
    addLetterOfCredit : function(component,event,helper){ 
        if(component.get('v.noOfletterOfCredit')<5){
            var lstLOC = JSON.parse(JSON.stringify(component.get('v.lstLOC')));  
            component.set('v.noOfletterOfCredit',component.get('v.noOfletterOfCredit')+1);
 			var objLOC = {};    
            objLOC.count = component.get('v.noOfletterOfCredit');
            objLOC.BankAddress = ''; 
            objLOC.IdentifyBank = '';
            objLOC.LOCComments =''; 
            if(component.get('v.isAmendment')){
	            objLOC.CreditLetterAmount = 0;
	            objLOC.holdLOCFor = 'Entire term incl. any options';
	            objLOC.otherComments = '';
            } else{
            	objLOC.LetterofCredit='';
            	objLOC.years = component.get("v.leaseYears");
            	objLOC.months = component.get("v.leaseMonths");
            }
            lstLOC.push(objLOC);
            component.set('v.lstLOC', lstLOC);
        }
    },
    deleteLetterOfCredit : function(component,event){ 
        if(component.get('v.noOfletterOfCredit')>0){
            var letterOfCredit = component.get("v.lstLOC");
            var toDeleteLOCS =  letterOfCredit.pop();
            component.set("v.lstLOC", letterOfCredit);
            var locsToDelete = JSON.parse(JSON.stringify(component.get("v.locsToDelete")));               
            toDeleteLOCS.count = component.get('v.noOfletterOfCredit');
            
            toDeleteLOCS.BankAddress = ''; 
            
            toDeleteLOCS.IdentifyBank = '';
            toDeleteLOCS.LOCComments =''; 
            if(component.get('v.isAmendment')){
	            toDeleteLOCS.CreditLetterAmount = 0;
	            toDeleteLOCS.holdLOCFor = '';
	            toDeleteLOCS.otherComments = '';
            } else{
            	toDeleteLOCS.years = 0;
            	toDeleteLOCS.months = 0;
            	toDeleteLOCS.LetterofCredit='';
            }
            
            locsToDelete.push(toDeleteLOCS);
            component.set('v.locsToDelete', locsToDelete);
            component.set("v.lstLOC", letterOfCredit);
            component.set('v.noOfletterOfCredit',component.get('v.noOfletterOfCredit')-1);
    	}
    },
    displayLOC : function (component, event){
        var result = component.get('v.result');
        var covenantTextFieldMap = result.covenantTextFieldMap;
        console.log('result loc',covenantTextFieldMap);
    	var validate = event.getParam('showErrors');
    	var showErrors = false;
        var letterOfCredit = component.get('v.lstLOC');
        var toDeleteLOCS =  component.get('v.locsToDelete');
        var opportunity = component.get('v.opportunity');
        for(var j = 0; j < toDeleteLOCS.length ; j++){
            var letterCredit = 'LetterofCredit_'+toDeleteLOCS[j].count+'_WF__c';  
            var bankAddress  = 'BankAddress_'+toDeleteLOCS[j].count+'_WF__c';                
            var hoc 		 = 'HoldLOCFor_'+toDeleteLOCS[j].count+'_WF__c';
            var identifyBank = 'IdentifyBank_'+toDeleteLOCS[j].count+'_WF__c';
            var locComments = 'LOCComments_'+ toDeleteLOCS[j].count+'_WF__c';
            
            var cdAmt = 'Credit_Letter_Amount_'+toDeleteLOCS[j].count+'_WF__c';  
            var hocAmd		 = 'Hold_LOC_For_'+toDeleteLOCS[j].count+'_Amendment_WF__c';
            var otherComments = 'Other_'+ toDeleteLOCS[j].count + '_WF__c';
            			            
            opportunity[bankAddress] = toDeleteLOCS[j].BankAddress;
            opportunity[identifyBank] = toDeleteLOCS[j].IdentifyBank;
            opportunity[locComments] = toDeleteLOCS[j].LOCComments;
            
            if(component.get('v.isAmendment')){
            	opportunity[cdAmt] = toDeleteLOCS[j].CreditLetterAmount;
            	opportunity[otherComments] = toDeleteLOCS[j].otherComments;
            	opportunity[hocAmd] = toDeleteLOCS[j].holdLOCFor;
            } else{
            	opportunity[letterCredit] = toDeleteLOCS[j].LetterofCredit;
            	opportunity[hoc] = toDeleteLOCS[j].years;
            }
            
        }
        for(var i = 0 ; i < letterOfCredit.length; i++){                         
            var letterCredit = 'LetterofCredit_'+letterOfCredit[i].count+'_WF__c';  
            var bankAddress  = 'BankAddress_'+letterOfCredit[i].count+'_WF__c';                
            var hoc 		 = 'HoldLOCFor_'+letterOfCredit[i].count+'_WF__c';
            var identifyBank = 'IdentifyBank_'+letterOfCredit[i].count+'_WF__c';
            var locComments = 'LOCComments_'+ letterOfCredit[i].count+'_WF__c';
            
            var cdAmt = 'Credit_Letter_Amount_'+letterOfCredit[i].count+'_WF__c';  
            var hocAmd		 = 'Hold_LOC_For_'+letterOfCredit[i].count+'_Amendment_WF__c';
            var otherComments = 'Other_'+ letterOfCredit[i].count + '_WF__c';
            
             /*GDM-7254*/
                console.log("Validating LOC");
                if(!$A.util.isUndefinedOrNull(letterOfCredit[i].BankAddress) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['BankAddress_'+letterOfCredit[i].count+'_WF__c'])
                   && letterOfCredit[i].BankAddress.length > covenantTextFieldMap['BankAddress_'+letterOfCredit[i].count+'_WF__c'])
                {
                    showErrors = true;
                    $A.util.removeClass(document.getElementById('bankAddress2'+i), 'slds-hide');
                    opportunity[bankAddress] = '';
                }
                else
                {
                    $A.util.addClass(document.getElementById('bankAddress2'+i), 'slds-hide');
                    opportunity[bankAddress] = letterOfCredit[i].BankAddress;
                }
            	/*GDM-7332*/
            	if(!$A.util.isUndefinedOrNull(letterOfCredit[i].IdentifyBank) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['IdentifyBank_'+letterOfCredit[i].count+'_WF__c'])
                   && letterOfCredit[i].IdentifyBank.length > covenantTextFieldMap['IdentifyBank_'+letterOfCredit[i].count+'_WF__c'])
                {
                    showErrors = true;
                    $A.util.removeClass(document.getElementById('IdentifyBankError'+i), 'slds-hide');
                    opportunity[identifyBank] = '';
                }
                else
                {
                    $A.util.addClass(document.getElementById('IdentifyBankError'+i), 'slds-hide');
                    opportunity[identifyBank] = letterOfCredit[i].IdentifyBank;
                }
				
            	if(!$A.util.isUndefinedOrNull(letterOfCredit[i].LOCComments) && !$A.util.isUndefinedOrNull(covenantTextFieldMap['LOCComments_'+letterOfCredit[i].count+'_WF__c'])
                   && letterOfCredit[i].LOCComments.length > covenantTextFieldMap['LOCComments_'+letterOfCredit[i].count+'_WF__c'])
                {
                    showErrors = true;
                    $A.util.removeClass(document.getElementById('LOCCommentsError'+i), 'slds-hide');
                    opportunity[locComments] = '';
                }
                else
                {
                    $A.util.addClass(document.getElementById('LOCCommentsError'+i), 'slds-hide');
                    opportunity[locComments] = letterOfCredit[i].LOCComments;
                }
            /* GDM-4789 changes */
            if(validate){
                if(component.get('v.isAmendment')){
                    if( letterOfCredit[i].CreditLetterAmount == '' || letterOfCredit[i].CreditLetterAmount == null  || letterOfCredit[i].CreditLetterAmount == undefined || letterOfCredit[i].CreditLetterAmount <= 0){
                        showErrors = true;
                        $A.util.removeClass(document.getElementById('locAmount'+i), 'slds-hide');
                    }else{
                        $A.util.addClass(document.getElementById('locAmount'+i), 'slds-hide');
                    }
                } else{
                    if( letterOfCredit[i].LetterofCredit == '' || letterOfCredit[i].LetterofCredit == null  || letterOfCredit[i].LetterofCredit == undefined || letterOfCredit[i].LetterofCredit <= 0){
                        showErrors = true;
                        $A.util.removeClass(document.getElementById('locAmount'+i), 'slds-hide');
                    }else{
                        $A.util.addClass(document.getElementById('locAmount'+i), 'slds-hide');
                    }
                }
              
            }
             
            component.set('v.showErrors', showErrors);
           //opportunity[bankAddress] = letterOfCredit[i].BankAddress;
            //opportunity[identifyBank] = letterOfCredit[i].IdentifyBank;
            //opportunity[locComments] = letterOfCredit[i].LOCComments;    
            
            if(component.get('v.isAmendment')){
            	opportunity[cdAmt] = letterOfCredit[i].CreditLetterAmount;
            	opportunity[otherComments] = letterOfCredit[i].otherComments;
            	opportunity[hocAmd] = letterOfCredit[i].holdLOCFor;
            } else{
            	opportunity[letterCredit] = letterOfCredit[i].LetterofCredit;
            	opportunity[hoc] = Number(letterOfCredit[i].years) * 12 + Number(letterOfCredit[i].months);
                opportunity[hocAmd] = letterOfCredit[i].holdLOCFor;
            }        
        }
        
        component.set('v.opportunity', opportunity);
    }
})