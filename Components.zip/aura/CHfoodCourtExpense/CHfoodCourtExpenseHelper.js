({
	setPicklistValues : function(component, result){
        var picklistMap = result.picklistMap;
        var objNames = 'Charges_WF__c';
        var fieldNames = result.FieldList;
        for(var eachField in fieldNames){
            if(!$A.util.isUndefinedOrNull(component.find(objNames + fieldNames[eachField]))){
                var optionVals = picklistMap[objNames + fieldNames[eachField]];
                if(!$A.util.isUndefinedOrNull(optionVals)){
                    component.find(objNames + fieldNames[eachField]).setLocalValues(optionVals);
                }
            }
        }
    }
})