({
    doInit : function(component, event, helper) {
        var charges = component.get('v.Charges');
        for(var item in charges){
            if(charges[item].RecordTypeId==component.get('v.ChargesRecordType')['Insurance']){
                component.set('v.insurance',charges[item]);
            }
        }
        console.log(component.get('v.insurance'));
    },
    changeCharges : function(component,event){
        var original = isNaN(parseFloat(event.getSource().get('v.value'))) ? 0 : parseFloat(event.getSource().get('v.value'));  
        //For Main     
        var standard = parseFloat(component.find('standard'+event.getSource().get('v.name')).get('v.value'));
        var dollar = (original-standard).toFixed(2);
        var percentage= parseFloat((dollar)/(standard)*100).toFixed(2);
        if(!isNaN(dollar)){
            component.find('varDollar'+event.getSource().get('v.name')).set('v.value','$ '+dollar);
        }
        if(isFinite(percentage)&&!isNaN(percentage)){
            component.find('varPer'+event.getSource().get('v.name')).set('v.value',percentage+' %');
        }
    },
    calculateVariance : function(component,event){
        var originalAmount = component.get('v.insurance.Exp_Initial_Annual_Amount_WF__c');
        var standardAmount = component.get('v.insurance.Standard_Exp_Initial_Annual_Amount_WF__c');
        var varianceAnnualAmount = (originalAmount-standardAmount).toFixed(2);
        var varianceAnnualPercentage = (varianceAnnualAmount/standardAmount*100).toFixed(2);
        if(!isNaN(varianceAnnualAmount)){
            component.set('v.insurance.Exp_Initial_Annual_Amount_Var_Amo_WF__c','$'+varianceAnnualAmount);
        }
        if(isFinite(varianceAnnualPercentage)&&!isNaN(varianceAnnualPercentage)){
            component.set('v.insurance.Exp_Initial_Annual_Amount_Var_Per_WF__c',varianceAnnualPercentage+'%');
        }else{
            component.set('v.insurance.Exp_Initial_Annual_Amount_Var_Per_WF__c','100%');
        }
    },
    changeChargeBool : function(component,event){
        if(!component.get('v.insurance.Charge_Type_Oth_WF__c')){
            component.set('v.insurance.Exp_Initial_Annual_Amount_WF__c',0);
            component.set('v.insurance.Exp_Initial_Annual_Amount_Var_Amo_WF__c','');
            component.set('v.insurance.Exp_Initial_Annual_Amount_Var_Per_WF__c','');
        }
    }
})