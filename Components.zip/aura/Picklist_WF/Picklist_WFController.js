({
    init: function(component, event, helper) {
        if(!component.get('v.disabled')){
            var useLocalOptions = false;
            if(!$A.util.isEmpty(component.get('v.localOptions'))){
                useLocalOptions = true;
            }
            console.log('***picklist', useLocalOptions);
            if(useLocalOptions){
				helper.setOptions(component, component.get('v.localOptions'));
			} else{
                console.log('I am here before variable declaration action');
				var action = component.get("c.fetchPicklist");
				console.log('I am here after variable declaration action' , action);            
                action.setParams({
					"objectName" : component.get('v.objectName'),
					"fieldName" : component.get('v.fieldName'),
					"selectedItems" : component.get('v.selectedItems')
				});
				action.setCallback(this, function(response) {
					var state = response.getState();
					if (state === "SUCCESS") {
						helper.setOptions(component, response.getReturnValue());
					}
					else if (state === "INCOMPLETE") {
						var errors = response.getError();
						if (errors) {
							if (errors[0] && errors[0].message) {
								console.log("Error message: " + errors[0].message);
							}
						} else {
							console.log("Unknown error");
						}
					}
					else if (state === "ERROR") {
						var errors = response.getError();
						if (errors) {
							if (errors[0] && errors[0].message) {
								console.log("Error message: " + errors[0].message);
                                							}
						} else {
							console.log("Unknown error");
						}
					}
				});
                console.log('I am reaching here successfully');
				$A.enqueueAction(action);
                console.log('I am reaching here successfully 2');
			}
        }
        else{
            if(component.get('v.multiple')){
                var mulSelectedvalue = component.get('v.selectedItems');
                 console.log('I am reaching here successfully 3' + mulSelectedvalue);
                if(!$A.util.isUndefinedOrNull(mulSelectedvalue)){
                    component.set('v.multipleSelectedItems',mulSelectedvalue.split(";").join("\n"));
                	 console.log('I am reaching here successfully 4' );
                }
            }
        }
    },
    
    handleClick: function(component, event, helper) {
        var mainDiv = component.find('main-div');
        $A.util.addClass(mainDiv, 'slds-is-open');
    },
    
    handleSelection: function(component, event, helper) {
        var item = event.currentTarget;
        if (item && item.dataset) {
            var value = item.dataset.value;
            var selected = item.dataset.selected;
            
            var options = component.get("v.options_");
            
            if (component.get('v.multiple')) {
                options.forEach(function(element) {
                    if (element.value == value) {
                        element.selected = selected == "true" ? false : true;
                    }
                });
            } else {
                options.forEach(function(element) {
                    if (element.value == value) {
                        element.selected = selected == "true" ? false : true;
                    } else {
                        element.selected = false;
                    }
                });
                var mainDiv = component.find('main-div');
                $A.util.removeClass(mainDiv, 'slds-is-open');
            }
               
            component.set("v.options_", options);
            var values = helper.getSelectedValues(component);
            var labels = helper.getSelectedLabels(component);
            
            helper.setInfoText(component,labels);
            var tempValue='';
            for(var item in values){
                tempValue=tempValue+values[item]+';';
            }
            tempValue = tempValue.replace(/[;]$/,'');
            component.set('v.selectedItems',tempValue);
            var name = component.get('v.name') != undefined ? component.get('v.name') : 'name';
            var compEvent = component.getEvent("onChange");
            compEvent.setParams({ 
                "values": values ,
                "name" : name
            });
            compEvent.fire();
        }
    },
    
    handleMouseLeave: function(component, event, helper) {
        component.set("v.dropdownOver",false);
        var mainDiv = component.find('main-div');
        $A.util.removeClass(mainDiv, 'slds-is-open');
    },
    
    handleMouseEnter: function(component, event, helper) {
        component.set("v.dropdownOver",true);
    },
    
    handleMouseOutButton: function(component, event, helper) {
        window.setTimeout(
            $A.getCallback(function() {
                if (component.isValid()) {
                    if (component.get("v.dropdownOver")) {
                        return;
                    }
                    var mainDiv = component.find('main-div');
                    $A.util.removeClass(mainDiv, 'slds-is-open');
                }
            }), 200
        );
    },
    
    setLocalValues: function(component, event, helper){
        var params = event.getParam('arguments');
        if (params) {
        	component.set('v.localOptions', params.optionVals);
            helper.setOptions(component, component.get('v.localOptions'));
        }
    }
})