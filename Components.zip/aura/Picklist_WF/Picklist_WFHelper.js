({
    setInfoText: function(component, values) {
        
        if (values.length == 0) {
            component.set("v.infoText", "Select an option...");
        }
        if (values.length == 1) {
            component.set("v.infoText", values[0]);
        }
        else if (values.length > 1) {
            component.set("v.infoText", values.length + " options selected");
        }
    },
    
    getSelectedValues: function(component){
        var options = component.get("v.options_");
        var values = [];
        options.forEach(function(element) {
            if (element.selected) {
                values.push(element.value);
            }
        });
        return values;
    },
    
    getSelectedLabels: function(component){
        var options = component.get("v.options_");
        var labels = [];
        options.forEach(function(element) {
            if (element.selected) {
                labels.push(element.label);
            }
        });
        return labels;
    },
    
    setOptions: function(component, options){
        component.set('v.options', options);
        var options = component.get("v.options"); 
        var selectedItems = component.get("v.selectedItems");
        if (typeof selectedItems != 'undefined' && selectedItems!=null){
            var selectedItemsSplit = selectedItems.split(';');
            options.forEach(function(element) {
                if(selectedItemsSplit.includes(element.value)){
                    element.selected = true;
                } else{
                    element.selected = false;
                }
            });
        }
        component.set("v.options_", options);
        var values = this.getSelectedValues(component);
        var labels = this.getSelectedLabels(component);
        
        this.setInfoText(component,labels);
        var tempValue='';
        for(var item in values){
            tempValue=tempValue+values[item]+';';
        }
        tempValue = tempValue.replace(/[;]$/,'');
        component.set('v.selectedItems',tempValue);
    }
})