({
    doInit : function(component, event, helper) {
        
        var covenant = component.get('v.Covenant');
        var kickouts = [];
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Kickout']){
                kickouts.push(covenant[item]);
                component.set('v.noOfKickouts',component.get('v.noOfKickouts')+1);
            }
        }
        if(kickouts.length > 0 && component.get('v.parentObj') == 'Opportunity'){
            component.set('v.boolKickout',true);
        }else{
            component.set('v.boolKickout',false);
        }
        component.set('v.lstKickouts',kickouts);
    },
    addKickout : function(component,event){ 
        if(component.get('v.noOfKickouts')<5){
            component.set('v.noOfKickouts',component.get('v.noOfKickouts')+1);
            var objKickout = {};    
            var lstKickouts = component.get('v.lstKickouts');
            objKickout.Id = null;            
            objKickout.TypeofKickout_WF__c = 'Mutual';
            objKickout.MeasuringPeriod_WF__c = '25-36';
            objKickout.OtherDescription_WF__c = '';
            objKickout.LandlordSalesThreshold_WF__c = null;
            objKickout.TenantSalesThreshold_WF__c = null;
            objKickout.NoticePerioddays_WF__c = null;
            objKickout.TerminationEffectivefromNoticeDate_WF__c = null;
            objKickout.IfTenantkickspaybackTACommiss_WF__c = false;
            objKickout.Unamortizedpaybacktype_WF__c = '$';
            objKickout.Unamortizedpaybackamount_WF__c = null;
            objKickout.Paybackunamoritzedleaseholdimprovemen_WF__c = false;
            objKickout.Unamoritzedleaseholdimprovementtype_WF__c = '$';
            objKickout.Unamoritzedleaseholdimprovementamount_WF__c  = null;
            objKickout.Unamoritzedleaseholdimprovementper_WF__c = null;
            objKickout.Unamortizedpaybackpercent_WF__c  = null;
            
            objKickout.RecordTypeId = component.get('v.CovenantRecordType')['Kickout'];
            
            component.set('v.lstKickouts', lstKickouts);
            var action = component.get('c.getExpiryDate');
            action.setParams({
                'strRcd' : component.get('v.RCDDate'),
                'kickouts' : '['+JSON.stringify(objKickout)+']'
            });
            action.setCallback(this, function(response){
                var result = response.getReturnValue();
                console.log(result);
                
                var covenant = component.get('v.Covenant');
                if(result!=null){
                    objKickout.StartDate_WF__c = result[0].StartDate_WF__c;
                    objKickout.EndDate_WF__c = result[0].EndDate_WF__c;
                }
                lstKickouts.push(objKickout);
                covenant.push(objKickout);
                component.set('v.lstKickouts',lstKickouts);
                component.set('v.Covenant',covenant);
                
                console.log('sss',component.get('v.lstKickouts'));
                var fetchPickList = $A.get("e.c:fetchPicklist");
                fetchPickList.fire();
            });
            $A.enqueueAction(action);
            
        }
    },
    deleteKickout : function(component,event){ 
        if(component.get('v.noOfKickouts')>0){
            var lstKickouts = component.get("v.lstKickouts");
            var covenant = component.get("v.Covenant");
            covenant.pop();
            var kickoutDelete = lstKickouts.pop();
            if(!$A.util.isUndefinedOrNull(kickoutDelete.Id)){
                var kickoutDeleteList = component.get('v.kickoutToDelete');
                kickoutDeleteList.push(kickoutDelete.Id)
                component.set('v.kickoutToDelete',kickoutDeleteList);
            }
            component.set("v.lstKickouts", lstKickouts);
            component.set("v.Covenant", covenant);
            component.set('v.noOfKickouts',component.get('v.noOfKickouts')-1);
        }
    },
    calculateStartAndEndDate : function(component, event, helper){        
        var action = component.get('c.getExpiryDate');
        action.setParams({
            'strRcd' : component.get('v.RCDDate'),
            'kickouts' : JSON.stringify(component.get('v.lstKickouts'))
        });
        action.setCallback(this, function(response){
            var result = response.getReturnValue();
              if(!$A.util.isUndefinedOrNull(result))
            {
                for(var i=0; i<component.get('v.lstKickouts').length;i++){
                    component.set('v.lstKickouts['+i+'].StartDate_WF__c',result[i].StartDate_WF__c);
                    component.set('v.lstKickouts['+i+'].EndDate_WF__c',result[i].EndDate_WF__c);
                }
            }
        });
        $A.enqueueAction(action);               
    },
    validateKickOuts : function(component, event, helper){        
        var kickouts = component.get('v.lstKickouts');
        console.log('kickout',kickouts);
        var kickoutsValidationBool=false;
        //Kickouts section fields        
        if(kickouts.length >0 && component.get('v.boolKickout')==true){
            for(var i=0; i<kickouts.length; i++){
                //check for Type Of Kickout not empty
                if(kickouts[i].TypeofKickout_WF__c == '' || kickouts[i].TypeofKickout_WF__c == null || kickouts[i].TypeofKickout_WF__c == '--None--'){
                    $A.util.removeClass(document.getElementById('kickoutTypeErrorId'+i), 'slds-hide');
                    kickoutsValidationBool = true;
                }else{
                    $A.util.addClass(document.getElementById('kickoutTypeErrorId'+i), 'slds-hide');
                }
                //check for End Date not empty
                if(kickouts[i].EndDate_WF__c == '' || kickouts[i].EndDate_WF__c == null){
                    $A.util.removeClass(document.getElementById('endDateErrorId'+i), 'slds-hide');
                    kickoutsValidationBool = true;
                }else{
                    $A.util.addClass(document.getElementById('endDateErrorId'+i), 'slds-hide');
                }
                //check for Landlord Sales Threshold not empty
                if(kickouts[i].TypeofKickout_WF__c=='Mutual' || kickouts[i].TypeofKickout_WF__c =='Landlord'){
                    if(kickouts[i].LandlordSalesThreshold_WF__c == '' || kickouts[i].LandlordSalesThreshold_WF__c == null){
                    $A.util.removeClass(document.getElementById('llThresholdErrorId'+i), 'slds-hide');
                        kickoutsValidationBool = true;
                    }else{
                    $A.util.addClass(document.getElementById('llThresholdErrorId'+i), 'slds-hide');
                    }
                }
                //check for Notice Period not empty
                if(kickouts[i].NoticePerioddays_WF__c == '' || kickouts[i].NoticePerioddays_WF__c == null){
                    $A.util.removeClass(document.getElementById('noticePeriodErrorId'+i), 'slds-hide');
                    kickoutsValidationBool = true;
                }else{
                    $A.util.addClass(document.getElementById('noticePeriodErrorId'+i), 'slds-hide');
                }
                //check for Tenant Sales Threshold not empty
                if(kickouts[i].TypeofKickout_WF__c=='Mutual' || kickouts[i].TypeofKickout_WF__c =='Tenant'){
                    if(kickouts[i].TenantSalesThreshold_WF__c == '' || kickouts[i].TenantSalesThreshold_WF__c == null){
                        $A.util.removeClass(document.getElementById('tsThresholdErrorId'+i), 'slds-hide');
                        kickoutsValidationBool = true;
                    }else{
                        $A.util.addClass(document.getElementById('tsThresholdErrorId'+i), 'slds-hide');
                    }
                }
                //check for Termination Effective from Notice Date not empty
                if(kickouts[i].TerminationEffectivefromNoticeDate_WF__c == '' || kickouts[i].TerminationEffectivefromNoticeDate_WF__c == null){
                    $A.util.removeClass(document.getElementById('terminationEffectiveErrorId'+i), 'slds-hide');
                    kickoutsValidationBool = true;
                }else{
                    $A.util.addClass(document.getElementById('terminationEffectiveErrorId'+i), 'slds-hide');
                }
                //check for Unamortized payback amount not empty
                if((kickouts[i].IfTenantkickspaybackTACommiss_WF__c) && 
                    (
                        (kickouts[i].Unamortizedpaybacktype_WF__c == '' || kickouts[i].Unamortizedpaybacktype_WF__c == null)
                        ||
                        (kickouts[i].Unamortizedpaybacktype_WF__c == '$' &&
                        (kickouts[i].Unamortizedpaybackamount_WF__c == '' || kickouts[i].Unamortizedpaybackamount_WF__c == null)
                        )
                        ||
                        (kickouts[i].Unamortizedpaybacktype_WF__c == '%' &&
                        (kickouts[i].Unamortizedpaybackpercent_WF__c == '' || kickouts[i].Unamortizedpaybackpercent_WF__c == null)
                        )
                    )
                ){
                    $A.util.removeClass(document.getElementById('paybackAmountErrorId'+i), 'slds-hide');
                    kickoutsValidationBool = true;
                }else{
                    $A.util.addClass(document.getElementById('paybackAmountErrorId'+i), 'slds-hide');
                }
            }
        }        
        console.log('kickoutsValidationBool',kickoutsValidationBool);
        component.set("v.kickoutError", kickoutsValidationBool);
    },
    changeKickouts : function(component,event){
        console.log('skdkhjdhj');
        var noOfkickouts = component.get('v.noOfKickouts');
        var lstKickout = component.get('v.lstKickouts');
        var lstToDelete = []
        for(var i=0 ;i<noOfkickouts; i++){
            lstKickout.pop();                      
        }   
        var action = component.get('c.deleteKickoutAll');
        action.setParams({
            "OppId" : component.get('v.recordId')
        });
        console.log(action.getParams());
        action.setCallback(this, function(response){
            var result = response.getReturnValue();  
            console.log('*************',result);
            if(result && response.getState() == 'SUCCESS' && component.isValid()){
                component.set('v.lstKickouts',lstKickout);
                component.set('v.noOfKickouts',0);
                var covenant = component.get('v.Covenant');
                var newCovenent = [];
                for(var item in covenant){
                    if(covenant[item].RecordTypeId!=component.get('v.CovenantRecordType')['Kickout']){
                        newCovenent.push(covenant[item]);
                    }
                }
                component.set('v.Covenant',newCovenent);
            }
        });
        $A.enqueueAction(action);
    },
    validateForNegativeValues:function(component, eve, helper){
         var kickouts = component.get('v.lstKickouts');
        console.log('checking kickouts');
        for(var iter=0; iter<kickouts.length;iter++){
            console.log('checking kickouts for loop' , kickouts[iter].Unamortizedpaybackamount_WF__c);
            if(kickouts[iter].Unamortizedpaybackpercent_WF__c != null && kickouts[iter].Unamortizedpaybackpercent_WF__c != '' && kickouts[iter].Unamortizedpaybackpercent_WF__c < 0 ){
                $A.util.removeClass(document.getElementById('UnamortizedpaybackamountErrorId' + iter), 'slds-hide');
            }
            else{
                $A.util.addClass(document.getElementById('UnamortizedpaybackamountErrorId' + iter), 'slds-hide');
            }
            if(kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c !=null && kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c!= '' && kickouts[iter].Unamoritzedleaseholdimprovementper_WF__c < 0 ){
                $A.util.removeClass(document.getElementById('LeaseholdimprovementErrorId'+iter), 'slds-hide');
            }
            else{
                $A.util.addClass(document.getElementById('LeaseholdimprovementErrorId'+iter), 'slds-hide');
            }
        }
    },
    changeLeaseholdImprovement : function(component, eve, helper){   
        var kickouts = component.get('v.lstKickouts');
        for(var item in kickouts){
            if(kickouts[item].Paybackunamoritzedleaseholdimprovemen_WF__c==false){
                kickouts[item].Unamoritzedleaseholdimprovementamount_WF__c = 0;
                kickouts[item].Unamoritzedleaseholdimprovementper_WF__c = 0;
            }
        }
        component.set('v.lstKickouts',kickouts);
    },
    changePaybackCommiss : function(component, eve, helper){
        console.log('in pay commision');
        var kickouts = component.get('v.lstKickouts');
        for(var item in kickouts){
            console.log('in pay loop');
            if(kickouts[item].IfTenantkickspaybackTACommiss_WF__c==false){
                kickouts[item].Unamortizedpaybackamount_WF__c = 0;
                kickouts[item].Unamortizedpaybackpercent_WF__c = 0;
            }
        }
        component.set('v.lstKickouts',kickouts);
    },
    changeLeaseholdImprovementPicklist : function(component, eve, helper){  
        var kickouts = component.get('v.lstKickouts');
        for(var item in kickouts){
            if(kickouts[item].Unamoritzedleaseholdimprovementtype_WF__c == '%'){
                kickouts[item].Unamoritzedleaseholdimprovementamount_WF__c = 0;                
            }
            else if(kickouts[item].Unamoritzedleaseholdimprovementtype_WF__c == '$'){
                kickouts[item].Unamoritzedleaseholdimprovementper_WF__c = 0;
            }
            else{
                kickouts[item].Unamoritzedleaseholdimprovementamount_WF__c = 0;   
                kickouts[item].Unamoritzedleaseholdimprovementper_WF__c = 0;              
            }
        }
        component.set('v.lstKickouts',kickouts);
    },
    changePaybackCommissPicklist : function(component, eve, helper){
        var kickouts = component.get('v.lstKickouts');
        for(var item in kickouts){
            if(kickouts[item].Unamortizedpaybacktype_WF__c == '%'){
                kickouts[item].Unamortizedpaybackamount_WF__c = 0;                
            }
            else if(kickouts[item].Unamortizedpaybacktype_WF__c == '$'){
                kickouts[item].Unamortizedpaybackpercent_WF__c = 0;
            }
            else{
                kickouts[item].Unamortizedpaybackamount_WF__c = 0;   
                kickouts[item].Unamortizedpaybackpercent_WF__c = 0;              
            }
        }
        component.set('v.lstKickouts',kickouts);
    }
})