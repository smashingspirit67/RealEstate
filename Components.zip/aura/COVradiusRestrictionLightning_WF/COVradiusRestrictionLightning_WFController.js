({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        console.log('radius',covenant);
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Radius Restriction']){
                component.set('v.radiusRestriction',covenant[item]);
                isPresent = true;
            }
        }
        if(!isPresent){
            var radiusRestriction = {};
            radiusRestriction.RadiusRestriction_WF__c=true;
            radiusRestriction.of_WF__c = 'Miles';
            radiusRestriction.RR_Other_WF__c = '';
            radiusRestriction.RadiusDistance_WF__c = 10;
            radiusRestriction.Duration_WF__c = 'Entire Term incl. any Option(s)';
            radiusRestriction.DurationYears_WF__c = '0';
            radiusRestriction.Duration_Months__c = '0';
            radiusRestriction.RadiusPenalty_WF__c = 'Incl. GS From Competing Location (standard);Any Kickout(s) Removed';
            radiusRestriction.RadiusAppliesTo_WF__c = '';
            radiusRestriction.RecordTypeId =component.get('v.CovenantRecordType')['Radius Restriction'];
            component.set('v.radiusRestriction',radiusRestriction);
            covenant.push(component.get('v.radiusRestriction'));
            component.set('v.Covenant',covenant);
        }
        var arrLeaseTermYearsOptions = [];
        var arrLeaseTermMonthsOptions = [];
        var action;
        for(var i=0;i<=25;i++){
            arrLeaseTermYearsOptions.push({ value: String(i), label: String(i) });
        }
        for(var i=0;i<12;i++){
            arrLeaseTermMonthsOptions.push({ value: String(i), label: String(i) });
        }
        component.set('v.arrLeaseTermYearsOptions',arrLeaseTermYearsOptions);
        component.set('v.arrLeaseTermMonthsOptions',arrLeaseTermMonthsOptions);
        helper.setPicklistValues(component,component.get('v.result'));
	},
    changeRadiusRestriction : function(component, event, helper) {
        component.set('v.radiusRestriction.of_WF__c','Miles');
        if(!$A.util.isUndefinedOrNull(component.find('noOf'))){
            component.find('noOf').reInit();
        }
        component.set('v.radiusRestriction.RR_Other_WF__c','');
        component.set('v.radiusRestriction.RadiusDistance_WF__c',10);
        component.set('v.radiusRestriction.Duration_WF__c','Entire Term incl. any Option(s)');
        if(!$A.util.isUndefinedOrNull(component.find('duration'))){
            component.find('duration').reInit();
        }
        component.set('v.radiusRestriction.DurationYears_WF__c',0);
        component.set('v.radiusRestriction.Duration_Months__c',0);
        component.set('v.radiusRestriction.RadiusPenalty_WF__c','Incl. GS From Competing Location (standard);Any Kickout(s) Removed');
        if(!$A.util.isUndefinedOrNull(component.find('radiusPenalty'))){
            component.find('radiusPenalty').reInit();
        }
        component.set('v.radiusRestriction.RadiusAppliesTo_WF__c','');
        if(!$A.util.isUndefinedOrNull(component.find('radiusAppliesTo'))){
            component.find('radiusAppliesTo').reInit();
        }
    },
    changeNoOf : function(component, event, helper) {
        component.set('v.radiusRestriction.RR_Other_WF__c','');
    },
    changeDuration : function(component, event, helper) {
        component.set('v.radiusRestriction.DurationYears_WF__c',0);
        component.set('v.radiusRestriction.Duration_Months__c',0);
    },
})