({
    doInit: function(component, event, helper) {
        helper.hideSpinner(component, event, helper);
        var yearPickValue = [];
        var monthPickValue = [];
        for(var i=0;i<=25;i++){
            yearPickValue.push({ value: String(i), label: String(i) });
        }
        for(var i=0;i<12;i++){
            monthPickValue.push({ value: String(i), label: String(i) });
        }
        component.set('v.yearPickValue',yearPickValue);
        component.set('v.monthPickValue',monthPickValue);
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermYears'))){            
            component.find('leaseTermYears').reInit();
        }
        if(!$A.util.isUndefinedOrNull(component.find('leaseTermMonths'))){            
            component.find('leaseTermMonths').reInit();
        }
    }, 
    cancel : function(component, event, helper) {
        component.set('v.showPopup', false);
    },
    save : function(component, event, helper) {
    	var boolIsReqFieldEmpty = false;
        if($A.util.isUndefinedOrNull(component.get('v.opp.EffectiveDate_WF__c'))){
            $A.util.removeClass(component.find("EffectivenessDateErr"), 'slds-hide');
            boolIsReqFieldEmpty = true;
        }else{
            $A.util.addClass(component.find("EffectivenessDateErr"), 'slds-hide');
        }
        if(component.get('v.opp.PercentRent_WF__c')){
            if($A.util.isEmpty(component.get('v.opp.RentCommentsPercent_WF__c'))){
                $A.util.removeClass(component.find("PercentageRentCommentsErr"), 'slds-hide');
                boolIsReqFieldEmpty = true;
            }else{
                $A.util.addClass(component.find("PercentageRentCommentsErr"), 'slds-hide');
            }
        }
        if(component.get('v.opp.ACDBEParticipation_WF__c')){
            if($A.util.isEmpty(component.get('v.opp.ACDBEParticipationPercentage_WF__c'))){
                $A.util.removeClass(component.find("ACDBEParticipationPercentageErr"), 'slds-hide');
                boolIsReqFieldEmpty = true;
            }else{
                $A.util.addClass(component.find("ACDBEParticipationPercentageErr"), 'slds-hide');
            }
        }
        if(!$A.util.isEmpty(component.get('v.operatorName'))&& !$A.util.isEmpty(component.get('v.operatorId'))){
            if(component.get('v.operatorName.RecordType.Name')!='Prospect'){
                $A.util.removeClass(component.find("OperatorMismatchError"), 'slds-hide');
                boolIsReqFieldEmpty = true;
            }else{
                $A.util.addClass(component.find("OperatorMismatchError"), 'slds-hide');
            }
        }
        if(component.get('v.centerName').Operating_Center_Type__c!='Airport'){
            $A.util.removeClass(component.find('CenterMismatchError'), 'slds-hide');
            boolIsReqFieldEmpty = true;
        }else{
            $A.util.addClass(component.find('CenterMismatchError'), 'slds-hide');
        }
        if(boolIsReqFieldEmpty){
            return;
        }
    	helper.insertOpportuniy(component,event, helper);
    },
    clearACDBE : function(component, event, helper) {
        if(component.get('v.opp.ACDBEParticipation_WF__c'))
            component.set('v.opp.ACDBEParticipationPercentage_WF__c', '0');
        else
            component.set('v.opp.ACDBEParticipationPercentage_WF__c', null);        
        component.set('v.opp.ACDBEComments_WF__c', '');
    },
    clearPercentRent : function(component, event, helper) {
    	component.set('v.opp.RentCommentsPercent_WF__c', '');
    },
    validateForNegativeValues : function(component, event, helper) {
        var ACDBEParticipation = component.get('v.opp.ACDBEParticipationPercentage_WF__c');
        console.log('s',ACDBEParticipation);
        if(ACDBEParticipation <0){
            console.log('if');
            $A.util.removeClass(component.find("ACDBEParticipationErr"), 'slds-hide');
        }
        else{
            console.log('else');
            $A.util.addClass(component.find("ACDBEParticipationErr"), 'slds-hide');
        }
    },
})