({
    insertOpportuniy: function(component, event, helper){
        this.showSpinner(component, event, helper);
        var action = component.get('c.insertOpportuniyMethod');
        var opportunity = component.get('v.opp');
        var centerName = component.get('v.centerName');
        var operatorName = component.get('v.operatorName');
        var dealmaker = component.get('v.dealMakerForMultiUnit');
        opportunity.CenterName_WF__c = centerName.Id;
        console.log('****!!!',component.get('v.operatorId'));
        if(!$A.util.isEmpty(component.get('v.operatorId'))){
            opportunity.Operator_WF__c = operatorName.Id;
        }
        opportunity.Dealmaker_WF__c = dealmaker.Id;
        if(!$A.util.isEmpty(component.get('v.operatorName')) && !$A.util.isEmpty(component.get('v.operatorId'))){
            opportunity.Name = centerName.CenterCode_LM__c +' '+ operatorName.Name +' '+opportunity.EffectiveDate_WF__c;
        }else{
            opportunity.Name = centerName.CenterCode_LM__c +' '+opportunity.EffectiveDate_WF__c;
        }
        action.setParams({
            "opp": opportunity
        }); 
        action.setCallback(this,function(response){
            if(response.getState() == "SUCCESS"){
                var result = response.getReturnValue();
                console.log('result',result);
                component.set('v.selectedRecord',result);
                component.set('v.selectedRecordId',result.Id);
                component.set('v.showPopup',false);
		   		component.set('v.cep',result.CEPDeal_WF__c);
            }else{
                alert('Please Enter Valid Data');
            }
            this.hideSpinner(component, event, helper);
        });
        $A.enqueueAction(action);
    },
    hideSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
        $A.util.addClass(spinner, "slds-hide");
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
        $A.util.removeClass(spinner, "slds-hide");
    },
})