({
    doInit : function(component, event, helper) {
        var covenant = component.get('v.Covenant');
        var CoTenants = [];
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Co-Tenancy']){
                CoTenants.push(covenant[item]);                
            }
        }
        for(var item in CoTenants){
            console.log('item',item);
            if(CoTenants[item].OperatingCoTenancy_WF__c && CoTenants[item].CoTenancyType_WF__c=='Operating'){
                component.set('v.boolCoTenancyRights',true);
            }
            if(CoTenants[item].OpeningCoTenancy_WF__c && CoTenants[item].CoTenancyType_WF__c=='Opening'){
                component.set('v.boolCoTenancyRights',true);
            }
            if(CoTenants[item].PosessionCoTenancy_WF__c && CoTenants[item].CoTenancyType_WF__c=='Posession'){
                component.set('v.boolCoTenancyRights',true);
            }
            if(CoTenants[item].ConstructionCoTenancy_WF__c && CoTenants[item].CoTenancyType_WF__c=='Construction'){
                component.set('v.boolCoTenancyRights',true);
            }           
        }
        console.log('CoTenants',CoTenants);
        var ct = {};
        ct.Remedy_WF__c = 'Reduction in Rent';
        ct.RemedyGLARequired_WF__c = 'Reduction in Rent';
        ct.RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
        ct.RemedyotherRequirement_WF__c = 'Reduction in Rent';
        ct.Concurrence_WF__c = 'Or';
        ct.ConcurrenceOpeningGLACTWF__c = 'Or';
        ct.OpeningCoTenancy_WF__c = false;
        ct.OperatingCoTenancy_WF__c = false;
        ct.PosessionCoTenancy_WF__c = false;
        ct.ConstructionCoTenancy_WF__c = false;
        ct.DepartmentStores_WF__c = false;
        ct.NooofDeptStoresatCenter_WF__c = null;
        ct.DefinitionofDeptStoresf_WF__c = '';
        ct.NoofDeptStoresRequired_WF__c = null;
        ct.DescriptionRemedy_WF__c = '';
        ct.IsTenantRequiredtoOpen_WF__c = false;
        ct.NamedStoreCoTenancy_WF__c = '';
        ct.GLARequired_WF__c = false;
        ct.GLAPercent_WF__c = null;
        ct.DescriptionGLARequired_WF__c = '';
        ct.IsTnntreqdtoopenGLAReqd_WF__c = false;
        ct.NamedStoreRequirement_WF__c = false;
        ct.NamedStoreCT_WF__c = '';
        ct.NoofNamedStoresRequired_WF__c = null;
        ct.DescriptionNamedStoreRequirement_WF__c = '';
        ct.IsTntReqdtoOpenNSRqmnt_WF__c = false;
        ct.OtherRequirement_WF__c = false;
        ct.Explanation_WF__c = '';
        ct.DescriptionOtherRequirement_WF__c = '';
        ct.IsTntReqdtoOpenOthrRqmnt_WF__c = false;
        ct.ReplacementTenantDescription_WF__c = '';
        ct.IsTntReqdtoAcceptPosession_WF__c = false;
        ct.IsTenantRequiredToStartConstruction_WF__c = false;
        ct.SalesTest_WF__c = null;
        ct.SalesTestMeasuringPeriod_WF__c = 'Months';
        ct.SalesTestMeasuringPeriodDays_WF__c = null;
        ct.SalesTestMeasuringPeriodMonths_WF__c = null;
        ct.RecordTypeId = $A.get("$Label.c.Covenant_Rec_Type_Co_Tenancy");
        var arrCovenants = [];
        //,component.set('v.boolCoTenancyRights',false);
        
        var coTenantOperating = JSON.parse(JSON.stringify(ct));
        coTenantOperating.CoTenancyType_WF__c = 'Operating';
        arrCovenants.push(coTenantOperating);
        var coTenantOpening = JSON.parse(JSON.stringify(ct));
        coTenantOpening.CoTenancyType_WF__c = 'Opening';
        arrCovenants.push(coTenantOpening);
        var coTenantConstruction = JSON.parse(JSON.stringify(ct));
        coTenantConstruction.CoTenancyType_WF__c = 'Construction';
        arrCovenants.push(coTenantConstruction);
        var coTenantPosession = JSON.parse(JSON.stringify(ct));
        coTenantPosession.CoTenancyType_WF__c = 'Posession';
        arrCovenants.push(coTenantPosession);
        
        if(CoTenants != null && CoTenants.length>0){
            var opening = false;
            var posession = false;
            
            for(var i=0;i<CoTenants.length;i++){
                if(CoTenants[i].CoTenancyType_WF__c == 'Operating'){                                    
                    arrCovenants[0] = CoTenants[i];
                }
                if(CoTenants[i].CoTenancyType_WF__c == 'Opening'){
                    arrCovenants[1] = CoTenants[i];
                    opening = true;
                }
                if(CoTenants[i].CoTenancyType_WF__c == 'Construction'){
                    arrCovenants[2] = CoTenants[i];
                }
                if(CoTenants[i].CoTenancyType_WF__c == 'Posession'){
                    arrCovenants[3] = CoTenants[i];
                    posession = true;
                }
            }
            
            /* Joshna - 3rd October '17 : removing this as its not required
			 *if(posession == false){
                var coTenantPos = JSON.parse(JSON.stringify(arrCovenants[1]));
                coTenantPos.OpeningCoTenancy_WF__c = false;
                coTenantPos.CoTenancyType_WF__c = 'Posession';
                arrCovenants[3] = coTenantPos;
            }*/
        }
        for(var item in arrCovenants){
            var isPresent = false;
            for(var item1 in covenant){
                if(covenant[item1].CoTenancyType_WF__c == arrCovenants[item].CoTenancyType_WF__c){
                    isPresent = true;
                }
            }
            if(!isPresent)
                covenant.push(arrCovenants[item]);
        }
        component.set('v.lstCoTenants',arrCovenants);
        component.set('v.Covenant',covenant);
    },
    validateCoTenancy : function(component, event, helper) {
        var coTenants = component.get('v.lstCoTenants');
        var CoTenancyError=false;
        if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
            for(var i=0; i<coTenants.length; i++){
                if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true)){
                    if(coTenants[i].OperatingCoTenancy_WF__c == true  && coTenants[i].CoTenancyType_WF__c == 'Operating'){
                        //check for Sales Test (decrease by %) not empty
                        if((coTenants[i].SalesTest_WF__c == '' || coTenants[i].SalesTest_WF__c == null) && coTenants[i].SalesTest_WF__c != 0){
                            console.log('salesTestDecrease empty-->',i);
                            $A.util.removeClass(document.getElementById('salesTestDecreaseErrorId' + i), 'slds-hide');
                            CoTenancyError = true;
                        }else{
                            $A.util.addClass(document.getElementById('salesTestDecreaseErrorId' + i), 'slds-hide');
                        }
                        //check for Sales Test Measing Period not empty
                        if(coTenants[i].SalesTestMeasuringPeriod_WF__c != '' || coTenants[i].SalesTestMeasuringPeriod_WF__c != null || coTenants[i].SalesTestMeasuringPeriod_WF__c != '--None--'){
                            if(coTenants[i].SalesTestMeasuringPeriod_WF__c == 'Months'){
                                if((coTenants[i].SalesTestMeasuringPeriodMonths_WF__c == '' || coTenants[i].SalesTestMeasuringPeriodMonths_WF__c == null) && coTenants[i].SalesTestMeasuringPeriodMonths_WF__c !== 0){
                                    $A.util.removeClass(document.getElementById('salesTestMeasPeriodMonthsErrorId' + i), 'slds-hide');
                                    CoTenancyError = true;
                                }else{
                                    $A.util.addClass(document.getElementById('salesTestMeasPeriodMonthsErrorId' + i), 'slds-hide');
                                }
                            }
                            else if(coTenants[i].SalesTestMeasuringPeriod_WF__c == 'Days'){                         
                                if((coTenants[i].SalesTestMeasuringPeriodDays_WF__c == '' || coTenants[i].SalesTestMeasuringPeriodDays_WF__c == null) && coTenants[i].SalesTestMeasuringPeriodDays_WF__c !== 0){
                                    console.log('salesTestMeasPeriod empty-->',i);
                                    $A.util.removeClass(document.getElementById('salesTestMeasPeriodDaysErrorId' + i), 'slds-hide');
                                    CoTenancyError = true;
                                }
                                else{
                                    $A.util.addClass(document.getElementById('salesTestMeasPeriodDaysErrorId' + i), 'slds-hide');
                                }
                            }
                        }						
                    }
                    if(coTenants[i].DepartmentStores_WF__c==true && (coTenants[i].OperatingCoTenancy_WF__c == true || coTenants[i].PosessionCoTenancy_WF__c == true || coTenants[i].ConstructionCoTenancy_WF__c == true)){
                        //check for # of Dept Stores at Center not empty
                        if(coTenants[i].NooofDeptStoresatCenter_WF__c == '' || coTenants[i].NooofDeptStoresatCenter_WF__c == null){
                            console.log('noDeptStoresAtCenter empty-->',i);
                            $A.util.removeClass(document.getElementById('noDeptStoresAtCenterErrorId' + i), 'slds-hide');
                            CoTenancyError = true;
                        }else{
                            $A.util.addClass(document.getElementById('noDeptStoresAtCenterErrorId' + i), 'slds-hide');
                        }
                        //check for # of Dept Stores Required not empty
                        if(coTenants[i].NoofDeptStoresRequired_WF__c == '' || coTenants[i].NoofDeptStoresRequired_WF__c == null){
                            console.log('noDeptStoresReqd empty-->',i);
                            $A.util.removeClass(document.getElementById('noDeptStoresReqdErrorId' + i), 'slds-hide');
                            CoTenancyError = true;
                        }else{
                            $A.util.addClass(document.getElementById('noDeptStoresReqdErrorId' + i), 'slds-hide');
                        }
                    }
                    //check for Department Stores and GLA Required - both can't be false (at least one to be selected). GDM-4274
                    if(coTenants[i].DepartmentStores_WF__c==false && coTenants[i].GLARequired_WF__c==false){
                        $A.util.removeClass(document.getElementById('deptStoreOrGLAReqdLabel1ErrorId' + i), 'slds-hide');
                        $A.util.removeClass(document.getElementById('deptStoreOrGLAReqdLabel2ErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }
                    else{
                        $A.util.addClass(document.getElementById('deptStoreOrGLAReqdLabel1ErrorId' + i), 'slds-hide');
                        $A.util.addClass(document.getElementById('deptStoreOrGLAReqdLabel2ErrorId' + i), 'slds-hide');
                    }
                    
                    if(coTenants[i].DepartmentStores_WF__c==true)
                    {
                        if(coTenants[i].DescriptionRemedy_WF__c == null || coTenants[i].DescriptionRemedy_WF__c == '')
                        {
                            $A.util.removeClass(document.getElementById('noDeptRemDescReqdErrorId' + i), 'slds-hide');
                            CoTenancyError = true;
                        }
                        else
                        {
                            $A.util.addClass(document.getElementById('noDeptRemDescReqdErrorId' + i), 'slds-hide');
                        }
                    } 
                    
                    /*if(coTenants[i].ReplacementTenantDescription_WF__c == null || coTenants[i].ReplacementTenantDescription_WF__c == '')
                    {
                        $A.util.removeClass(document.getElementById('RepDescReqErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }
                    else
                    {
                        $A.util.addClass(document.getElementById('RepDescReqErrorId' + i), 'slds-hide');
                    }*/
                    
                    //check for Definition of Dept. Store sf not empty
                    if(coTenants[i].DepartmentStores_WF__c==true && coTenants[i].OpeningCoTenancy_WF__c == true && (coTenants[i].DefinitionofDeptStoresf_WF__c == '' || coTenants[i].DefinitionofDeptStoresf_WF__c == null)){
                        console.log('defDeptStore empty-->',i);
                        $A.util.removeClass(document.getElementById('defDeptStoreErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('defDeptStoreErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy not empty
                    if(coTenants[i].DepartmentStores_WF__c==true && coTenants[i].Remedy_WF__c == '' || coTenants[i].Remedy_WF__c == null || coTenants[i].Remedy_WF__c == '--None--'){
                        console.log('remedy empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyErrorId' + i), 'slds-hide');
                    }
                    //check for Concurrence not empty
                    if(coTenants[i].OpeningCoTenancy_WF__c == true && (coTenants[i].Concurrence_WF__c == '' || coTenants[i].Concurrence_WF__c == null || coTenants[i].Concurrence_WF__c == '--None--')){
                        console.log('concurrence empty-->',i);
                        $A.util.removeClass(document.getElementById('concurrenceErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('concurrenceErrorId' + i), 'slds-hide');
                    }
                    //check for GLA % not empty
                    if( coTenants[i].GLARequired_WF__c == true && (coTenants[i].GLAPercent_WF__c == '' || coTenants[i].GLAPercent_WF__c == null)){
                        console.log('gla % empty-->',i);
                        $A.util.removeClass(document.getElementById('glaPercentErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('glaPercentErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy GLA Required not empty
                    if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].RemedyGLARequired_WF__c == '' || coTenants[i].RemedyGLARequired_WF__c == null || coTenants[i].RemedyGLARequired_WF__c == '--None--')){
                        console.log('remedyGLAReqd empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyGLAReqdErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyGLAReqdErrorId' + i), 'slds-hide');
                    }
                    //check for Description GLA Required not empty
                    if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].DescriptionGLARequired_WF__c == '' || coTenants[i].DescriptionGLARequired_WF__c == null)){
                        console.log('descGLAReqd empty-->',i);
                        $A.util.removeClass(document.getElementById('descGLAReqdErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('descGLAReqdErrorId' + i), 'slds-hide');
                    }
                    //check for Named Store CT not empty
                    if( coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].NamedStoreCT_WF__c == '' || coTenants[i].NamedStoreCT_WF__c == null)){
                        console.log('namedStoreCT empty-->',i);
                        $A.util.removeClass(document.getElementById('namedStoreCTErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('namedStoreCTErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy Named Store Requirement not empty
                    if(coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].RemedyNamedStoreRequirement_WF__c == '' || coTenants[i].RemedyNamedStoreRequirement_WF__c == null || coTenants[i].RemedyNamedStoreRequirement_WF__c == '--None--')){
                        console.log('remedyNamedStoreReq empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyNamedStoreReqErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyNamedStoreReqErrorId' + i), 'slds-hide');
                    }
                    //check for Description Named Store Requirement not empty
                    if(coTenants[i].NamedStoreRequirement_WF__c == true && (coTenants[i].DescriptionNamedStoreRequirement_WF__c == '' || coTenants[i].DescriptionNamedStoreRequirement_WF__c == null)){
                        console.log('descNamedStoreReq empty-->',i);
                        $A.util.removeClass(document.getElementById('descNamedStoreReqErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('descNamedStoreReqErrorId' + i), 'slds-hide');
                    }
                    //check for Explanation not empty
                    if( coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].Explanation_WF__c == '' || coTenants[i].Explanation_WF__c == null)){
                        console.log('explanation_WF__c empty-->',i);
                        $A.util.removeClass(document.getElementById('explanationErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('explanationErrorId' + i), 'slds-hide');
                    }
                    //check for Remedy Other Requirement not empty
                    if(coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].RemedyotherRequirement_WF__c == '' || coTenants[i].RemedyotherRequirement_WF__c == null || coTenants[i].RemedyotherRequirement_WF__c == '--None--')){
                        console.log('remedyOtherReq empty-->',i);
                        $A.util.removeClass(document.getElementById('remedyOtherReqErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('remedyOtherReqErrorId' + i), 'slds-hide');
                    }
                    //check for Description Other Requirement not empty
                    if(coTenants[i].OtherRequirement_WF__c == true && (coTenants[i].DescriptionOtherRequirement_WF__c == '' || coTenants[i].DescriptionOtherRequirement_WF__c == null)){
                        console.log('descOtherReq empty-->',i);
                        $A.util.removeClass(document.getElementById('descOtherReqErrorId' + i), 'slds-hide');
                        CoTenancyError = true;
                    }else{
                        $A.util.addClass(document.getElementById('descOtherReqErrorId' + i), 'slds-hide');
                    }
                    console.log('coTenants[i].CoTenancyType_WF__c', coTenants[i].CoTenancyType_WF__c);
                    console.log('coTenants[i].OperatingCoTenancy_WF__c', coTenants[i].OperatingCoTenancy_WF__c);
                    console.log('coTenants[i].OpeningCoTenancy_WF__c', coTenants[i].OpeningCoTenancy_WF__c);
                    console.log('coTenants[i].ConstructionCoTenancy_WF__c', coTenants[i].ConstructionCoTenancy_WF__c);
                    console.log('coTenants[i].PosessionCoTenancy_WF__c', coTenants[i].PosessionCoTenancy_WF__c);
                }

            }
             
            helper.validateCovenantTextField(component,component.get('v.result'));
            if(CoTenancyError || component.get('v.coTenancyTempError'))
            {
                component.set('v.CoTenancyError',true);

            }
            else
            {
                component.set('v.CoTenancyError',false);

            }

        }
       
        else{
            	component.set("v.CoTenancyError", false);
        }  
    },
    changeCoTenancy : function(component,event,helper){
        var lstCoTenants = component.get('v.lstCoTenants');
        for(var item in lstCoTenants){
            lstCoTenants[item].ConstructionCoTenancy_WF__c=false;
            lstCoTenants[item].OpeningCoTenancy_WF__c=false;
            lstCoTenants[item].OperatingCoTenancy_WF__c=false;
            lstCoTenants[item].PosessionCoTenancy_WF__c=false;
        }
        console.log('1');
        helper.clearOperatingCoTenancy(component,event);
        console.log('2');
        helper.clearOpeningCoTenancy(component,event);
        console.log('3');
        helper.clearConstructionCoTenancy(component,event);
        console.log('4');
        helper.clearPosessionCoTenancy(component,event);
        console.log('5');
    },
    changeOperatingCoTenancy : function(component,event,helper){
        helper.clearOperatingCoTenancy(component,event);        
    },
    changeOpeningCoTenancy : function(component,event,helper){
        helper.clearOpeningCoTenancy(component,event);        
    },
    changeConstructionCoTenancy : function(component,event,helper){
        helper.clearConstructionCoTenancy(component,event);        
    },
    changePossessionCoTenancy : function(component,event,helper){
        helper.clearPosessionCoTenancy(component,event);        
    },
    enableHelpTextdescriptionRemedy : function(component, event, helper){
        component.set('v.showHelpTextDesRem',true);
    },
    enableHelpTextDesGLA : function(component, event, helper){
        component.set('v.showHelpTextDesGLA',true);
    },
    enableHelpTextdescriptionNSR : function(component, event, helper){
        component.set('v.showHelpTextDesNSR',true);
    },
    enableHelpTextdescriptionOR : function(component, event, helper){
        component.set('v.showHelpTextDesRemOR',true);
    },
    enableHelpTextdesExclRemedy : function(component, event, helper){
        component.set('v.showHelpTextDesExclRemedy',true);
    },
    enableHelpTextdesSLR : function(component, event, helper){
        component.set('v.showHelpTextDesSLR',true);
    },
    enableHelpTextdesSTR : function(component, event, helper){
        component.set('v.showHelpTextDesSTR',true);
    },
    enableHelpTextSRR : function(component, event, helper){
        component.set('v.showHelpTextSRR',true);
    },
    enableHelpTextCAR : function(component, event, helper){
        component.set('v.showHelpTextCAR',true);
    },
    disableHelpText : function(component, event, helper){
        component.set('v.showHelpTextDesRem',false);
        component.set('v.showHelpTextDesGLA',false);
        component.set('v.showHelpTextDesNSR',false);
        component.set('v.showHelpTextDesRemOR',false);
        component.set('v.showHelpTextDesExclRemedy',false);
        component.set('v.showHelpTextDesSLR',false);
        component.set('v.showHelpTextDesSTR',false);
        component.set('v.showHelpTextSRR',false);
        component.set('v.showHelpTextCAR',false);
    },
    validateForNegativeValues:function(component, eve, helper){
        
        console.log('entered onchange negative values method-->');
        //Co-Tenancy section fields
        var coTenants = component.get('v.lstCoTenants');
        
        if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
            for(var i=0; i<coTenants.length; i++){
                if((i==0 && coTenants[i].OperatingCoTenancy_WF__c == true) || (i==1 && coTenants[i].OpeningCoTenancy_WF__c == true) || (i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true) || (i==3 && coTenants[i].PosessionCoTenancy_WF__c == true)){
                    if(coTenants[i].OperatingCoTenancy_WF__c == true){
                        //check for Sales Test (decrease by %) not negative
                        if(coTenants[i].SalesTest_WF__c != '' && coTenants[i].SalesTest_WF__c != null && coTenants[i].SalesTest_WF__c <0){
                            console.log('salesTestDecrease negative-->',i);
                            $A.util.removeClass(document.getElementById('salesTestDecreaseNegativeId' + i), 'slds-hide');
                        }else{
                            $A.util.addClass(document.getElementById('salesTestDecreaseNegativeId' + i), 'slds-hide');
                        }
                    }
                    
                    //check for GLA % not negative
                    if(coTenants[i].GLARequired_WF__c == true && (coTenants[i].GLAPercent_WF__c != '' && coTenants[i].GLAPercent_WF__c != null && coTenants[i].GLAPercent_WF__c <0)){
                        console.log('gla % negative-->',i);
                        $A.util.removeClass(document.getElementById('glaPercentNegativeId' + i), 'slds-hide');
                    }else{
                        $A.util.addClass(document.getElementById('glaPercentNegativeId' + i), 'slds-hide');
                    }
                }
            }
        }
    },
     changeOtherRequirement : function(component,event,helper){        
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                	coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTntReqdtoOpenOthrRqmnt_WF__c = false;
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTenantRequiredToStartConstruction_WF__c = false;
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].OtherRequirement_WF__c == false){                
                    coTenants[i].Explanation_WF__c = '';
                	coTenants[i].RemedyotherRequirement_WF__c = 'Reduction in Rent';
                	coTenants[i].DescriptionOtherRequirement_WF__c = '';
                    coTenants[i].IsTntReqdtoAcceptPosession_WF__c = false;
                }
                
            }
        }
    },
    changeNamedStoreRequirement : function(component,event,helper){
    var coTenants = component.get('v.lstCoTenants');
    if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
    	for(var i=0; i<coTenants.length; i++){
    		if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
            	coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
             if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
    			coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
                coTenants[i].IsTntReqdtoOpenNSRqmnt_WF__c = false;
			}
            if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){
                coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
			if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].NamedStoreRequirement_WF__c == false){                
           		coTenants[i].NamedStoreCT_WF__c = '';
    			coTenants[i].NoofNamedStoresRequired_WF__c = 0;
    			coTenants[i].RemedyNamedStoreRequirement_WF__c = 'Reduction in Rent';
    			coTenants[i].DescriptionNamedStoreRequirement_WF__c = '';
            }
 		}
 	}
 	},
    changeMajorTenants : function(component,event,helper){
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].IsTenantRequiredtoOpen_WF__c=false;
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].DepartmentStores_WF__c == false){
                    coTenants[i].NooofDeptStoresatCenter_WF__c = 0;
                    coTenants[i].NoofDeptStoresRequired_WF__c = 0;
                    coTenants[i].DefinitionofDeptStoresf_WF__c = '';
                    coTenants[i].Remedy_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionRemedy_WF__c = '';
                    coTenants[i].Concurrence_WF__c = 'Or';
                    coTenants[i].NamedStoreCoTenancy_WF__c='';
                    
                }
            }
        }
    },
    
    changeGLARequired : function(component,event,helper){
        var coTenants = component.get('v.lstCoTenants');
        if(coTenants.length >0 && component.get('v.boolCoTenancyRights')==true){
            for(var i=0; i<coTenants.length; i++){
                if(i==0 && coTenants[i].OperatingCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==1 && coTenants[i].OpeningCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].IsTnntreqdtoopenGLAReqd_WF__c=false;
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==2 && coTenants[i].ConstructionCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
                if(i==3 && coTenants[i].PosessionCoTenancy_WF__c == true && coTenants[i].GLARequired_WF__c == false){
                    coTenants[i].GLAPercent_WF__c ='0';
                    coTenants[i].RemedyGLARequired_WF__c ='Reduction in Rent';
                    coTenants[i].DescriptionGLARequired_WF__c = '';
                    coTenants[i].ConcurrenceOpeningGLACTWF__c = 'Or';
                }
            }
        }
    } 
})