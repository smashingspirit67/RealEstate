({
	doInit : function(component, event, helper) {
		helper.getRecords(component);
	}
})