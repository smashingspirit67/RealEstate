({
	getRecords : function(component) {
		var action = component.get("c.getRecords");
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            if(component.isValid()){
                var responseVal = response.getReturnValue();
                console.log(responseVal);
                component.set("v.records", responseVal.comparableDeals);
                component.set("v.similarOpps", responseVal.similarOpps);
                component.set("v.dbaName", responseVal.dbaName);
                component.set("v.dateFormat", responseVal.dateFormat);
            }
        });
        $A.enqueueAction(action);
	}
})