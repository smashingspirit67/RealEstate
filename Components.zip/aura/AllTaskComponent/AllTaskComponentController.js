({
    doInit : function(component, event, helper) {
        //helper.getTotalNumberOfTasks(component);
        //helper.getColumnAndAction(component);
        //helper.getTasks(component);
        helper.fetchPickListVal(component, 'Subject', 'newTaskSelect1');
        helper.fetchPickListVal(component, 'Status', 'newTaskSelect2');
        helper.fetchPickListVal(component, 'Priority', 'newTaskSelect3');
        helper.fetchPickListVal1(component, 'StageName', 'newTaskSelect4');
         
        //component.set("v.newTask.WhatId",component.get("v.recordId"));
    },
     searchRecords : function(component, event, helper) {
       // helper.getTotalNumberOfTasks(component);
        helper.getColumnAndAction(component);
        helper.getTasks(component);
        component.set("v.newTask.WhatId",component.get("v.recordId"));
    },
     
    handleLoadMoreTasks: function (component, event, helper) {
        event.getSource().set("v.isLoading", true);
        component.set('v.loadMoreStatus', 'Loading....');
        helper.getMoreTasks(component, component.get('v.rowsToLoad')).then($A.getCallback(function (data) {
            if (component.get('v.data').length == component.get('v.totalNumberOfRows')) {
                component.set('v.enableInfiniteLoading', false);
                component.set('v.loadMoreStatus', 'No more data to load');
            } else {
                var currentData = component.get('v.data');
                var newData = currentData.concat(data);
                component.set('v.data', newData);
                component.set('v.loadMoreStatus', 'Please scroll down to load more data');
            }
            event.getSource().set("v.isLoading", false);
        }));
    },
     
    handleSelectedRows: function (component, event, helper) {
        var data = component.get('v.data');
        var selectedRowList =  component.get("v.selectedRowsList");
        console.log('selectedRowList-' + selectedRowList);
    },
     
    handleSelectedRow: function(component, event, helper){
        var selectedRows = event.getParam('selectedRows');
        component.set("v.selectedRowsCount", selectedRows.length);
        let obj =[] ; 
        for (var i = 0; i < selectedRows.length; i++){
            obj.push({Name:selectedRows[i].Name});
        }
        component.set("v.selectedRowsDetails", JSON.stringify(obj) );
        component.set("v.selectedRowsList", event.getParam('selectedRows'));
    },
     
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        switch (action.name) {
            case 'new':
                helper.createTaskRecord(component, event);
                break;
            case 'edit':
                helper.editTaskRecord(component, event);
                break;
            case 'delete':
                helper.deleteTaskRecord(component, event);
                break;
            case 'view':
                helper.viewTaskRecord(component, event);
                break;
            case 'viewSubtask':
                helper.viewSubTaskRecord(component, event);
                break;    
        }
    },
     
    handleColumnSorting: function (component, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        component.set("v.sortedBy", fieldName);
        component.set("v.sortedDirection", sortDirection);
        helper.sortData(component, fieldName, sortDirection);
    },
    
    
    onPicklistChange: function(component, event, helper) {
        // get the value of select option
        var val= event.getSource().get("v.value");
        var field = event.getSource().get("v.label");               
        component.set("v.newTask." + field,val);
        //console.log(component.get("v.newTask"));
    }
})