({
	doInit : function(component, event, helper) {
        var action = component.get('c.fetchOpportunity');
        action.setParams({
            "recordId" : component.get('v.recordId')
        });
        action.setCallback(this, function(response){
        	var isSuccess = response.getState();
            console.log('isSuccess',isSuccess);
            if(isSuccess){
                var result = response.getReturnValue();
                console.log('result',result);
                if(result != null){
                    console.log(result);            
                    if(result.StageName==='Offer'){
                        component.set('v.showOfferSheet',true);
                    }else{
						if(result.RecordType.DeveloperName !=='Amendment_Termination' && 
                            result.RecordType.DeveloperName !=='Amendment_Assignment' &&
                            result.RecordType.DeveloperName !=='Amendment_Rent_Relief' && 
                            result.RecordType.DeveloperName !=='Amendment_Renewal'){
                            component.set('v.showDealSheet',true);
                        }
                        else if(result.RecordType.DeveloperName ==='Amendment_Renewal'){
                            component.set('v.showRenewal',true);
                        }
                        else if(result.RecordType.DeveloperName ==='Amendment_Termination'){
                            component.set('v.showTermination',true);
                        }
                        else if(result.RecordType.DeveloperName ==='Amendment_Assignment'){
                            component.set('v.showAssignment',true);
                        }
                        else if(result.RecordType.DeveloperName ==='Amendment_Rent_Relief'){
                            component.set('v.showRentRelief',true);
                        }
                    }
                }
            }
        });
       $A.enqueueAction(action);
	}
})