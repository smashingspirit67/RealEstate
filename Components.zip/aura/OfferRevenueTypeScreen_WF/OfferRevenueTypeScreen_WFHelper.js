({
    doInitHelper : function(cmp, eve, helper) { 
        var action  = cmp.get('c.getDivisionOnUser');
        action.setCallback(this,function(response){
            var strRevenueLine = response.getReturnValue();
            cmp.set("v.strRevenueLine", strRevenueLine==null?'--None--':strRevenueLine);
        });
        $A.enqueueAction(action);
    },
    doNextHelper : function(cmp, eve, helper) { 
        var boolIsCrossUpSellYes= cmp.get('v.boolIsCrossUpSellYes');
        var strDealRevenueLine = cmp.get('v.strDealRevenueLine');
    	var strRevenueLineField = cmp.find('revenueLineId');
        /*Make Revenue Line Mandatory*/
        if(cmp.get('v.strRevenueLine')==null||cmp.get('v.strRevenueLine')=='none'){
            strRevenueLineField.set("v.errors", [{message:"Revenue Line cannot be empty."}]);
        }
        /*Make deal revenue line mandatory*/
       else if(boolIsCrossUpSellYes&&strDealRevenueLine!=null){
            cmp.set("v.intStepNum", cmp.get("v.intStepNum")+1); 
        }     
       else if(!boolIsCrossUpSellYes){
            cmp.set("v.intStepNum", cmp.get("v.intStepNum")+1); 
        }
            else{
                cmp.set('v.boolIsDealRevenueLineNone' , true);
            }
        
    },
    displayDRevenueProdTypeHelper: function(component, event, helper) {
        console.log('inside displayDRevenueProdTypeHelper '+component.get('v.strSell'));
        var productFamily= component.get('v.strSell');
        if(productFamily == 'Yes'){
            component.set("v.boolIsCrossUpSellYes", true);
            
        }
        else{
            component.set("v.boolIsCrossUpSellYes", false);
        }
    },
    onChangeDealRevenueLineHelper: function(component, event, helper) {
        var strDealRevenueLine;
        var strDealRevenueLines = component.get('v.strDealRevenueLine');
        if(strDealRevenueLines!=null){
            var strDealRevenueLine = strDealRevenueLines.split(";");          
            if(strDealRevenueLine!=null && strDealRevenueLine.length>0){
                
                var index = strDealRevenueLine.indexOf('');
                if(index!=-1){
                    strDealRevenueLine.splice(index,1); 
                    
                }
                if(strDealRevenueLine.length>0){
                    
                    component.set('v.lstDealRevenueLine',strDealRevenueLine);
                }
            }
        }
        if (strDealRevenueLine!=null){
            // changed 'Airport' to 'Airport Leasing' as the name was changed in component
            var boolPermAirPresent = strDealRevenueLine.includes('Permanent Leasing') || strDealRevenueLine.includes('Airport Leasing');
        }
        console.log('lstDealRevenueLine: '+strDealRevenueLine);
        console.log('boolPermAirPresent: '+boolPermAirPresent);
        console.log(strDealRevenueLine.includes('Permanent Leasing'));
        if(boolPermAirPresent){
            component.set("v.strProductFamily", 'GLA');
            
        }
        else{
            component.set("v.strProductFamily", 'Non-GLA');
        }
    },
})