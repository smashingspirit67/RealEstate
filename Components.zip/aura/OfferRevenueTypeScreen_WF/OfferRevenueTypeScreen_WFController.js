({  
    /* This method is called when the page is loaded. */
	doInit : function(component, event, helper) {
        helper.doInitHelper(component, event, helper);
	},
	doNext : function(cmp, eve, helper) {
        helper.doNextHelper(cmp, eve, helper);
    },
     displayDRevenueProdType : function(component, event, helper) {
    	helper.displayDRevenueProdTypeHelper(component, event, helper);
    },
     onChangeDealRevenueLine : function(component, event, helper) {
    	helper.onChangeDealRevenueLineHelper(component, event, helper);
    },
})