({
	holdReasonChange : function(component,event,helper){
        helper.setPicklistValues(component,component.get('v.result'));       
    }, 
    /*** Start Clearing logic for Data ***/
    changeOpportunityDeadOtherReason : function(component,event, helper){
            component.set('v.sObj.OtherReasonOpportunityDead_WF__c','');
        	component.set('v.oppDeadCommsLenError',false);
    },
    updateHoldReasonDescription : function(component,event, helper){
        //if(component.get('v.sObj.On_Hold_WF__c')){
          //  component.set('v.HoldDescription','Deal not approved by Tenant\'s REC.');   
        //}else{
            if(component.get('v.sObj.On_Hold_WF__c')){
            	component.set('v.sObj.On_Hold_WF__c',true);      
            }else{
                component.set('v.sObj.On_Hold_WF__c',false);      
            }    
            component.set('v.sObj.HoldReason_WF__c','');      
            component.set('v.HoldDescription','');   
        //}
        console.log('+++On_Hold_WF__c++updateHoldReasonDescription',component.get('v.sObj.On_Hold_WF__c'),'++HoldReason_WF__c++',component.get('v.sObj.HoldReason_WF__c')); 
    },
    clearJVPartner : function(component,event, helper){
        if(!$A.util.isUndefinedOrNull(component.find("OpportunityJV_Partner_Approval_WF__c"))){
        	component.find('OpportunityJV_Partner_Approval_WF__c').reInit();
        }
	}    

    /*** End Clearing logic for Data ***/ 
})