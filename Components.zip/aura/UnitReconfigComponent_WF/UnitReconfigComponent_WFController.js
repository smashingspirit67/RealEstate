({
    doInit : function (component, event, helper){
        var strProducts = component.get('v.strProducts');
        var idOpportunity = component.get('v.idOpportunity');
        var unitConfig =component.get('v.unitConfig');
        var selectedProducts = component.get('v.selectedProducts');   
        console.log('unit===> ',unitConfig);
        if( !unitConfig.empty && unitConfig.length > 0){
            if(strProducts != undefined){
                component.set('v.stepNum', 3);
                component.set('v.isSplit','true');
            }else if(idOpportunity != null){
                component.set('v.stepNum', 3);
                component.set('v.isSplit','false');
            }
        }else{
            if(idOpportunity != null && !selectedProducts.empty){
                component.set('v.stepNum', 3);
                component.set('v.isSplit','false');
            }else if(idOpportunity != null && selectedProducts.empty){
                component.set('v.stepNum', 3);
                component.set('v.isSplit','true');
            }
            
        }
    }
})