({
	doInit : function(component, event, helper){
        helper.doInitHelper(component);
	},
	showModal : function(component, event, helper) {
        helper.showModalHelper(component);
	}
})