({
    showDetails : function(component, event, helper) {
        if(component.get("v.clickable")){
            var appEvent = $A.get("e.c:passSection");  
            console.log(component.get("v.id"));
            appEvent.setParams({
                "section" : component.get("v.id")
            });
            appEvent.fire();
        }
    }
})