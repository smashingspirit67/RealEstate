({
    
    doInit: function(component, event, helper) {
      // call the fetchPickListVal(component, field_API_Name, aura_attribute_name_for_store_options) -
      // method for get picklist values dynamic   
        helper.fetchPickListVal(component, 'TaskType_WF__c', 'taskTypePicklistOpts');
        helper.fetchPickListVal(component, 'NoticeType_WF__c', 'noticeTypePicklistOpts');
        helper.fetchPickListVal(component, 'Reason_for_Notice_WF__c', 'reasonNoticePicklistOpts');
        helper.fetchPickListVal(component, 'TeamName_WF__c', 'teamNamePicklistOpts');
        helper.fetchPickListVal(component, 'Status', 'statusPicklistOpts');
        helper.fetchPickListVal(component, 'Priority', 'priorityPicklistOpts');
    },
    
    inlineEditSubject : function(component,event,helper){   
        // show the subject edit field popup 
        component.set("v.subjectEditMode", true); 
        // after the 100 millisecond set focus to input field   
        setTimeout(function(){ 
            component.find("inputId").focus();
        }, 100);
    },
    
    inlineEditStatus : function(component,event,helper){   
        // show the status edit field popup 
        component.set("v.statusEditMode", true); 
        // after set statusEditMode true, set picklist options to picklist field 
        component.find("taskStatus").set("v.options" , component.get("v.statusPicklistOpts"));
        // after the 100 millisecond set focus to input field   
        setTimeout(function(){ 
            component.find("taskStatus").focus();
        }, 100);
    },
    
     onSubjectChange : function(component,event,helper){ 
        // if edit field value changed and field not equal to blank,
        // then show save and cancel button by set attribute to true
        if(event.getSource().get("v.value").trim() != ''){ 
            component.set("v.showSaveCancelBtn",true);
        }
    },
 
    onStatusChange : function(component,event,helper){ 
        // if picklist value change,
        // then show save and cancel button by set attribute to true
        component.set("v.showSaveCancelBtn",true);
    },     
    
    closeSubjectBox : function (component, event, helper) {
      // on focus out, close the input section by setting the 'subjectEditMode' att. as false   
        component.set("v.subjectEditMode", false); 
      // check if change/update Subject field is blank, then add error class to column -
      // by setting the 'showErrorClass' att. as True , else remove error class by setting it False   
        if(event.getSource().get("v.value").trim() == ''){
            component.set("v.showErrorClass",true);
        }else{
            component.set("v.showErrorClass",false);
        }
    }, 
    
    closeStatusBox : function (component, event, helper) {
       // on focus out, close the input section by setting the 'ratingEditMode' att. as false
        component.set("v.statusEditMode", false); 
    },
    
   
})