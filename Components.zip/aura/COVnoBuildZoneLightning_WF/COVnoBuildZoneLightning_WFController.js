({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['SLR']){
                component.set('v.SLR',covenant[item]);
                isPresent = true;
            }
        }
        if(!isPresent){
            var SLR = {};
            SLR.RecordTypeId =component.get('v.CovenantRecordType')['SLR'];
            component.set('v.SLR',SLR);
            covenant.push(component.get('v.SLR'));
            component.set('v.Covenant',covenant);
        }
	},
    changeBuildZone : function(component, event, helper) {
        component.set('v.SLR.Zone_WF__c',false);
        component.set('v.SLR.ZoneDetails_WF__c','');
        component.set('v.SLR.DescriptionZone_WF__c','');
    },
    changeZone : function(component, event, helper) {
        component.set('v.SLR.ZoneDetails_WF__c','');
        component.set('v.SLR.DescriptionZone_WF__c','');
    },
    enableHelpTextDesc : function(component, event, helper){
        component.set('v.showHelpTextDesc', true);
    },
    disableHelpText : function(component, event, helper){
        component.set('v.showHelpTextDesc', false);
    }
})