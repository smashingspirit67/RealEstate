({
	doInit : function(component, event, helper) {
        if(component.get('v.idCenter')!=null){
            if(component.get('v.allUnitConfigs').length > 0){
        		component.set('v.boolIsMerge',true);
			helper.configureUnitConfigs(component, component.get('v.allUnitConfigs'));
                component.set('v.configuringInprogress', true);
            }
        	else{
        		if(component.get('v.idOpportunity') != null){
    				helper.doInitHelper(component);
                }
            }
        }
        helper.populateRemainingGLAHelper(component);
    },
    changeUnits : function(component, event, helper) {
        component.set('v.boolChangeOpportunity', true);
        component.set('v.intTotalGLA',"");
        component.set('v.intTotalRemainingGLA',"");
        component.set('v.intTotalProposedGLA',"");
        component.set('v.strComments',"");
    },
    addRemainingGLARows : function(cmp, eve, helper){
    	helper.addRemainingGLARowsHelper(cmp);
    },
    populateRemainingGLA : function(cmp, eve, helper){
    	helper.populateRemainingGLAHelper(cmp);     
    },
    checkUnitDeal: function(component, event, helper) {
        // Get the values from the form
        console.log('here');
        var records=component.get('v.selectedProducts');
        var selectedRecords = [];
        console.log(records);
        console.log(records.length);
        for(var each in records){
            console.log(records[each].selectedDealUnit);
            if(records[each].selectedDealUnit){
                selectedRecords.push(records[each]);
            }
        } 
        var errorDiv = component.find('alertDiv');
            if(selectedRecords.length > 1)
            {   
             component.set("v.errorMessage", "Choose only one record");
           
            $A.util.removeClass(errorDiv, 'slds-hide');
            }
            else
            {
			  $A.util.addClass(errorDiv, 'slds-hide');
            }
    },
	validateUnitNoInSelectedProd : function(component, event, helper){
		var obj = JSON.parse(JSON.stringify(component.get('v.selectedProducts')));
        helper.validateUnitNoHelper(component, obj); 
	},
	validateUnitNoInRemainingGLAProd : function(component, event, helper){
		var obj = JSON.parse(JSON.stringify(component.get('v.remainingGLAProducts')));
        helper.validateUnitNoHelper(component, obj); 
    }
})