({
	doInitHelper : function(component) {
        var act = component.get('c.getUnitConfigurationsOnOppty');
        act.setParams({
            "idOpportunity":component.get('v.idOpportunity'),
            "boolIsMerge":component.get('v.boolIsMerge'),
            "unitType" :  component.get('v.unitType')
        });
        act.setCallback(this, function(response){
            var result = response.getReturnValue();
        	this.configureUnitConfigs(component,result);
            var hideSpinner = $A.get("e.c:hideSpinnerEvent_WF");
            if(!$A.util.isUndefinedOrNull(hideSpinner)){
                hideSpinner.fire(); 
            }
		});
        $A.enqueueAction(act);
    },
    configureUnitConfigs : function(component,result){
        	var unitConfigs = [];
        	var selectedUnits = [];
        	var remainingGLAUnits = [];
        	
            var intTotalGLA = 0;
            var intTotalProposedGLA = 0;
            var intTotalRemainingGLA = 0;
			var intTotalAdditionalGLA=0;
            var addProduct = [];
            
            if(result != null){
                for(var i=0;i<result.length;i++){
                    if(!$A.util.isUndefinedOrNull(result[i].popoutGLA))
                    result[i].popoutGLARounded = Math.round(result[i].popoutGLA);
                    if(!$A.util.isUndefinedOrNull(result[i].GLA))
                    result[i].remainingGLARounded = Math.round(result[i].GLA);
                    if(result[i].IsRemainingGLA == false){
                        console.log(result[i].dealUnitNumber);
                        console.log(String(component.get('v.strProducts')));
						console.log(String(result[i].dealUnitNumber) == String(component.get('v.strProducts')));                        
                        //GDM-8420 Issue 7 Changes
                        /*  if(result[i].dealUnitNumber == String(component.get('v.strProducts'))){
                            result[i].selectedDealUnit = true;
                        }
                        */
                        if(result[i].idProduct!==undefined && result[i].idProduct !== null){
                            addProduct.push(result[i].idProduct);
                        }
                        selectedUnits.push(result[i]);
                        intTotalGLA = intTotalGLA + result[i].GLA;
                        if(result[i].includepopout == true)
                        {
                        	intTotalGLA = intTotalGLA + result[i].popoutGLA;
                        }
                        console.log('GLAPP', result[i].proposedGLA, intTotalProposedGLA);
                        intTotalProposedGLA = intTotalProposedGLA + result[i].proposedGLA;
                		component.set('v.storageAnnualIncr',result[i].StorageAnnIncr != null ? result[i].StorageAnnIncr : 0.05);   
                		component.set('v.storageGLA',result[i].GLA != null ? result[i].GLA : 0);
                		component.set('v.storageTerm',result[i].StorageTerm != null ? result[i].StorageTerm : '');
                		component.set('v.storageElecCharge',result[i].StorageElecChr != null ? result[i].StorageElecChr : 0);
                		component.set('v.storageType',result[i].StorageType != null ? result[i].StorageType : '');
					}else{
                    	remainingGLAUnits.push(result[i]);
                        intTotalRemainingGLA = intTotalRemainingGLA + result[i].proposedGLA;
                	}
				}
			var allUnitConfigs = [];
                if(!$A.util.isUndefinedOrNull(remainingGLAUnits) && !$A.util.isUndefinedOrNull(selectedUnits)){
                    if(remainingGLAUnits.length > 0 && selectedUnits.length >  0){
                        allUnitConfigs = selectedUnits.concat(remainingGLAUnits);
                        component.set('v.allUnitConfigs', allUnitConfigs);
                    }else if (selectedUnits.length > 0){                        
                        component.set('v.allUnitConfigs', selectedUnits);
                    }else if( remainingGLAUnits.length >  0 ){                        
                        component.set('v.allUnitConfigs', remainingGLAUnits);
                    }
                }else if (!$A.util.isUndefinedOrNull(selectedUnits)){
                    if (selectedUnits.length > 0){                        
                        component.set('v.allUnitConfigs', selectedUnits);    
                    }                    
                }else if(!$A.util.isUndefinedOrNull(remainingGLAUnits)){
                    if (remainingGLAUnits.length > 0){                           
                        component.set('v.allUnitConfigs', remainingGLAUnits);
                    }
                }             
                component.set('v.boolMerge',true);
            	component.set('v.selectedProducts',selectedUnits);
            	component.set('v.addProduct', addProduct);
                component.set('v.remainingGLAProducts',remainingGLAUnits);
                console.log('intTotalRemainingGLAintTotalRemainingGLAintTotalRemainingGLA',intTotalRemainingGLA);
                //GDM-8345 Changes
                component.set('v.intTotalRemainingGLA',Math.round(intTotalGLA-intTotalProposedGLA-intTotalRemainingGLA));
                component.set('v.boolChangeOpportunity',false);
                component.set('v.intTotalProposedGLA',Math.round(intTotalProposedGLA));
            	component.set('v.intGLAUsed',Math.round(intTotalProposedGLA));
                component.set('v.intTotalGLA',Math.round(intTotalGLA));
                component.set('v.boolChangeOpportunity',false);
            }
            else{
                component.set('v.boolMerge',false);                
            }
            var hideSpinner = $A.get("e.c:hideSpinnerEvent_WF");
            if(!$A.util.isUndefinedOrNull(hideSpinner)){
                hideSpinner.fire(); 
            }


    },
    populateRemainingGLAHelper : function(cmp){
        var selectedProducts = [];
        var obj = JSON.parse(JSON.stringify(cmp.get('v.selectedProducts')));
        
        var remainingGLAProducts = [];
        remainingGLAProducts = JSON.parse(JSON.stringify(cmp.get('v.remainingGLAProducts')));
        
        var intTotalProposedGLA = 0;
        var intTotalGLA = 0;
        var intTotalRemainingGLA = 0; 
		var popOutError = 'false';
		var negPopOutError = 'false';
		
		for(var i=0;i<obj.length;i++)
		{            
			
            console.log('++obj[i].remainingGLA++',obj[i].remainingGLA,'+++obj[i].GLA++',obj[i].GLA,'round GLA++',Math.round(obj[i].GLA));
			if(obj[i].proposedGLA == null)
			{
				obj[i].proposedGLA = 0;
            }
            
			if(obj[i].GLA ==null || obj[i].GLA == '')
            {
            	obj[i].GLA = 0;
            }

			if(obj[i].proposedGLA != null && obj[i].proposedGLA >= 0)
			{
				//GDM:8345 Changes : Added Math.Round for Caluculations
				obj[i].remainingGLA = obj[i].GLAIntegerValue - obj[i].proposedGLA; 
                intTotalProposedGLA = intTotalProposedGLA + Math.round(obj[i].proposedGLA);
                console.log('++obj[i].GLA+++ ',obj[i].GLA);
                intTotalGLA = intTotalGLA + obj[i].GLA;
            }
            else if(obj[i].proposedGLA != null && obj[i].proposedGLA < 0)
			{
				negPopOutError = 'true';
            }
            
            if(obj[i].includepopout == true)
			{
                //GDM:8345 Changes
                if(!$A.util.isUndefinedOrNull(obj[i].popoutGLA) && obj[i].popoutGLA != '')// && obj[i].popoutGLA > 0)
                {
                    intTotalGLA = intTotalGLA + obj[i].popoutGLA;
                    obj[i].remainingGLA = obj[i].remainingGLA + obj[i].popoutGLA;
                }
                else
                {
                	popOutError = 'true';
                }
            }
            if (isNaN(obj[i].remainingGLA)) {
                obj[i].remainingGLA =0;
            }
        }
        if(popOutError == 'true')
        {
        	$A.util.removeClass(cmp.find("nopopoutGLAErrorId"), 'slds-hide');
        }
        else
        {
        	$A.util.addClass(cmp.find("nopopoutGLAErrorId"), 'slds-hide');
        }
        
        if(negPopOutError == 'true')
        {
        	$A.util.removeClass(cmp.find("negativeValuesErrorId"), 'slds-hide');
        }
        else
        {
        	$A.util.addClass(cmp.find("negativeValuesErrorId"), 'slds-hide');
        }
            
        intTotalRemainingGLA = Math.round(intTotalGLA - intTotalProposedGLA);
        console.log('++intTotalRemainingGLA++++',intTotalRemainingGLA,'++++intTotalGLA++',intTotalGLA);
        intTotalGLA = Math.round(intTotalGLA);
        for(var i=0;i<remainingGLAProducts.length;i++){
            if(remainingGLAProducts[i].proposedGLA != null){
            	if(remainingGLAProducts[i].proposedGLA < 0)
            	{
            		negPopOutError = 'true';
            	}
            	else
            	{
            		//GDM:8345 Changes : Added Math.round
                    intTotalRemainingGLA = intTotalRemainingGLA - remainingGLAProducts[i].proposedGLA;
            	}
            }
        }
        
        if(negPopOutError == 'true')
        {
        	$A.util.removeClass(cmp.find("negativeValuesErrorId"), 'slds-hide');
        }
        else
        {
        	$A.util.addClass(cmp.find("negativeValuesErrorId"), 'slds-hide');
        }
        
        if(intTotalRemainingGLA < 0){
            $A.util.removeClass(cmp.find("remainingGLAError"), 'slds-hide');
        }
        else
		{
            $A.util.addClass(cmp.find("remainingGLAError"), 'slds-hide');
        }
        
        if(popOutError == 'true' || negPopOutError == 'true' || intTotalRemainingGLA < 0)
        {
        	cmp.set('v.errorsOnPage', 'true');
        }
        else
        {
        	cmp.set('v.errorsOnPage', 'false');
        }
        
        //if(hasAllRowsPopulated == true){
            cmp.set('v.intTotalGLA',intTotalGLA);
            cmp.set('v.intGLAUsed',intTotalProposedGLA);
            cmp.set('v.intTotalProposedGLA',intTotalProposedGLA);
            cmp.set('v.intTotalGLA',intTotalGLA);
            //cmp.set('v.intTotalRemainingGLA',intTotalGLA - intTotalProposedGLA);
            cmp.set('v.intTotalRemainingGLA',intTotalRemainingGLA);
        	cmp.set('v.intTotalProposedGLARecal',intTotalProposedGLA);
        	console.log('++intTotalProposedGLA++',intTotalProposedGLA);
        //}
        cmp.set('v.selectedProducts',obj);
    },
    addRemainingGLARowsHelper : function(cmp){
        var remainingGLAProducts = [];
        var remainingGLAProduct;
        var obj = JSON.parse(JSON.stringify(cmp.get('v.selectedProducts')));
       	remainingGLAProducts = JSON.parse(JSON.stringify(cmp.get('v.remainingGLAProducts')));
        remainingGLAProduct = obj[0];
        remainingGLAProduct.idProduct = "";
        remainingGLAProduct.dealUnitNumber = "";
        remainingGLAProduct.selected = false;
        remainingGLAProduct.unitNo = "";
        remainingGLAProduct.productType = "";
        remainingGLAProduct.occupied = "";
        remainingGLAProduct.expirationDate = null;
        remainingGLAProduct.GLA = null;
        remainingGLAProduct.tenantName = "";
        remainingGLAProduct.proposedGLA = null;
        remainingGLAProduct.remainingGLA = null;
        remainingGLAProduct.IsRemainingGLA = true;
        remainingGLAProduct.selectedDealUnit =false;
        
        remainingGLAProducts.push(remainingGLAProduct);
        cmp.set('v.remainingGLAProducts',remainingGLAProducts);
    },
	validateUnitNoHelper : function(cmp, obj){
		var boolUnitNoError = false;
		
		for(var i=0;i<obj.length;i++){
			if(obj[i].dealUnitNumber != null && obj[i].dealUnitNumber.match("[}=/<>,;\\\^\$\.\|\?\*\+\(\)\[\{!@#%&\_-]")){
				boolUnitNoError = true;
			}
		}
		if(boolUnitNoError==true){
			$A.util.removeClass(cmp.find("unitNoErrorId"), 'slds-hide');
		}else{
			$A.util.addClass(cmp.find("unitNoErrorId"), 'slds-hide');
		}
	}
})