({
    insertAccount: function(component, event, helper){
        this.showSpinner(component, event, helper);
        var action = component.get('c.insertAccountMethod');
        var account = component.get('v.acc1');
        account.LE_Is_Broker_Or_Agency_WF__c=component.get('v.brokerOrAgency');
        account.OperatorOrNone_WF__c = component.get('v.OperatorOrNone');
        var operator = component.get('v.operatorName');
        var contact = component.get('v.con');
        console.log('contactcontactcontact',contact);
        var address = component.get('v.add');
        action.setParams({
            "acc": account,
            "con": contact,
            "add": address,
            "addType" : component.get('v.addressType'),
            "fieldValue" : component.get('v.fieldValue'),
            "operator" : operator
        }); 
        action.setCallback(this,function(response){
            if(response.getState() == "SUCCESS"){
                var result = response.getReturnValue();
                component.set('v.acc1',result.B2BCustomer);
                component.set('v.con',result.guarantorContact); 
                component.set('v.guarantorCon', result.guarantorContact);
                component.set('v.add', result.BillingAddress);
                if(component.get('v.acc1.LE_Is_Broker_Or_Agency_WF__c')=='Broker'){
                	component.set('v.Broker',component.get('v.acc2'));
                }
                if(component.get('v.fieldValue') === 'LegalEntity'){
                    var myEvent = $A.get("e.c:AddressChange");
                    var billingAddress;
                    var noticeAddress;
                    var fireEvent = false;
                    if(component.get('v.addressType') === 'Notice'){
                        noticeAddress = component.get('v.add');
                        fireEvent = true;
                    } else if(component.get('v.addressType') === 'Billing'){
                        billingAddress = component.get('v.add');
                        fireEvent = true;
                    }
                    if(!$A.util.isUndefinedOrNull(myEvent) && fireEvent){
                        myEvent.setParams({
                            "billingAddress": billingAddress,
                            "noticeAddress": noticeAddress,
                            "fieldValue": component.get('v.fieldValue')
                        });
                        myEvent.fire();
                    }
                }
		   		component.set('v.showPopup',false);
            }else{
                alert('Please Enter Valid Data');
            }
            this.hideSpinner(component, event, helper);
        });
        $A.enqueueAction(action);
    },
    insertBrokerAccount: function(component, event, helper){
        this.showSpinner(component, event, helper); 
        var address=component.get('v.add'); 
        var action = component.get('c.newAccountNeedsType');
        action.setParams({
            "acc": component.get('v.acc2'),
            "recordType": 'Prospect',
            "con": component.get('v.brokerContact'),
            "addType" : component.get('v.addressType'),
            "inputAddr" : address
        });
        action.setCallback(this,function(response){
            if(response.getState() == "SUCCESS"){
				var result = response.getReturnValue();
                component.set('v.Broker', result);
                component.set('v.acc2',result);
                
                var acc1=component.get("v.acc1");											//obtain account 1 details to set-up hierarchy
            	acc1.ParentId = result.Id;
            	component.set('v.acc1', acc1);

                this.insertAccount(component, event, helper); 
            }else{
                alert('Broker Account insert failed');
            }
            this.hideSpinner(component, event, helper);
        });
        $A.enqueueAction(action);
	}, 
    hideSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
        $A.util.addClass(spinner, "slds-hide");
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner: function(component, event, helper) {
		var spinner = component.find('spinner');
        $A.util.removeClass(spinner, "slds-hide");
    }, 
    sendAccountToLookup: function(component, event, helper){
    	if(!$A.util.isEmpty(component.get('v.acc1.Id'))){
    		component.set('v.selectedRecord',component.get('v.acc1'));
            component.set('v.selectedRecordId', component.get('v.acc1.Id'));
        }
    }
})