({
    doInit: function(component, event, helper) {
        var dispVal= component.get("v.fieldValue");
        /*
        Known account creation types: 
        LegalEntity
        SuperParent
        DBACustomer
        Parent
        Guarantor
        Broker
        Operator
        */
        if(dispVal=='LegalEntity' || dispVal =='legalEntity' || dispVal == 'Permanent Leasing OpportunityLegalEntityFromOfferDetails' ||dispVal == 'Permanent LeasingLegalEntity' || dispVal == 'Airport LeasingLegalEntityFromOfferDetails' || dispVal =='Airport LeasingLegalEntity'){
            component.set('v.HeaderDescription','Legal Entity'); 
        }else if(dispVal=='SuperParent' || dispVal=='B2BCustomerSuperParent'){
			component.set('v.HeaderDescription','Super Parent'); 
        }else if(dispVal=='DBACustomer' || dispVal=='B2BCustomer'){
			component.set('v.HeaderDescription','DBA Customer'); 
        }else if(dispVal=='Parent' || dispVal=='B2BCustomerParent'){
			component.set('v.HeaderDescription','Parent'); 
        }else if(dispVal.includes('Guarantor')){	/*"includes" here because Guarantor_WF component adds a value to the end of the fieldValue*/
			component.set('v.HeaderDescription','Guarantor'); 
        }else if(dispVal=='Broker'){
			component.set('v.HeaderDescription','Broker'); 
        }
        else if(dispVal=='Operator'){
			component.set('v.HeaderDescription','Operator'); 
        }
        component.find('addressType').reInit();
        if(component.find('brokerOrAgency')){					
			component.find('brokerOrAgency').reInit(); 
        }
        if(component.find('operatorOrNone')){					
			component.find('operatorOrNone').reInit(); 
        }
        var dVal = component.get("v.displayValue");
        if(typeof dVal === "undefined" || dVal === null || dVal === ''){
        	component.set("v.displayValue", component.get("v.fieldValue"));
        }
        if(component.get('v.fieldValue')=='LegalEntity' ||component.get('v.fieldValue')=='Permanent LeasingLegalEntity' ||component.get('v.fieldValue')=='Airport LeasingLegalEntity' || component.get('v.displayValue')=='Guarantor' || component.get('v.fieldValue')=='Permanent LeasingLegalEntityFromOfferDetails' || component.get('v.fieldValue')=='Permanent Leasing OpportunityLegalEntityFromOfferDetails'||component.get('v.fieldValue')=='Airport LeasingLegalEntityFromOfferDetails'){
            component.find('legalEntityTypeField').reInit();
            component.find('stateOfFormation').reInit();
        }
        helper.hideSpinner(component, event, helper);
    }, 
    cancel : function(component, event, helper) {
        component.set('v.showPopup', false);
    },
    save : function(component, event, helper) {
    	var boolIsReqFieldEmpty = false;
    	var errorCmp;
        var emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        errorCmp = component.find("accNameError");
        component.set('v.showLEPhoneError',false);
        component.set('v.showBrokerPhoneError',false);
    	if($A.util.isEmpty(component.get('v.acc1.Name'))){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("legalEntityNotSelected");
    	if($A.util.isEmpty(component.get('v.acc1.CompanyLegalType_WF__c'))&&(component.get('v.fieldValue')=='LegalEntity'||component.get('v.fieldValue')=='LegalEntityFromOfferDetails')){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("sOFBlank");
        if(component.get('v.acc1.CompanyLegalType_WF__c') === 'Individual' && !$A.util.isEmpty(component.get('v.acc1.StateOfIncorporation_WF__c')) && component.get('v.acc1.StateOfIncorporation_WF__c') !== '--None--'){
            $A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
        }
        errorCmp = component.find("formationStateError");
        if(component.get('v.acc1.CompanyLegalType_WF__c') !== 'Individual'){
            if(($A.util.isEmpty(component.get('v.acc1.StateOfIncorporation_WF__c')) || component.get('v.acc1.StateOfIncorporation_WF__c') == '--None--') &&(component.get('v.fieldValue')=='LegalEntity'||component.get('v.fieldValue')=='LegalEntityFromOfferDetails')){
                $A.util.removeClass(errorCmp, 'slds-hide');
                boolIsReqFieldEmpty = true;
            } else{
                $A.util.addClass(errorCmp, 'slds-hide');
            }
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("addressError");
    	if($A.util.isEmpty(component.get('v.add.StreetLine1_WF__c'))){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("cityFieldError");
    	if($A.util.isEmpty(component.get('v.add.City_WF__c'))){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("stateFieldError");
    	if($A.util.isEmpty(component.get('v.add.State_WF__c'))&&!component.get('v.noState')){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("zipCodeFieldError");
    	if($A.util.isEmpty(component.get('v.add.PostalCode_WF__c'))){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        //check for country/state errors
        console.log("country is empty: "+$A.util.isEmpty(component.get('v.add.Country_WF__c')));
    	if($A.util.isEmpty(component.get('v.add.Country_WF__c'))){
    		component.set('v.checkCountryStateError', true); 
            boolIsReqFieldEmpty = true;
        } else{
            component.set('v.checkCountryStateError', false);
    	}
        if(!component.get('v.noState')&&$A.util.isEmpty(component.get('v.add.State_WF__c'))){
    		component.set('v.checkCountryStateError', true); 
            boolIsReqFieldEmpty = true;
        }
    	errorCmp = component.find("addTypeError");
    	if($A.util.isEmpty(component.get('v.addressType'))||component.get('v.addressType')=='Select an option...'){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
    	errorCmp = component.find("firstNameError");
        if($A.util.isEmpty(component.get('v.con.FirstName'))&&component.get('v.fieldValue')!=='DBACustomer' && component.get('v.fieldValue')!=='Airport LeasingLegalEntityFromOfferDetails' && component.get('v.fieldValue')!=='Airport LeasingLegalEntity'){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("lastNameError");
    	if($A.util.isEmpty(component.get('v.con.LastName'))&&component.get('v.fieldValue')!=='DBACustomer'&& component.get('v.fieldValue')!=='Airport LeasingLegalEntityFromOfferDetails' && component.get('v.fieldValue')!=='Airport LeasingLegalEntity'){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("emptyPhoneNumber");
    	if($A.util.isEmpty(component.get('v.con.Phone'))
           &&component.get('v.fieldValue')!=='DBACustomer' && component.get('v.fieldValue')!=='Airport LeasingLegalEntityFromOfferDetails'
           && component.get('v.fieldValue')!=='Airport LeasingLegalEntity' 
           &&!component.get('v.LEContactPhoneError')){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("emptyEmail");
        var emptyEmail=$A.util.isEmpty(component.get('v.con.Email'))&&component.get('v.fieldValue')!=='DBACustomer'&&component.get('v.fieldValue')!=='Airport LeasingLegalEntityFromOfferDetails' && component.get('v.fieldValue')!=='Airport LeasingLegalEntity'; 
        if(emptyEmail){
    		$A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        } else{
            $A.util.addClass(errorCmp, 'slds-hide');
    	}
        errorCmp = component.find("badEmail");
        if(!emptyEmail&&!component.get('v.con.Email').match(emailFormat)&&component.get('v.fieldValue')!=='DBACustomer'&&component.get('v.fieldValue')!=='Airport LeasingLegalEntityFromOfferDetails' && component.get('v.fieldValue')!=='Airport LeasingLegalEntity'){
    		$A.util.removeClass(errorCmp, 'slds-hide');
        	boolIsReqFieldEmpty = true;
        } else{
        	$A.util.addClass(errorCmp, 'slds-hide');
    	}
        var brokerField = component.find("brokerNameField");
        var brokerOrAgency=component.get('v.brokerOrAgency');
        var BrokerAccountAlreadyExists=false; 

        if(brokerOrAgency==='Broker'){																			/*if "Broker," then validate Broker fields*/
            errorCmp = component.find("acc2NameError");
            for(var i=0;i<brokerField.length; i++){
                if(brokerField[i].get("v.fieldValue")==='LegalEntityFromPopup'){
                    if(!$A.util.isEmpty(brokerField[i].get("v.selectedRecord"))
                       &&brokerField[i].get("v.selectedRecord")!='{}'){
                        $A.util.addClass(errorCmp, 'slds-hide');
                        component.set('v.acc2',brokerField[i].get("v.selectedRecord"));							/*setting acc2 account by account*/
                        BrokerAccountAlreadyExists=true; 
                    }else if(!$A.util.isEmpty(brokerField[i].get("v.SearchKeyWord"))
                             &&($A.util.isEmpty(brokerField[i].get("v.selectedRecord"))||brokerField[i].get("v.selectedRecord")=='{}')){
                        $A.util.addClass(errorCmp, 'slds-hide');
                        var acc2=component.get('v.acc2');                                                       /*setting acc2 account by text*/
						acc2.Name=brokerField[i].get("v.SearchKeyWord"); 
                        component.set('v.acc2',acc2);
                    }else{
                        boolIsReqFieldEmpty = true;
                        $A.util.removeClass(errorCmp, 'slds-hide');
                    }
                }
            }
        }else if((brokerOrAgency!=='Broker'&&brokerOrAgency!=="Agency"&&brokerOrAgency!=="None")&&component.get('v.fieldValue')==='LegalEntity'){
            errorCmp = component.find("AgencyOrBrokerError");													/*if "type" picklist has not been selected*/
            $A.util.removeClass(errorCmp, 'slds-hide');
            boolIsReqFieldEmpty = true;
        }else{
            errorCmp = component.find("AgencyOrBrokerError");													/*Broker not selected, but option chosen*/
			$A.util.addClass(errorCmp, 'slds-hide');
        }
        if(brokerOrAgency==='Broker'){
			errorCmp = component.find("brokerFirstNameError");
        	if($A.util.isEmpty(component.get('v.brokerContact.FirstName'))){
    			$A.util.removeClass(errorCmp, 'slds-hide');
            	boolIsReqFieldEmpty = true;
        	} else{
            	$A.util.addClass(errorCmp, 'slds-hide');
    		}
        	errorCmp = component.find("brokerLastNameError");
        	if($A.util.isEmpty(component.get('v.brokerContact.LastName'))){
    			$A.util.removeClass(errorCmp, 'slds-hide');
            	boolIsReqFieldEmpty = true;
        	} else{
            	$A.util.addClass(errorCmp, 'slds-hide');
    		}
            errorCmp = component.find("brokerPhoneError");
        	if($A.util.isEmpty(component.get('v.brokerContact.Phone'))&&!component.get('v.BrokerContactPhoneError')){
    			$A.util.removeClass(errorCmp, 'slds-hide');
            	boolIsReqFieldEmpty = true;
        	} else{
            	$A.util.addClass(errorCmp, 'slds-hide');
    		}
            errorCmp = component.find("brokerEmailError");
        	if($A.util.isEmpty(component.get('v.brokerContact.Email'))){
    			$A.util.removeClass(errorCmp, 'slds-hide');
            	boolIsReqFieldEmpty = true;
        	} else{
            	$A.util.addClass(errorCmp, 'slds-hide');
    		}
            errorCmp = component.find("badBrokerEmail");
        	if(!component.get('v.brokerContact.Email').match(emailFormat)){
    			$A.util.removeClass(errorCmp, 'slds-hide');
            	boolIsReqFieldEmpty = true;
        	} else{
            	$A.util.addClass(errorCmp, 'slds-hide');
    		}
        }
        var LEPhoneError = component.get('v.LEContactPhoneError');
        var showPhoneError=component.get('v.showLEPhoneError');
        LEPhoneError ? component.set('v.showLEPhoneError', true) : component.set('v.showLEPhoneError', false);

        var BrokerPhoneError = component.get('v.BrokerContactPhoneError'); 
        BrokerPhoneError ? component.set('v.showBrokerPhoneError', true) : component.set('v.showBrokerPhoneError', false);
        
        if(LEPhoneError||BrokerPhoneError){
			boolIsReqFieldEmpty=true;
        }
        		/*broker account must be created first to associate account hierarchy correctly*/
    	if(boolIsReqFieldEmpty)	return;
        
        if(BrokerAccountAlreadyExists&&brokerOrAgency=='Broker'){												/*if the broker account was entered previously*/
			var acc1=component.get("v.acc1");
            acc1.ParentId = component.get('v.acc2').Id;
            component.set('v.acc1', acc1);
            helper.insertAccount(component, event, helper); 
        }else if(BrokerAccountAlreadyExists&&brokerOrAgency!='Broker'){											/*if LE needs to be created, but not broker account*/
			helper.insertAccount(component, event, helper); 
        } else if(component.get('v.fieldValue')==='LegalEntityFromOfferDetails'&&brokerOrAgency!="Broker"){
        	var acc1=component.get("v.acc1");
            component.set('v.acc1', acc1);
            helper.insertAccount(component, event, helper);
        } else if(component.get('v.fieldValue')!=='LegalEntity'){												/*if broker is irrelevant*/
            var acc1=component.get("v.acc1");
            acc1.LE_Is_Broker_Or_Agency_WF__c='None'; 
            component.set('v.acc1', acc1);
            helper.insertAccount(component, event, helper);
        }else if(component.get('v.fieldValue')==='LegalEntity'&&brokerOrAgency!="Broker"){	
			var acc1=component.get("v.acc1");
            acc1.LE_Is_Broker_Or_Agency_WF__c=brokerOrAgency;
            acc1.ParentId = component.get('v.acc2').Id;
            component.set('v.acc1', acc1);
            helper.insertAccount(component, event, helper);
        }else{																									/*if only the broker account needs to be created*/
			helper.insertBrokerAccount(component, event, helper);
        }
    },
    brokerOrAgencyCondition: function(component, event, helper){
		var condition = component.get("v.brokerOrAgency");
        if(condition==='Broker'){
            var acc2=component.get("v.acc2");							/*get the blank broker account*/
            var brokerAccountName = component.find("brokerNameBox");	/*get the name that's supposed to be on the broker account*/
            $A.util.removeClass(brokerAccountName, 'slds-hide');		/*show the name field for the broker account*/
            acc2.LE_Is_Broker_Or_Agency_WF__c='Broker'; 				/*set account to be of "broker" type*/
            acc2.Name=brokerAccountName; 								/*set account name*/
            component.set('v.acc2', acc2); 								/*set the account variable*/
        }else{															/*if it's not a broker, there is no need to access acc2*/
			var brokerAccount = component.find("brokerNameBox");	
            $A.util.addClass(brokerAccount, 'slds-hide');		
        }
    }, 
    showacc1: function(component, event, helper){
    	helper.sendAccountToLookup(component,event,helper); 
        component.set('v.LegalEntityType', component.get('v.acc1.CompanyLegalType_WF__c'));
        component.set('v.StateOfIncorporation', component.get('v.acc1.StateOfIncorporation_WF__c'));
    }
})