/*quickAddController.js*/
({
    clickSubmit: function(component, event, helper) {
        // Get the values from the form
        var recordId=component.get('v.recordId');
        
        var action=component.get("c.submitApproval");
        // Display the total in a "toast" status message
        action.setParams({
            "opportunityId":recordId 
        });
        console.log(recordId);
        action.setCallback(this,function(response){
            var responsestring=response.getReturnValue();
            console.log(responsestring);
            component.set('v.alertmesage',responsestring);
            console.log(responsestring != $A.get("$Label.c.ApprovalSuccess"));
            console.log($A.get("$Label.c.ApprovalSuccess"));
            if(responsestring != $A.get("$Label.c.ApprovalSuccess"))
            {   
            var errorDiv = component.find('alertDiv');
            $A.util.removeClass(errorDiv, 'slds-hide');
            }
            else
            {
            if(typeof sforce !== "undefined" && sforce !== null) {
                sforce.one.navigateToURL('/' + recordId);
            }else{
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": recordId,
                    "slideDevName": "related"
                });
                navEvt.fire();
            }
            }
        });
        console.log(action);
        $A.enqueueAction(action);  
       /* window.setTimeout(function() {  
            $A.get('e.force:refreshView').fire();}, 1000    );*/
        /* window.setTimeout(function() {  
            $A.get('e.force:refreshView').fire();}, 3000    ); */
         window.setTimeout(function() {  
            $A.get('e.force:refreshView').fire();}, 5000    ); 
    }
})