({
	toRight : function(component, event, helper) {
        helper.toRight(component);
	},
    toLeft : function(component, event, helper) {
        helper.toLeft(component);
	}
})