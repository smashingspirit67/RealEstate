({
	toRight : function(component) {
		var optionsLeft = [];
        var optionsRight = component.get("v.selectedOptions");
        var uniqueID = component.get("v.uniqueID");
        var listFrom = document.getElementById('leftOptions' + uniqueID);
        var listTo = document.getElementById('rightOptions' + uniqueID);
        for ( var x = 0; x < listTo.options.length; x++) {
        	listTo.options[x].selected = false;
        }
        for ( var x = 0; x < listFrom.options.length; x++) {
        	if (listFrom.options[x].selected == true) {
            	optionsRight.push(listFrom.options[x].value);
            } else{
                optionsLeft.push(listFrom.options[x].value);
            }
        }
        component.set("v.options", optionsLeft);
        component.set("v.selectedOptions", optionsRight);
	},
    toLeft : function(component){
        var optionsLeft = component.get("v.options");
        var optionsRight = [];
        var uniqueID = component.get("v.uniqueID");
		var listFrom = document.getElementById('leftOptions' + uniqueID);
        var listTo = document.getElementById('rightOptions' + uniqueID);
        for ( var x = 0; x < listFrom.options.length; x++) {
            listFrom.options[x].selected = false;
        }
        for ( var x = 0; x < listTo.options.length; x++) {
        	if (listTo.options[x].selected == true) {
            	optionsLeft.push(listTo.options[x].value);
            } else{
                optionsRight.push(listTo.options[x].value);
            }
        }
        component.set("v.options", optionsLeft);
        component.set("v.selectedOptions", optionsRight);
    }
})