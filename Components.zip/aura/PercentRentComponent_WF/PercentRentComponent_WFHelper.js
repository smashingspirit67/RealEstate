({
    defaultsHelper : function(component, event, helper) {
        if(!component.get('v.opportunity.PercentRent_WF__c')){
            component.set('v.opportunity.RentCommentsPercent_WF__c','');
        }
        if(!component.get('v.opportunity.OptionsToPercentRent_WF__c')){
            component.set('v.opportunity.OptionRentCommentsPercent_WF__c','');
        }
        var newValue = event.getParam('value');        
        if(typeof newValue == 'boolean'){
        if(!component.get('v.IsOptions') && component.get('v.opportunity.PercentRent_WF__c')){
            //Joshna, 30 Jun, updated based on WLMS.. When there's no min rent default to below values and disable picklists
            if(!component.get('v.IsMinimumRent')){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointType_WF__c')) || component.get('v.opportunity.BreakpointType_WF__c') === '--None--' || component.get('v.opportunity.BreakpointType_WF__c') === 'Natural'){
                    component.set('v.opportunity.BreakpointType_WF__c', 'Unnatural');
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.RentTypeBasis_WF__c')) || component.get('v.opportunity.RentTypeBasis_WF__c') === '--None--' || component.get('v.opportunity.RentTypeBasis_WF__c') === 'Minimum Rent'){
                    component.set('v.opportunity.RentTypeBasis_WF__c', 'Other');
                }
                helper.breakPointChHelper(component);
                helper.clearColHelper(component);
                if(!$A.util.isUndefinedOrNull(component.find('idBreakPointType')) || !$A.util.isUndefinedOrNull(component.find('idRentTypeBasis'))){
                    component.set('v.readOnly', true);
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointStepType_WF__c')) || component.get('v.opportunity.BreakpointStepType_WF__c') === ''){
                    component.set('v.opportunity.BreakpointStepType_WF__c', '--None--');
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.PercentRentRate_WF__c')) || component.get('v.opportunity.PercentRentRate_WF__c') === ''){
                    component.set('v.opportunity.PercentRentRate_WF__c', '--None--');
                }
            } else if(component.get('v.IsMinimumRent')){
                /*if non null, we know that the scenario is edit, so don't override.. only if it's null or none, which is its being
                  used for the first time or unchecked and checked, set to default values
                */
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.BreakpointType_WF__c')) || component.get('v.opportunity.BreakpointType_WF__c') === '--None--'){
                    component.set('v.opportunity.BreakpointType_WF__c', 'Natural');
                    helper.breakPointChHelper(component);
                }
                if(!$A.util.isUndefinedOrNull(component.find('idBreakPointType')) || !$A.util.isUndefinedOrNull(component.find('idRentTypeBasis'))){
                    component.set('v.readOnly', false);
                }
            }
        } else if(!component.get('v.IsOptions') && !component.get('v.opportunity.PercentRent_WF__c')){
            //set to these values when % rent is unchecked
            component.set('v.opportunity.BreakpointType_WF__c', '--None--');
            helper.breakPointChHelper(component);
            component.set('v.opportunity.RentTypeBasis_WF__c', '--None--');
            component.set('v.opportunity.BreakpointStepType_WF__c', '--None--');
            component.set('v.opportunity.PercentRentRate_WF__c', '--None--');            
            helper.clearColHelper(component);
        }
        //Code for options
        if(component.get('v.IsOptions') && component.get('v.opportunity.OptionsToPercentRent_WF__c')){
            //Joshna, 30 Jun, updated based on WLMS.. When there's no min rent default to below values and disable picklists
            if(!component.get('v.IsMinimumRent')){
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsBreakpointType_WF__c')) || component.get('v.opportunity.OptionsBreakpointType_WF__c') === '--None--' || component.get('v.opportunity.OptionsBreakpointType_WF__c') === 'Natural'){
                    component.set('v.opportunity.OptionsBreakpointType_WF__c', 'Unnatural');
                }
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsRentTypeBasis_WF__c'))  || component.get('v.opportunity.OptionsRentTypeBasis_WF__c') === '--None--' || component.get('v.opportunity.OptionsRentTypeBasis_WF__c') === 'Minimum Rent'){
                    component.set('v.opportunity.OptionsRentTypeBasis_WF__c', 'Other');
                }
                helper.breakPointChHelper(component);
                helper.clearColHelper(component);
              
                component.set('v.optionsReadOnly', true);
            } else if(component.get('v.IsMinimumRent')){
                /*if non null, we know that the scenario is edit, so don't override.. only if it's null or none, which is its being
                  used for the first time or unchecked and checked, set to default values
                */
                if($A.util.isUndefinedOrNull(component.get('v.opportunity.OptionsBreakpointType_WF__c')) || component.get('v.opportunity.OptionsBreakpointType_WF__c') === '--None--'){
                    component.set('v.opportunity.OptionsBreakpointType_WF__c', 'Natural');
                    helper.breakPointChHelper(component);
                }
               
                component.set('v.optionsReadOnly', false);
            }
        } else if(component.get('v.IsOptions') && !component.get('v.opportunity.OptionsToPercentRent_WF__c')){
            //set to these values when % rent is unchecked
            component.set('v.opportunity.OptionsBreakpointType_WF__c', '--None--');
            helper.breakPointChHelper(component);
            component.set('v.opportunity.OptionsRentTypeBasis_WF__c', '--None--');
            component.set('v.opportunity.OptionsBreakpointStepType_WF__c', '--None--');
            component.set('v.opportunity.OptionsPercentRentRate_WF__c', '--None--');
            
            
            helper.clearColHelper(component);
        }
        }
    },
    
    breakPointChHelper : function(cmp,eve){
        var breakpointType = cmp.get('v.opportunity.BreakpointType_WF__c');
        var optionsBreakpointType = cmp.get('v.opportunity.OptionsBreakpointType_WF__c');
        var isOptions = cmp.get('v.IsOptions');
        var lstGrowthRates = cmp.get('v.lstGrowthRateTable');   
        console.log('Inside breakpoint method');
        if(isOptions !== true){
        if(breakpointType === 'Natural' || (breakpointType =='Unnatural' && cmp.get('v.opportunity.RentTypeBasis_WF__c') !== '--None--' )){
            cmp.set('v.unitOfMeasure', '%');
            cmp.set("v.showTable", true);
                    if(!$A.util.isUndefinedOrNull(cmp.find('percentTable')))
                    cmp.find('percentTable').resetErrorBanner();                    
            }else{
            cmp.set("v.showTable", false);
                    var lstGrowthRates = cmp.get('v.lstGrowthRateTable');        
                    if( !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.RentTypeBasis_WF__c') == 'Other'){
                        if(!$A.util.isUndefinedOrNull(lstGrowthRates) && lstGrowthRates.length > 0 ){
                            for(var i = lstGrowthRates.length - 1; i >= 0 ; i--){
                                if(i == 0 ){
                                    lstGrowthRates[i].datEndDate = lstGrowthRates[i].datStartDate;
                                    lstGrowthRates[i].decBrkptCalcpercent = null;
                                    lstGrowthRates[i].decBreakpointAmount = null;
                                    lstGrowthRates[i].boolEstimatedPercent = false;
                                    lstGrowthRates[i].percentComments = '';
                                    lstGrowthRates[i].decRentRate = null;
                                }else{
                                    lstGrowthRates.pop();
                                }
                            }
                        }
                    }else{
                    if( lstGrowthRates != undefined && lstGrowthRates != [] ){            
                        for ( var i = 0 ; i < lstGrowthRates.length; i++ ){
                            lstGrowthRates[i].decBrkptCalcpercent = null;
                            lstGrowthRates[i].decBreakpointAmount = null;
                            lstGrowthRates[i].boolEstimatedPercent = false;
                            lstGrowthRates[i].percentComments = '';
                            lstGrowthRates[i].decRentRate = null;
            }
                        }   
                    }
                    if(!$A.util.isUndefinedOrNull(lstGrowthRates)){
                        if(lstGrowthRates.length > 0){
                        cmp.set('v.lstGrowthRateTable', lstGrowthRates);                 
                        }
                    }  
            }
        }else{
            if(optionsBreakpointType === 'Natural' || (optionsBreakpointType =='Unnatural' && cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') !== '--None--' )){
                cmp.set('v.unitOfMeasure', '%');             
                cmp.set("v.showOptionsTable", true);
                if(!$A.util.isUndefinedOrNull(cmp.find('optionsPercentTable')))
                cmp.find('optionsPercentTable').resetErrorBanner();                
            }else{
                cmp.set("v.showOptionsTable", false);
                var lstGrowthRates = cmp.get('v.lstGrowthRateTable');    
                if( !cmp.get('v.IsMinimumRent') && cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c') == 'Other'){
                    if(!$A.util.isUndefinedOrNull(lstGrowthRates) && lstGrowthRates.length > 0 ){
                        for(var i = lstGrowthRates.length - 1; i >= 0 ; i--){
                            if(i == 0 ){
                                lstGrowthRates[i].datEndDate = lstGrowthRates[i].datStartDate;
                                lstGrowthRates[i].decBrkptCalcpercent = null;
                                lstGrowthRates[i].decBreakpointAmount = null;
                                lstGrowthRates[i].boolEstimatedPercent = false;
                                lstGrowthRates[i].percentComments = '';
                                lstGrowthRates[i].decRentRate = null;
                            }else{
                                lstGrowthRates.pop();
                            }
                        }
                    }
                }else{
                    if( lstGrowthRates != undefined && lstGrowthRates != [] ){            
                        for ( var i = 0 ; i < lstGrowthRates.length; i++ ){
                            lstGrowthRates[i].decBrkptCalcpercent = null;
                            lstGrowthRates[i].decBreakpointAmount = null;
                            lstGrowthRates[i].boolEstimatedPercent = false;
                            lstGrowthRates[i].percentComments = '';
                            lstGrowthRates[i].decRentRate = null;
                        }            
                        cmp.set('v.lstGrowthRateTable', lstGrowthRates);                 
                    } 
                }
            }
        }
        var lstGrowthRates = cmp.get('v.lstGrowthRateTable');        
        if( lstGrowthRates != undefined && lstGrowthRates != [] && eve !== undefined){            
            for ( var i = 0 ; i < lstGrowthRates.length; i++ ){
                lstGrowthRates[i].decBrkptCalcpercent = null;
                lstGrowthRates[i].decBreakpointAmount = null;
                lstGrowthRates[i].boolEstimatedPercent = false;
                lstGrowthRates[i].percentComments = '';
                lstGrowthRates[i].decRentRate = null;
            }            
            cmp.set('v.lstGrowthRateTable', lstGrowthRates);                 
        }  
            if(cmp.get('v.IsOptions') !== true){
            if(!cmp.get('v.IsMinimumRent')){
                if(cmp.get('v.opportunity.BreakpointType_WF__c') ==='Unnatural' && $A.util.isUndefinedOrNull(cmp.get('v.lstGrowthRateTable'))){                
                    cmp.set('v.lstGrowthRateTable', []);                
                }
            }
            }else{
            if(!cmp.get('v.IsMinimumRent')){
                if(cmp.get('v.opportunity.OptionsBreakpointType_WF__c') ==='Unnatural'  && $A.util.isUndefinedOrNull(cmp.get('v.lstGrowthRateTable'))){                
                    cmp.set('v.lstGrowthRateTable', []);                
                }
            }
        }
    },
    
    clearColHelper : function(cmp, eve){
        var breakpointType = cmp.get('v.opportunity.BreakpointType_WF__c');
        var optionsBreakpointType = cmp.get('v.opportunity.OptionsBreakpointType_WF__c');
        var rentTypeBasis = cmp.get('v.opportunity.RentTypeBasis_WF__c');
        var optionsRentTypeBasis = cmp.get('v.opportunity.OptionsRentTypeBasis_WF__c');
         var isOptions = cmp.get('v.IsOptions');
        console.log('Inside breakpoint 2 method');        
        if(rentTypeBasis !== '--None--'){
            if($A.util.isUndefinedOrNull(cmp.get('v.opportunity.BreakpointStepType_WF__c')) || cmp.get('v.opportunity.BreakpointStepType_WF__c') === ''){
                cmp.set('v.opportunity.BreakpointStepType_WF__c', '--None--');
            }
            if($A.util.isUndefinedOrNull(cmp.get('v.opportunity.PercentRentRate_WF__c')) || cmp.get('v.opportunity.PercentRentRate_WF__c') === ''){
                cmp.set('v.opportunity.PercentRentRate_WF__c', '--None--');
            }
        }
        //Code for options..
        if(optionsRentTypeBasis !== '--None--'){
            if($A.util.isUndefinedOrNull(cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c')) || cmp.get('v.opportunity.OptionsBreakpointStepType_WF__c') === ''){
                cmp.set('v.opportunity.OptionsBreakpointStepType_WF__c', '--None--');
            }
            if($A.util.isUndefinedOrNull(cmp.get('v.opportunity.OptionsPercentRentRate_WF__c')) || cmp.get('v.opportunity.OptionsPercentRentRate_WF__c') === ''){
                cmp.set('v.opportunity.OptionsPercentRentRate_WF__c', '--None--');
            }
        }
        if(isOptions !== true){
        if(breakpointType == 'Unnatural' && rentTypeBasis != '--None--'){
                cmp.set('v.showTable', true);     
                if(!$A.util.isUndefinedOrNull(cmp.find('percentTable')))
                cmp.find('percentTable').resetErrorBanner();
            }else{
            cmp.set('v.showTable', false);
            }
        }else{
            if(optionsBreakpointType == 'Unnatural' && optionsRentTypeBasis != '--None--'){   
                cmp.set('v.showOptionsTable', true);
                if(!$A.util.isUndefinedOrNull(cmp.find('optionsPercentTable')))
                cmp.find('optionsPercentTable').resetErrorBanner();
            }else{
                cmp.set('v.showOptionsTable', false);
            }
        }
        var lstGrowthRates = cmp.get('v.lstGrowthRateTable');        
        if( lstGrowthRates != undefined && lstGrowthRates != [] && eve !== undefined){            
            for ( var i = 0 ; i < lstGrowthRates.length; i++ ){
                lstGrowthRates[i].decBrkptCalcpercent = null;
                lstGrowthRates[i].decBreakpointAmount = null;
                lstGrowthRates[i].boolEstimatedPercent = false;
                lstGrowthRates[i].percentComments = '';
                lstGrowthRates[i].decRentRate = null;
            }            
            cmp.set('v.lstGrowthRateTable', lstGrowthRates);                 
        }
    }
})