({               
    handleDefaults : function(component, event, helper) {
        helper.defaultsHelper(component, event, helper);
    }, 
    getBreakPointType : function(cmp, eve, helper){    
        helper.breakPointChHelper(cmp,eve);
    },	    
    clearColumnsInTheList : function(cmp, eve, helper){
        helper.clearColHelper(cmp, eve);       
    }
})