({
	doInit : function(component, event, helper) {
		var covenant = component.get('v.Covenant');
        var isPresent = false;
        for(var item in covenant){
            if(covenant[item].RecordTypeId==component.get('v.CovenantRecordType')['Landlord Termination Rights']){
                component.set('v.landlordTerminationtionRight',covenant[item]);
                isPresent = true;
            }
        }
        
        if(!isPresent){
            var landlordTerminationtionRight = {};
            landlordTerminationtionRight.RecordTypeId =component.get('v.CovenantRecordType')['Landlord Termination Rights'];
            landlordTerminationtionRight.StandardTerminationRights_WF__c = true;
            component.set('v.landlordTerminationtionRight',landlordTerminationtionRight);
            covenant.push(component.get('v.landlordTerminationtionRight'));
            component.set('v.Covenant',covenant);
        }
	},
    enableHelpTextdesSTR : function(component, event, helper){
        component.set('v.showHelpTextDesSTR',true);
    },
    disableHelpText : function(component, event, helper){
        component.set('v.showHelpTextDesSTR',false);
    },
    changeLLTermination : function(component, event, helper){
        component.set('v.landlordTerminationtionRight.TerminationRightsDescription_WF__c','');
    }
})