({
	holdReasonChange : function(component,event){
        var strDesc = '';
        var strReason = component.get('v.sObj.HoldReason_WF__c');
        // handle value change
        // strDesc = (strReason=='H1')? "Deal not approved by Tenant's REC.": (strReason=='H2')? "Leasing/Development Hold.": (strReason=='H3')? "Tenant Unresponsive.": (strReason=='H4')? "Tenant's atty/rep not authorized to work on deal or will not work on deal due to prioritizing other deals first.": (strReason=='H5')?"Tenant states deal is dead." : (strReason=='H6')?,"Tenant executed deal stalled due to issue with Tenant Entity." : (strReason=='H7')?,"Tenant executed deal stalled out due to Tenant's failure to provide Security Deposit, LOC, other money due, etc." : (strReason=='H8')?"Other." : (strReason=='H9')?"JV/Lender approval pending." : (strReason=='H10')? "Waiting more than 5 business days for a Deal Modification on a Tenant executed document.":"" ;
        switch(strReason){
            case 'H1':
                strDesc = "Deal not approved by Tenant's REC.";
                break;
            case 'H2':
                strDesc = "Leasing/Development Hold.";
                break;
            case 'H3':
                strDesc = "Tenant Unresponsive.";
                break;
            case 'H4':
                strDesc = "Tenant's atty/rep not authorized to work on deal or will not work on deal due to prioritizing other deals first.";
                break;
            case 'H5':
                strDesc = "Tenant states deal is dead.";
                break;
            case 'H6':
                strDesc = "Tenant executed deal stalled due to issue with Tenant Entity.";
                break;
            case 'H7':
                strDesc = "Tenant executed deal stalled out due to Tenant's failure to provide Security Deposit, LOC, other money due, etc.";
                break;
            case 'H8':
                strDesc = "Other.";
                break;
            case 'H9':
                strDesc = "JV/Lender approval pending.";
                break;
            case 'H10':
                strDesc = "Waiting more than 5 business days for a Deal Modification on a Tenant executed document.";
        }
        component.set('v.HoldDescription',strDesc);
        if(strReason != 'H8')
        component.set('v.sObj.HoldOtherReasonComment_WF__c','');
        if(component.get('v.sObj.HoldReason_WF__c') != null && component.get('v.sObj.HoldReason_WF__c') != ''){
            component.set('v.sObj.On_Hold_WF__c',true);
            console.log('++++Check if True');
        }    
        else if(component.get('v.sObj.HoldReason_WF__c') == null || component.get('v.sObj.HoldReason_WF__c') == ''){
            component.set('v.sObj.On_Hold_WF__c',false);
            console.log('++++Check if False');
        }
        if(component.get('v.sObj.On_Hold_WF__c') && !$A.util.isEmpty(component.get('v.sObj.HoldReason_WF__c'))){
            component.set('v.oppOnHoldValidation',false); 
        }
        console.log('++ON Hold Status++holdReasonChange',component.get('v.sObj.On_Hold_WF__c'),'++Hold Reason++',component.get('v.sObj.HoldReason_WF__c'),'++Description++',component.get('v.sObj.HoldDescription_WF__c'));
    }, 
    /*** Start Clearing logic for Data ***/
    changeOpportunityDeadOtherReason : function(component,event, helper){
            component.set('v.sObj.OtherReasonOpportunityDead_WF__c','');            
    },
    updateHoldReasonDescription : function(component,event, helper){
        if(component.get('v.sObj.On_Hold_WF__c')){
            component.set('v.sObj.On_Hold_WF__c',true);      
            //component.set('v.HoldDescription','Deal not approved by Tenant\'s REC.');   
        }else{
            component.set('v.sObj.On_Hold_WF__c',false);      
            component.set('v.sObj.HoldReason_WF__c','');      
            component.set('v.HoldDescription','');   
        }
        if(component.get('v.sObj.On_Hold_WF__c') && !($A.util.isEmpty(component.get('v.sObj.HoldReason_WF__c')))){
            component.set('v.oppOnHoldValidation',false); 
        }
        console.log('++ON Hold Status++updateHoldReasonDescription',component.get('v.sObj.On_Hold_WF__c'),'++Hold Reason++',component.get('v.sObj.HoldReason_WF__c',''));
    },
    changeOpportunityDeadOtherReason : function(component,event, helper){
            component.set('v.sObj.OtherReasonOpportunityDead_WF__c','');            
    }
    
})