({
	doNext : function(component, event, helper) {
		component.set("v.intStepNum", component.get("v.intStepNum")+1);        
	}
})